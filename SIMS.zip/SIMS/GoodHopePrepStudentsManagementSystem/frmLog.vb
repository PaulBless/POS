﻿Imports System.Data.Sql
Imports System.Data.SqlClient
Imports System.Text

Public Class frmLog

    Dim epassword As String
    Dim frm As New AdminSection

    Private Sub login_Click(sender As Object, e As EventArgs) Handles login.Click
        If username.Text = "" Then
            MessageBox.Show("Username is required.", "Login Error", MessageBoxButtons.OK, MessageBoxIcon.Information)
            username.Focus()
            Exit Sub
        End If
        If password.Text = "" Then
            MessageBox.Show("Password is required.", "Login Error", MessageBoxButtons.OK, MessageBoxIcon.Information)
            password.Focus()
            Exit Sub
        End If

        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            query = "SELECT Staff.StaffID, RTRIM(Staff.FirstName + ' '+ Staff.MiddleName + ' ' + Staff.LastName) as Name, Users.Username, Users.Password, Users.Role, Users.Status FROM Staff INNER JOIN Users ON Staff.StaffID = Users.staffID  where Users.Username=@d1"
            com = New SqlCommand(query, con)
            com.Parameters.AddWithValue("@d1", username.Text)
            dr = com.ExecuteReader(CommandBehavior.CloseConnection)
            If dr.Read() Then
                LogUid = dr(0)  'read the userid
                LogName = dr(1).ToString()  'read the fullname
                LogUName = dr(2).ToString() 'read the username
                LogUPass = dr(3).ToString() 'read the user password
                LogURole = dr(4).ToString() 'read the role of user
                UserStatus = dr(5).ToString() 'read the current status of user
                dr.Close()


                If con.State = ConnectionState.Open Then con.Close() 'close db connection if opend
                con.Open()  'open db connection
                'variables for encrypt
                Dim epwd As String 'variable for entered password
                epwd = EncryptNew(password.Text)    'encrypt entered password
                Dim enteredpwd As String = password.Text    'read raw entered password value
                Dim entereduname As String = username.Text 'read entered username
                Dim cs As String = "select password from vwLogin where Username='" & entereduname & "'"
                com = New SqlCommand(cs, con)
                dr = com.ExecuteReader(CommandBehavior.CloseConnection)
                If dr.Read() = True Then
                    Dim mypwd As String = dr(0).ToString()  'read raw stored password
                    LogUPass = dr(0).ToString() 'read stored encrypted password
                    'If (epwd <> LogUPass) Then MsgBox("The password is incorrect. Try Again", MsgBoxStyle.OkOnly + MsgBoxStyle.Exclamation, "Login Failed") : password.Focus() : password.SelectAll() : Exit Sub
                    If (mypwd <> enteredpwd) Then MsgBox("The password is incorrect. Try Again", MsgBoxStyle.OkOnly + MsgBoxStyle.Exclamation, "Login Failed") : password.Focus() : password.SelectAll() : Exit Sub
                    If Not dr.Read() Then
                        dr.Close()
                    End If
                End If

                'display error message for deactivated user account
                If UserStatus = "INACTIVE" Then
                    MsgBox("Login Denied!" + vbCrLf + "Your account is currently de-activated... See your System Administrator", MsgBoxStyle.OkOnly + MsgBoxStyle.Critical, "Account Locked") : username.Clear() : password.Clear() : Exit Sub
                End If

                'access control method
                'system administrator section
                If (LogURole = "ADMINISTRATOR") Then
                    username.Text = ""
                    password.Text = ""
                    Me.Hide()
                    frm.Show()
                    frm.lblUser.Text = LogName
                    frm.lblUserType.Text = LogURole
                End If
                'bursar section
                If (LogURole = "ACCOUNTANT") Then
                    username.Text = ""
                    password.Text = ""
                    Me.Hide()
                    frm.FinanceToolStrip.Enabled = True
                    frm.UtilitiesToolStrip.Enabled = True
                    frm.CreateNewUserToolStrip.Enabled = False
                    frm.ChangePasswordToolStrip.Enabled = True
                    frm.AccountSettingsToolStripMenuItem.Enabled = False
                    frm.PasswordRecoveryToolStripMenuItem.Enabled = False
                    frm.PasswordRecoveryToolStripMenuItem.Enabled = False
                    frm.StudentsToolStrip.Enabled = True
                    frm.NewStudentRegistrationToolStripMenuItem.Enabled = False
                    frm.ManageStudentsToolStripMenuItem.Enabled = True
                    frm.ViewStudentProfileToolStripMenuItem.Enabled = False
                    frm.ManageStudentProfileToolStripMenuItem.Enabled = False
                    frm.SearchStudentToolStripMenuItem.Enabled = False
                    frm.EmployeeToolStrip.Enabled = True
                    frm.EmployeeRegistration.Enabled = False
                    frm.StaffReportToolStripMenuItem.Enabled = True
                    frm.RegisteredStaffToolStripMenuItem.Enabled = False
                    frm.RegisteredStaffDeptToolStripMenuItem.Enabled = False

                    frm.Show()
                    frm.lblUser.Text = LogName
                    frm.lblUserType.Text = LogURole
                End If
                'guest section
                If (LogURole = "USER") Then
                    username.Text = ""
                    password.Text = ""
                    Me.Hide()
                    frm.UtilitiesToolStrip.Enabled = True
                    frm.CreateNewUserToolStrip.Enabled = False
                    frm.ChangePasswordToolStrip.Enabled = True
                    frm.AccountSettingsToolStripMenuItem.Enabled = False
                    frm.StudentsToolStrip.Enabled = True
                    frm.NewStudentRegistrationToolStripMenuItem.Enabled = False
                    frm.ManageStudentsToolStripMenuItem.Enabled = True
                    frm.ViewStudentProfileToolStripMenuItem.Enabled = False
                    frm.ManageStudentProfileToolStripMenuItem.Enabled = False
                    frm.SearchStudentToolStripMenuItem.Enabled = False
                    frm.Show()
                    frm.lblUser.Text = LogName
                    frm.lblUserType.Text = LogURole
                End If

                If (LogURole = "TEACHER") Then

                End If
            Else
                MsgBox("The username does not Exists or is Incorrect! ", MsgBoxStyle.OkOnly + MsgBoxStyle.Critical, "Access Denied")
                username.Focus()
                username.SelectAll()
                Exit Sub
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

   Private Sub cancel_Click(sender As Object, e As EventArgs) Handles cancel.Click
        Me.Close()
    End Sub

    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs) Handles Panel1.Paint

    End Sub
End Class