﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmLog
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmLog))
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.LinkLabelForgetPassword = New System.Windows.Forms.LinkLabel()
        Me.LabelPassword = New System.Windows.Forms.Label()
        Me.LabelUsername = New System.Windows.Forms.Label()
        Me.password = New System.Windows.Forms.TextBox()
        Me.username = New System.Windows.Forms.TextBox()
        Me.cancel = New System.Windows.Forms.Button()
        Me.login = New System.Windows.Forms.Button()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.LightSkyBlue
        Me.Panel1.Controls.Add(Me.Panel2)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(470, 196)
        Me.Panel1.TabIndex = 11
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.Transparent
        Me.Panel2.BackgroundImage = CType(resources.GetObject("Panel2.BackgroundImage"), System.Drawing.Image)
        Me.Panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel2.Controls.Add(Me.Label3)
        Me.Panel2.Location = New System.Drawing.Point(77, 2)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(317, 193)
        Me.Panel2.TabIndex = 8
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Times New Roman", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.SteelBlue
        Me.Label3.Location = New System.Drawing.Point(2, -3)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(313, 26)
        Me.Label3.TabIndex = 8
        Me.Label3.Text = "LOGIN AUTHENTICATION"
        '
        'LinkLabelForgetPassword
        '
        Me.LinkLabelForgetPassword.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LinkLabelForgetPassword.ForeColor = System.Drawing.Color.DeepSkyBlue
        Me.LinkLabelForgetPassword.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline
        Me.LinkLabelForgetPassword.LinkColor = System.Drawing.Color.DeepSkyBlue
        Me.LinkLabelForgetPassword.Location = New System.Drawing.Point(0, 368)
        Me.LinkLabelForgetPassword.Name = "LinkLabelForgetPassword"
        Me.LinkLabelForgetPassword.Size = New System.Drawing.Size(520, 26)
        Me.LinkLabelForgetPassword.TabIndex = 18
        Me.LinkLabelForgetPassword.TabStop = True
        Me.LinkLabelForgetPassword.Text = "Forget Password?"
        Me.LinkLabelForgetPassword.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.LinkLabelForgetPassword.Visible = False
        '
        'LabelPassword
        '
        Me.LabelPassword.AutoSize = True
        Me.LabelPassword.BackColor = System.Drawing.Color.White
        Me.LabelPassword.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelPassword.ForeColor = System.Drawing.Color.LightSkyBlue
        Me.LabelPassword.Location = New System.Drawing.Point(33, 262)
        Me.LabelPassword.Name = "LabelPassword"
        Me.LabelPassword.Size = New System.Drawing.Size(112, 24)
        Me.LabelPassword.TabIndex = 17
        Me.LabelPassword.Text = "Password :"
        '
        'LabelUsername
        '
        Me.LabelUsername.AutoSize = True
        Me.LabelUsername.BackColor = System.Drawing.Color.White
        Me.LabelUsername.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelUsername.ForeColor = System.Drawing.Color.LightSkyBlue
        Me.LabelUsername.Location = New System.Drawing.Point(25, 214)
        Me.LabelUsername.Name = "LabelUsername"
        Me.LabelUsername.Size = New System.Drawing.Size(126, 24)
        Me.LabelUsername.TabIndex = 16
        Me.LabelUsername.Text = "User Name :"
        '
        'password
        '
        Me.password.BackColor = System.Drawing.Color.White
        Me.password.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.password.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.password.Location = New System.Drawing.Point(155, 262)
        Me.password.MaxLength = 30
        Me.password.Name = "password"
        Me.password.PasswordChar = Global.Microsoft.VisualBasic.ChrW(8226)
        Me.password.Size = New System.Drawing.Size(290, 29)
        Me.password.TabIndex = 2
        Me.password.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'username
        '
        Me.username.BackColor = System.Drawing.Color.White
        Me.username.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.username.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.username.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.username.Location = New System.Drawing.Point(155, 213)
        Me.username.MaxLength = 30
        Me.username.Name = "username"
        Me.username.Size = New System.Drawing.Size(290, 29)
        Me.username.TabIndex = 1
        Me.username.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'cancel
        '
        Me.cancel.BackColor = System.Drawing.Color.DeepSkyBlue
        Me.cancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.cancel.FlatAppearance.BorderColor = System.Drawing.Color.DeepSkyBlue
        Me.cancel.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightSkyBlue
        Me.cancel.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSkyBlue
        Me.cancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cancel.Font = New System.Drawing.Font("Segoe UI Black", 14.0!, System.Drawing.FontStyle.Bold)
        Me.cancel.ForeColor = System.Drawing.Color.White
        Me.cancel.Image = CType(resources.GetObject("cancel.Image"), System.Drawing.Image)
        Me.cancel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.cancel.Location = New System.Drawing.Point(325, 312)
        Me.cancel.Name = "cancel"
        Me.cancel.Size = New System.Drawing.Size(120, 39)
        Me.cancel.TabIndex = 4
        Me.cancel.Text = "&EXIT"
        Me.cancel.UseVisualStyleBackColor = False
        '
        'login
        '
        Me.login.FlatAppearance.BorderColor = System.Drawing.Color.DeepSkyBlue
        Me.login.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightSkyBlue
        Me.login.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightBlue
        Me.login.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.login.Font = New System.Drawing.Font("Segoe UI Black", 14.0!, System.Drawing.FontStyle.Bold)
        Me.login.ForeColor = System.Drawing.Color.DeepSkyBlue
        Me.login.Image = CType(resources.GetObject("login.Image"), System.Drawing.Image)
        Me.login.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.login.Location = New System.Drawing.Point(186, 312)
        Me.login.Name = "login"
        Me.login.Size = New System.Drawing.Size(120, 39)
        Me.login.TabIndex = 3
        Me.login.Text = "&LOGIN"
        Me.login.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.login.UseVisualStyleBackColor = True
        '
        'frmLog
        '
        Me.AcceptButton = Me.login
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.CancelButton = Me.cancel
        Me.ClientSize = New System.Drawing.Size(470, 391)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.LinkLabelForgetPassword)
        Me.Controls.Add(Me.LabelPassword)
        Me.Controls.Add(Me.LabelUsername)
        Me.Controls.Add(Me.password)
        Me.Controls.Add(Me.username)
        Me.Controls.Add(Me.cancel)
        Me.Controls.Add(Me.login)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmLog"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "frmLog"
        Me.Panel1.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents LinkLabelForgetPassword As System.Windows.Forms.LinkLabel
    Friend WithEvents LabelPassword As System.Windows.Forms.Label
    Friend WithEvents LabelUsername As System.Windows.Forms.Label
    Friend WithEvents password As System.Windows.Forms.TextBox
    Friend WithEvents username As System.Windows.Forms.TextBox
    Friend WithEvents cancel As System.Windows.Forms.Button
    Friend WithEvents login As System.Windows.Forms.Button
End Class
