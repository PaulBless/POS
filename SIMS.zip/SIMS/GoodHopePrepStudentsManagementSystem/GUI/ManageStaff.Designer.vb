﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ManageStaff
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(ManageStaff))
        Me.txtSID = New System.Windows.Forms.TextBox()
        Me.txtcode = New System.Windows.Forms.TextBox()
        Me.btnsearch = New System.Windows.Forms.Button()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.btnDeactivate = New System.Windows.Forms.Button()
        Me.btn_Cancel = New System.Windows.Forms.Button()
        Me.btn_Refresh_form = New System.Windows.Forms.Button()
        Me.btnTerminate = New System.Windows.Forms.Button()
        Me.btn_Delete = New System.Windows.Forms.Button()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.txtSSNIT = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.txtdesignation = New System.Windows.Forms.TextBox()
        Me.txtNationality = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtphoneno = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtstaffcode = New System.Windows.Forms.TextBox()
        Me.cbogender = New System.Windows.Forms.ComboBox()
        Me.txttitle = New System.Windows.Forms.TextBox()
        Me.lbl_StaffTitle = New System.Windows.Forms.Label()
        Me.lbl_StaffGender = New System.Windows.Forms.Label()
        Me.txtothernames = New System.Windows.Forms.TextBox()
        Me.l = New System.Windows.Forms.Label()
        Me.txtfirstname = New System.Windows.Forms.TextBox()
        Me.lbl_StaffFirstname = New System.Windows.Forms.Label()
        Me.lbl_StaffSurname = New System.Windows.Forms.Label()
        Me.cboDesignation = New System.Windows.Forms.ComboBox()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.EndDate = New System.Windows.Forms.DateTimePicker()
        Me.StartDate = New System.Windows.Forms.DateTimePicker()
        Me.cboType = New System.Windows.Forms.ComboBox()
        Me.portfolio = New System.Windows.Forms.ComboBox()
        Me.cboStatus = New System.Windows.Forms.ComboBox()
        Me.lbl_Staffdepartment = New System.Windows.Forms.Label()
        Me.lbl_Staffjob = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.lbl_Staffcategory = New System.Windows.Forms.Label()
        Me.cboSaffdepartment = New System.Windows.Forms.ComboBox()
        Me.cbocategory = New System.Windows.Forms.ComboBox()
        Me.cboqualification = New System.Windows.Forms.ComboBox()
        Me.lbl_StaffDateEmployed = New System.Windows.Forms.Label()
        Me.cbobackground = New System.Windows.Forms.ComboBox()
        Me.lbl_StaffEmail = New System.Windows.Forms.Label()
        Me.lbl_Staffqualification = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.txtEmpID = New System.Windows.Forms.TextBox()
        Me.btnHelp = New System.Windows.Forms.Button()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.GroupBox5.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'txtSID
        '
        Me.txtSID.AutoCompleteCustomSource.AddRange(New String() {"Class Teacher", "Driver", "Cook", "Assistant Headmaster", "Sports Master", "Form Teacher", "Feeding Fee Coordinator", "Bus Fee Cordinator", "Subject Teacher", "Security"})
        Me.txtSID.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.txtSID.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.txtSID.BackColor = System.Drawing.Color.White
        Me.txtSID.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.txtSID.Location = New System.Drawing.Point(146, 4)
        Me.txtSID.Name = "txtSID"
        Me.txtSID.Size = New System.Drawing.Size(48, 21)
        Me.txtSID.TabIndex = 72
        Me.txtSID.Visible = False
        '
        'txtcode
        '
        Me.txtcode.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.txtcode.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.txtcode.BackColor = System.Drawing.Color.White
        Me.txtcode.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.txtcode.Location = New System.Drawing.Point(823, 6)
        Me.txtcode.Name = "txtcode"
        Me.txtcode.Size = New System.Drawing.Size(108, 21)
        Me.txtcode.TabIndex = 71
        Me.txtcode.Visible = False
        '
        'btnsearch
        '
        Me.btnsearch.BackColor = System.Drawing.Color.LightSkyBlue
        Me.btnsearch.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnsearch.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnsearch.Image = CType(resources.GetObject("btnsearch.Image"), System.Drawing.Image)
        Me.btnsearch.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnsearch.Location = New System.Drawing.Point(21, 0)
        Me.btnsearch.Name = "btnsearch"
        Me.btnsearch.Size = New System.Drawing.Size(101, 31)
        Me.btnsearch.TabIndex = 10
        Me.btnsearch.Text = "&Search"
        Me.btnsearch.UseVisualStyleBackColor = False
        Me.btnsearch.Visible = False
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.btnDeactivate)
        Me.GroupBox5.Controls.Add(Me.btn_Cancel)
        Me.GroupBox5.Controls.Add(Me.btn_Refresh_form)
        Me.GroupBox5.Controls.Add(Me.btnTerminate)
        Me.GroupBox5.Controls.Add(Me.btn_Delete)
        Me.GroupBox5.Controls.Add(Me.btnSave)
        Me.GroupBox5.Location = New System.Drawing.Point(12, 413)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(922, 72)
        Me.GroupBox5.TabIndex = 57
        Me.GroupBox5.TabStop = False
        '
        'btnDeactivate
        '
        Me.btnDeactivate.BackColor = System.Drawing.SystemColors.Control
        Me.btnDeactivate.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnDeactivate.Enabled = False
        Me.btnDeactivate.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnDeactivate.Font = New System.Drawing.Font("Tahoma", 11.0!, System.Drawing.FontStyle.Bold)
        Me.btnDeactivate.ForeColor = System.Drawing.Color.SteelBlue
        Me.btnDeactivate.Image = CType(resources.GetObject("btnDeactivate.Image"), System.Drawing.Image)
        Me.btnDeactivate.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnDeactivate.Location = New System.Drawing.Point(174, 22)
        Me.btnDeactivate.Name = "btnDeactivate"
        Me.btnDeactivate.Size = New System.Drawing.Size(130, 40)
        Me.btnDeactivate.TabIndex = 14
        Me.btnDeactivate.Text = "&De-activate"
        Me.btnDeactivate.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnDeactivate.UseVisualStyleBackColor = False
        '
        'btn_Cancel
        '
        Me.btn_Cancel.BackColor = System.Drawing.SystemColors.Control
        Me.btn_Cancel.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_Cancel.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btn_Cancel.Font = New System.Drawing.Font("Tahoma", 11.0!, System.Drawing.FontStyle.Bold)
        Me.btn_Cancel.ForeColor = System.Drawing.Color.SteelBlue
        Me.btn_Cancel.Image = CType(resources.GetObject("btn_Cancel.Image"), System.Drawing.Image)
        Me.btn_Cancel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_Cancel.Location = New System.Drawing.Point(781, 22)
        Me.btn_Cancel.Name = "btn_Cancel"
        Me.btn_Cancel.Size = New System.Drawing.Size(116, 40)
        Me.btn_Cancel.TabIndex = 13
        Me.btn_Cancel.Text = "&Close"
        Me.btn_Cancel.UseVisualStyleBackColor = False
        '
        'btn_Refresh_form
        '
        Me.btn_Refresh_form.BackColor = System.Drawing.SystemColors.Control
        Me.btn_Refresh_form.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_Refresh_form.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btn_Refresh_form.Font = New System.Drawing.Font("Tahoma", 11.0!, System.Drawing.FontStyle.Bold)
        Me.btn_Refresh_form.ForeColor = System.Drawing.Color.SteelBlue
        Me.btn_Refresh_form.Image = CType(resources.GetObject("btn_Refresh_form.Image"), System.Drawing.Image)
        Me.btn_Refresh_form.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_Refresh_form.Location = New System.Drawing.Point(336, 22)
        Me.btn_Refresh_form.Name = "btn_Refresh_form"
        Me.btn_Refresh_form.Size = New System.Drawing.Size(108, 40)
        Me.btn_Refresh_form.TabIndex = 12
        Me.btn_Refresh_form.Text = "&Clear"
        Me.btn_Refresh_form.UseVisualStyleBackColor = False
        '
        'btnTerminate
        '
        Me.btnTerminate.BackColor = System.Drawing.SystemColors.Control
        Me.btnTerminate.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnTerminate.Enabled = False
        Me.btnTerminate.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnTerminate.Font = New System.Drawing.Font("Tahoma", 11.0!, System.Drawing.FontStyle.Bold)
        Me.btnTerminate.ForeColor = System.Drawing.Color.SteelBlue
        Me.btnTerminate.Image = CType(resources.GetObject("btnTerminate.Image"), System.Drawing.Image)
        Me.btnTerminate.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnTerminate.Location = New System.Drawing.Point(476, 22)
        Me.btnTerminate.Name = "btnTerminate"
        Me.btnTerminate.Size = New System.Drawing.Size(119, 40)
        Me.btnTerminate.TabIndex = 11
        Me.btnTerminate.Text = "&Terminate"
        Me.btnTerminate.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnTerminate.UseVisualStyleBackColor = False
        '
        'btn_Delete
        '
        Me.btn_Delete.BackColor = System.Drawing.SystemColors.Control
        Me.btn_Delete.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_Delete.Enabled = False
        Me.btn_Delete.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btn_Delete.Font = New System.Drawing.Font("Tahoma", 11.0!, System.Drawing.FontStyle.Bold)
        Me.btn_Delete.ForeColor = System.Drawing.Color.SteelBlue
        Me.btn_Delete.Image = CType(resources.GetObject("btn_Delete.Image"), System.Drawing.Image)
        Me.btn_Delete.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_Delete.Location = New System.Drawing.Point(627, 22)
        Me.btn_Delete.Name = "btn_Delete"
        Me.btn_Delete.Size = New System.Drawing.Size(122, 40)
        Me.btn_Delete.TabIndex = 11
        Me.btn_Delete.Text = "&Delete"
        Me.btn_Delete.UseVisualStyleBackColor = False
        '
        'btnSave
        '
        Me.btnSave.BackColor = System.Drawing.SystemColors.Control
        Me.btnSave.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnSave.Enabled = False
        Me.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnSave.Font = New System.Drawing.Font("Tahoma", 11.0!, System.Drawing.FontStyle.Bold)
        Me.btnSave.ForeColor = System.Drawing.Color.SteelBlue
        Me.btnSave.Image = CType(resources.GetObject("btnSave.Image"), System.Drawing.Image)
        Me.btnSave.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnSave.Location = New System.Drawing.Point(26, 22)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(116, 40)
        Me.btnSave.TabIndex = 10
        Me.btnSave.Text = "&Save"
        Me.btnSave.UseVisualStyleBackColor = False
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.txtSSNIT)
        Me.GroupBox3.Controls.Add(Me.Label9)
        Me.GroupBox3.Controls.Add(Me.txtdesignation)
        Me.GroupBox3.Controls.Add(Me.txtNationality)
        Me.GroupBox3.Controls.Add(Me.Label7)
        Me.GroupBox3.Controls.Add(Me.txtphoneno)
        Me.GroupBox3.Controls.Add(Me.Label1)
        Me.GroupBox3.Controls.Add(Me.txtstaffcode)
        Me.GroupBox3.Controls.Add(Me.cbogender)
        Me.GroupBox3.Controls.Add(Me.txttitle)
        Me.GroupBox3.Controls.Add(Me.lbl_StaffTitle)
        Me.GroupBox3.Controls.Add(Me.lbl_StaffGender)
        Me.GroupBox3.Controls.Add(Me.txtothernames)
        Me.GroupBox3.Controls.Add(Me.l)
        Me.GroupBox3.Controls.Add(Me.txtfirstname)
        Me.GroupBox3.Controls.Add(Me.lbl_StaffFirstname)
        Me.GroupBox3.Controls.Add(Me.lbl_StaffSurname)
        Me.GroupBox3.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.Location = New System.Drawing.Point(12, 85)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(414, 311)
        Me.GroupBox3.TabIndex = 58
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Staff Info"
        '
        'txtSSNIT
        '
        Me.txtSSNIT.AutoCompleteCustomSource.AddRange(New String() {"Class Teacher", "Driver", "Cook", "Assistant Headmaster", "Sports Master", "Form Teacher", "Feeding Fee Coordinator", "Bus Fee Cordinator", "Subject Teacher", "Security"})
        Me.txtSSNIT.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.txtSSNIT.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.txtSSNIT.BackColor = System.Drawing.Color.White
        Me.txtSSNIT.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtSSNIT.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.txtSSNIT.Location = New System.Drawing.Point(119, 244)
        Me.txtSSNIT.Name = "txtSSNIT"
        Me.txtSSNIT.ReadOnly = True
        Me.txtSSNIT.Size = New System.Drawing.Size(269, 21)
        Me.txtSSNIT.TabIndex = 71
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.Label9.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.Label9.Location = New System.Drawing.Point(17, 246)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(76, 19)
        Me.Label9.TabIndex = 70
        Me.Label9.Text = "SSNIT No."
        '
        'txtdesignation
        '
        Me.txtdesignation.AutoCompleteCustomSource.AddRange(New String() {"Class Teacher", "Driver", "Cook", "Assistant Headmaster", "Sports Master", "Form Teacher", "Feeding Fee Coordinator", "Bus Fee Cordinator", "Subject Teacher", "Security"})
        Me.txtdesignation.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.txtdesignation.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.txtdesignation.BackColor = System.Drawing.Color.White
        Me.txtdesignation.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtdesignation.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.txtdesignation.Location = New System.Drawing.Point(119, 279)
        Me.txtdesignation.Name = "txtdesignation"
        Me.txtdesignation.Size = New System.Drawing.Size(269, 21)
        Me.txtdesignation.TabIndex = 71
        '
        'txtNationality
        '
        Me.txtNationality.AutoCompleteCustomSource.AddRange(New String() {"Class Teacher", "Driver", "Cook", "Assistant Headmaster", "Sports Master", "Form Teacher", "Feeding Fee Coordinator", "Bus Fee Cordinator", "Subject Teacher", "Security"})
        Me.txtNationality.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.txtNationality.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.txtNationality.BackColor = System.Drawing.Color.White
        Me.txtNationality.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtNationality.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.txtNationality.Location = New System.Drawing.Point(119, 214)
        Me.txtNationality.Name = "txtNationality"
        Me.txtNationality.ReadOnly = True
        Me.txtNationality.Size = New System.Drawing.Size(269, 21)
        Me.txtNationality.TabIndex = 71
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.Label7.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.Label7.Location = New System.Drawing.Point(17, 216)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(83, 19)
        Me.Label7.TabIndex = 70
        Me.Label7.Text = "Nationality"
        '
        'txtphoneno
        '
        Me.txtphoneno.AutoCompleteCustomSource.AddRange(New String() {"Class Teacher", "Driver", "Cook", "Assistant Headmaster", "Sports Master", "Form Teacher", "Feeding Fee Coordinator", "Bus Fee Cordinator", "Subject Teacher", "Security"})
        Me.txtphoneno.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.txtphoneno.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.txtphoneno.BackColor = System.Drawing.Color.White
        Me.txtphoneno.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtphoneno.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.txtphoneno.Location = New System.Drawing.Point(119, 184)
        Me.txtphoneno.Name = "txtphoneno"
        Me.txtphoneno.ReadOnly = True
        Me.txtphoneno.Size = New System.Drawing.Size(269, 21)
        Me.txtphoneno.TabIndex = 71
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.Label1.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.Label1.Location = New System.Drawing.Point(16, 186)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(79, 19)
        Me.Label1.TabIndex = 70
        Me.Label1.Text = "Phone No:"
        '
        'txtstaffcode
        '
        Me.txtstaffcode.AutoCompleteCustomSource.AddRange(New String() {"Class Teacher", "Driver", "Cook", "Assistant Headmaster", "Sports Master", "Form Teacher", "Feeding Fee Coordinator", "Bus Fee Cordinator", "Subject Teacher", "Security"})
        Me.txtstaffcode.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.txtstaffcode.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.txtstaffcode.BackColor = System.Drawing.Color.White
        Me.txtstaffcode.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtstaffcode.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.txtstaffcode.Location = New System.Drawing.Point(119, 31)
        Me.txtstaffcode.Name = "txtstaffcode"
        Me.txtstaffcode.ReadOnly = True
        Me.txtstaffcode.Size = New System.Drawing.Size(269, 21)
        Me.txtstaffcode.TabIndex = 69
        '
        'cbogender
        '
        Me.cbogender.BackColor = System.Drawing.Color.White
        Me.cbogender.Enabled = False
        Me.cbogender.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbogender.FormattingEnabled = True
        Me.cbogender.Items.AddRange(New Object() {"FEMALE", "MALE"})
        Me.cbogender.Location = New System.Drawing.Point(119, 151)
        Me.cbogender.Name = "cbogender"
        Me.cbogender.Size = New System.Drawing.Size(269, 24)
        Me.cbogender.TabIndex = 41
        '
        'txttitle
        '
        Me.txttitle.AutoCompleteCustomSource.AddRange(New String() {"Class Teacher", "Driver", "Cook", "Assistant Headmaster", "Sports Master", "Form Teacher", "Feeding Fee Coordinator", "Bus Fee Cordinator", "Subject Teacher", "Security"})
        Me.txttitle.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.txttitle.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.txttitle.BackColor = System.Drawing.Color.White
        Me.txttitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.txttitle.Location = New System.Drawing.Point(119, 61)
        Me.txttitle.Name = "txttitle"
        Me.txttitle.ReadOnly = True
        Me.txttitle.Size = New System.Drawing.Size(269, 21)
        Me.txttitle.TabIndex = 67
        '
        'lbl_StaffTitle
        '
        Me.lbl_StaffTitle.AutoSize = True
        Me.lbl_StaffTitle.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.lbl_StaffTitle.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_StaffTitle.Location = New System.Drawing.Point(22, 63)
        Me.lbl_StaffTitle.Name = "lbl_StaffTitle"
        Me.lbl_StaffTitle.Size = New System.Drawing.Size(42, 19)
        Me.lbl_StaffTitle.TabIndex = 48
        Me.lbl_StaffTitle.Text = "Title:"
        '
        'lbl_StaffGender
        '
        Me.lbl_StaffGender.AutoSize = True
        Me.lbl_StaffGender.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.lbl_StaffGender.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_StaffGender.Location = New System.Drawing.Point(17, 154)
        Me.lbl_StaffGender.Name = "lbl_StaffGender"
        Me.lbl_StaffGender.Size = New System.Drawing.Size(63, 19)
        Me.lbl_StaffGender.TabIndex = 46
        Me.lbl_StaffGender.Text = "Gender:"
        '
        'txtothernames
        '
        Me.txtothernames.BackColor = System.Drawing.Color.White
        Me.txtothernames.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtothernames.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.txtothernames.Location = New System.Drawing.Point(119, 121)
        Me.txtothernames.Name = "txtothernames"
        Me.txtothernames.ReadOnly = True
        Me.txtothernames.Size = New System.Drawing.Size(269, 21)
        Me.txtothernames.TabIndex = 44
        '
        'l
        '
        Me.l.AutoSize = True
        Me.l.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.l.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.l.Location = New System.Drawing.Point(17, 31)
        Me.l.Name = "l"
        Me.l.Size = New System.Drawing.Size(93, 19)
        Me.l.TabIndex = 63
        Me.l.Text = "Employee ID"
        '
        'txtfirstname
        '
        Me.txtfirstname.BackColor = System.Drawing.Color.White
        Me.txtfirstname.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtfirstname.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.txtfirstname.Location = New System.Drawing.Point(119, 91)
        Me.txtfirstname.Name = "txtfirstname"
        Me.txtfirstname.ReadOnly = True
        Me.txtfirstname.Size = New System.Drawing.Size(269, 21)
        Me.txtfirstname.TabIndex = 43
        '
        'lbl_StaffFirstname
        '
        Me.lbl_StaffFirstname.AutoSize = True
        Me.lbl_StaffFirstname.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.lbl_StaffFirstname.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_StaffFirstname.Location = New System.Drawing.Point(16, 122)
        Me.lbl_StaffFirstname.Name = "lbl_StaffFirstname"
        Me.lbl_StaffFirstname.Size = New System.Drawing.Size(101, 19)
        Me.lbl_StaffFirstname.TabIndex = 42
        Me.lbl_StaffFirstname.Text = "Other Names:"
        '
        'lbl_StaffSurname
        '
        Me.lbl_StaffSurname.AutoSize = True
        Me.lbl_StaffSurname.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.lbl_StaffSurname.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_StaffSurname.Location = New System.Drawing.Point(17, 93)
        Me.lbl_StaffSurname.Name = "lbl_StaffSurname"
        Me.lbl_StaffSurname.Size = New System.Drawing.Size(78, 19)
        Me.lbl_StaffSurname.TabIndex = 40
        Me.lbl_StaffSurname.Text = "Firstname:"
        '
        'cboDesignation
        '
        Me.cboDesignation.BackColor = System.Drawing.Color.White
        Me.cboDesignation.Enabled = False
        Me.cboDesignation.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboDesignation.FormattingEnabled = True
        Me.cboDesignation.Location = New System.Drawing.Point(158, 153)
        Me.cboDesignation.Name = "cboDesignation"
        Me.cboDesignation.Size = New System.Drawing.Size(315, 24)
        Me.cboDesignation.TabIndex = 41
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.EndDate)
        Me.GroupBox4.Controls.Add(Me.StartDate)
        Me.GroupBox4.Controls.Add(Me.cboType)
        Me.GroupBox4.Controls.Add(Me.portfolio)
        Me.GroupBox4.Controls.Add(Me.cboStatus)
        Me.GroupBox4.Controls.Add(Me.lbl_Staffdepartment)
        Me.GroupBox4.Controls.Add(Me.lbl_Staffjob)
        Me.GroupBox4.Controls.Add(Me.cboDesignation)
        Me.GroupBox4.Controls.Add(Me.Label6)
        Me.GroupBox4.Controls.Add(Me.Label5)
        Me.GroupBox4.Controls.Add(Me.Label4)
        Me.GroupBox4.Controls.Add(Me.lbl_Staffcategory)
        Me.GroupBox4.Controls.Add(Me.cboSaffdepartment)
        Me.GroupBox4.Controls.Add(Me.cbocategory)
        Me.GroupBox4.Controls.Add(Me.cboqualification)
        Me.GroupBox4.Controls.Add(Me.lbl_StaffDateEmployed)
        Me.GroupBox4.Controls.Add(Me.cbobackground)
        Me.GroupBox4.Controls.Add(Me.lbl_StaffEmail)
        Me.GroupBox4.Controls.Add(Me.lbl_Staffqualification)
        Me.GroupBox4.Controls.Add(Me.Label8)
        Me.GroupBox4.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox4.Location = New System.Drawing.Point(433, 85)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(498, 311)
        Me.GroupBox4.TabIndex = 69
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Job && Educational Information"
        '
        'EndDate
        '
        Me.EndDate.CalendarFont = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EndDate.CalendarMonthBackground = System.Drawing.Color.White
        Me.EndDate.CustomFormat = "dd/MM/yyyy"
        Me.EndDate.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EndDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.EndDate.Location = New System.Drawing.Point(362, 275)
        Me.EndDate.Name = "EndDate"
        Me.EndDate.ShowCheckBox = True
        Me.EndDate.Size = New System.Drawing.Size(111, 23)
        Me.EndDate.TabIndex = 72
        '
        'StartDate
        '
        Me.StartDate.CalendarFont = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StartDate.CalendarMonthBackground = System.Drawing.Color.White
        Me.StartDate.CustomFormat = "dd/MM/yyyy"
        Me.StartDate.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StartDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.StartDate.Location = New System.Drawing.Point(158, 275)
        Me.StartDate.Name = "StartDate"
        Me.StartDate.ShowCheckBox = True
        Me.StartDate.Size = New System.Drawing.Size(123, 23)
        Me.StartDate.TabIndex = 72
        '
        'cboType
        '
        Me.cboType.BackColor = System.Drawing.Color.White
        Me.cboType.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboType.FormattingEnabled = True
        Me.cboType.Items.AddRange(New Object() {"CASUAL", "CONTRACT", "INTERNSHIP", "OTHER", "PERMANENT", "TEMPORAL"})
        Me.cboType.Location = New System.Drawing.Point(158, 214)
        Me.cboType.Name = "cboType"
        Me.cboType.Size = New System.Drawing.Size(315, 24)
        Me.cboType.Sorted = True
        Me.cboType.TabIndex = 41
        '
        'portfolio
        '
        Me.portfolio.BackColor = System.Drawing.Color.White
        Me.portfolio.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.portfolio.FormattingEnabled = True
        Me.portfolio.Items.AddRange(New Object() {"ASSISTANT HEADTEACHER", "CLASS TEACHER", "CULTURE CO-ORDINATOR", "DRAMA CO-ORDINATOR", "FORM MASTER", "FORM MISTRESS", "HEAD, SECURITY", "OTHER", "SANITATION CO-ORDINATOR", "SCHOOL CHAPLAIN", "SPORTS MASTER", "SUBJECT TEACHER"})
        Me.portfolio.Location = New System.Drawing.Point(158, 184)
        Me.portfolio.Name = "portfolio"
        Me.portfolio.Size = New System.Drawing.Size(315, 24)
        Me.portfolio.Sorted = True
        Me.portfolio.TabIndex = 41
        '
        'cboStatus
        '
        Me.cboStatus.BackColor = System.Drawing.Color.White
        Me.cboStatus.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboStatus.FormattingEnabled = True
        Me.cboStatus.Items.AddRange(New Object() {"ACTIVE", "INACTIVE"})
        Me.cboStatus.Location = New System.Drawing.Point(158, 244)
        Me.cboStatus.Name = "cboStatus"
        Me.cboStatus.Size = New System.Drawing.Size(315, 24)
        Me.cboStatus.TabIndex = 41
        '
        'lbl_Staffdepartment
        '
        Me.lbl_Staffdepartment.AutoSize = True
        Me.lbl_Staffdepartment.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.lbl_Staffdepartment.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_Staffdepartment.Location = New System.Drawing.Point(23, 126)
        Me.lbl_Staffdepartment.Name = "lbl_Staffdepartment"
        Me.lbl_Staffdepartment.Size = New System.Drawing.Size(97, 19)
        Me.lbl_Staffdepartment.TabIndex = 70
        Me.lbl_Staffdepartment.Text = "Department :"
        '
        'lbl_Staffjob
        '
        Me.lbl_Staffjob.AutoSize = True
        Me.lbl_Staffjob.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.lbl_Staffjob.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_Staffjob.Location = New System.Drawing.Point(23, 157)
        Me.lbl_Staffjob.Name = "lbl_Staffjob"
        Me.lbl_Staffjob.Size = New System.Drawing.Size(96, 19)
        Me.lbl_Staffjob.TabIndex = 68
        Me.lbl_Staffjob.Text = "Designation :"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.Label6.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.Label6.Location = New System.Drawing.Point(23, 186)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(73, 19)
        Me.Label6.TabIndex = 46
        Me.Label6.Text = "Portfolio:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.Label5.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.Label5.Location = New System.Drawing.Point(23, 216)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(133, 19)
        Me.Label5.TabIndex = 46
        Me.Label5.Text = "Appointment Type"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.Label4.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.Label4.Location = New System.Drawing.Point(23, 248)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(111, 19)
        Me.Label4.TabIndex = 46
        Me.Label4.Text = "Current Status :"
        '
        'lbl_Staffcategory
        '
        Me.lbl_Staffcategory.AutoSize = True
        Me.lbl_Staffcategory.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.lbl_Staffcategory.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_Staffcategory.Location = New System.Drawing.Point(23, 94)
        Me.lbl_Staffcategory.Name = "lbl_Staffcategory"
        Me.lbl_Staffcategory.Size = New System.Drawing.Size(76, 19)
        Me.lbl_Staffcategory.TabIndex = 67
        Me.lbl_Staffcategory.Text = "Category:"
        '
        'cboSaffdepartment
        '
        Me.cboSaffdepartment.BackColor = System.Drawing.Color.White
        Me.cboSaffdepartment.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboSaffdepartment.FormattingEnabled = True
        Me.cboSaffdepartment.Items.AddRange(New Object() {"KINDERGARTEN", "LOWER PRIMARY", "UPPER PRIMARY", "JUNIOR HIGH SCHOOL"})
        Me.cboSaffdepartment.Location = New System.Drawing.Point(158, 122)
        Me.cboSaffdepartment.Name = "cboSaffdepartment"
        Me.cboSaffdepartment.Size = New System.Drawing.Size(315, 24)
        Me.cboSaffdepartment.TabIndex = 41
        '
        'cbocategory
        '
        Me.cbocategory.BackColor = System.Drawing.Color.White
        Me.cbocategory.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbocategory.FormattingEnabled = True
        Me.cbocategory.Items.AddRange(New Object() {"Non-Teaching", "Teaching"})
        Me.cbocategory.Location = New System.Drawing.Point(158, 91)
        Me.cbocategory.Name = "cbocategory"
        Me.cbocategory.Size = New System.Drawing.Size(315, 24)
        Me.cbocategory.TabIndex = 41
        '
        'cboqualification
        '
        Me.cboqualification.BackColor = System.Drawing.Color.White
        Me.cboqualification.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboqualification.FormattingEnabled = True
        Me.cboqualification.Items.AddRange(New Object() {"BACHELOR OF ARTS(BA)", "BACHELOR OF EDUCATION(BED)", "BACHELOR OF SCIENCE(BSC)", "BACHELOR OF TECHNOLOGY(B TECH)", "CERTIFICATE IN JOURNALISM", "CERTIFICATE IN NURSING", "CERTIFICATE IN SECRETARIALSHIP", "DIPLOMA IN EDUCATION", "HIGHER NATIONAL DIPLOMA(HND)", "MASTER OF PHILOSOPHY(M PHIL)", "NATIONAL VOCATIONAL TRAINING INSTITUTE(N.V.T.I)", "SECONDARY SCHOOL CERTIFICATE EXAMINATION(SSCE)", "WEST AFRICAN SECONDARY SCHOOL CERTIFICATE EXAMINATION(WASSCE)"})
        Me.cboqualification.Location = New System.Drawing.Point(158, 60)
        Me.cboqualification.Name = "cboqualification"
        Me.cboqualification.Size = New System.Drawing.Size(315, 24)
        Me.cboqualification.TabIndex = 41
        '
        'lbl_StaffDateEmployed
        '
        Me.lbl_StaffDateEmployed.AutoSize = True
        Me.lbl_StaffDateEmployed.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.lbl_StaffDateEmployed.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_StaffDateEmployed.Location = New System.Drawing.Point(23, 279)
        Me.lbl_StaffDateEmployed.Name = "lbl_StaffDateEmployed"
        Me.lbl_StaffDateEmployed.Size = New System.Drawing.Size(80, 19)
        Me.lbl_StaffDateEmployed.TabIndex = 65
        Me.lbl_StaffDateEmployed.Text = "Start Date "
        '
        'cbobackground
        '
        Me.cbobackground.BackColor = System.Drawing.Color.White
        Me.cbobackground.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbobackground.FormattingEnabled = True
        Me.cbobackground.Items.AddRange(New Object() {"BASIC", "SECONDARY", "TERTIARY", "OTHER"})
        Me.cbobackground.Location = New System.Drawing.Point(158, 29)
        Me.cbobackground.Name = "cbobackground"
        Me.cbobackground.Size = New System.Drawing.Size(315, 24)
        Me.cbobackground.TabIndex = 41
        '
        'lbl_StaffEmail
        '
        Me.lbl_StaffEmail.AutoSize = True
        Me.lbl_StaffEmail.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.lbl_StaffEmail.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_StaffEmail.Location = New System.Drawing.Point(23, 33)
        Me.lbl_StaffEmail.Name = "lbl_StaffEmail"
        Me.lbl_StaffEmail.Size = New System.Drawing.Size(125, 19)
        Me.lbl_StaffEmail.TabIndex = 50
        Me.lbl_StaffEmail.Text = "Educational Level"
        '
        'lbl_Staffqualification
        '
        Me.lbl_Staffqualification.AutoSize = True
        Me.lbl_Staffqualification.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.lbl_Staffqualification.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_Staffqualification.Location = New System.Drawing.Point(23, 64)
        Me.lbl_Staffqualification.Name = "lbl_Staffqualification"
        Me.lbl_Staffqualification.Size = New System.Drawing.Size(98, 19)
        Me.lbl_Staffqualification.TabIndex = 66
        Me.lbl_Staffqualification.Text = "Qualification:"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.Label8.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.Label8.Location = New System.Drawing.Point(294, 278)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(68, 19)
        Me.Label8.TabIndex = 65
        Me.Label8.Text = "End Date"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.SteelBlue
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(943, 35)
        Me.Panel1.TabIndex = 72
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Trebuchet MS", 18.0!, System.Drawing.FontStyle.Bold)
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(293, 6)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(357, 29)
        Me.Label3.TabIndex = 12
        Me.Label3.Text = "J o b   P r o f i l e   M a s t e r y"
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.SystemColors.Control
        Me.Panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel2.Controls.Add(Me.btnsearch)
        Me.Panel2.Controls.Add(Me.txtcode)
        Me.Panel2.Controls.Add(Me.txtSID)
        Me.Panel2.Controls.Add(Me.txtEmpID)
        Me.Panel2.Controls.Add(Me.btnHelp)
        Me.Panel2.Controls.Add(Me.Label14)
        Me.Panel2.Location = New System.Drawing.Point(0, 36)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(943, 30)
        Me.Panel2.TabIndex = 91
        '
        'txtEmpID
        '
        Me.txtEmpID.BackColor = System.Drawing.Color.White
        Me.txtEmpID.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtEmpID.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.txtEmpID.Location = New System.Drawing.Point(287, 5)
        Me.txtEmpID.Name = "txtEmpID"
        Me.txtEmpID.Size = New System.Drawing.Size(217, 21)
        Me.txtEmpID.TabIndex = 88
        '
        'btnHelp
        '
        Me.btnHelp.BackColor = System.Drawing.Color.Firebrick
        Me.btnHelp.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnHelp.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnHelp.FlatAppearance.BorderColor = System.Drawing.Color.DarkGray
        Me.btnHelp.FlatAppearance.BorderSize = 0
        Me.btnHelp.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnHelp.Font = New System.Drawing.Font("Tahoma", 7.25!, System.Drawing.FontStyle.Bold)
        Me.btnHelp.ForeColor = System.Drawing.Color.White
        Me.btnHelp.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnHelp.Location = New System.Drawing.Point(510, 5)
        Me.btnHelp.Name = "btnHelp"
        Me.btnHelp.Size = New System.Drawing.Size(29, 21)
        Me.btnHelp.TabIndex = 89
        Me.btnHelp.Text = "GO"
        Me.btnHelp.UseVisualStyleBackColor = False
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.Label14.ForeColor = System.Drawing.Color.Indigo
        Me.Label14.Location = New System.Drawing.Point(194, 6)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(93, 19)
        Me.Label14.TabIndex = 87
        Me.Label14.Text = "Employee ID"
        '
        'ManageStaff
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(943, 493)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox5)
        Me.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "ManageStaff"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "SMIS"
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents btn_Cancel As System.Windows.Forms.Button
    Friend WithEvents btn_Refresh_form As System.Windows.Forms.Button
    Friend WithEvents btn_Delete As System.Windows.Forms.Button
    Friend WithEvents btnSave As System.Windows.Forms.Button
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents lbl_StaffTitle As System.Windows.Forms.Label
    Friend WithEvents lbl_StaffGender As System.Windows.Forms.Label
    Friend WithEvents lbl_StaffFirstname As System.Windows.Forms.Label
    Friend WithEvents lbl_StaffSurname As System.Windows.Forms.Label
    Friend WithEvents l As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents lbl_Staffdepartment As System.Windows.Forms.Label
    Friend WithEvents lbl_Staffjob As System.Windows.Forms.Label
    Friend WithEvents lbl_Staffcategory As System.Windows.Forms.Label
    Friend WithEvents lbl_StaffEmail As System.Windows.Forms.Label
    Friend WithEvents lbl_Staffqualification As System.Windows.Forms.Label
    Friend WithEvents lbl_StaffDateEmployed As System.Windows.Forms.Label
    Friend WithEvents btnsearch As System.Windows.Forms.Button
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents btnDeactivate As System.Windows.Forms.Button
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents btnHelp As System.Windows.Forms.Button
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents btnTerminate As System.Windows.Forms.Button
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Public WithEvents cbogender As System.Windows.Forms.ComboBox
    Public WithEvents txttitle As System.Windows.Forms.TextBox
    Public WithEvents txtothernames As System.Windows.Forms.TextBox
    Public WithEvents txtfirstname As System.Windows.Forms.TextBox
    Public WithEvents txtstaffcode As System.Windows.Forms.TextBox
    Public WithEvents txtphoneno As System.Windows.Forms.TextBox
    Public WithEvents txtdesignation As System.Windows.Forms.TextBox
    Public WithEvents cboSaffdepartment As System.Windows.Forms.ComboBox
    Public WithEvents cbocategory As System.Windows.Forms.ComboBox
    Public WithEvents cboqualification As System.Windows.Forms.ComboBox
    Public WithEvents cbobackground As System.Windows.Forms.ComboBox
    Public WithEvents txtcode As System.Windows.Forms.TextBox
    Public WithEvents txtSID As System.Windows.Forms.TextBox
    Public WithEvents StartDate As System.Windows.Forms.DateTimePicker
    Public WithEvents cboStatus As System.Windows.Forms.ComboBox
    Public WithEvents cboType As System.Windows.Forms.ComboBox
    Public WithEvents portfolio As System.Windows.Forms.ComboBox
    Public WithEvents txtEmpID As System.Windows.Forms.TextBox
    Public WithEvents txtNationality As System.Windows.Forms.TextBox
    Public WithEvents EndDate As System.Windows.Forms.DateTimePicker
    Public WithEvents txtSSNIT As System.Windows.Forms.TextBox
    Public WithEvents cboDesignation As System.Windows.Forms.ComboBox
End Class
