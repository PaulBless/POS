﻿Imports System.Data.Sql
Imports System.Data.SqlClient

Imports System.Windows.Forms

Public Class StaffSection
    'Dim con As SqlConnection
    'Dim adap As SqlDataAdapter
    'Dim cmd As SqlCommand
    'Dim ds As DataSet

    Private Sub StaffSection_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        Dim res = MessageBox.Show("Close the Software?", "Confirm Close", MessageBoxButtons.YesNo, MessageBoxIcon.Error)
        If res = Windows.Forms.DialogResult.Yes Then
            e.Cancel = False
        Else
            e.Cancel = True
        End If
    End Sub

    Private Sub StaffSection_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'open database connection
        'con = New SqlConnection("Data Source=PAA-PC\SQLEXPRESS;Initial Catalog=dbSIMS;Integrated Security=True")
        'con.Open()

        If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
        ConnectionModule.con.Open()

        'display current loguser
        Me.ToolStripStatusUserShow.Text = Login_Form.TextBoxUsername.Text
        Me.ToolStripLabelDesignation.Text = Login_Form.RadioButtonUser.Text

        ' display system current date and time
        Me.lbl_datetimeshow.Text = System.DateTime.Today.ToLongDateString + " " & System.DateTime.Now.ToLongTimeString
    End Sub

    Private Sub AboutSIMDToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AboutSIMDToolStripMenuItem.Click
        'call about form
        About_SIMS.MdiParent = Me
        About_SIMS.Show()
    End Sub

    Private Sub ChangePasswordToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ChangePasswordToolStripMenuItem.Click
        'call the change password form
        PasswordChange.MdiParent = Me
        PasswordChange.Show()
    End Sub

    Private Sub ForgottenPasswordToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ForgottenPasswordToolStripMenuItem.Click
        'call forgetten password form
        'forgetpassword.MdiParent = Me
        'forgetpassword.Show()
    End Sub

    Private Sub StudentAssessmentToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SearchStudentToolStripMenuItem.Click
        'call search student form
        AdvancedSearch.MdiParent = Me
        AdvancedSearch.Show()
        AdvancedSearch.Dock = DockStyle.None

    End Sub

    Private Sub ToolStripMenuItemLock_Click(sender As Object, e As EventArgs)
        'disable all menuitems in current section
        'display login screen for user to sign in again
        Login_Form.Show()
        Me.Hide()
    End Sub

    Private Sub ToolStripMenuItemLogOff_Click(sender As Object, e As EventArgs) Handles ToolStripMenuItemLogOff.Click
        Dim logout = MessageBox.Show("Are you sure you want to log out?", "Confirm Log Out", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If logout = Windows.Forms.DialogResult.Yes Then
            Login_Form.Show()
            Me.Hide()
        ElseIf logout = Windows.Forms.DialogResult.No Then
            Me.Show()
        End If
    End Sub

    Private Sub ToolStripMenuItemExit_Click(sender As Object, e As EventArgs) Handles ToolStripMenuItemExit.Click
        Dim close = MessageBox.Show("Close the software", "Confirm Close", MessageBoxButtons.OKCancel, MessageBoxIcon.Question)
        If close = Windows.Forms.DialogResult.OK Then
            Application.Exit()
        ElseIf close = Windows.Forms.DialogResult.Cancel Then
            Me.Show()
        End If
    End Sub

    Private Sub changAccountSettingsStripMenuItem_Click(sender As Object, e As EventArgs) Handles changAccountSettingsStripMenuItem.Click
        MsgBox("Please, you are requested to see your system administrator to make any changes to your account( Password, Username, etc.", MsgBoxStyle.Information + MsgBoxStyle.OkOnly)
    End Sub

    Private Sub DialyAttendanceToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DialyAttendanceToolStripMenuItem.Click

    End Sub

    Private Sub ViewStudentProfileToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ViewStudentProfileToolStripMenuItem.Click

    End Sub
End Class
