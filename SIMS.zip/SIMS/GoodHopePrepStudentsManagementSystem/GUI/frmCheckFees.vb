﻿Imports System.Data.SqlClient

Public Class frmCheckFees

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub txtSID_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Public Sub GetData()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()

            com1 = New SqlCommand("SELECT dbo.Students.ID, dbo.Students.RegistrationNumber, (dbo.Students.FirstName + ' ' + dbo.Students.MiddleName + ' ' + dbo.Students.LastName) AS SName, dbo.Students.Gender, dbo.Students.Class, dbo.SchoolFees.Year, dbo.SchoolFees.Term, dbo.SchoolFees.Amount, dbo.SchoolFees.DatePaid FROM dbo.SchoolFees INNER JOIN dbo.Students ON dbo.SchoolFees.StudentID=dbo.Students.ID order by ID ASC", ConnectionModule.con)
            dr = com1.ExecuteReader(CommandBehavior.CloseConnection)
            dgv.Rows.Clear()
            While (dr.Read() = True)
                dgv.Rows.Add(dr(0), dr(1), dr(2), dr(3), dr(4), dr(5), dr(6), dr(7), dr(8))
            End While
            con.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error at getdata", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub frmCheckFees_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        GetData()
    End Sub

    Private Sub txtStudentName_TextChanged(sender As Object, e As EventArgs) Handles txtStudentName.TextChanged
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()

            com1 = New SqlCommand("SELECT dbo.Students.ID, dbo.Students.RegistrationNumber, (dbo.Students.FirstName + ' ' + dbo.Students.MiddleName + ' ' + dbo.Students.LastName) AS SName, dbo.Students.Gender, dbo.Students.Class, dbo.SchoolFees.Year, dbo.SchoolFees.Term, dbo.SchoolFees.Amount, dbo.SchoolFees.DatePaid FROM dbo.SchoolFees INNER JOIN dbo.Students ON dbo.SchoolFees.StudentID=dbo.Students.ID where students.FirstName like '%" & txtStudentName.Text & "%' order by [DatePaid] ASC", ConnectionModule.con)
            dr = com1.ExecuteReader(CommandBehavior.CloseConnection)
            dgv.Rows.Clear()
            While (dr.Read() = True)
                dgv.Rows.Add(dr(0), dr(1), dr(2), dr(3), dr(4), dr(5), dr(6), dr(7), dr(8))
            End While
            con.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error at name", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub txtRegNo_TextChanged(sender As Object, e As EventArgs) Handles txtRegNo.TextChanged
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()

            com1 = New SqlCommand("SELECT dbo.Students.ID, dbo.Students.RegistrationNumber, (dbo.Students.FirstName + ' ' + dbo.Students.MiddleName + ' ' + dbo.Students.LastName) AS SName, dbo.Students.Gender, dbo.Students.Class, dbo.SchoolFees.Year, dbo.SchoolFees.Term, dbo.SchoolFees.Amount, dbo.SchoolFees.DatePaid FROM dbo.SchoolFees INNER JOIN dbo.Students ON dbo.SchoolFees.StudentID=dbo.Students.ID where students.RegistrationNumber like '%" & txtRegNo.Text & "%' order by [DatePaid] ASC", ConnectionModule.con)
            dr = com1.ExecuteReader(CommandBehavior.CloseConnection)
            dgv.Rows.Clear()
            While (dr.Read() = True)
                dgv.Rows.Add(dr(0), dr(1), dr(2), dr(3), dr(4), dr(5), dr(6), dr(7), dr(8))
            End While
            con.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub txtYear_TextChanged(sender As Object, e As EventArgs) Handles txtYear.TextChanged
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()

            com1 = New SqlCommand("SELECT dbo.Students.ID, dbo.Students.RegistrationNumber, (dbo.Students.FirstName + ' ' + dbo.Students.MiddleName + ' ' + dbo.Students.LastName) AS SName, dbo.Students.Gender, dbo.Students.Class, dbo.SchoolFees.Year, dbo.SchoolFees.Term, dbo.SchoolFees.Amount, dbo.SchoolFees.DatePaid FROM dbo.SchoolFees INNER JOIN dbo.Students ON dbo.SchoolFees.StudentID=dbo.Students.ID where SchoolFees.Year like '%" & txtYear.Text & "%' order by [DatePaid] ASC", ConnectionModule.con)
            dr = com1.ExecuteReader(CommandBehavior.CloseConnection)
            dgv.Rows.Clear()
            While (dr.Read() = True)
                dgv.Rows.Add(dr(0), dr(1), dr(2), dr(3), dr(4), dr(5), dr(6), dr(7), dr(8))
            End While
            con.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error at year", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub txtTerm_TextChanged(sender As Object, e As EventArgs) Handles txtTerm.TextChanged
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()

            com1 = New SqlCommand("SELECT dbo.Students.ID, dbo.Students.RegistrationNumber, (dbo.Students.FirstName + ' ' + dbo.Students.MiddleName + ' ' + dbo.Students.LastName) AS SName, dbo.Students.Gender, dbo.Students.Class, dbo.SchoolFees.Year, dbo.SchoolFees.Term, dbo.SchoolFees.Amount, dbo.SchoolFees.DatePaid FROM dbo.SchoolFees INNER JOIN dbo.Students ON dbo.SchoolFees.StudentID=dbo.Students.ID where SchoolFees.Term like '%" & txtTerm.Text & "%' order by [DatePaid] ASC", ConnectionModule.con)
            dr = com1.ExecuteReader(CommandBehavior.CloseConnection)
            dgv.Rows.Clear()
            While (dr.Read() = True)
                dgv.Rows.Add(dr(0), dr(1), dr(2), dr(3), dr(4), dr(5), dr(6), dr(7), dr(8))
            End While
            con.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        txtYear.Clear()
        txtStudentName.Clear()
        txtTerm.Clear()
        txtRegNo.Clear()
        GetData()
    End Sub
End Class