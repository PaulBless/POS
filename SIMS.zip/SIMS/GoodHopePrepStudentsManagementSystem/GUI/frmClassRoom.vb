﻿Imports System.Data.SqlClient

Public Class frmClassRoom

    Private Sub btn_Cancel_Student_Form_Click(sender As Object, e As EventArgs) Handles btnDelete.Click

        If ID.Text = String.Empty Then MsgBox("Invalid record selection, check..", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "SIMS Error") : Exit Sub

        If MessageBox.Show("Delete selected class ---'" + txtRoom.Text + "'---", "Confirmation", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) = DialogResult.OK Then
            Try
                If con.State = ConnectionState.Open Then con.Close()
                con.Open()
                com1 = New SqlCommand("delete from classroom where ID='" & dgv.SelectedRows(0).Cells(0).Value & "'", ConnectionModule.con)
                com1.ExecuteNonQuery()
                MessageBox.Show("Record deleted.", "SIMS", MessageBoxButtons.OK, MessageBoxIcon.Information)
                com1.Dispose()
                con.Close()
                'clear controls
                ID.Clear()
                txtRoom.Clear()
                cboDept.ResetText()
                GetClassRooms()

            Catch ex As Exception
                MessageBox.Show(ex.Message)
            End Try

        Else
            MessageBox.Show("Operation cancelled by user", "SIMS", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If


    End Sub

    Private Sub btn_SaveStudentRecord_Click(sender As Object, e As EventArgs) Handles btn_SaveStudentRecord.Click
        Try
            If cboDept.Text = "" Then MsgBox("Specify department", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "Error") : Exit Sub
            If txtRoom.Text = "" Then MsgBox("Enter class room", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "Error") : Exit Sub

            'check record exists
            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            com1 = New SqlCommand("select * from classroom where dept='" & cboDept.Text & "' and room='" & (txtRoom.Text) & "'", ConnectionModule.con)
            dr = com1.ExecuteReader(CommandBehavior.CloseConnection)
            If dr.Read() = True Then
                dr.Close()
                con.Close()
                MsgBox("Record Exists.. Cannot save duplicate record..." + vbCrLf + "NB:- Please update the record..", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "SMIS") : Exit Sub
            Else
                If con.State = ConnectionState.Open Then con.Close()
                com1 = New SqlCommand("insert into ClassRoom(Dept,Room) values (@d1,@d2)", con)
                com1.Parameters.Add("@d1", SqlDbType.NVarChar).Value = cboDept.Text
                com1.Parameters.Add("@d2", SqlDbType.NVarChar).Value = txtRoom.Text
                con.Open()
                com1.ExecuteNonQuery()
                MessageBox.Show("Class room saved.", "SMIS", MessageBoxButtons.OK, MessageBoxIcon.Information)
                com1.Dispose()  'dispose the command
                con.Close()     'close the db connection
                'clear controls
                ID.Clear()
                txtRoom.Clear()
                cboDept.ResetText()
                GetClassRooms()
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub
    Private Sub GetClassRooms()
        Try
            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            com1 = New SqlCommand("select * from classroom", con)
            dr = com1.ExecuteReader(CommandBehavior.CloseConnection)
            dgv.Rows.Clear()
            While dr.Read() = True
                dgv.Rows.Add(dr(0), dr(1), dr(2))
            End While
            'dr.Close()
            con.Close()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Public Sub GetDepartment()
        Try
            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            dset = New Data.DataSet()
            adapter = New SqlDataAdapter()
            adapter.SelectCommand = New SqlCommand("select name from tbldepartment order by deptid asc", ConnectionModule.con)
            dset.Clear()
            adapter.Fill(dset, "tbldepartment")
            cboDept.DataSource = dset.Tables("tbldepartment")
            cboDept.DisplayMember = "name"
            cboDept.Refresh()
            cboDept.SelectedIndex = -1
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at get dept")
            con.Close()
        End Try
    End Sub

    Private Sub btn_Refresh_form_Click(sender As Object, e As EventArgs) Handles btn_Refresh_form.Click
        If ID.Text = String.Empty Then MsgBox("Invalid record selection, check..", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "SIMS Error") : Exit Sub

        If MsgBox("Are you sure you want to update this record..", MsgBoxStyle.Exclamation + MsgBoxStyle.OkCancel, "Confirmation") = DialogResult.OK Then
            Try
                If con.State = ConnectionState.Open Then con.Close()
                con.Open()
                com1 = New SqlCommand("update ClassRoom set Dept=@d1, Room=@d2 where ID='" & dgv.SelectedRows(0).Cells(0).Value & "'", con)
                com1.Parameters.Add("@d1", SqlDbType.NVarChar).Value = cboDept.Text
                com1.Parameters.Add("@d2", SqlDbType.NVarChar).Value = txtRoom.Text
                com1.ExecuteNonQuery()

                MessageBox.Show("Record updated.", "SIMS", MessageBoxButtons.OK, MessageBoxIcon.Information)
                com1.Dispose()
                con.Close()
                'clear controls
                ID.Clear()
                txtRoom.Clear()
                cboDept.ResetText()
                GetClassRooms()

            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End If

    End Sub

  Private Sub frmClassRoom_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        GetClassRooms()
        ActiveControl = txtRoom
    End Sub

    Private Sub dgv_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv.CellClick
        dgv.SelectAll()
    End Sub

    Private Sub dgv_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv.CellContentClick
        Try
            ID.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(0).Value
            cboDept.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(1).Value.ToString()
            txtRoom.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(2).Value.ToString()
            btn_SaveStudentRecord.Enabled = False
            btnDelete.Enabled = True
            btn_Refresh_form.Enabled = True

        Catch ex As Exception

        End Try
    End Sub

    Private Sub txtRoom_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtRoom.KeyPress
        Select Case Asc(e.KeyChar)
            Case 8, 32, 65 To 90, 97 To 122, 48 To 57
                e.Handled = False
            Case Else
                e.Handled = True
        End Select
    End Sub

    Private Sub txtRoom_TextChanged(sender As Object, e As EventArgs) Handles txtRoom.TextChanged

    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click

    End Sub

    Private Sub cboDept_DropDown(sender As Object, e As EventArgs) Handles cboDept.DropDown
        GetDepartment()
    End Sub
End Class