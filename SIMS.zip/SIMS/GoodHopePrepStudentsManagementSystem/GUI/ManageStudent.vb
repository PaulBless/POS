﻿Imports System.Data.SqlClient

Public Class ManageStudent

    Public Sub GetData()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            'query = "select "
            Dim cmd = New SqlCommand("SELECT RTRIM(ID),RTRIM(RegistrationNumber),RTRIM(FirstName), RTRIM(MiddleName), RTRIM(LastName), RTRIM(DOB),RTRIM(Age),RTRIM(Department),RTRIM(Class),RTRIM(Region),RTRIM(District),RTRIM(Nationality),RTRIM(HouseAddress),RTRIM(ContactName),RTRIM(ContactNumber),RTRIM(ContactAddress),RTRIM(ContactOccupation),RTRIM(ContactRelation),RTRIM(ContactEmail),RTRIM(ContactWorkNo),RTRIM(Gender),RTRIM(Title),RTRIM(Hometown),RTRIM(Religion),RTRIM(RegistrationDate) from Students order by ID ASC", ConnectionModule.con)
            Dim rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection)
            dgv.Rows.Clear()
            While (rdr.Read() = True)
                'dgv.AutoGenerateColumns = False
                dgv.Rows.Add(rdr(0), rdr(1), rdr(2), rdr(3) + "  " + rdr(4), rdr(5), rdr(6), rdr(7), rdr(8), rdr(9), rdr(10), rdr(11), rdr(12), rdr(13), rdr(14), rdr(15), rdr(16), rdr(17), rdr(18), rdr(19), rdr(20), rdr(21), rdr(22), rdr(23), rdr(24))
            End While
            con.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub txtDept_TextChanged(sender As Object, e As EventArgs) Handles txtDept.TextChanged
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()

            Dim cmd = New SqlCommand("SELECT RTRIM(ID),RTRIM(RegistrationNumber),RTRIM(FirstName), RTRIM(MiddleName), RTRIM(LastName), RTRIM(DOB),RTRIM(Age),RTRIM(Department),RTRIM(Class),RTRIM(Region),RTRIM(District),RTRIM(Nationality),RTRIM(HouseAddress),RTRIM(ContactName),RTRIM(ContactNumber),RTRIM(ContactAddress),RTRIM(ContactOccupation),RTRIM(ContactRelation),RTRIM(ContactEmail),RTRIM(ContactWorkNo),RTRIM(Gender),RTRIM(Title),RTRIM(Hometown),RTRIM(RegistrationDate),RTRIM(Religion) from Students where Department like '%" & txtDept.Text & "%' order by Department ASC", ConnectionModule.con)
            Dim rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection)
            dgv.Rows.Clear()
            While (rdr.Read() = True)
                dgv.Rows.Add(rdr(0), rdr(1), rdr(2), rdr(3) + "  " + rdr(4), rdr(5), rdr(6), rdr(7), rdr(8), rdr(9), rdr(10), rdr(11), rdr(12), rdr(13), rdr(14), rdr(15), rdr(16), rdr(17), rdr(18), rdr(19), rdr(20), rdr(21), rdr(22), rdr(23), rdr(24))
            End While
            con.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub txtRegNo_TextChanged(sender As Object, e As EventArgs) Handles txtRegNo.TextChanged
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()

            Dim cmd = New SqlCommand("SELECT RTRIM(ID),RTRIM(RegistrationNumber),RTRIM(FirstName), RTRIM(MiddleName), RTRIM(LastName), RTRIM(DOB),RTRIM(Age),RTRIM(Department),RTRIM(Class),RTRIM(Region),RTRIM(District),RTRIM(Nationality),RTRIM(HouseAddress),RTRIM(ContactName),RTRIM(ContactNumber),RTRIM(ContactAddress),RTRIM(ContactOccupation),RTRIM(ContactRelation),RTRIM(ContactEmail),RTRIM(ContactWorkNo),RTRIM(Gender),RTRIM(Title),RTRIM(Hometown),RTRIM(RegistrationDate),RTRIM(Religion) from Students where RegistrationNumber like '%" & txtRegNo.Text & "%' order by FirstName ASC", ConnectionModule.con)
            Dim rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection)
            dgv.Rows.Clear()
            While (rdr.Read() = True)
                dgv.Rows.Add(rdr(0), rdr(1), rdr(2), rdr(3) + "  " + rdr(4), rdr(5), rdr(6), rdr(7), rdr(8), rdr(9), rdr(10), rdr(11), rdr(12), rdr(13), rdr(14), rdr(15), rdr(16), rdr(17), rdr(18), rdr(19), rdr(20), rdr(21), rdr(22), rdr(23), rdr(24))
            End While
            con.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub txtStudentName_TextChanged(sender As Object, e As EventArgs) Handles txtStudentName.TextChanged
      Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()

            Dim cmd = New SqlCommand("SELECT RTRIM(ID),RTRIM(RegistrationNumber),RTRIM(FirstName), RTRIM(MiddleName), RTRIM(LastName), RTRIM(DOB),RTRIM(Age),RTRIM(Department),RTRIM(Class),RTRIM(Region),RTRIM(District),RTRIM(Nationality),RTRIM(HouseAddress),RTRIM(ContactName),RTRIM(ContactNumber),RTRIM(ContactAddress),RTRIM(ContactOccupation),RTRIM(ContactRelation),RTRIM(ContactEmail),RTRIM(ContactWorkNo),RTRIM(Gender),RTRIM(Title),RTRIM(Hometown),RTRIM(RegistrationDate),RTRIM(Religion) from Students where FirstName like '%" & txtStudentName.Text & "%' order by FirstName ASC", ConnectionModule.con)
            Dim rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection)
            dgv.Rows.Clear()
            While (rdr.Read() = True)
                dgv.Rows.Add(rdr(0), rdr(1), rdr(2), rdr(3) + "  " + rdr(4), rdr(5), rdr(6), rdr(7), rdr(8), rdr(9), rdr(10), rdr(11), rdr(12), rdr(13), rdr(14), rdr(15), rdr(16), rdr(17), rdr(18), rdr(19), rdr(20), rdr(21), rdr(22), rdr(23), rdr(24))
            End While
            con.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        txtRegNo.Clear()
        txtDept.Clear()
        txtStudentName.Clear()
        GetData()
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
        End Sub

    Private Sub ManageStudent_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        GetData()
    End Sub

    Private Sub dgv_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv.CellContentClick

    End Sub
End Class