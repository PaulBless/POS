﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Text


Public Class Login_Form

   
    Dim con As SqlConnection
    Dim cmd As SqlCommand
    Dim dr As SqlDataReader
    Dim adap As SqlDataAdapter
    Dim ds As DataSet

    Dim sql As String

    Private Sub Login_Form_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        'con = New SqlConnection("Data Source=PAA-PC\SQLEXPRESS;Initial Catalog=dbSIMS;Integrated Security=True")
        'con.Open()

    End Sub

    Private Sub ButtonCancel_Click(sender As Object, e As EventArgs) Handles ButtonCancel.Click
        'close the form 
        Application.Exit()
    End Sub

    Private Sub ButtonLogin_Click(sender As Object, e As EventArgs) Handles ButtonLogin.Click
        'prompt user of credentials
        'alert user to input login information
        If TextBoxUsername.Text = "" Then
            MessageBox.Show("Please enter user name ", "User Name Error", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1)
            TextBoxUsername.Focus()
            Exit Sub
        ElseIf TextBoxPassword.Text = "" Then
            MessageBox.Show("Please enter password ", "Password Error", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1)
            TextBoxPassword.Focus()
            Exit Sub
        ElseIf RadioButtonAdmin.Checked = False And RadioButtonUser.Checked = False Then
            MessageBox.Show("Please select role", "Role Error", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1)
            Exit Sub
        End If

        'If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
        'ConnectionModule.con.Open()

        'this section of code fires to
        'login user based on the radiobutton checked
        'used to determine the role of the user
        If RadioButtonAdmin.Checked = True Then

            adap = New SqlDataAdapter("Select Username,Password From AdminLogin Where (Username = '" & TextBoxUsername.Text & "' ) AND (Password = '" & TextBoxPassword.Text & "')", con)
            ds = New DataSet()
            adap.Fill(ds, "Login")
            If (ds.Tables("Login").Rows.Count > 0) Then
                'show admin section
                'if username and password correct
                AdminSection.Show()
                Me.Hide()

                'clear all the form controls
                'to enable new entry
                TextBoxUsername.Clear()
                TextBoxPassword.Clear()
                RadioButtonAdmin.Checked = False
                RadioButtonUser.Checked = False
                'set the textbox field focus
                TextBoxUsername.Focus()
            Else
                'username and password not same in the database
                MessageBox.Show("Username or Password Incorrect! Retry... ", "SIMS Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1)
                'clear all the form controls
                TextBoxUsername.Clear()
                TextBoxPassword.Clear()
                RadioButtonAdmin.Checked = False
                RadioButtonUser.Checked = False
                'set the textbox field focus
                TextBoxUsername.Focus()
            End If
            Exit Sub
        ElseIf RadioButtonUser.Checked = True Then
            adap = New SqlDataAdapter("Select Username,Password From UsersLogin Where (Username = '" & TextBoxUsername.Text & "' ) AND (Password = '" & TextBoxPassword.Text & "')", con)
            ds = New DataSet()
            adap.Fill(ds, "Login")
            If (ds.Tables("Login").Rows.Count > 0) Then
                'show user section
                'if username and password correct or found in database
                StaffSection.Show()
                Me.Hide()
                
                'clear all the form controls
                TextBoxUsername.Clear()
                TextBoxPassword.Clear()
                RadioButtonAdmin.Checked = False
                RadioButtonUser.Checked = False
                'set the textbox field focus
                TextBoxUsername.Focus()
            Else
                'show error message if username and password not found in database
                MessageBox.Show("Username or Password Incorrect! Retry... ", "SIMS Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1)
                'clear all the form controls
                TextBoxUsername.Clear()
                TextBoxPassword.Clear()
                RadioButtonAdmin.Checked = False
                RadioButtonUser.Checked = False
                'set the textbox field focus
                TextBoxUsername.Focus()
            End If
            Exit Sub
        End If

        'close connection to the database
        con.Close()
    End Sub
    Private Sub LinkLabelForgetPassword_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabelForgetPassword.LinkClicked
        'show forget password form 
        'for user to retrieve his/her lost password
        frmPasswordRecovery.ShowDialog()
    End Sub

    Private Sub RadioButtonAdmin_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButtonAdmin.CheckedChanged

    End Sub
End Class