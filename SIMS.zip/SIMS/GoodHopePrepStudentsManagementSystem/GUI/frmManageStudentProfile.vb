﻿Imports System.Data.SqlClient

Public Class frmManageStudentProfile

    Public Sub GetData()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            Dim cmd = New SqlCommand("SELECT RTRIM(ID),RTRIM(RegistrationNumber),RTRIM(FirstName), RTRIM(MiddleName), RTRIM(LastName), RTRIM(DOB),RTRIM(Age),RTRIM(Department),RTRIM(Class),RTRIM(Region),RTRIM(District),RTRIM(Nationality),RTRIM(HouseAddress),RTRIM(ContactName),RTRIM(ContactNumber),RTRIM(ContactAddress),RTRIM(ContactOccupation),RTRIM(ContactRelation),RTRIM(ContactEmail),RTRIM(ContactWorkNo),RTRIM(Gender),RTRIM(Title),RTRIM(Hometown),RTRIM(Religion),RTRIM(RegistrationDate) from Students order by ID ASC ", ConnectionModule.con)
            Dim rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection)
            dgv.Rows.Clear()
            While (rdr.Read() = True)
                dgv.Rows.Add(rdr(0), rdr(1), rdr(2), rdr(3), rdr(4), rdr(5), rdr(6), rdr(7), rdr(8), rdr(9), rdr(10), rdr(11), rdr(12), rdr(13), rdr(14), rdr(15), rdr(16), rdr(17), rdr(18), rdr(19), rdr(20), rdr(21), rdr(22), rdr(23), rdr(24))
            End While
            con.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error at getdata", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub frmManageStudentProfile_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        GetData()

    End Sub

    Sub ClearMe()
        txtSID.Clear()
        txtRegNo.Clear()
        txt_Student_Contact_Address.Clear()
        txt_Student_Contact_Email.Clear()
        txt_Student_Contact_Name.Clear()
        txt_Student_Contact_Number.Clear()
        txt_Student_Contact_WorkNo.Clear()
        txt_Student_Hometown.Clear()
        txt_Student_House_Number.Clear()
        txtFirstName.Clear()
        txtLastname.Clear()
        txtMDName.Clear()
        cbo_Student_Nationality.ResetText()
        cbo_Student_Region.ResetText()
        txt_student_age.Clear()
        cbo_Student_Contact_Occupation.ResetText()
        cboTitle.ResetText()
        cbo_Student_District.ResetText()
        cbo_Student_Religion.ResetText()
        dtpicker_Student_DateOfBirth.Text = Today
        dtpDate.Text = Today
        cboDepartment.ResetText()
        cboClass.ResetText()
        cbo_Student_Contact_Relation.ResetText()
        cboGender.ResetText()

    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        If txtSID.Text = "" Then
            MessageBox.Show("Invalid record selection, Please select a student", "SIMS-Error", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Exit Sub
        Else
            Try
                If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                ConnectionModule.con.Open()
                If MsgBox("Are You Sure You Want To Update Information?", MsgBoxStyle.YesNo + MsgBoxStyle.Question, "SIMS-Confirmation") = MsgBoxResult.Yes Then
                    Dim update As SqlCommand = New SqlCommand("update Students set FirstName=@d2, MiddleName=@d3, LastName=@d4, DOB=@d5, Age=@d6, Department=@d7, Class=@d8, Region=@d9, District=@d10, Nationality=@d11, HouseAddress=@d12, ContactName=@d13, ContactNumber=@d14, ContactAddress=@d15, ContactOccupation=@d16, ContactRelation=@d17, ContactEmail=@d18, ContactWorkNo=@d19, Gender=@d20, Title=@d21, Hometown=@d22, Religion=@d24 where ID='" & dgv.SelectedRows(0).Cells(0).Value & "'", ConnectionModule.con)
                    update.Parameters.AddWithValue("@d2", txtFirstName.Text)
                    update.Parameters.AddWithValue("@d3", txtMDName.Text)
                    update.Parameters.AddWithValue("@d4", txtLastname.Text)
                    update.Parameters.AddWithValue("@d5", dtpicker_Student_DateOfBirth.Text.ToString)
                    update.Parameters.AddWithValue("@d6", txt_student_age.Text)
                    update.Parameters.AddWithValue("@d7", cboDepartment.Text)
                    update.Parameters.AddWithValue("@d8", cboClass.Text)
                    update.Parameters.AddWithValue("@d9", cbo_Student_Region.Text)
                    update.Parameters.AddWithValue("@d10", cbo_Student_District.Text)
                    update.Parameters.AddWithValue("@d11", cbo_Student_Nationality.Text)
                    update.Parameters.AddWithValue("@d12", txt_Student_House_Number.Text)
                    update.Parameters.AddWithValue("@d13", txt_Student_Contact_Name.Text)
                    update.Parameters.AddWithValue("@d14", txt_Student_Contact_Number.Text)
                    update.Parameters.AddWithValue("@d15", txt_Student_Contact_Address.Text)
                    update.Parameters.AddWithValue("@d16", cbo_Student_Contact_Occupation.Text)
                    update.Parameters.AddWithValue("@d17", cbo_Student_Contact_Relation.Text)
                    update.Parameters.AddWithValue("@d18", txt_Student_Contact_Email.Text)
                    update.Parameters.AddWithValue("@d19", txt_Student_Contact_WorkNo.Text)
                    update.Parameters.AddWithValue("@d20", cboGender.Text)
                    update.Parameters.AddWithValue("@d21", cboTitle.Text)
                    update.Parameters.AddWithValue("@d22", txt_Student_Hometown.Text)
                    update.Parameters.AddWithValue("@d24", cbo_Student_Religion.Text)
                    update.ExecuteNonQuery()

                    MessageBox.Show("Successfully Updated Student Record.", "Success!", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    GetData()
                    ClearMe()
                    btnDelete.Enabled = False
                    btnSave.Enabled = False

                End If

            Catch ex As Exception
                MessageBox.Show(ex.Message)
            Finally
                con.Close()

            End Try


        End If

    End Sub

    Private Sub dgv_CellContentDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv.CellContentDoubleClick
        Try
            If Not dgv.Rows(dgv.CurrentRow.Index).Cells(18).Value = String.Empty Then
                txt_Student_Contact_Email.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(18).Value.ToString()
            Else
                txt_Student_Contact_Email.Text = ""
            End If
            If Not dgv.Rows(dgv.CurrentRow.Index).Cells(19).Value = String.Empty Then
                txt_Student_Contact_WorkNo.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(19).Value.ToString()
            Else
                txt_Student_Contact_WorkNo.Text = ""
            End If
            If Not dgv.Rows(dgv.CurrentRow.Index).Cells(3).Value = String.Empty Then
                txtMDName.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(3).Value.ToString()
            Else
                txtMDName.Text = ""
            End If

            txtSID.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(0).Value
            txtRegNo.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(1).Value.ToString()
            txtFirstName.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(2).Value.ToString()
            'txtMDName.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(3).Value.ToString()
            txtLastname.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(4).Value.ToString()
            dtpicker_Student_DateOfBirth.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(5).Value
            txt_student_age.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(6).Value
            cboDepartment.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(7).Value.ToString()
            cboClass.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(8).Value.ToString()
            cbo_Student_Region.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(9).Value.ToString()
            cbo_Student_District.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(10).Value.ToString()
            cbo_Student_Nationality.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(11).Value.ToString()
            txt_Student_House_Number.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(12).Value.ToString()
            txt_Student_Contact_Name.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(13).Value.ToString()
            txt_Student_Contact_Number.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(14).Value.ToString()
            txt_Student_Contact_Address.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(15).Value.ToString()
            cbo_Student_Contact_Occupation.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(16).Value.ToString()
            cbo_Student_Contact_Relation.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(17).Value.ToString()
            'txt_Student_Contact_Email.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(18).Value.ToString()
            'txt_Student_Contact_WorkNo.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(19).Value.ToString()
            cboGender.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(20).Value.ToString()
            cboTitle.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(21).Value.ToString()
            txt_Student_Hometown.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(22).Value.ToString()
            cbo_Student_Religion.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(23).Value.ToString()
            dtpDate.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(24).Value
            btnDelete.Enabled = True
            btnSave.Enabled = True

        Catch ex As Exception
            MsgBox(ex.ToString())
        End Try
    End Sub

    Private Sub dgv_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv.CellClick
        dgv.SelectAll()
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        If MsgBox("Clear the form?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "SIMS") = MsgBoxResult.Yes Then
            ClearMe()
        End If
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub

    Private Sub dtpicker_Student_DateOfBirth_ValueChanged(sender As Object, e As EventArgs) Handles dtpicker_Student_DateOfBirth.ValueChanged
        'calculate student age from DOB
        Dim studentAge As New Integer
        studentAge = DateTime.Today.Year - dtpicker_Student_DateOfBirth.Value.Year
        txt_student_age.Text = studentAge.ToString
    End Sub

    Private Sub cbo_Student_Title_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboTitle.SelectedIndexChanged
        If cboTitle.SelectedItem = "Master" Then
            cboGender.Items.Clear()
            cboGender.Items.Add("MALE")
            Exit Sub
        End If
        If cboTitle.SelectedItem = "Miss" Then
            cboGender.Items.Clear()
            cboGender.Items.Add("FEMALE")
            Exit Sub
        End If
    End Sub

    Private Sub cboDepartment_DropDown(sender As Object, e As EventArgs) Handles cboDepartment.DropDown
        GetDeptList()
    End Sub
    Public Sub GetDeptList()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            dset = New Data.DataSet()
            adapter = New SqlDataAdapter()
            adapter.SelectCommand = New SqlCommand("select distinct dept from classroom order by dept", ConnectionModule.con)
            dset.Clear()
            adapter.Fill(dset, "classroom")
            cboDepartment.DataSource = dset.Tables("classroom")
            cboDepartment.DisplayMember = "dept"
            cboDepartment.Refresh()
            cboDepartment.SelectedIndex = -1
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at get academic dept")
            con.Close()
        End Try
    End Sub

    Private Sub cbo_Student_Department_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboDepartment.SelectedIndexChanged
        'If cboDepartment.SelectedItem = "KINDERGARTEN" Then
        '    cboClass.Items.Clear()
        '    cboClass.Items.Add("CRECHE")
        '    cboClass.Items.Add("NURSERY 1")
        '    cboClass.Items.Add("NURSERY 2")
        '    cboClass.Items.Add("KG 1")
        '    cboClass.Items.Add("KG 2")
        '    Exit Sub
        'End If

        'If cboDepartment.SelectedItem = "LOWER PRIMARY" Then
        '    cboClass.Items.Clear()
        '    cboClass.Items.Add("PRIMARY 1")
        '    cboClass.Items.Add("PRIMARY 2")
        '    cboClass.Items.Add("PRIMARY 3")
        '    Exit Sub
        'End If

        'If cboDepartment.SelectedItem = "UPPER PRIMARY" Then
        '    cboClass.Items.Clear()
        '    cboClass.Items.Add("PRIMARY 4")
        '    cboClass.Items.Add("PRIMARY 5")
        '    cboClass.Items.Add("PRIMARY 6")
        '    Exit Sub
        'End If

        'If cboDepartment.SelectedItem = "JUNIOR HIGH SCHOOL" Then
        '    cboClass.Items.Clear()
        '    cboClass.Items.Add("JHS 1")
        '    cboClass.Items.Add("JHS 2")
        '    cboClass.Items.Add("JHS 3")
        '    Exit Sub
        'End If

    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        'check invalid record selection
        If txtSID.Text = "" Then
            MessageBox.Show("Invalid record selection, Please select a student", "SIMS-Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Exit Sub
        Else
            If MsgBox("The selected student record will be permanently deleted from the system" + vbNewLine + _
                          "It is not recommended to delete student record because the student history will be truncated." + vbNewLine + _
                          "Continue?", MsgBoxStyle.OkCancel + MsgBoxStyle.Critical, "Confirmation") = MsgBoxResult.Ok Then
                Try
                    If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                    ConnectionModule.con.Open()

                    com = New SqlCommand("delete from Students where ID='" & dgv.SelectedRows(0).Cells(0).Value & "'", con)
                    com.ExecuteNonQuery()
                    MessageBox.Show("Student Record Successfully Deleted", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    btnDelete.Enabled = True
                    btnSave.Enabled = True
                    Exit Sub

                Catch ex As Exception
                    MessageBox.Show(ex.ToString, "error at delete")
                End Try
            Else

            End If
        End If

    End Sub

    Private Sub cbo_Student_District_Click(sender As Object, e As EventArgs) Handles cbo_Student_District.Click
        If cbo_Student_Region.Text = "" Then
            MsgBox("You must select region", , "SIMS")
            Exit Sub
        End If
    End Sub

#Region "get district of each region"
    Sub AddDistricts_Ashanti()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            Dim dst As Data.DataSet = New Data.DataSet
            Dim dtAdpt As SqlDataAdapter = New SqlDataAdapter
            dst.Clear()

            dtAdpt.SelectCommand = New SqlCommand("SELECT ID,Name FROM tblAshantiRegion", ConnectionModule.con)
            dtAdpt.Fill(dst, "tblAshantiRegion")
            cbo_Student_District.DataSource = dst.Tables("tblAshantiRegion")
            cbo_Student_District.DisplayMember = "Name"
            cbo_Student_District.ValueMember = "ID"
            cbo_Student_District.SelectedIndex = -1
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        con.Close()
    End Sub
    Sub AddDistricts_Eastern()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            Dim dst As Data.DataSet = New Data.DataSet
            Dim dtAdpt As SqlDataAdapter = New SqlDataAdapter
            dst.Clear()

            dtAdpt.SelectCommand = New SqlCommand("SELECT ID,Name FROM tblEasternRegion", ConnectionModule.con)
            dtAdpt.Fill(dst, "tblEasternRegion")
            cbo_Student_District.DataSource = dst.Tables("tblEasternRegion")
            cbo_Student_District.DisplayMember = "Name"
            cbo_Student_District.ValueMember = "ID"
            cbo_Student_District.SelectedIndex = -1
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        con.Close()
    End Sub
    Sub AddDistricts_Central()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            Dim dst As Data.DataSet = New Data.DataSet
            Dim dtAdpt As SqlDataAdapter = New SqlDataAdapter
            dst.Clear()

            dtAdpt.SelectCommand = New SqlCommand("SELECT ID,Name FROM tblCentralRegion", ConnectionModule.con)
            dtAdpt.Fill(dst, "tblCentralRegion")
            cbo_Student_District.DataSource = dst.Tables("tblCentralRegion")
            cbo_Student_District.DisplayMember = "Name"
            cbo_Student_District.ValueMember = "ID"
            cbo_Student_District.SelectedIndex = -1
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        con.Close()
    End Sub
    Sub AddDistricts_UpperEast()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            Dim dst As Data.DataSet = New Data.DataSet
            Dim dtAdpt As SqlDataAdapter = New SqlDataAdapter
            dst.Clear()

            dtAdpt.SelectCommand = New SqlCommand("SELECT ID,Name FROM tblUERegion", ConnectionModule.con)
            dtAdpt.Fill(dst, "tblUERegion")
            cbo_Student_District.DataSource = dst.Tables("tblUERegion")
            cbo_Student_District.DisplayMember = "Name"
            cbo_Student_District.ValueMember = "ID"
            cbo_Student_District.SelectedIndex = -1
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        con.Close()
    End Sub
    Sub AddDistricts_BrongAhafo()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            Dim dst As Data.DataSet = New Data.DataSet
            Dim dtAdpt As SqlDataAdapter = New SqlDataAdapter
            dst.Clear()

            dtAdpt.SelectCommand = New SqlCommand("SELECT ID,Name FROM tblBARegion", ConnectionModule.con)
            dtAdpt.Fill(dst, "tblBARegion")
            cbo_Student_District.DataSource = dst.Tables("tblBARegion")
            cbo_Student_District.DisplayMember = "Name"
            cbo_Student_District.ValueMember = "ID"
            cbo_Student_District.SelectedIndex = -1
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        con.Close()
    End Sub
    Sub AddDistricts_Northern()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            Dim dst As Data.DataSet = New Data.DataSet
            Dim dtAdpt As SqlDataAdapter = New SqlDataAdapter
            dst.Clear()

            dtAdpt.SelectCommand = New SqlCommand("SELECT ID,Name FROM tblNorthernRegion", ConnectionModule.con)
            dtAdpt.Fill(dst, "tblNorthernRegion")
            cbo_Student_District.DataSource = dst.Tables("tblNorthernRegion")
            cbo_Student_District.DisplayMember = "Name"
            cbo_Student_District.ValueMember = "ID"
            cbo_Student_District.SelectedIndex = -1
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        con.Close()
    End Sub
    Sub AddDistricts_UpperWest()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            Dim dst As Data.DataSet = New Data.DataSet
            Dim dtAdpt As SqlDataAdapter = New SqlDataAdapter
            dst.Clear()

            dtAdpt.SelectCommand = New SqlCommand("SELECT ID,Name FROM tblUWRegion", ConnectionModule.con)
            dtAdpt.Fill(dst, "tblUWRegion")
            cbo_Student_District.DataSource = dst.Tables("tblUWRegion")
            cbo_Student_District.DisplayMember = "Name"
            cbo_Student_District.ValueMember = "ID"
            cbo_Student_District.SelectedIndex = -1
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        con.Close()
    End Sub
    Sub AddDistricts_Volta()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            Dim dst As Data.DataSet = New Data.DataSet
            Dim dtAdpt As SqlDataAdapter = New SqlDataAdapter
            dst.Clear()

            dtAdpt.SelectCommand = New SqlCommand("SELECT ID,Name FROM tblVoltaRegion", ConnectionModule.con)
            dtAdpt.Fill(dst, "tblVoltaRegion")
            cbo_Student_District.DataSource = dst.Tables("tblVoltaRegion")
            cbo_Student_District.DisplayMember = "Name"
            cbo_Student_District.ValueMember = "ID"
            cbo_Student_District.SelectedIndex = -1
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        con.Close()
    End Sub
    Sub AddDistricts_GreaterAccra()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            Dim dst As Data.DataSet = New Data.DataSet
            Dim dtAdpt As SqlDataAdapter = New SqlDataAdapter
            dst.Clear()

            dtAdpt.SelectCommand = New SqlCommand("SELECT ID,Name FROM tblGARegion", ConnectionModule.con)
            dtAdpt.Fill(dst, "tblGARegion")
            cbo_Student_District.DataSource = dst.Tables("tblAGARegion")
            cbo_Student_District.DisplayMember = "Name"
            cbo_Student_District.ValueMember = "ID"
            cbo_Student_District.SelectedIndex = -1
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        con.Close()
    End Sub
    Sub AddDistricts_Western()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            Dim dst As Data.DataSet = New Data.DataSet
            Dim dtAdpt As SqlDataAdapter = New SqlDataAdapter
            dst.Clear()

            dtAdpt.SelectCommand = New SqlCommand("SELECT ID,Name FROM tblWesternRegion", ConnectionModule.con)
            dtAdpt.Fill(dst, "tblWesternRegion")
            cbo_Student_District.DataSource = dst.Tables("tblWesternRegion")
            cbo_Student_District.DisplayMember = "Name"
            cbo_Student_District.ValueMember = "ID"
            cbo_Student_District.SelectedIndex = -1
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        con.Close()
    End Sub

#End Region

    Private Sub cbo_Student_District_DropDown(sender As Object, e As EventArgs) Handles cbo_Student_District.DropDown
        'set datasource to selected region/district
        If cbo_Student_Region.Text = "ASHANTI" Then
            cbo_Student_District.ResetText()
            AddDistricts_Ashanti()
            Exit Sub
        ElseIf cbo_Student_Region.Text = "BRONG AHAFO" Then
            cbo_Student_District.ResetText()
            AddDistricts_BrongAhafo()
            Exit Sub
        ElseIf cbo_Student_Region.Text = "CENTRAL" Then
            cbo_Student_District.ResetText()
            AddDistricts_Central()
            Exit Sub
        ElseIf cbo_Student_Region.Text = "EASTERN" Then
            cbo_Student_District.ResetText()
            AddDistricts_Eastern()
            Exit Sub
        ElseIf cbo_Student_Region.Text = "GREATER ACCRA" Then
            cbo_Student_District.ResetText()
            AddDistricts_GreaterAccra()
            Exit Sub
        ElseIf cbo_Student_Region.Text = "NORTHERN" Then
            cbo_Student_District.ResetText()
            AddDistricts_Northern()
            Exit Sub
        ElseIf cbo_Student_Region.Text = "UPPER EAST" Then
            cbo_Student_District.ResetText()
            AddDistricts_UpperEast()
            Exit Sub
        ElseIf cbo_Student_Region.Text = "UPPER WEST" Then
            cbo_Student_District.ResetText()
            AddDistricts_UpperWest()
            Exit Sub
        ElseIf cbo_Student_Region.Text = "VOLTA" Then
            cbo_Student_District.ResetText()
            AddDistricts_Volta()
            Exit Sub
        ElseIf cbo_Student_Region.Text = "WESTERN" Then
            cbo_Student_District.ResetText()
            AddDistricts_Western()
            Exit Sub
        End If
    End Sub

    Private Sub dgv_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv.CellContentClick

    End Sub
    Public Sub ClassListKg()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            dset = New Data.DataSet()
            adapter = New SqlDataAdapter()
            adapter.SelectCommand = New SqlCommand("select distinct room from classroom where Dept='KINDERGARTEN' order by room asc", ConnectionModule.con)
            dset.Clear()
            adapter.Fill(dset, "classroom")
            cboClass.DataSource = dset.Tables("classroom")
            cboClass.DisplayMember = "room"
            ''cboYear.ValueMember = "ID"
            cboClass.Refresh()
            cboClass.SelectedIndex = -1
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at get academic year")
            con.Close()
        End Try
    End Sub
    Public Sub ClassListLp()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            dset = New Data.DataSet()
            adapter = New SqlDataAdapter()
            adapter.SelectCommand = New SqlCommand("select distinct room from classroom where Dept='LOWER PRIMARY' order by room asc", ConnectionModule.con)
            dset.Clear()
            adapter.Fill(dset, "classroom")
            cboClass.DataSource = dset.Tables("classroom")
            cboClass.DisplayMember = "room"
            ''cboYear.ValueMember = "ID"
            cboClass.Refresh()
            cboClass.SelectedIndex = -1
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at get academic year")
            con.Close()
        End Try
    End Sub
    Public Sub ClassListUp()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            dset = New Data.DataSet()
            adapter = New SqlDataAdapter()
            adapter.SelectCommand = New SqlCommand("select distinct room from classroom where Dept='UPPER PRIMARY' order by room asc", ConnectionModule.con)
            dset.Clear()
            adapter.Fill(dset, "classroom")
            cboClass.DataSource = dset.Tables("classroom")
            cboClass.DisplayMember = "room"
            ''cboYear.ValueMember = "ID"
            cboClass.Refresh()
            cboClass.SelectedIndex = -1
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at get academic year")
            con.Close()
        End Try
    End Sub
    Public Sub ClassListJhs()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            dset = New Data.DataSet()
            adapter = New SqlDataAdapter()
            adapter.SelectCommand = New SqlCommand("select distinct room from classroom where Dept='JUNIOR HIGH SCHOOL' order by room asc", ConnectionModule.con)
            dset.Clear()
            adapter.Fill(dset, "classroom")
            cboClass.DataSource = dset.Tables("classroom")
            cboClass.DisplayMember = "room"
            cboClass.Refresh()
            cboClass.SelectedIndex = -1
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at get academic year")
            con.Close()
        End Try
    End Sub

    Private Sub cbo_Student_Class_DropDown(sender As Object, e As EventArgs) Handles cboClass.DropDown
        If cboDepartment.Text = "KINDERGARTEN" Then
            cboClass.ResetText()
            ClassListKg()
            Exit Sub
        ElseIf cboDepartment.Text = "LOWER PRIMARY" Then
            cboClass.ResetText()
            ClassListLp()
            Exit Sub
        ElseIf cboDepartment.Text = "UPPER PRIMARY" Then
            cboClass.ResetText()
            ClassListUp()
            Exit Sub
        ElseIf cboDepartment.Text = "JUNIOR HIGH SCHOOL" Then
            cboClass.ResetText()
            ClassListJhs()
            Exit Sub
        End If
    End Sub

    Private Sub cbo_Student_Class_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboClass.SelectedIndexChanged

    End Sub

    Private Sub cbo_Student_District_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbo_Student_District.SelectedIndexChanged

    End Sub

    Private Sub cbo_Student_Gender_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboGender.SelectedIndexChanged
        'If cboGender.SelectedItem = "MALE" Then
        '    cboTitle.Items.Clear()
        '    cboTitle.Items.Add("Master")
        '    Exit Sub
        'End If

        'If cboGender.SelectedItem = "FEMALE" Then
        '    cboTitle.Items.Clear()
        '    cboTitle.Items.Add("Miss")
        '    Exit Sub
        'End If

    End Sub

    Private Sub txt_Student_Contact_Number_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txt_Student_Contact_Number.KeyPress
        If Asc(e.KeyChar) <> 13 AndAlso Asc(e.KeyChar) <> 8 AndAlso Not IsNumeric(e.KeyChar) AndAlso Asc(e.KeyChar) <> 46 Then
            e.Handled = True
        Else
            e.Handled = False
        End If
    End Sub

    Private Sub txt_Student_Contact_Number_TextChanged(sender As Object, e As EventArgs) Handles txt_Student_Contact_Number.TextChanged

    End Sub

    Private Sub txt_Student_Contact_WorkNo_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txt_Student_Contact_WorkNo.KeyPress
        If Asc(e.KeyChar) <> 13 AndAlso Asc(e.KeyChar) <> 8 AndAlso Not IsNumeric(e.KeyChar) AndAlso Asc(e.KeyChar) <> 46 Then
            e.Handled = True
        Else
            e.Handled = False
        End If
    End Sub

    Private Sub txt_Student_Contact_Email_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txt_Student_Contact_Email.KeyPress
        Select Case Asc(e.KeyChar)
            Case 8, 45, 46, 64, 127, 48 To 57, 65 To 90, 97 To 122
                e.Handled = False
            Case Else
                e.Handled = True
        End Select
    End Sub

    Private Sub txt_Student_Contact_Email_TextChanged(sender As Object, e As EventArgs) Handles txt_Student_Contact_Email.TextChanged

    End Sub

    Private Sub txtRegNo_TextChanged(sender As Object, e As EventArgs) Handles txtRegNo.TextChanged

    End Sub

    Private Sub txtFirstName_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtFirstName.KeyPress
        Select Case Asc(e.KeyChar)
            Case 8, 32, 65 To 90, 97 To 122
                e.Handled = False
            Case Else
                e.Handled = True
        End Select
    End Sub

    Private Sub txtFirstName_TextChanged(sender As Object, e As EventArgs) Handles txtFirstName.TextChanged

    End Sub

    Private Sub txtLastname_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtLastname.KeyPress
        Select Case Asc(e.KeyChar)
            Case 8, 32, 45, 65 To 90, 97 To 122
                e.Handled = False
            Case Else
                e.Handled = True
        End Select
    End Sub

    Private Sub txtMDName_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtMDName.KeyPress
        Select Case Asc(e.KeyChar)
            Case 8, 32, 65 To 90, 97 To 122
                e.Handled = False
            Case Else
                e.Handled = True
        End Select
    End Sub

    Private Sub txt_Student_Contact_Address_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txt_Student_Contact_Address.KeyPress
        Select Case Asc(e.KeyChar)
            Case 48 To 57, 8, 32, 65 To 90, 97 To 122
                e.Handled = False
            Case Else
                e.Handled = True
        End Select
    End Sub

    Private Sub txt_Student_Contact_Address_TextChanged(sender As Object, e As EventArgs) Handles txt_Student_Contact_Address.TextChanged

    End Sub
End Class