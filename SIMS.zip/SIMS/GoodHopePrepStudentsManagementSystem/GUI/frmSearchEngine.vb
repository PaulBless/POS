﻿Imports System.Data.SqlClient

Public Class frmSearchEngine

    Private Sub frmSearchEngine_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        GetData()

    End Sub

    Private Sub dgv_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv.CellClick
        dgv.SelectAll()
    End Sub

    Private Sub dgv_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv.CellContentClick
        Dim nform As New frmStaffJobDetails
        Dim drow As New System.Windows.Forms.DataGridViewRow
        For Each drow In Me.dgv.SelectedRows
            Using frmStaffJobDetails
                frmStaffJobDetails.txtEmpID.Text = drow.Cells(1).Value
                frmStaffJobDetails.lbl_1.Text = drow.Cells(2).Value + Space(1) + drow.Cells(3).Value
                frmStaffJobDetails.lbl_2.Text = drow.Cells(4).Value
                frmStaffJobDetails.lbl_3.Text = drow.Cells(5).Value
                frmStaffJobDetails.lbl_4.Text = drow.Cells(6).Value
                frmStaffJobDetails.lbl_5.Text = drow.Cells(7).Value
                frmStaffJobDetails.lbl_6.Text = drow.Cells(10).Value
                frmStaffJobDetails.lbl_1.Visible = True
                frmStaffJobDetails.lbl_2.Visible = True
                frmStaffJobDetails.lbl_3.Visible = True
                frmStaffJobDetails.lbl_4.Visible = True
                frmStaffJobDetails.lbl_5.Visible = True
                frmStaffJobDetails.lbl_6.Visible = True
                frmStaffJobDetails.Show()
            End Using
           
            'nform.txtEmpID.Text = drow.Cells(1).Value
            'nform.lbl_1.Text = drow.Cells(2).Value + Space(1) + drow.Cells(3).Value
            'nform.lbl_2.Text = drow.Cells(4).Value
            'nform.lbl_3.Text = drow.Cells(5).Value
            'nform.lbl_4.Text = drow.Cells(6).Value
            'nform.lbl_5.Text = drow.Cells(7).Value
            'nform.lbl_6.Text = drow.Cells(1).Value
            'nform.lbl_1.Visible = True
            'nform.lbl_2.Visible = True
            'nform.lbl_3.Visible = True
            'nform.lbl_4.Visible = True
            'nform.lbl_5.Visible = True
            'nform.lbl_6.Visible = True
            'nform.Show()
        Next
    End Sub
    Public Sub GetData()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            com = New SqlCommand("SELECT RTRIM(StaffID),RTRIM(StaffCode),RTRIM(FirstName), RTRIM(MiddleName) + ' ' + RTRIM(LastName) AS OtherNames, RTRIM(Gender),RTRIM(Title),RTRIM(PhoneNumber),RTRIM(Background),RTRIM(Qualification),RTRIM(Category),RTRIM(Department),RTRIM(Designation),RTRIM(Portfolio),RTRIM(Type),RTRIM(Status),RTRIM(Date),RTRIM(End_Date),RTRIM(Nationality),RTRIM(SSNIT) FROM vwStaffJobDetails1 order by FirstName ASC ", ConnectionModule.con)
            dr = com.ExecuteReader(CommandBehavior.CloseConnection)
            dgv.Rows.Clear()
            While (dr.Read() = True)
                dgv.Rows.Add(dr(0), dr(1), dr(2), dr(3), dr(4), dr(5), dr(6), dr(7), dr(8), dr(9), dr(10), dr(11), dr(12), dr(13), dr(14), dr(15), dr(16), dr(17), dr(18))
            End While
            'set total result found
            lblResult.Text = "Record found - " & dgv.Rows.Count
            con.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error at getdata", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub dgv_CellContentDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv.CellContentDoubleClick
        '    Try
        '        Dim frm As New ManageStaff
        '        'With {ManageStaff}
        '        frm.txtSID.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(0).Value
        '        frm.txtEmpID.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(1).Value
        '        frm.txtcode.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(1).Value
        '        frm.txtfirstname.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(2).Value.ToString()
        '        frm.txtothernames.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(3).Value.ToString()
        '        frm.cbogender.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(4).Value
        '        frm.txttitle.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(5).Value.ToString()
        '        frm.txtphoneno.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(6).Value
        '        frm.cbobackground.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(7).Value.ToString()
        '        frm.cboqualification.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(8).Value.ToString()
        '        frm.cbocategory.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(9).Value.ToString()
        '        frm.cboSaffdepartment.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(10).Value.ToString()
        '        frm.cboDesignation.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(11).Value.ToString()
        '        frm.txtdesignation.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(11).Value
        '        frm.portfolio.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(12).Value
        '        frm.cboType.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(13).Value
        '        frm.cboStatus.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(14).Value
        '        frm.StartDate.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(15).Value
        '        frm.EndDate.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(16).Value
        '        frm.txtNationality.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(17).Value
        '        frm.txtSSNIT.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(18).Value
        '        'End With
        'Me.Hide()
        '    Catch ex As Exception
        '        MsgBox(ex.Message.ToString())
        '    End Try

        Dim nform As New frmStaffJobDetails
        Dim drow As New System.Windows.Forms.DataGridViewRow
        For Each drow In Me.dgv.SelectedRows
            nform.txtEmpID.Text = drow.Cells(1).Value
            nform.lbl_1.Text = drow.Cells(2).Value + Space(1) + drow.Cells(3).Value
            nform.lbl_2.Text = drow.Cells(4).Value
            nform.lbl_3.Text = drow.Cells(5).Value
            nform.lbl_4.Text = drow.Cells(6).Value
            nform.lbl_5.Text = drow.Cells(7).Value
            nform.lbl_6.Text = drow.Cells(1).Value
            nform.lbl_1.Visible = True
            nform.lbl_2.Visible = True
            nform.lbl_3.Visible = True
            nform.lbl_4.Visible = True
            nform.lbl_5.Visible = True
            nform.lbl_6.Visible = True
            nform.Show()
        Next
    End Sub
End Class