﻿Imports System.Data.SqlClient

Public Class frmTeacherAssignment

    Private Sub btnHelp_Click(sender As Object, e As EventArgs) Handles btnHelp.Click
        If txtEmpID.Text = "" Then
            txtEmpID.AppendText("invalid")
            Exit Sub
        Else
            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            query = "select staffid, firstname + ' ' + middlename + ' ' + lastname as sname, category from vwStaffJobDetails1 where staffcode='" & txtEmpID.Text & "'"
            com = New SqlCommand(query, con)
            dr = com.ExecuteReader(CommandBehavior.CloseConnection)
            If dr.HasRows Then
                If dr.Read() Then
                    Dim empcat As String = dr(2).ToString
                    If empcat <> "Teaching" Then MsgBox("The employee id you entered is valid, BUT the employee does not belong to the 'Teaching Category'", MsgBoxStyle.OkOnly + MsgBoxStyle.Critical, "Search Error") : txtEmpID.SelectAll() : Exit Sub
                    SearchId = dr(0).ToString()
                    txtName.Text = dr(1).ToString()
                    btnSave.Enabled = True
                    dr.Close()
                    con.Close()
                Else
                    '
                End If
            Else
                MsgBox("The Employee ID is not correct or invalid, please check..", MsgBoxStyle.OkOnly + MsgBoxStyle.Critical, "Search Error") : txtEmpID.Clear() : Exit Sub
            End If

        End If

    End Sub

    Public Sub MyClassRooms()
        Try
            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            dset = New Data.DataSet()
            adapter = New SqlDataAdapter()
            adapter.SelectCommand = New SqlCommand("select distinct room from classroom order by room asc", ConnectionModule.con)
            dset.Clear()
            adapter.Fill(dset, "classroom")
            cboRoom.DataSource = dset.Tables("classroom")
            cboRoom.DisplayMember = "room"
            ''cboYear.ValueMember = "ID"
            cboRoom.Refresh()
            cboRoom.SelectedIndex = -1
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at get rooms")
            con.Close()
        End Try
    End Sub

    Public Sub AcademicYear()
        Try
            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            dset = New Data.DataSet()
            adapter = New SqlDataAdapter()
            adapter.SelectCommand = New SqlCommand("select distinct year from session order by year desc", ConnectionModule.con)
            dset.Clear()
            adapter.Fill(dset, "session")
            cboYear.DataSource = dset.Tables("session")
            cboYear.DisplayMember = "year"
            ''cboYear.ValueMember = "ID"
            cboYear.Refresh()
            cboYear.SelectedIndex = -1
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at get academicyear")
            con.Close()
        End Try
    End Sub
    Public Sub AcademicTerm()
        Try
            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            dset = New Data.DataSet()
            adapter = New SqlDataAdapter()
            adapter.SelectCommand = New SqlCommand("select distinct term from session order by term asc", ConnectionModule.con)
            dset.Clear()
            adapter.Fill(dset, "session")
            cboTerm.DataSource = dset.Tables("session")
            cboTerm.DisplayMember = "term"
            cboTerm.Refresh()
            cboTerm.SelectedIndex = -1
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at get academicterm")
            con.Close()
        End Try
    End Sub
    Public Sub GetSubjects()
        Try
            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            dset = New Data.DataSet()
            adapter = New SqlDataAdapter()
            adapter.SelectCommand = New SqlCommand("select distinct name from subjects order by name asc", ConnectionModule.con)
            dset.Clear()
            adapter.Fill(dset, "subjects")
            cboSubject.DataSource = dset.Tables("subjects")
            cboSubject.DisplayMember = "name"
            cboSubject.Refresh()
            cboSubject.SelectedIndex = -1
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at get subject")
            con.Close()
        End Try
    End Sub

    Private Sub cboTerm_DropDown(sender As Object, e As EventArgs) Handles cboTerm.DropDown
        AcademicTerm()
    End Sub

    Private Sub cboYear_DropDown(sender As Object, e As EventArgs) Handles cboYear.DropDown
        AcademicYear()
    End Sub

    Private Sub cboRoom_DropDown(sender As Object, e As EventArgs) Handles cboRoom.DropDown
        MyClassRooms()
    End Sub

    Private Sub cboSubject_DropDown(sender As Object, e As EventArgs) Handles cboSubject.DropDown
        GetSubjects()
    End Sub
    Private Sub CTAssignment()
        Try
            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            com1 = New SqlCommand("select a_id, staff_id, staffcode, firstname + ' ' + middlename + ' ' + lastname as sname, a_class, a_year, a_term, a_subject, a_date from Staff, ClassTeacher where staff_id = StaffID", ConnectionModule.con)
            dr = com1.ExecuteReader(CommandBehavior.CloseConnection)
            dgv.Rows.Clear()
            While dr.Read() = True
                dgv.Rows.Add(dr(0), dr(1), dr(2), dr(3), dr(4), dr(5), dr(6), dr(7), dr(8))
            End While
            'dr.Close()
            con.Close()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        If cboRoom.Text = "" Then MsgBox("Specify the class/form you want to assign teacher", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "SIMS Error") : Exit Sub
        If cboYear.Text = "" Then MsgBox("Select the academic year", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "SIMS Error") : Exit Sub
        If cboTerm.Text = "" Then MsgBox("Select the academic term", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "SIMS Error") : Exit Sub

        If MsgBox("Assign --'" + txtName.Text + "'--" + " to " + cboRoom.Text + ". Are you sure?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "Confirmation") = MsgBoxResult.Yes Then
            Try
                'check record exists
                If con.State = ConnectionState.Open Then con.Close()
                con.Open()
                com1 = New SqlCommand("select * from classteacher where staff_id='" & (SearchId) & "'", ConnectionModule.con)
                dr = com1.ExecuteReader(CommandBehavior.CloseConnection)
                If dr.Read() = True Then
                    dr.Close()
                    con.Close()
                    MsgBox("Record Exists.. Cannot save duplicate record..." + vbCrLf + "NB:- Please update the record..", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "SIMS") : Exit Sub
                Else
                    If con.State = ConnectionState.Open Then con.Close()
                    com1 = New SqlCommand("insert into classteacher(staff_id,a_class,a_year,a_term,a_subject,a_date) values (@d1,@d2,@d3,@d4,@d5,@d6)", ConnectionModule.con)
                    com1.Parameters.Add("@d1", SqlDbType.Int).Value = SearchId
                    com1.Parameters.Add("@d2", SqlDbType.NVarChar).Value = cboRoom.Text.Trim()
                    com1.Parameters.Add("@d3", SqlDbType.NVarChar).Value = cboYear.Text
                    com1.Parameters.Add("@d4", SqlDbType.NVarChar).Value = cboTerm.Text
                    com1.Parameters.Add("@d5", SqlDbType.NVarChar).Value = cboSubject.Text
                    com1.Parameters.Add("@d6", SqlDbType.Date).Value = Date.Now
                    con.Open()
                    com1.ExecuteNonQuery()
                    MessageBox.Show("Successfully saved.", "SIMS", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    com1.Dispose()  'dispose the command
                    con.Close()     'close the db connection
                    'clear controls
                    Clearing()
                    CTAssignment()
                    btnSave.Enabled = True
                    btnDelete.Enabled = False
                    btnUpdate.Enabled = False
                End If

            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End If
    End Sub

    Sub Clearing()
        txtEmpID.Clear()
        txtName.Clear()
        cboRoom.ResetText()
        cboYear.ResetText()
        cboTerm.ResetText()
        dtpDOB.Text = Now
        CTAssignment()
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        If MsgBox("Do you really want to update this record?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "SIMS") = MsgBoxResult.Yes Then
            Try
                'check record exists
                If con.State = ConnectionState.Open Then con.Close()
                con.Open()
                com = New SqlCommand("select * from classteacher where staff_id='" & SearchId & "'", con)
                dr = com.ExecuteReader(CommandBehavior.CloseConnection)
                If dr.HasRows() = True Then
                    'update the record
                    If con.State = ConnectionState.Open Then con.Close()
                    con.Open()
                    com1 = New SqlCommand("update classteacher set a_class=@d1, a_year=@d2, a_term=@d3, a_subject=@d4 where staff_id='" & SearchId & "'", con)
                    com1.Parameters.Add("@d1", SqlDbType.NVarChar).Value = cboRoom.Text.Trim()
                    com1.Parameters.Add("@d2", SqlDbType.NVarChar).Value = cboYear.Text
                    com1.Parameters.Add("@d3", SqlDbType.NVarChar).Value = cboTerm.Text
                    com1.Parameters.Add("@d4", SqlDbType.NVarChar).Value = cboSubject.Text
                    com1.ExecuteNonQuery()
                    MessageBox.Show("Successfully updated.", "SIMS", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    com1.Dispose()
                    con.Close()
                    'clear controls
                    Clearing()
                    CTAssignment()
                    btnSave.Enabled = True
                    btnUpdate.Enabled = False
                    btnDelete.Enabled = False
                Else
                    'show error message
                    MessageBox.Show("Could not find specific record criteria to perform update.. ", "SIMS", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Exit Sub
                End If

            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End If
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        If MsgBox("Do you really want to delete this record?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "SIMS") = MsgBoxResult.Yes Then
            Try
                'check record exists
                If con.State = ConnectionState.Open Then con.Close()
                con.Open()
                com = New SqlCommand("select * from classteacher where staff_id='" & SearchId & "'", con)
                dr = com.ExecuteReader(CommandBehavior.CloseConnection)
                If dr.HasRows() = True Then
                    'delete record
                    If con.State = ConnectionState.Open Then con.Close()
                    con.Open()
                    com1 = New SqlCommand("delete from classteacher where staff_id='" & SearchId & "'", ConnectionModule.con)
                    com1.ExecuteNonQuery()
                    MessageBox.Show("Successfully deleted.", "SIMS", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    com1.Dispose()
                    con.Close()
                    'clear controls
                    Clearing()
                    CTAssignment()
                    btnSave.Enabled = True
                    btnUpdate.Enabled = False
                    btnDelete.Enabled = False
                Else
                    'show error message
                    MessageBox.Show("Could not find specific record criteria to perform deletion.. ", "SIMS", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Exit Sub
                End If

            Catch ex As Exception
                MessageBox.Show(ex.Message)
            End Try
        End If
    End Sub

    Private Sub dgv_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv.CellClick
        dgv.SelectAll()
    End Sub

    Private Sub dgv_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv.CellContentClick

    End Sub

    Private Sub dgv_CellContentDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv.CellContentDoubleClick
        Try
            SearchId = dgv.Rows(dgv.CurrentRow.Index).Cells(1).Value.ToString()
            dtpDOB.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(8).Value
            txtName.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(3).Value.ToString()
            txtEmpID.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(2).Value.ToString()
            cboRoom.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(4).Value.ToString()
            cboYear.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(5).Value.ToString()
            cboTerm.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(6).Value.ToString()
            cboSubject.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(7).Value.ToString()
            btnUpdate.Enabled = True
            btnDelete.Enabled = True
            btnSave.Enabled = False
        Catch ex As Exception

        End Try
    End Sub

    Private Sub frmTeacherAssignment_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        CTAssignment()
    End Sub

End Class