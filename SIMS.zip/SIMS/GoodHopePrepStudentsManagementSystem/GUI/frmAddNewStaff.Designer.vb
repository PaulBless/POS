﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAddNewStaff
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmAddNewStaff))
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.dtpDOB = New System.Windows.Forms.DateTimePicker()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.txtStaffSsnit = New System.Windows.Forms.TextBox()
        Me.lbl_Staffssnit = New System.Windows.Forms.Label()
        Me.cboreligion = New System.Windows.Forms.ComboBox()
        Me.lblregion = New System.Windows.Forms.Label()
        Me.lbl_StaffReligion = New System.Windows.Forms.Label()
        Me.txtstaffage = New System.Windows.Forms.TextBox()
        Me.cboStaffregion = New System.Windows.Forms.ComboBox()
        Me.cboNationality = New System.Windows.Forms.ComboBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.lbl_StaffNationality = New System.Windows.Forms.Label()
        Me.txthouseno = New System.Windows.Forms.TextBox()
        Me.lbl_StaffHouseno = New System.Windows.Forms.Label()
        Me.lbl_StaffDOB = New System.Windows.Forms.Label()
        Me.txtStaffemail = New System.Windows.Forms.TextBox()
        Me.lbl_StaffEmail = New System.Windows.Forms.Label()
        Me.txtStaffphone = New System.Windows.Forms.TextBox()
        Me.lbl_StaffMobileno = New System.Windows.Forms.Label()
        Me.txtStaffhometown = New System.Windows.Forms.TextBox()
        Me.lbl_StaffHometown = New System.Windows.Forms.Label()
        Me.cbomaritalstatus = New System.Windows.Forms.ComboBox()
        Me.lbl_StaffMaritalStatus = New System.Windows.Forms.Label()
        Me.cboTitle = New System.Windows.Forms.ComboBox()
        Me.lbl_StaffTitle = New System.Windows.Forms.Label()
        Me.cboGender = New System.Windows.Forms.ComboBox()
        Me.lbl_StaffGender = New System.Windows.Forms.Label()
        Me.txtStaffmiddlename = New System.Windows.Forms.TextBox()
        Me.txtStafffirstname = New System.Windows.Forms.TextBox()
        Me.txtStaffsurname = New System.Windows.Forms.TextBox()
        Me.lbl_StaffFirstname = New System.Windows.Forms.Label()
        Me.lbl_StaffMiddlename = New System.Windows.Forms.Label()
        Me.lbl_StaffSurname = New System.Windows.Forms.Label()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.cboAllowance = New System.Windows.Forms.ComboBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtSalary = New System.Windows.Forms.TextBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.cboContactRelation = New System.Windows.Forms.ComboBox()
        Me.cboOccupation = New System.Windows.Forms.ComboBox()
        Me.txtContacthouse = New System.Windows.Forms.TextBox()
        Me.lbl_Staffcontactno = New System.Windows.Forms.Label()
        Me.lbl_StaffOccup = New System.Windows.Forms.Label()
        Me.txlocality = New System.Windows.Forms.TextBox()
        Me.lbl_Staffcontown = New System.Windows.Forms.Label()
        Me.txtContactphone = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lbl_Staffconphone = New System.Windows.Forms.Label()
        Me.txtContactname = New System.Windows.Forms.TextBox()
        Me.lbl_StaffConName = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.cboKinRelation = New System.Windows.Forms.ComboBox()
        Me.lbl_Staffnextrel = New System.Windows.Forms.Label()
        Me.txtNextkinno = New System.Windows.Forms.TextBox()
        Me.lbl_Staffnextno = New System.Windows.Forms.Label()
        Me.txtNextofkin = New System.Windows.Forms.TextBox()
        Me.lbl_Staffnextkin = New System.Windows.Forms.Label()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.dtpDOB)
        Me.GroupBox1.Controls.Add(Me.Label22)
        Me.GroupBox1.Controls.Add(Me.Label21)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.Label19)
        Me.GroupBox1.Controls.Add(Me.Label18)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label30)
        Me.GroupBox1.Controls.Add(Me.txtStaffSsnit)
        Me.GroupBox1.Controls.Add(Me.lbl_Staffssnit)
        Me.GroupBox1.Controls.Add(Me.cboreligion)
        Me.GroupBox1.Controls.Add(Me.lblregion)
        Me.GroupBox1.Controls.Add(Me.lbl_StaffReligion)
        Me.GroupBox1.Controls.Add(Me.txtstaffage)
        Me.GroupBox1.Controls.Add(Me.cboStaffregion)
        Me.GroupBox1.Controls.Add(Me.cboNationality)
        Me.GroupBox1.Controls.Add(Me.Label13)
        Me.GroupBox1.Controls.Add(Me.lbl_StaffNationality)
        Me.GroupBox1.Controls.Add(Me.txthouseno)
        Me.GroupBox1.Controls.Add(Me.lbl_StaffHouseno)
        Me.GroupBox1.Controls.Add(Me.lbl_StaffDOB)
        Me.GroupBox1.Controls.Add(Me.txtStaffemail)
        Me.GroupBox1.Controls.Add(Me.lbl_StaffEmail)
        Me.GroupBox1.Controls.Add(Me.txtStaffphone)
        Me.GroupBox1.Controls.Add(Me.lbl_StaffMobileno)
        Me.GroupBox1.Controls.Add(Me.txtStaffhometown)
        Me.GroupBox1.Controls.Add(Me.lbl_StaffHometown)
        Me.GroupBox1.Controls.Add(Me.cbomaritalstatus)
        Me.GroupBox1.Controls.Add(Me.lbl_StaffMaritalStatus)
        Me.GroupBox1.Controls.Add(Me.cboTitle)
        Me.GroupBox1.Controls.Add(Me.lbl_StaffTitle)
        Me.GroupBox1.Controls.Add(Me.cboGender)
        Me.GroupBox1.Controls.Add(Me.lbl_StaffGender)
        Me.GroupBox1.Controls.Add(Me.txtStaffmiddlename)
        Me.GroupBox1.Controls.Add(Me.txtStafffirstname)
        Me.GroupBox1.Controls.Add(Me.txtStaffsurname)
        Me.GroupBox1.Controls.Add(Me.lbl_StaffFirstname)
        Me.GroupBox1.Controls.Add(Me.lbl_StaffMiddlename)
        Me.GroupBox1.Controls.Add(Me.lbl_StaffSurname)
        Me.GroupBox1.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(10, 41)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(614, 263)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Personal Information"
        '
        'dtpDOB
        '
        Me.dtpDOB.CustomFormat = "dd/MM/yyyy"
        Me.dtpDOB.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtpDOB.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpDOB.Location = New System.Drawing.Point(427, 23)
        Me.dtpDOB.Name = "dtpDOB"
        Me.dtpDOB.ShowCheckBox = True
        Me.dtpDOB.Size = New System.Drawing.Size(123, 21)
        Me.dtpDOB.TabIndex = 59
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.ForeColor = System.Drawing.Color.Red
        Me.Label22.Location = New System.Drawing.Point(410, 201)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(15, 19)
        Me.Label22.TabIndex = 69
        Me.Label22.Text = "*"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.ForeColor = System.Drawing.Color.Red
        Me.Label21.Location = New System.Drawing.Point(409, 164)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(15, 19)
        Me.Label21.TabIndex = 68
        Me.Label21.Text = "*"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.Red
        Me.Label8.Location = New System.Drawing.Point(414, 28)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(15, 19)
        Me.Label8.TabIndex = 67
        Me.Label8.Text = "*"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.ForeColor = System.Drawing.Color.Red
        Me.Label19.Location = New System.Drawing.Point(91, 231)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(15, 19)
        Me.Label19.TabIndex = 67
        Me.Label19.Text = "*"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.ForeColor = System.Drawing.Color.Red
        Me.Label18.Location = New System.Drawing.Point(409, 128)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(15, 19)
        Me.Label18.TabIndex = 67
        Me.Label18.Text = "*"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.Red
        Me.Label7.Location = New System.Drawing.Point(401, 60)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(15, 19)
        Me.Label7.TabIndex = 67
        Me.Label7.Text = "*"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.Red
        Me.Label6.Location = New System.Drawing.Point(82, 130)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(15, 19)
        Me.Label6.TabIndex = 66
        Me.Label6.Text = "*"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.Red
        Me.Label5.Location = New System.Drawing.Point(86, 60)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(15, 19)
        Me.Label5.TabIndex = 66
        Me.Label5.Text = "*"
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.ForeColor = System.Drawing.Color.Red
        Me.Label30.Location = New System.Drawing.Point(82, 25)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(15, 19)
        Me.Label30.TabIndex = 66
        Me.Label30.Text = "*"
        '
        'txtStaffSsnit
        '
        Me.txtStaffSsnit.BackColor = System.Drawing.Color.White
        Me.txtStaffSsnit.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtStaffSsnit.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.txtStaffSsnit.Location = New System.Drawing.Point(427, 229)
        Me.txtStaffSsnit.MaxLength = 20
        Me.txtStaffSsnit.Name = "txtStaffSsnit"
        Me.txtStaffSsnit.Size = New System.Drawing.Size(177, 21)
        Me.txtStaffSsnit.TabIndex = 15
        '
        'lbl_Staffssnit
        '
        Me.lbl_Staffssnit.AutoSize = True
        Me.lbl_Staffssnit.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_Staffssnit.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_Staffssnit.Location = New System.Drawing.Point(326, 232)
        Me.lbl_Staffssnit.Name = "lbl_Staffssnit"
        Me.lbl_Staffssnit.Size = New System.Drawing.Size(70, 17)
        Me.lbl_Staffssnit.TabIndex = 65
        Me.lbl_Staffssnit.Text = "SSNIT No."
        '
        'cboreligion
        '
        Me.cboreligion.AutoCompleteCustomSource.AddRange(New String() {"ATHEISM", "BUDHISM", "CHRISTIANITY", "JUDAISM", "ISLAM", "TRADITIONALIST"})
        Me.cboreligion.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.cboreligion.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.cboreligion.BackColor = System.Drawing.Color.White
        Me.cboreligion.DropDownHeight = 100
        Me.cboreligion.DropDownWidth = 100
        Me.cboreligion.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.cboreligion.FormattingEnabled = True
        Me.cboreligion.IntegralHeight = False
        Me.cboreligion.Items.AddRange(New Object() {"CHRISTIANITY", "ISLAM", "TRADITIONALIST"})
        Me.cboreligion.Location = New System.Drawing.Point(427, 197)
        Me.cboreligion.Name = "cboreligion"
        Me.cboreligion.Size = New System.Drawing.Size(177, 23)
        Me.cboreligion.TabIndex = 14
        '
        'lblregion
        '
        Me.lblregion.AutoSize = True
        Me.lblregion.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblregion.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lblregion.Location = New System.Drawing.Point(326, 200)
        Me.lblregion.Name = "lblregion"
        Me.lblregion.Size = New System.Drawing.Size(63, 17)
        Me.lblregion.TabIndex = 58
        Me.lblregion.Text = "Religion "
        '
        'lbl_StaffReligion
        '
        Me.lbl_StaffReligion.AutoSize = True
        Me.lbl_StaffReligion.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaffReligion.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_StaffReligion.Location = New System.Drawing.Point(326, 162)
        Me.lbl_StaffReligion.Name = "lbl_StaffReligion"
        Me.lbl_StaffReligion.Size = New System.Drawing.Size(51, 17)
        Me.lbl_StaffReligion.TabIndex = 45
        Me.lbl_StaffReligion.Text = "Region"
        '
        'txtstaffage
        '
        Me.txtstaffage.BackColor = System.Drawing.Color.White
        Me.txtstaffage.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.txtstaffage.Location = New System.Drawing.Point(583, 24)
        Me.txtstaffage.Name = "txtstaffage"
        Me.txtstaffage.Size = New System.Drawing.Size(21, 21)
        Me.txtstaffage.TabIndex = 55
        '
        'cboStaffregion
        '
        Me.cboStaffregion.AutoCompleteCustomSource.AddRange(New String() {"AMERICAN", "BURKINABE", "CHINESE", "GHANAIAN", "IVORIAN", "JAPANESE", "NIGERIAN", "TOGOLESE", "SOUTH AFRICAN", "OTHER "})
        Me.cboStaffregion.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.cboStaffregion.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.cboStaffregion.BackColor = System.Drawing.Color.White
        Me.cboStaffregion.DropDownHeight = 45
        Me.cboStaffregion.DropDownWidth = 45
        Me.cboStaffregion.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.cboStaffregion.FormattingEnabled = True
        Me.cboStaffregion.IntegralHeight = False
        Me.cboStaffregion.Items.AddRange(New Object() {"ASHANTI", "BRONG AHAFO", "CENTRAL", "EASTERN", "GREATER ACCRA", "NORTHERN", "UPPER EAST", "UPPER WEST", "VOLTA", "WESTERN"})
        Me.cboStaffregion.Location = New System.Drawing.Point(427, 161)
        Me.cboStaffregion.Name = "cboStaffregion"
        Me.cboStaffregion.Size = New System.Drawing.Size(177, 23)
        Me.cboStaffregion.TabIndex = 13
        '
        'cboNationality
        '
        Me.cboNationality.AutoCompleteCustomSource.AddRange(New String() {"AMERICAN", "BURKINABE", "CHINESE", "GHANAIAN", "IVORIAN", "JAPANESE", "NIGERIAN", "TOGOLESE", "SOUTH AFRICAN", "OTHER "})
        Me.cboNationality.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.cboNationality.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.cboNationality.BackColor = System.Drawing.Color.White
        Me.cboNationality.DropDownHeight = 35
        Me.cboNationality.DropDownWidth = 35
        Me.cboNationality.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.cboNationality.FormattingEnabled = True
        Me.cboNationality.IntegralHeight = False
        Me.cboNationality.Items.AddRange(New Object() {"GHANAIAN", "NON-GHANAIAN"})
        Me.cboNationality.Location = New System.Drawing.Point(427, 126)
        Me.cboNationality.Name = "cboNationality"
        Me.cboNationality.Size = New System.Drawing.Size(177, 23)
        Me.cboNationality.TabIndex = 12
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.Label13.Location = New System.Drawing.Point(553, 26)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(32, 17)
        Me.Label13.TabIndex = 54
        Me.Label13.Text = "Age"
        '
        'lbl_StaffNationality
        '
        Me.lbl_StaffNationality.AutoSize = True
        Me.lbl_StaffNationality.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaffNationality.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_StaffNationality.Location = New System.Drawing.Point(326, 130)
        Me.lbl_StaffNationality.Name = "lbl_StaffNationality"
        Me.lbl_StaffNationality.Size = New System.Drawing.Size(77, 17)
        Me.lbl_StaffNationality.TabIndex = 42
        Me.lbl_StaffNationality.Text = "Nationality"
        '
        'txthouseno
        '
        Me.txthouseno.BackColor = System.Drawing.Color.White
        Me.txthouseno.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txthouseno.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.txthouseno.Location = New System.Drawing.Point(113, 229)
        Me.txthouseno.Name = "txthouseno"
        Me.txthouseno.Size = New System.Drawing.Size(197, 21)
        Me.txthouseno.TabIndex = 8
        '
        'lbl_StaffHouseno
        '
        Me.lbl_StaffHouseno.AutoSize = True
        Me.lbl_StaffHouseno.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaffHouseno.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_StaffHouseno.Location = New System.Drawing.Point(12, 227)
        Me.lbl_StaffHouseno.Name = "lbl_StaffHouseno"
        Me.lbl_StaffHouseno.Size = New System.Drawing.Size(73, 17)
        Me.lbl_StaffHouseno.TabIndex = 52
        Me.lbl_StaffHouseno.Text = "House No."
        '
        'lbl_StaffDOB
        '
        Me.lbl_StaffDOB.AutoSize = True
        Me.lbl_StaffDOB.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaffDOB.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_StaffDOB.Location = New System.Drawing.Point(326, 28)
        Me.lbl_StaffDOB.Name = "lbl_StaffDOB"
        Me.lbl_StaffDOB.Size = New System.Drawing.Size(92, 17)
        Me.lbl_StaffDOB.TabIndex = 50
        Me.lbl_StaffDOB.Text = "Date of Birth "
        '
        'txtStaffemail
        '
        Me.txtStaffemail.BackColor = System.Drawing.Color.White
        Me.txtStaffemail.CharacterCasing = System.Windows.Forms.CharacterCasing.Lower
        Me.txtStaffemail.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.txtStaffemail.Location = New System.Drawing.Point(427, 93)
        Me.txtStaffemail.Name = "txtStaffemail"
        Me.txtStaffemail.Size = New System.Drawing.Size(177, 21)
        Me.txtStaffemail.TabIndex = 11
        '
        'lbl_StaffEmail
        '
        Me.lbl_StaffEmail.AutoSize = True
        Me.lbl_StaffEmail.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaffEmail.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_StaffEmail.Location = New System.Drawing.Point(326, 97)
        Me.lbl_StaffEmail.Name = "lbl_StaffEmail"
        Me.lbl_StaffEmail.Size = New System.Drawing.Size(51, 17)
        Me.lbl_StaffEmail.TabIndex = 48
        Me.lbl_StaffEmail.Text = "E-mail "
        '
        'txtStaffphone
        '
        Me.txtStaffphone.BackColor = System.Drawing.Color.White
        Me.txtStaffphone.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtStaffphone.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.txtStaffphone.Location = New System.Drawing.Point(427, 59)
        Me.txtStaffphone.MaxLength = 10
        Me.txtStaffphone.Name = "txtStaffphone"
        Me.txtStaffphone.Size = New System.Drawing.Size(177, 21)
        Me.txtStaffphone.TabIndex = 10
        '
        'lbl_StaffMobileno
        '
        Me.lbl_StaffMobileno.AutoSize = True
        Me.lbl_StaffMobileno.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaffMobileno.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_StaffMobileno.Location = New System.Drawing.Point(326, 60)
        Me.lbl_StaffMobileno.Name = "lbl_StaffMobileno"
        Me.lbl_StaffMobileno.Size = New System.Drawing.Size(69, 17)
        Me.lbl_StaffMobileno.TabIndex = 46
        Me.lbl_StaffMobileno.Text = "Phone No"
        '
        'txtStaffhometown
        '
        Me.txtStaffhometown.BackColor = System.Drawing.Color.White
        Me.txtStaffhometown.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtStaffhometown.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.txtStaffhometown.Location = New System.Drawing.Point(113, 197)
        Me.txtStaffhometown.Name = "txtStaffhometown"
        Me.txtStaffhometown.Size = New System.Drawing.Size(197, 21)
        Me.txtStaffhometown.TabIndex = 7
        '
        'lbl_StaffHometown
        '
        Me.lbl_StaffHometown.AutoSize = True
        Me.lbl_StaffHometown.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaffHometown.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_StaffHometown.Location = New System.Drawing.Point(12, 195)
        Me.lbl_StaffHometown.Name = "lbl_StaffHometown"
        Me.lbl_StaffHometown.Size = New System.Drawing.Size(80, 17)
        Me.lbl_StaffHometown.TabIndex = 42
        Me.lbl_StaffHometown.Text = "Hometown "
        '
        'cbomaritalstatus
        '
        Me.cbomaritalstatus.AutoCompleteCustomSource.AddRange(New String() {"Attached", "Divorced", "Married", "Single"})
        Me.cbomaritalstatus.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.cbomaritalstatus.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.cbomaritalstatus.BackColor = System.Drawing.Color.White
        Me.cbomaritalstatus.DropDownHeight = 65
        Me.cbomaritalstatus.DropDownWidth = 65
        Me.cbomaritalstatus.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.cbomaritalstatus.FormattingEnabled = True
        Me.cbomaritalstatus.IntegralHeight = False
        Me.cbomaritalstatus.Items.AddRange(New Object() {"Attached", "Divorced", "Married", "Single"})
        Me.cbomaritalstatus.Location = New System.Drawing.Point(113, 164)
        Me.cbomaritalstatus.Name = "cbomaritalstatus"
        Me.cbomaritalstatus.Size = New System.Drawing.Size(197, 23)
        Me.cbomaritalstatus.TabIndex = 6
        '
        'lbl_StaffMaritalStatus
        '
        Me.lbl_StaffMaritalStatus.AutoSize = True
        Me.lbl_StaffMaritalStatus.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaffMaritalStatus.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_StaffMaritalStatus.Location = New System.Drawing.Point(12, 166)
        Me.lbl_StaffMaritalStatus.Name = "lbl_StaffMaritalStatus"
        Me.lbl_StaffMaritalStatus.Size = New System.Drawing.Size(94, 17)
        Me.lbl_StaffMaritalStatus.TabIndex = 26
        Me.lbl_StaffMaritalStatus.Text = "Marital Status"
        '
        'cboTitle
        '
        Me.cboTitle.AutoCompleteCustomSource.AddRange(New String() {"Miss", "Mr", "Mrs"})
        Me.cboTitle.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.cboTitle.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.cboTitle.BackColor = System.Drawing.Color.White
        Me.cboTitle.DropDownHeight = 50
        Me.cboTitle.DropDownWidth = 50
        Me.cboTitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.cboTitle.FormattingEnabled = True
        Me.cboTitle.IntegralHeight = False
        Me.cboTitle.Location = New System.Drawing.Point(233, 128)
        Me.cboTitle.Name = "cboTitle"
        Me.cboTitle.Size = New System.Drawing.Size(77, 23)
        Me.cboTitle.TabIndex = 5
        '
        'lbl_StaffTitle
        '
        Me.lbl_StaffTitle.AutoSize = True
        Me.lbl_StaffTitle.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold)
        Me.lbl_StaffTitle.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_StaffTitle.Location = New System.Drawing.Point(197, 131)
        Me.lbl_StaffTitle.Name = "lbl_StaffTitle"
        Me.lbl_StaffTitle.Size = New System.Drawing.Size(36, 17)
        Me.lbl_StaffTitle.TabIndex = 24
        Me.lbl_StaffTitle.Text = "Title"
        '
        'cboGender
        '
        Me.cboGender.AutoCompleteCustomSource.AddRange(New String() {"FEMALE", "MALE"})
        Me.cboGender.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.cboGender.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.cboGender.BackColor = System.Drawing.Color.White
        Me.cboGender.DropDownHeight = 35
        Me.cboGender.DropDownWidth = 35
        Me.cboGender.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.cboGender.FormattingEnabled = True
        Me.cboGender.IntegralHeight = False
        Me.cboGender.Items.AddRange(New Object() {"FEMALE", "MALE"})
        Me.cboGender.Location = New System.Drawing.Point(113, 128)
        Me.cboGender.Name = "cboGender"
        Me.cboGender.Size = New System.Drawing.Size(77, 23)
        Me.cboGender.TabIndex = 4
        '
        'lbl_StaffGender
        '
        Me.lbl_StaffGender.AutoSize = True
        Me.lbl_StaffGender.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaffGender.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_StaffGender.Location = New System.Drawing.Point(12, 129)
        Me.lbl_StaffGender.Name = "lbl_StaffGender"
        Me.lbl_StaffGender.Size = New System.Drawing.Size(52, 17)
        Me.lbl_StaffGender.TabIndex = 22
        Me.lbl_StaffGender.Text = "Gender"
        '
        'txtStaffmiddlename
        '
        Me.txtStaffmiddlename.BackColor = System.Drawing.Color.White
        Me.txtStaffmiddlename.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtStaffmiddlename.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.txtStaffmiddlename.Location = New System.Drawing.Point(113, 93)
        Me.txtStaffmiddlename.MaxLength = 200
        Me.txtStaffmiddlename.Name = "txtStaffmiddlename"
        Me.txtStaffmiddlename.Size = New System.Drawing.Size(197, 21)
        Me.txtStaffmiddlename.TabIndex = 3
        '
        'txtStafffirstname
        '
        Me.txtStafffirstname.BackColor = System.Drawing.Color.White
        Me.txtStafffirstname.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtStafffirstname.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.txtStafffirstname.Location = New System.Drawing.Point(113, 59)
        Me.txtStafffirstname.MaxLength = 300
        Me.txtStafffirstname.Name = "txtStafffirstname"
        Me.txtStafffirstname.Size = New System.Drawing.Size(197, 21)
        Me.txtStafffirstname.TabIndex = 2
        '
        'txtStaffsurname
        '
        Me.txtStaffsurname.BackColor = System.Drawing.Color.White
        Me.txtStaffsurname.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtStaffsurname.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.txtStaffsurname.Location = New System.Drawing.Point(113, 24)
        Me.txtStaffsurname.MaxLength = 300
        Me.txtStaffsurname.Name = "txtStaffsurname"
        Me.txtStaffsurname.Size = New System.Drawing.Size(197, 21)
        Me.txtStaffsurname.TabIndex = 1
        '
        'lbl_StaffFirstname
        '
        Me.lbl_StaffFirstname.AutoSize = True
        Me.lbl_StaffFirstname.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaffFirstname.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_StaffFirstname.Location = New System.Drawing.Point(12, 60)
        Me.lbl_StaffFirstname.Name = "lbl_StaffFirstname"
        Me.lbl_StaffFirstname.Size = New System.Drawing.Size(79, 17)
        Me.lbl_StaffFirstname.TabIndex = 9
        Me.lbl_StaffFirstname.Text = "First Name "
        '
        'lbl_StaffMiddlename
        '
        Me.lbl_StaffMiddlename.AutoSize = True
        Me.lbl_StaffMiddlename.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaffMiddlename.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_StaffMiddlename.Location = New System.Drawing.Point(12, 94)
        Me.lbl_StaffMiddlename.Name = "lbl_StaffMiddlename"
        Me.lbl_StaffMiddlename.Size = New System.Drawing.Size(91, 17)
        Me.lbl_StaffMiddlename.TabIndex = 8
        Me.lbl_StaffMiddlename.Text = "Middle Name"
        '
        'lbl_StaffSurname
        '
        Me.lbl_StaffSurname.AutoSize = True
        Me.lbl_StaffSurname.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaffSurname.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_StaffSurname.Location = New System.Drawing.Point(12, 25)
        Me.lbl_StaffSurname.Name = "lbl_StaffSurname"
        Me.lbl_StaffSurname.Size = New System.Drawing.Size(73, 17)
        Me.lbl_StaffSurname.TabIndex = 7
        Me.lbl_StaffSurname.Text = "Last Name"
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.Label17)
        Me.GroupBox4.Controls.Add(Me.cboAllowance)
        Me.GroupBox4.Controls.Add(Me.Label3)
        Me.GroupBox4.Controls.Add(Me.Label1)
        Me.GroupBox4.Controls.Add(Me.txtSalary)
        Me.GroupBox4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.GroupBox4.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox4.Location = New System.Drawing.Point(632, 308)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(350, 88)
        Me.GroupBox4.TabIndex = 3
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Salary Information"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.ForeColor = System.Drawing.Color.Red
        Me.Label17.Location = New System.Drawing.Point(154, 23)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(15, 19)
        Me.Label17.TabIndex = 46
        Me.Label17.Text = "*"
        '
        'cboAllowance
        '
        Me.cboAllowance.AutoCompleteCustomSource.AddRange(New String() {"ATHEISM", "BUDHISM", "CHRISTIANITY", "JUDAISM", "ISLAM", "TRADITIONALIST"})
        Me.cboAllowance.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.cboAllowance.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.cboAllowance.BackColor = System.Drawing.Color.White
        Me.cboAllowance.DropDownHeight = 75
        Me.cboAllowance.DropDownWidth = 75
        Me.cboAllowance.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.cboAllowance.FormattingEnabled = True
        Me.cboAllowance.IntegralHeight = False
        Me.cboAllowance.Items.AddRange(New Object() {"Yes", "No"})
        Me.cboAllowance.Location = New System.Drawing.Point(180, 46)
        Me.cboAllowance.Name = "cboAllowance"
        Me.cboAllowance.Size = New System.Drawing.Size(162, 23)
        Me.cboAllowance.TabIndex = 3
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label3.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.Label3.Location = New System.Drawing.Point(39, 50)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(119, 17)
        Me.Label3.TabIndex = 38
        Me.Label3.Text = "Allowance Benefit"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label1.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.Label1.Location = New System.Drawing.Point(39, 23)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(109, 17)
        Me.Label1.TabIndex = 38
        Me.Label1.Text = "Basic Salary Gh¢"
        '
        'txtSalary
        '
        Me.txtSalary.BackColor = System.Drawing.Color.White
        Me.txtSalary.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtSalary.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.txtSalary.Location = New System.Drawing.Point(180, 19)
        Me.txtSalary.MaxLength = 5
        Me.txtSalary.Name = "txtSalary"
        Me.txtSalary.Size = New System.Drawing.Size(162, 21)
        Me.txtSalary.TabIndex = 1
        Me.txtSalary.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Label12)
        Me.GroupBox2.Controls.Add(Me.Label10)
        Me.GroupBox2.Controls.Add(Me.Label11)
        Me.GroupBox2.Controls.Add(Me.Label9)
        Me.GroupBox2.Controls.Add(Me.cboContactRelation)
        Me.GroupBox2.Controls.Add(Me.cboOccupation)
        Me.GroupBox2.Controls.Add(Me.txtContacthouse)
        Me.GroupBox2.Controls.Add(Me.lbl_Staffcontactno)
        Me.GroupBox2.Controls.Add(Me.lbl_StaffOccup)
        Me.GroupBox2.Controls.Add(Me.txlocality)
        Me.GroupBox2.Controls.Add(Me.lbl_Staffcontown)
        Me.GroupBox2.Controls.Add(Me.txtContactphone)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Controls.Add(Me.lbl_Staffconphone)
        Me.GroupBox2.Controls.Add(Me.txtContactname)
        Me.GroupBox2.Controls.Add(Me.lbl_StaffConName)
        Me.GroupBox2.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.Location = New System.Drawing.Point(632, 41)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(350, 263)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Emergency Contact Information"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.Color.Red
        Me.Label12.Location = New System.Drawing.Point(77, 131)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(15, 19)
        Me.Label12.TabIndex = 46
        Me.Label12.Text = "*"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.Red
        Me.Label10.Location = New System.Drawing.Point(72, 26)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(15, 19)
        Me.Label10.TabIndex = 45
        Me.Label10.Text = "*"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.Red
        Me.Label11.Location = New System.Drawing.Point(77, 97)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(15, 19)
        Me.Label11.TabIndex = 45
        Me.Label11.Text = "*"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.Red
        Me.Label9.Location = New System.Drawing.Point(78, 62)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(15, 19)
        Me.Label9.TabIndex = 45
        Me.Label9.Text = "*"
        '
        'cboContactRelation
        '
        Me.cboContactRelation.AutoCompleteCustomSource.AddRange(New String() {"ACCOUNTANT", "APPRENTICE", "ARCHITECT", "ARMY OFFICER", "ARTISAN", "ASSEMBLYMAN", "AUDITOR", "BAKER", "BANKER", "BEAUTY PRACTITIONER", "BUSINESSMAN", "BUSINESS ANALYST", "CARPENTOR", "CATERER", "CHEF", "CIVIL SERVANT", "CLERGY", "COMPUTER SCIENTIST", "CONSTRUCTION ENGINEER", "DATABASE ADMINISTRATOR", "DESIGNER", "DISPENSING ASSISTANT", "DOCTOR", "DRIVER", "ELECTRICIAN", "FARMER", "FASHION DESIGNER", "FISHERMAN", "FISH MONGER", "FOOD VENDOR", "FOOTBALLER", "FOREIGN DIPLOMAT", "HAIR DRESSER", "HEALTH AID ", "HOUSE WIFE", "IMMIGRATION OFFICER", "LABOURER", "LAWYER", "LEGAL PRACTITIONER", "MASON", "MATRON", "MEDICAL PRACTITIONER", "MINER", "MINING ENGINEER", "MUSICIAN", "NETWORK ADMINISTRATOR", "NETWORK ENGINEER", "NURSE", "OTHER", "PAINTER", "PASTOR", "PENSIONER", "PHARMACIST", "PHARMACY TECHNICIAN", "POLICE OFFICER", "PROGRAMMER", "PUBLIC SERVANT", "RADIO PRESENTER", "REAL ESTATE AGENT", "RECEPTIONIST", "SALES PERSON", "SEAMSTRESS", "SECRETARY", "SECURITY", "STATE MINSTER", "STOCK BROKER", "STORE KEEPER", "SYSTEM ADMINISTRATOR", "TAILOR", "TEACHER", "TRADER", "TRAVEL AGENT", "TYPIST", "UNEMPLOYED"})
        Me.cboContactRelation.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.cboContactRelation.BackColor = System.Drawing.Color.White
        Me.cboContactRelation.DropDownHeight = 105
        Me.cboContactRelation.DropDownWidth = 105
        Me.cboContactRelation.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.cboContactRelation.FormattingEnabled = True
        Me.cboContactRelation.IntegralHeight = False
        Me.cboContactRelation.Items.AddRange(New Object() {"Aunt", "Brother", "Father", "GrandFather", "GrandMother", "Husband", "Mother", "Other", "Sister", "StepFather", "StepMother", "Uncle", "Wife"})
        Me.cboContactRelation.Location = New System.Drawing.Point(97, 159)
        Me.cboContactRelation.Name = "cboContactRelation"
        Me.cboContactRelation.Size = New System.Drawing.Size(245, 23)
        Me.cboContactRelation.Sorted = True
        Me.cboContactRelation.TabIndex = 5
        '
        'cboOccupation
        '
        Me.cboOccupation.AutoCompleteCustomSource.AddRange(New String() {"ACCOUNTANT", "APPRENTICE", "ARCHITECT", "ARMY OFFICER", "ARTISAN", "ASSEMBLYMAN", "AUDITOR", "BAKER", "BANKER", "BEAUTY PRACTITIONER", "BUSINESSMAN", "BUSINESS ANALYST", "CARPENTOR", "CATERER", "CHEF", "CIVIL SERVANT", "CLERGY", "COMPUTER SCIENTIST", "CONSTRUCTION ENGINEER", "DATABASE ADMINISTRATOR", "DESIGNER", "DISPENSING ASSISTANT", "DOCTOR", "DRIVER", "ELECTRICIAN", "FARMER", "FASHION DESIGNER", "FISHERMAN", "FISH MONGER", "FOOD VENDOR", "FOOTBALLER", "FOREIGN DIPLOMAT", "HAIR DRESSER", "HEALTH AID ", "HOUSE WIFE", "IMMIGRATION OFFICER", "LABOURER", "LAWYER", "LEGAL PRACTITIONER", "MASON", "MATRON", "MEDICAL PRACTITIONER", "MINER", "MINING ENGINEER", "MUSICIAN", "NETWORK ADMINISTRATOR", "NETWORK ENGINEER", "NURSE", "OTHER", "PAINTER", "PASTOR", "PENSIONER", "PHARMACIST", "PHARMACY TECHNICIAN", "POLICE OFFICER", "PROGRAMMER", "PUBLIC SERVANT", "RADIO PRESENTER", "REAL ESTATE AGENT", "RECEPTIONIST", "SALES PERSON", "SEAMSTRESS", "SECRETARY", "SECURITY", "STATE MINSTER", "STOCK BROKER", "STORE KEEPER", "SYSTEM ADMINISTRATOR", "TAILOR", "TEACHER", "TRADER", "TRAVEL AGENT", "TYPIST", "UNEMPLOYED"})
        Me.cboOccupation.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.cboOccupation.BackColor = System.Drawing.Color.White
        Me.cboOccupation.DropDownHeight = 105
        Me.cboOccupation.DropDownWidth = 105
        Me.cboOccupation.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.cboOccupation.FormattingEnabled = True
        Me.cboOccupation.IntegralHeight = False
        Me.cboOccupation.Items.AddRange(New Object() {"ACCOUNTANT", "APPRENTICE", "ARCHITECT", "ARMY OFFICER", "ARTISAN", "ASSEMBLYMAN", "AUDITOR", "BAKER", "BANKER", "BEAUTY PRACTITIONER", "BUSINESS ANALYST", "BUSINESSMAN", "CARPENTOR", "CATERER", "CHEF", "CIVIL SERVANT", "CLERGY", "COMPUTER SCIENTIST", "CONSTRUCTION ENGINEER", "DATABASE ADMINISTRATOR", "DESIGNER", "DISPENSING ASSISTANT", "DOCTOR", "DRIVER", "ELECTRICIAN", "FARMER", "FASHION DESIGNER", "FISH MONGER", "FISHERMAN", "FOOD VENDOR", "FOOTBALLER", "FOREIGN DIPLOMAT", "HAIR DRESSER", "HEALTH AID ", "HOUSE WIFE", "IMMIGRATION OFFICER", "LABOURER", "LAWYER", "LEGAL PRACTITIONER", "MASON", "MATRON", "MEDICAL PRACTITIONER", "MINER", "MINING ENGINEER", "MUSICIAN", "NETWORK ADMINISTRATOR", "NETWORK ENGINEER", "NURSE", "OTHER", "PAINTER", "PASTOR", "PENSIONER", "PHARMACIST", "PHARMACY TECHNICIAN", "POLICE OFFICER", "PROGRAMMER", "PUBLIC SERVANT", "RADIO PRESENTER", "REAL ESTATE AGENT", "RECEPTIONIST", "SALES PERSON", "SEAMSTRESS", "SECRETARY", "SECURITY", "STATE MINSTER", "STOCK BROKER", "STORE KEEPER", "SYSTEM ADMINISTRATOR", "TAILOR", "TEACHER", "TRADER", "TRAVEL AGENT", "TYPIST", "UNEMPLOYED"})
        Me.cboOccupation.Location = New System.Drawing.Point(97, 197)
        Me.cboOccupation.Name = "cboOccupation"
        Me.cboOccupation.Size = New System.Drawing.Size(245, 23)
        Me.cboOccupation.TabIndex = 6
        '
        'txtContacthouse
        '
        Me.txtContacthouse.BackColor = System.Drawing.Color.White
        Me.txtContacthouse.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtContacthouse.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.txtContacthouse.Location = New System.Drawing.Point(97, 128)
        Me.txtContacthouse.MaxLength = 50
        Me.txtContacthouse.Name = "txtContacthouse"
        Me.txtContacthouse.Size = New System.Drawing.Size(246, 21)
        Me.txtContacthouse.TabIndex = 4
        '
        'lbl_Staffcontactno
        '
        Me.lbl_Staffcontactno.AutoSize = True
        Me.lbl_Staffcontactno.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_Staffcontactno.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_Staffcontactno.Location = New System.Drawing.Point(10, 129)
        Me.lbl_Staffcontactno.Name = "lbl_Staffcontactno"
        Me.lbl_Staffcontactno.Size = New System.Drawing.Size(73, 17)
        Me.lbl_Staffcontactno.TabIndex = 44
        Me.lbl_Staffcontactno.Text = "House No "
        '
        'lbl_StaffOccup
        '
        Me.lbl_StaffOccup.AutoSize = True
        Me.lbl_StaffOccup.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaffOccup.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_StaffOccup.Location = New System.Drawing.Point(10, 200)
        Me.lbl_StaffOccup.Name = "lbl_StaffOccup"
        Me.lbl_StaffOccup.Size = New System.Drawing.Size(82, 17)
        Me.lbl_StaffOccup.TabIndex = 43
        Me.lbl_StaffOccup.Text = "Occupation "
        '
        'txlocality
        '
        Me.txlocality.BackColor = System.Drawing.Color.White
        Me.txlocality.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txlocality.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.txlocality.Location = New System.Drawing.Point(97, 93)
        Me.txlocality.MaxLength = 150
        Me.txlocality.Name = "txlocality"
        Me.txlocality.Size = New System.Drawing.Size(246, 21)
        Me.txlocality.TabIndex = 3
        '
        'lbl_Staffcontown
        '
        Me.lbl_Staffcontown.AutoSize = True
        Me.lbl_Staffcontown.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_Staffcontown.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_Staffcontown.Location = New System.Drawing.Point(10, 95)
        Me.lbl_Staffcontown.Name = "lbl_Staffcontown"
        Me.lbl_Staffcontown.Size = New System.Drawing.Size(56, 17)
        Me.lbl_Staffcontown.TabIndex = 41
        Me.lbl_Staffcontown.Text = "Locality"
        '
        'txtContactphone
        '
        Me.txtContactphone.BackColor = System.Drawing.Color.White
        Me.txtContactphone.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtContactphone.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.txtContactphone.Location = New System.Drawing.Point(97, 59)
        Me.txtContactphone.MaxLength = 10
        Me.txtContactphone.Name = "txtContactphone"
        Me.txtContactphone.Size = New System.Drawing.Size(245, 21)
        Me.txtContactphone.TabIndex = 2
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.Label2.Location = New System.Drawing.Point(10, 161)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(63, 17)
        Me.Label2.TabIndex = 38
        Me.Label2.Text = "Relation "
        '
        'lbl_Staffconphone
        '
        Me.lbl_Staffconphone.AutoSize = True
        Me.lbl_Staffconphone.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_Staffconphone.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_Staffconphone.Location = New System.Drawing.Point(10, 60)
        Me.lbl_Staffconphone.Name = "lbl_Staffconphone"
        Me.lbl_Staffconphone.Size = New System.Drawing.Size(51, 17)
        Me.lbl_Staffconphone.TabIndex = 39
        Me.lbl_Staffconphone.Text = "Phone "
        '
        'txtContactname
        '
        Me.txtContactname.BackColor = System.Drawing.Color.White
        Me.txtContactname.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtContactname.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.txtContactname.Location = New System.Drawing.Point(97, 24)
        Me.txtContactname.MaxLength = 250
        Me.txtContactname.Name = "txtContactname"
        Me.txtContactname.Size = New System.Drawing.Size(246, 21)
        Me.txtContactname.TabIndex = 1
        '
        'lbl_StaffConName
        '
        Me.lbl_StaffConName.AutoSize = True
        Me.lbl_StaffConName.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaffConName.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_StaffConName.Location = New System.Drawing.Point(10, 24)
        Me.lbl_StaffConName.Name = "lbl_StaffConName"
        Me.lbl_StaffConName.Size = New System.Drawing.Size(48, 17)
        Me.lbl_StaffConName.TabIndex = 36
        Me.lbl_StaffConName.Text = "Name "
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.Label20)
        Me.GroupBox3.Controls.Add(Me.Label16)
        Me.GroupBox3.Controls.Add(Me.Label15)
        Me.GroupBox3.Controls.Add(Me.cboKinRelation)
        Me.GroupBox3.Controls.Add(Me.lbl_Staffnextrel)
        Me.GroupBox3.Controls.Add(Me.txtNextkinno)
        Me.GroupBox3.Controls.Add(Me.lbl_Staffnextno)
        Me.GroupBox3.Controls.Add(Me.txtNextofkin)
        Me.GroupBox3.Controls.Add(Me.lbl_Staffnextkin)
        Me.GroupBox3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.GroupBox3.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.Location = New System.Drawing.Point(10, 307)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(614, 88)
        Me.GroupBox3.TabIndex = 2
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Next Of Kin Information (if any)"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.ForeColor = System.Drawing.Color.Red
        Me.Label20.Location = New System.Drawing.Point(421, 50)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(15, 19)
        Me.Label20.TabIndex = 47
        Me.Label20.Text = "*"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.ForeColor = System.Drawing.Color.Red
        Me.Label16.Location = New System.Drawing.Point(93, 50)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(15, 19)
        Me.Label16.TabIndex = 46
        Me.Label16.Text = "*"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.Color.Red
        Me.Label15.Location = New System.Drawing.Point(95, 21)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(15, 19)
        Me.Label15.TabIndex = 46
        Me.Label15.Text = "*"
        '
        'cboKinRelation
        '
        Me.cboKinRelation.AutoCompleteCustomSource.AddRange(New String() {"ATHEISM", "BUDHISM", "CHRISTIANITY", "JUDAISM", "ISLAM", "TRADITIONALIST"})
        Me.cboKinRelation.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.cboKinRelation.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.cboKinRelation.BackColor = System.Drawing.Color.White
        Me.cboKinRelation.DropDownHeight = 75
        Me.cboKinRelation.DropDownWidth = 75
        Me.cboKinRelation.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.cboKinRelation.FormattingEnabled = True
        Me.cboKinRelation.IntegralHeight = False
        Me.cboKinRelation.Items.AddRange(New Object() {"Brother", "Cousin", "Daughter", "Husband", "Nephew", "Niece", "Sister", "Son", "Wife"})
        Me.cboKinRelation.Location = New System.Drawing.Point(113, 48)
        Me.cboKinRelation.Name = "cboKinRelation"
        Me.cboKinRelation.Size = New System.Drawing.Size(197, 23)
        Me.cboKinRelation.TabIndex = 3
        '
        'lbl_Staffnextrel
        '
        Me.lbl_Staffnextrel.AutoSize = True
        Me.lbl_Staffnextrel.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold)
        Me.lbl_Staffnextrel.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_Staffnextrel.Location = New System.Drawing.Point(28, 48)
        Me.lbl_Staffnextrel.Name = "lbl_Staffnextrel"
        Me.lbl_Staffnextrel.Size = New System.Drawing.Size(59, 17)
        Me.lbl_Staffnextrel.TabIndex = 40
        Me.lbl_Staffnextrel.Text = "Relation"
        '
        'txtNextkinno
        '
        Me.txtNextkinno.BackColor = System.Drawing.Color.White
        Me.txtNextkinno.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtNextkinno.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.txtNextkinno.Location = New System.Drawing.Point(442, 48)
        Me.txtNextkinno.MaxLength = 10
        Me.txtNextkinno.Name = "txtNextkinno"
        Me.txtNextkinno.Size = New System.Drawing.Size(162, 21)
        Me.txtNextkinno.TabIndex = 2
        '
        'lbl_Staffnextno
        '
        Me.lbl_Staffnextno.AutoSize = True
        Me.lbl_Staffnextno.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold)
        Me.lbl_Staffnextno.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_Staffnextno.Location = New System.Drawing.Point(351, 50)
        Me.lbl_Staffnextno.Name = "lbl_Staffnextno"
        Me.lbl_Staffnextno.Size = New System.Drawing.Size(69, 17)
        Me.lbl_Staffnextno.TabIndex = 38
        Me.lbl_Staffnextno.Text = "Phone No"
        '
        'txtNextofkin
        '
        Me.txtNextofkin.BackColor = System.Drawing.Color.White
        Me.txtNextofkin.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtNextofkin.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.txtNextofkin.Location = New System.Drawing.Point(113, 19)
        Me.txtNextofkin.MaxLength = 250
        Me.txtNextofkin.Name = "txtNextofkin"
        Me.txtNextofkin.Size = New System.Drawing.Size(491, 21)
        Me.txtNextofkin.TabIndex = 1
        '
        'lbl_Staffnextkin
        '
        Me.lbl_Staffnextkin.AutoSize = True
        Me.lbl_Staffnextkin.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold)
        Me.lbl_Staffnextkin.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_Staffnextkin.Location = New System.Drawing.Point(24, 19)
        Me.lbl_Staffnextkin.Name = "lbl_Staffnextkin"
        Me.lbl_Staffnextkin.Size = New System.Drawing.Size(71, 17)
        Me.lbl_Staffnextkin.TabIndex = 36
        Me.lbl_Staffnextkin.Text = "Full Name"
        '
        'btnSave
        '
        Me.btnSave.BackColor = System.Drawing.SystemColors.Control
        Me.btnSave.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnSave.Font = New System.Drawing.Font("Tahoma", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSave.ForeColor = System.Drawing.Color.SteelBlue
        Me.btnSave.Image = CType(resources.GetObject("btnSave.Image"), System.Drawing.Image)
        Me.btnSave.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnSave.Location = New System.Drawing.Point(221, 19)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(145, 40)
        Me.btnSave.TabIndex = 62
        Me.btnSave.Text = "Save"
        Me.btnSave.UseVisualStyleBackColor = False
        '
        'btnClear
        '
        Me.btnClear.BackColor = System.Drawing.SystemColors.Control
        Me.btnClear.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnClear.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnClear.Font = New System.Drawing.Font("Tahoma", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClear.ForeColor = System.Drawing.Color.SteelBlue
        Me.btnClear.Image = CType(resources.GetObject("btnClear.Image"), System.Drawing.Image)
        Me.btnClear.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnClear.Location = New System.Drawing.Point(414, 19)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(145, 40)
        Me.btnClear.TabIndex = 62
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = False
        '
        'btnCancel
        '
        Me.btnCancel.BackColor = System.Drawing.SystemColors.Control
        Me.btnCancel.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnCancel.Font = New System.Drawing.Font("Tahoma", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCancel.ForeColor = System.Drawing.Color.SteelBlue
        Me.btnCancel.Image = CType(resources.GetObject("btnCancel.Image"), System.Drawing.Image)
        Me.btnCancel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnCancel.Location = New System.Drawing.Point(607, 19)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(145, 40)
        Me.btnCancel.TabIndex = 62
        Me.btnCancel.Text = "Close"
        Me.btnCancel.UseVisualStyleBackColor = False
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.btnCancel)
        Me.GroupBox5.Controls.Add(Me.btnSave)
        Me.GroupBox5.Controls.Add(Me.btnClear)
        Me.GroupBox5.Location = New System.Drawing.Point(10, 402)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(972, 74)
        Me.GroupBox5.TabIndex = 4
        Me.GroupBox5.TabStop = False
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.SteelBlue
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(992, 35)
        Me.Panel1.TabIndex = 86
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Trebuchet MS", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(347, 6)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(323, 29)
        Me.Label4.TabIndex = 12
        Me.Label4.Text = "New Employee Registration"
        '
        'frmAddNewStaff
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(992, 481)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.GroupBox4)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.Name = "frmAddNewStaff"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "SMIS"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents txtStaffmiddlename As System.Windows.Forms.TextBox
    Friend WithEvents txtStafffirstname As System.Windows.Forms.TextBox
    Friend WithEvents txtStaffsurname As System.Windows.Forms.TextBox
    Friend WithEvents lbl_StaffFirstname As System.Windows.Forms.Label
    Friend WithEvents lbl_StaffMiddlename As System.Windows.Forms.Label
    Friend WithEvents lbl_StaffSurname As System.Windows.Forms.Label
    Friend WithEvents cbomaritalstatus As System.Windows.Forms.ComboBox
    Friend WithEvents lbl_StaffMaritalStatus As System.Windows.Forms.Label
    Friend WithEvents cboTitle As System.Windows.Forms.ComboBox
    Friend WithEvents lbl_StaffTitle As System.Windows.Forms.Label
    Friend WithEvents cboGender As System.Windows.Forms.ComboBox
    Friend WithEvents lbl_StaffGender As System.Windows.Forms.Label
    Friend WithEvents cboreligion As System.Windows.Forms.ComboBox
    Friend WithEvents lblregion As System.Windows.Forms.Label
    Friend WithEvents txtstaffage As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents txthouseno As System.Windows.Forms.TextBox
    Friend WithEvents lbl_StaffHouseno As System.Windows.Forms.Label
    ' Friend WithEvents dtpStaff As Date
    Friend WithEvents lbl_StaffDOB As System.Windows.Forms.Label
    Friend WithEvents txtStaffemail As System.Windows.Forms.TextBox
    Friend WithEvents lbl_StaffEmail As System.Windows.Forms.Label
    Friend WithEvents txtStaffphone As System.Windows.Forms.TextBox
    Friend WithEvents lbl_StaffMobileno As System.Windows.Forms.Label
    Friend WithEvents txtStaffhometown As System.Windows.Forms.TextBox
    Friend WithEvents lbl_StaffHometown As System.Windows.Forms.Label
    Friend WithEvents lbl_StaffReligion As System.Windows.Forms.Label
    Friend WithEvents cboStaffregion As System.Windows.Forms.ComboBox
    Friend WithEvents cboNationality As System.Windows.Forms.ComboBox
    Friend WithEvents lbl_StaffNationality As System.Windows.Forms.Label
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents cboContactRelation As System.Windows.Forms.ComboBox
    Friend WithEvents cboOccupation As System.Windows.Forms.ComboBox
    Friend WithEvents txtContacthouse As System.Windows.Forms.TextBox
    Friend WithEvents lbl_Staffcontactno As System.Windows.Forms.Label
    Friend WithEvents lbl_StaffOccup As System.Windows.Forms.Label
    Friend WithEvents txlocality As System.Windows.Forms.TextBox
    Friend WithEvents lbl_Staffcontown As System.Windows.Forms.Label
    Friend WithEvents txtContactphone As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents lbl_Staffconphone As System.Windows.Forms.Label
    Friend WithEvents txtContactname As System.Windows.Forms.TextBox
    Friend WithEvents lbl_StaffConName As System.Windows.Forms.Label
    Friend WithEvents cboKinRelation As System.Windows.Forms.ComboBox
    Friend WithEvents lbl_Staffnextrel As System.Windows.Forms.Label
    Friend WithEvents txtNextkinno As System.Windows.Forms.TextBox
    Friend WithEvents lbl_Staffnextno As System.Windows.Forms.Label
    Friend WithEvents txtNextofkin As System.Windows.Forms.TextBox
    Friend WithEvents lbl_Staffnextkin As System.Windows.Forms.Label
    Friend WithEvents btnSave As System.Windows.Forms.Button
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents txtStaffSsnit As System.Windows.Forms.TextBox
    Friend WithEvents lbl_Staffssnit As System.Windows.Forms.Label
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtSalary As System.Windows.Forms.TextBox
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Private WithEvents Label8 As System.Windows.Forms.Label
    Private WithEvents Label7 As System.Windows.Forms.Label
    Private WithEvents Label6 As System.Windows.Forms.Label
    Private WithEvents Label5 As System.Windows.Forms.Label
    Private WithEvents Label30 As System.Windows.Forms.Label
    Private WithEvents Label10 As System.Windows.Forms.Label
    Private WithEvents Label9 As System.Windows.Forms.Label
    Private WithEvents Label11 As System.Windows.Forms.Label
    Private WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents cboAllowance As System.Windows.Forms.ComboBox
    Private WithEvents Label17 As System.Windows.Forms.Label
    Private WithEvents Label16 As System.Windows.Forms.Label
    Private WithEvents Label15 As System.Windows.Forms.Label
    Private WithEvents Label18 As System.Windows.Forms.Label
    Private WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents dtpDOB As System.Windows.Forms.DateTimePicker
    Private WithEvents Label20 As System.Windows.Forms.Label
    Private WithEvents Label22 As System.Windows.Forms.Label
    Private WithEvents Label21 As System.Windows.Forms.Label
End Class
