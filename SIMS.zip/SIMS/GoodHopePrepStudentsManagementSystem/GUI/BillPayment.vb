﻿Public Class BillPayment

    Private Sub BillPayment_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class