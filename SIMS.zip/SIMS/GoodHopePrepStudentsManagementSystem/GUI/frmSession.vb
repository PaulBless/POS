﻿Imports System.Data.SqlClient

Public Class frmSession

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub  EmptyControls()
        txtID.Text = ""
        txtYear.Text = ""
        txtTerm.Text = ""
        ''dgv.Refresh()
        GetSessionData()
    End Sub

    Private Sub GetSessionData()
        Try
            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            com1 = New SqlCommand("select * from session", ConnectionModule.con)
            dr = com1.ExecuteReader(CommandBehavior.CloseConnection)
            dgv.Rows.Clear()
            While dr.Read() = True
                dgv.Rows.Add(dr(0), dr(1), dr(2))
            End While
            'dr.Close()
            con.Close()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        Try
            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            If txtID.Text = String.Empty Then MsgBox("Invalid record selection, check..", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "SIMS Error") : Exit Sub

            If MessageBox.Show("Delete selected academic session --- '" + txtYear.Text + "'--- Term ---'" + txtTerm.Text + "---'" + vbCrLf + "Continue?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.Yes Then
                com1 = New SqlCommand("delete from Session where ID='" & dgv.SelectedRows(0).Cells(0).Value & "'", ConnectionModule.con)
                com1.ExecuteNonQuery()
                MessageBox.Show("Record deleted successfully.", "SIMS", MessageBoxButtons.OK, MessageBoxIcon.Information)
                com1.Dispose()
                con.Close()
                EmptyControls()

            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        Try
            If txtTerm.Text = String.Empty Then MsgBox("Input error, specify term.", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "SIMS Error") : Exit Sub
            If txtYear.Text = String.Empty Then MsgBox("Input error, specify academic year", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "SIMS Error") : Exit Sub
            'check record exists
            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            com1 = New SqlCommand("select * from session where Year='" & (txtYear.Text) & "' and Term='" & txtTerm.Text & "'", ConnectionModule.con)
            dr = com1.ExecuteReader(CommandBehavior.CloseConnection)
            If dr.Read() = True Then
                dr.Close()
                con.Close()
                MsgBox("Record Exists.. Cannot save duplicate record..." + vbCrLf + "NB:- Please update the record..", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "SIMS") : Exit Sub
            Else
                If con.State = ConnectionState.Open Then con.Close()
                com1 = New SqlCommand("insert into Session(Year,Term) values (@d1,@d2)", ConnectionModule.con)
                com1.Parameters.Add("@d1", SqlDbType.NVarChar).Value = txtYear.Text
                com1.Parameters.Add("@d2", SqlDbType.NVarChar).Value = txtTerm.Text
                con.Open()
                com1.ExecuteNonQuery()
                MessageBox.Show("Academic session saved successfully.", "SIMS", MessageBoxButtons.OK, MessageBoxIcon.Information)
                com1.Dispose()  'dispose the command
                con.Close()     'close the db connection
                EmptyControls() 'clear the controls
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub frmSession_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        GetSessionData()

    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        Try
            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            If txtID.Text = String.Empty Then MsgBox("Invalid record selection, check..", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "SIMS Error") : Exit Sub

            com1 = New SqlCommand("update Session set Year=@d1, Term=@d2 where ID='" & dgv.SelectedRows(0).Cells(0).Value & "'", con)
            com1.Parameters.Add("@d1", SqlDbType.NVarChar).Value = txtYear.Text
            com1.Parameters.Add("@d2", SqlDbType.NVarChar).Value = txtTerm.Text
            com1.ExecuteNonQuery()

            MessageBox.Show("Record updated successfully.", "SIMS", MessageBoxButtons.OK, MessageBoxIcon.Information)
            com1.Dispose()
            con.Close()
            EmptyControls()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub dgv_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv.CellContentClick
        Try
            txtID.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(0).Value
            txtYear.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(1).Value.ToString()
            txtTerm.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(2).Value.ToString()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub txtYear_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtYear.KeyPress
        If Asc(e.KeyChar) <> 47 AndAlso Asc(e.KeyChar) <> 13 AndAlso Asc(e.KeyChar) <> 8 AndAlso Not IsNumeric(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub

    Private Sub txtYear_TextChanged(sender As Object, e As EventArgs) Handles txtYear.TextChanged
      
    End Sub
End Class