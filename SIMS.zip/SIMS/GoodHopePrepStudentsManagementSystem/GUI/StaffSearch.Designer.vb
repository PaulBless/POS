﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class StaffSearch
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(StaffSearch))
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.txtCode = New System.Windows.Forms.TextBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.txtDept = New System.Windows.Forms.TextBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.txtStaffName = New System.Windows.Forms.TextBox()
        Me.gbostfresult = New System.Windows.Forms.GroupBox()
        Me.dgv = New System.Windows.Forms.DataGridView()
        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column28 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column29 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column22 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column8 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column9 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column10 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column13 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column12 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column24 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column21 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column11 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column23 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column14 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column15 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column26 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column16 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column17 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column18 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column19 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column20 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column27 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column25 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.btnrefresh = New System.Windows.Forms.Button()
        Me.btncancel = New System.Windows.Forms.Button()
        Me.btnUpdate = New System.Windows.Forms.Button()
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.dtpDOB = New System.Windows.Forms.DateTimePicker()
        Me.ssnit = New System.Windows.Forms.TextBox()
        Me.lbl_Staffssnit = New System.Windows.Forms.Label()
        Me.religion = New System.Windows.Forms.ComboBox()
        Me.lblregion = New System.Windows.Forms.Label()
        Me.lbl_StaffReligion = New System.Windows.Forms.Label()
        Me.txtstaffage = New System.Windows.Forms.TextBox()
        Me.region = New System.Windows.Forms.ComboBox()
        Me.nationality = New System.Windows.Forms.ComboBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.lbl_StaffNationality = New System.Windows.Forms.Label()
        Me.houseno = New System.Windows.Forms.TextBox()
        Me.lbl_StaffHouseno = New System.Windows.Forms.Label()
        Me.lbl_StaffDOB = New System.Windows.Forms.Label()
        Me.email = New System.Windows.Forms.TextBox()
        Me.lbl_StaffEmail = New System.Windows.Forms.Label()
        Me.phoneno = New System.Windows.Forms.TextBox()
        Me.lbl_StaffMobileno = New System.Windows.Forms.Label()
        Me.hometown = New System.Windows.Forms.TextBox()
        Me.lbl_StaffHometown = New System.Windows.Forms.Label()
        Me.status = New System.Windows.Forms.ComboBox()
        Me.lbl_StaffMaritalStatus = New System.Windows.Forms.Label()
        Me.cboStafftitle = New System.Windows.Forms.ComboBox()
        Me.lbl_StaffTitle = New System.Windows.Forms.Label()
        Me.gender = New System.Windows.Forms.ComboBox()
        Me.lbl_StaffGender = New System.Windows.Forms.Label()
        Me.txtStaffmiddlename = New System.Windows.Forms.TextBox()
        Me.txtStafffirstname = New System.Windows.Forms.TextBox()
        Me.txtStaffsurname = New System.Windows.Forms.TextBox()
        Me.lbl_StaffFirstname = New System.Windows.Forms.Label()
        Me.lbl_StaffMiddlename = New System.Windows.Forms.Label()
        Me.lbl_StaffSurname = New System.Windows.Forms.Label()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.cboContactRelation = New System.Windows.Forms.ComboBox()
        Me.cboContactoccupation = New System.Windows.Forms.ComboBox()
        Me.txtContacthouse = New System.Windows.Forms.TextBox()
        Me.lbl_Staffcontactno = New System.Windows.Forms.Label()
        Me.lbl_StaffOccup = New System.Windows.Forms.Label()
        Me.locality = New System.Windows.Forms.TextBox()
        Me.lbl_Staffcontown = New System.Windows.Forms.Label()
        Me.txtContactphone = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lbl_Staffconphone = New System.Windows.Forms.Label()
        Me.txtContactname = New System.Windows.Forms.TextBox()
        Me.lbl_StaffConName = New System.Windows.Forms.Label()
        Me.GroupBox8 = New System.Windows.Forms.GroupBox()
        Me.cboKinRelation = New System.Windows.Forms.ComboBox()
        Me.lbl_Staffnextrel = New System.Windows.Forms.Label()
        Me.Nextkinno = New System.Windows.Forms.TextBox()
        Me.lbl_Staffnextno = New System.Windows.Forms.Label()
        Me.nextofkin = New System.Windows.Forms.TextBox()
        Me.lbl_Staffnextkin = New System.Windows.Forms.Label()
        Me.GroupBox9 = New System.Windows.Forms.GroupBox()
        Me.txtEID = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtEmpID = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.txtSalary = New System.Windows.Forms.TextBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.gbostfresult.SuspendLayout()
        CType(Me.dgv, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox5.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        Me.GroupBox7.SuspendLayout()
        Me.GroupBox8.SuspendLayout()
        Me.GroupBox9.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.GroupBox4)
        Me.GroupBox1.Controls.Add(Me.GroupBox3)
        Me.GroupBox1.Controls.Add(Me.GroupBox2)
        Me.GroupBox1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold)
        Me.GroupBox1.Location = New System.Drawing.Point(15, 40)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(951, 82)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.txtCode)
        Me.GroupBox4.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox4.ForeColor = System.Drawing.Color.Black
        Me.GroupBox4.Location = New System.Drawing.Point(350, 15)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(250, 59)
        Me.GroupBox4.TabIndex = 45
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Search By Employee ID"
        '
        'txtCode
        '
        Me.txtCode.BackColor = System.Drawing.Color.White
        Me.txtCode.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtCode.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCode.Location = New System.Drawing.Point(33, 21)
        Me.txtCode.Name = "txtCode"
        Me.txtCode.Size = New System.Drawing.Size(184, 22)
        Me.txtCode.TabIndex = 42
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.txtDept)
        Me.GroupBox3.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.ForeColor = System.Drawing.Color.Black
        Me.GroupBox3.Location = New System.Drawing.Point(644, 15)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(276, 59)
        Me.GroupBox3.TabIndex = 44
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Search By Gender"
        '
        'txtDept
        '
        Me.txtDept.BackColor = System.Drawing.Color.White
        Me.txtDept.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtDept.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDept.Location = New System.Drawing.Point(52, 21)
        Me.txtDept.Name = "txtDept"
        Me.txtDept.Size = New System.Drawing.Size(184, 22)
        Me.txtDept.TabIndex = 42
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.txtStaffName)
        Me.GroupBox2.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.ForeColor = System.Drawing.Color.Black
        Me.GroupBox2.Location = New System.Drawing.Point(24, 15)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(276, 59)
        Me.GroupBox2.TabIndex = 43
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Search By FirstName"
        '
        'txtStaffName
        '
        Me.txtStaffName.BackColor = System.Drawing.Color.White
        Me.txtStaffName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtStaffName.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtStaffName.Location = New System.Drawing.Point(48, 21)
        Me.txtStaffName.Name = "txtStaffName"
        Me.txtStaffName.Size = New System.Drawing.Size(184, 22)
        Me.txtStaffName.TabIndex = 42
        '
        'gbostfresult
        '
        Me.gbostfresult.Controls.Add(Me.dgv)
        Me.gbostfresult.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold)
        Me.gbostfresult.Location = New System.Drawing.Point(15, 130)
        Me.gbostfresult.Name = "gbostfresult"
        Me.gbostfresult.Size = New System.Drawing.Size(954, 207)
        Me.gbostfresult.TabIndex = 31
        Me.gbostfresult.TabStop = False
        Me.gbostfresult.Text = "Search Results"
        '
        'dgv
        '
        Me.dgv.AllowUserToAddRows = False
        Me.dgv.AllowUserToResizeColumns = False
        Me.dgv.AllowUserToResizeRows = False
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.MenuHighlight
        Me.dgv.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.dgv.BackgroundColor = System.Drawing.Color.White
        Me.dgv.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.DarkSlateGray
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold)
        DataGridViewCellStyle2.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgv.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.dgv.ColumnHeadersHeight = 30
        Me.dgv.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1, Me.Column2, Me.Column3, Me.Column28, Me.Column29, Me.Column4, Me.Column22, Me.Column6, Me.Column7, Me.Column5, Me.Column8, Me.Column9, Me.Column10, Me.Column13, Me.Column12, Me.Column24, Me.Column21, Me.Column11, Me.Column23, Me.Column14, Me.Column15, Me.Column26, Me.Column16, Me.Column17, Me.Column18, Me.Column19, Me.Column20, Me.Column27, Me.Column25})
        Me.dgv.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.dgv.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgv.EnableHeadersVisualStyles = False
        Me.dgv.GridColor = System.Drawing.SystemColors.AppWorkspace
        Me.dgv.Location = New System.Drawing.Point(3, 19)
        Me.dgv.MultiSelect = False
        Me.dgv.Name = "dgv"
        Me.dgv.ReadOnly = True
        Me.dgv.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.Color.SteelBlue
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold)
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.Teal
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv.RowHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.dgv.RowHeadersVisible = False
        Me.dgv.RowHeadersWidth = 30
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle4.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.MenuHighlight
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgv.RowsDefaultCellStyle = DataGridViewCellStyle4
        Me.dgv.RowTemplate.Height = 18
        Me.dgv.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgv.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgv.Size = New System.Drawing.Size(948, 185)
        Me.dgv.TabIndex = 53
        '
        'Column1
        '
        Me.Column1.HeaderText = "No."
        Me.Column1.Name = "Column1"
        Me.Column1.ReadOnly = True
        Me.Column1.Visible = False
        Me.Column1.Width = 50
        '
        'Column2
        '
        Me.Column2.HeaderText = "Employee ID"
        Me.Column2.Name = "Column2"
        Me.Column2.ReadOnly = True
        Me.Column2.Width = 110
        '
        'Column3
        '
        Me.Column3.HeaderText = "First Name"
        Me.Column3.Name = "Column3"
        Me.Column3.ReadOnly = True
        Me.Column3.Width = 140
        '
        'Column28
        '
        Me.Column28.HeaderText = "Middle Name"
        Me.Column28.Name = "Column28"
        Me.Column28.ReadOnly = True
        Me.Column28.Width = 120
        '
        'Column29
        '
        Me.Column29.HeaderText = "Surname"
        Me.Column29.Name = "Column29"
        Me.Column29.ReadOnly = True
        Me.Column29.Width = 150
        '
        'Column4
        '
        Me.Column4.HeaderText = "Gender"
        Me.Column4.Name = "Column4"
        Me.Column4.ReadOnly = True
        Me.Column4.Width = 80
        '
        'Column22
        '
        Me.Column22.HeaderText = "Title"
        Me.Column22.Name = "Column22"
        Me.Column22.ReadOnly = True
        Me.Column22.Width = 70
        '
        'Column6
        '
        Me.Column6.HeaderText = "Date of Birth"
        Me.Column6.Name = "Column6"
        Me.Column6.ReadOnly = True
        '
        'Column7
        '
        Me.Column7.HeaderText = "Age"
        Me.Column7.Name = "Column7"
        Me.Column7.ReadOnly = True
        Me.Column7.Width = 60
        '
        'Column5
        '
        Me.Column5.HeaderText = "Marital Status"
        Me.Column5.Name = "Column5"
        Me.Column5.ReadOnly = True
        Me.Column5.Width = 110
        '
        'Column8
        '
        Me.Column8.HeaderText = "Phone No"
        Me.Column8.Name = "Column8"
        Me.Column8.ReadOnly = True
        '
        'Column9
        '
        Me.Column9.HeaderText = "Email"
        Me.Column9.Name = "Column9"
        Me.Column9.ReadOnly = True
        Me.Column9.Width = 140
        '
        'Column10
        '
        Me.Column10.HeaderText = "Hometown"
        Me.Column10.Name = "Column10"
        Me.Column10.ReadOnly = True
        Me.Column10.Width = 120
        '
        'Column13
        '
        Me.Column13.HeaderText = "House Address"
        Me.Column13.Name = "Column13"
        Me.Column13.ReadOnly = True
        Me.Column13.Width = 130
        '
        'Column12
        '
        Me.Column12.HeaderText = "Nationality"
        Me.Column12.Name = "Column12"
        Me.Column12.ReadOnly = True
        Me.Column12.Width = 120
        '
        'Column24
        '
        Me.Column24.HeaderText = "Region"
        Me.Column24.Name = "Column24"
        Me.Column24.ReadOnly = True
        Me.Column24.Width = 110
        '
        'Column21
        '
        Me.Column21.HeaderText = "Religion"
        Me.Column21.Name = "Column21"
        Me.Column21.ReadOnly = True
        Me.Column21.Width = 120
        '
        'Column11
        '
        Me.Column11.HeaderText = "SSNIT No"
        Me.Column11.Name = "Column11"
        Me.Column11.ReadOnly = True
        Me.Column11.Width = 140
        '
        'Column23
        '
        Me.Column23.HeaderText = "Basic Salary"
        Me.Column23.Name = "Column23"
        Me.Column23.ReadOnly = True
        Me.Column23.Width = 120
        '
        'Column14
        '
        Me.Column14.HeaderText = "Contact Name"
        Me.Column14.Name = "Column14"
        Me.Column14.ReadOnly = True
        Me.Column14.Width = 150
        '
        'Column15
        '
        Me.Column15.HeaderText = "Contact No"
        Me.Column15.Name = "Column15"
        Me.Column15.ReadOnly = True
        Me.Column15.Width = 110
        '
        'Column26
        '
        Me.Column26.HeaderText = "Location"
        Me.Column26.Name = "Column26"
        Me.Column26.ReadOnly = True
        Me.Column26.Width = 110
        '
        'Column16
        '
        Me.Column16.HeaderText = "Contact House No"
        Me.Column16.Name = "Column16"
        Me.Column16.ReadOnly = True
        Me.Column16.Width = 150
        '
        'Column17
        '
        Me.Column17.HeaderText = "Occupation"
        Me.Column17.Name = "Column17"
        Me.Column17.ReadOnly = True
        Me.Column17.Width = 150
        '
        'Column18
        '
        Me.Column18.HeaderText = "Relationship"
        Me.Column18.Name = "Column18"
        Me.Column18.ReadOnly = True
        Me.Column18.Width = 130
        '
        'Column19
        '
        Me.Column19.HeaderText = "Next Of Kin"
        Me.Column19.Name = "Column19"
        Me.Column19.ReadOnly = True
        Me.Column19.Width = 160
        '
        'Column20
        '
        Me.Column20.HeaderText = "Tel No of Kin"
        Me.Column20.Name = "Column20"
        Me.Column20.ReadOnly = True
        Me.Column20.Width = 120
        '
        'Column27
        '
        Me.Column27.HeaderText = "Relationship"
        Me.Column27.Name = "Column27"
        Me.Column27.ReadOnly = True
        Me.Column27.Width = 110
        '
        'Column25
        '
        Me.Column25.HeaderText = "Date Employed"
        Me.Column25.Name = "Column25"
        Me.Column25.ReadOnly = True
        Me.Column25.Width = 120
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'btnrefresh
        '
        Me.btnrefresh.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnrefresh.BackColor = System.Drawing.SystemColors.Control
        Me.btnrefresh.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnrefresh.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnrefresh.Font = New System.Drawing.Font("Tahoma", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnrefresh.ForeColor = System.Drawing.Color.SteelBlue
        Me.btnrefresh.Image = CType(resources.GetObject("btnrefresh.Image"), System.Drawing.Image)
        Me.btnrefresh.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnrefresh.Location = New System.Drawing.Point(324, 14)
        Me.btnrefresh.Name = "btnrefresh"
        Me.btnrefresh.Size = New System.Drawing.Size(140, 40)
        Me.btnrefresh.TabIndex = 34
        Me.btnrefresh.Text = "Clea&r"
        Me.btnrefresh.UseVisualStyleBackColor = False
        '
        'btncancel
        '
        Me.btncancel.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btncancel.BackColor = System.Drawing.SystemColors.Control
        Me.btncancel.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btncancel.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btncancel.Font = New System.Drawing.Font("Tahoma", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btncancel.ForeColor = System.Drawing.Color.SteelBlue
        Me.btncancel.Image = CType(resources.GetObject("btncancel.Image"), System.Drawing.Image)
        Me.btncancel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btncancel.Location = New System.Drawing.Point(660, 14)
        Me.btncancel.Name = "btncancel"
        Me.btncancel.Size = New System.Drawing.Size(140, 40)
        Me.btncancel.TabIndex = 33
        Me.btncancel.Text = "&Close"
        Me.btncancel.UseVisualStyleBackColor = False
        '
        'btnUpdate
        '
        Me.btnUpdate.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnUpdate.BackColor = System.Drawing.SystemColors.Control
        Me.btnUpdate.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnUpdate.Enabled = False
        Me.btnUpdate.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnUpdate.Font = New System.Drawing.Font("Tahoma", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnUpdate.ForeColor = System.Drawing.Color.SteelBlue
        Me.btnUpdate.Image = CType(resources.GetObject("btnUpdate.Image"), System.Drawing.Image)
        Me.btnUpdate.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnUpdate.Location = New System.Drawing.Point(156, 14)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.Size = New System.Drawing.Size(140, 40)
        Me.btnUpdate.TabIndex = 36
        Me.btnUpdate.Text = "&Save"
        Me.btnUpdate.UseVisualStyleBackColor = False
        '
        'btnDelete
        '
        Me.btnDelete.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnDelete.BackColor = System.Drawing.SystemColors.Control
        Me.btnDelete.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnDelete.Enabled = False
        Me.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnDelete.Font = New System.Drawing.Font("Tahoma", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDelete.ForeColor = System.Drawing.Color.SteelBlue
        Me.btnDelete.Image = CType(resources.GetObject("btnDelete.Image"), System.Drawing.Image)
        Me.btnDelete.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnDelete.Location = New System.Drawing.Point(492, 14)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.Size = New System.Drawing.Size(140, 40)
        Me.btnDelete.TabIndex = 35
        Me.btnDelete.Text = "&Delete"
        Me.btnDelete.UseVisualStyleBackColor = False
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.btnUpdate)
        Me.GroupBox5.Controls.Add(Me.btncancel)
        Me.GroupBox5.Controls.Add(Me.btnDelete)
        Me.GroupBox5.Controls.Add(Me.btnrefresh)
        Me.GroupBox5.Location = New System.Drawing.Point(12, 653)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(957, 60)
        Me.GroupBox5.TabIndex = 37
        Me.GroupBox5.TabStop = False
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.Label10)
        Me.GroupBox6.Controls.Add(Me.Label6)
        Me.GroupBox6.Controls.Add(Me.Label5)
        Me.GroupBox6.Controls.Add(Me.Label8)
        Me.GroupBox6.Controls.Add(Me.dtpDOB)
        Me.GroupBox6.Controls.Add(Me.ssnit)
        Me.GroupBox6.Controls.Add(Me.lbl_Staffssnit)
        Me.GroupBox6.Controls.Add(Me.religion)
        Me.GroupBox6.Controls.Add(Me.lblregion)
        Me.GroupBox6.Controls.Add(Me.lbl_StaffReligion)
        Me.GroupBox6.Controls.Add(Me.txtstaffage)
        Me.GroupBox6.Controls.Add(Me.region)
        Me.GroupBox6.Controls.Add(Me.nationality)
        Me.GroupBox6.Controls.Add(Me.Label13)
        Me.GroupBox6.Controls.Add(Me.lbl_StaffNationality)
        Me.GroupBox6.Controls.Add(Me.houseno)
        Me.GroupBox6.Controls.Add(Me.lbl_StaffHouseno)
        Me.GroupBox6.Controls.Add(Me.lbl_StaffDOB)
        Me.GroupBox6.Controls.Add(Me.email)
        Me.GroupBox6.Controls.Add(Me.lbl_StaffEmail)
        Me.GroupBox6.Controls.Add(Me.phoneno)
        Me.GroupBox6.Controls.Add(Me.lbl_StaffMobileno)
        Me.GroupBox6.Controls.Add(Me.hometown)
        Me.GroupBox6.Controls.Add(Me.lbl_StaffHometown)
        Me.GroupBox6.Controls.Add(Me.status)
        Me.GroupBox6.Controls.Add(Me.lbl_StaffMaritalStatus)
        Me.GroupBox6.Controls.Add(Me.cboStafftitle)
        Me.GroupBox6.Controls.Add(Me.lbl_StaffTitle)
        Me.GroupBox6.Controls.Add(Me.gender)
        Me.GroupBox6.Controls.Add(Me.lbl_StaffGender)
        Me.GroupBox6.Controls.Add(Me.txtStaffmiddlename)
        Me.GroupBox6.Controls.Add(Me.txtStafffirstname)
        Me.GroupBox6.Controls.Add(Me.txtStaffsurname)
        Me.GroupBox6.Controls.Add(Me.lbl_StaffFirstname)
        Me.GroupBox6.Controls.Add(Me.lbl_StaffMiddlename)
        Me.GroupBox6.Controls.Add(Me.lbl_StaffSurname)
        Me.GroupBox6.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox6.Location = New System.Drawing.Point(15, 343)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(635, 220)
        Me.GroupBox6.TabIndex = 38
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "Personal Information"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.Red
        Me.Label10.Location = New System.Drawing.Point(419, 51)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(15, 19)
        Me.Label10.TabIndex = 69
        Me.Label10.Text = "*"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.Red
        Me.Label6.Location = New System.Drawing.Point(92, 107)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(15, 19)
        Me.Label6.TabIndex = 68
        Me.Label6.Text = "*"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.Red
        Me.Label5.Location = New System.Drawing.Point(88, 51)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(15, 19)
        Me.Label5.TabIndex = 68
        Me.Label5.Text = "*"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.Red
        Me.Label8.Location = New System.Drawing.Point(91, 24)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(15, 19)
        Me.Label8.TabIndex = 68
        Me.Label8.Text = "*"
        '
        'dtpDOB
        '
        Me.dtpDOB.CalendarFont = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtpDOB.CustomFormat = "dd/MM/yyy"
        Me.dtpDOB.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtpDOB.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpDOB.Location = New System.Drawing.Point(440, 21)
        Me.dtpDOB.Name = "dtpDOB"
        Me.dtpDOB.ShowCheckBox = True
        Me.dtpDOB.Size = New System.Drawing.Size(113, 21)
        Me.dtpDOB.TabIndex = 67
        '
        'ssnit
        '
        Me.ssnit.BackColor = System.Drawing.Color.White
        Me.ssnit.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.ssnit.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.ssnit.Location = New System.Drawing.Point(440, 187)
        Me.ssnit.MaxLength = 20
        Me.ssnit.Name = "ssnit"
        Me.ssnit.Size = New System.Drawing.Size(176, 21)
        Me.ssnit.TabIndex = 66
        '
        'lbl_Staffssnit
        '
        Me.lbl_Staffssnit.AutoSize = True
        Me.lbl_Staffssnit.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold)
        Me.lbl_Staffssnit.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_Staffssnit.Location = New System.Drawing.Point(349, 190)
        Me.lbl_Staffssnit.Name = "lbl_Staffssnit"
        Me.lbl_Staffssnit.Size = New System.Drawing.Size(70, 17)
        Me.lbl_Staffssnit.TabIndex = 65
        Me.lbl_Staffssnit.Text = "SSNIT No."
        '
        'religion
        '
        Me.religion.AutoCompleteCustomSource.AddRange(New String() {"ATHEISM", "BUDHISM", "CHRISTIANITY", "JUDAISM", "ISLAM", "TRADITIONALIST"})
        Me.religion.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.religion.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.religion.BackColor = System.Drawing.Color.White
        Me.religion.DropDownHeight = 50
        Me.religion.DropDownWidth = 50
        Me.religion.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.religion.FormattingEnabled = True
        Me.religion.IntegralHeight = False
        Me.religion.Items.AddRange(New Object() {"CHRISTIANITY", "ISLAM", "TRADITIONALIST"})
        Me.religion.Location = New System.Drawing.Point(440, 157)
        Me.religion.Name = "religion"
        Me.religion.Size = New System.Drawing.Size(175, 23)
        Me.religion.TabIndex = 59
        '
        'lblregion
        '
        Me.lblregion.AutoSize = True
        Me.lblregion.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold)
        Me.lblregion.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lblregion.Location = New System.Drawing.Point(349, 161)
        Me.lblregion.Name = "lblregion"
        Me.lblregion.Size = New System.Drawing.Size(67, 17)
        Me.lblregion.TabIndex = 58
        Me.lblregion.Text = "Religion :"
        '
        'lbl_StaffReligion
        '
        Me.lbl_StaffReligion.AutoSize = True
        Me.lbl_StaffReligion.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold)
        Me.lbl_StaffReligion.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_StaffReligion.Location = New System.Drawing.Point(349, 130)
        Me.lbl_StaffReligion.Name = "lbl_StaffReligion"
        Me.lbl_StaffReligion.Size = New System.Drawing.Size(59, 17)
        Me.lbl_StaffReligion.TabIndex = 45
        Me.lbl_StaffReligion.Text = "Region :"
        '
        'txtstaffage
        '
        Me.txtstaffage.BackColor = System.Drawing.Color.White
        Me.txtstaffage.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.txtstaffage.Location = New System.Drawing.Point(593, 20)
        Me.txtstaffage.Name = "txtstaffage"
        Me.txtstaffage.Size = New System.Drawing.Size(21, 21)
        Me.txtstaffage.TabIndex = 55
        '
        'region
        '
        Me.region.AutoCompleteCustomSource.AddRange(New String() {"AMERICAN", "BURKINABE", "CHINESE", "GHANAIAN", "IVORIAN", "JAPANESE", "NIGERIAN", "TOGOLESE", "SOUTH AFRICAN", "OTHER "})
        Me.region.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.region.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.region.BackColor = System.Drawing.Color.White
        Me.region.DropDownHeight = 45
        Me.region.DropDownWidth = 45
        Me.region.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.region.FormattingEnabled = True
        Me.region.IntegralHeight = False
        Me.region.Items.AddRange(New Object() {"ASHANTI", "BRONG AHAFO", "CENTRAL", "EASTERN", "GREATER ACCRA", "NORTHERN", "UPPER EAST", "UPPER WEST", "VOLTA", "WESTERN"})
        Me.region.Location = New System.Drawing.Point(439, 129)
        Me.region.Name = "region"
        Me.region.Size = New System.Drawing.Size(175, 23)
        Me.region.Sorted = True
        Me.region.TabIndex = 43
        '
        'nationality
        '
        Me.nationality.AutoCompleteCustomSource.AddRange(New String() {"AMERICAN", "BURKINABE", "CHINESE", "GHANAIAN", "IVORIAN", "JAPANESE", "NIGERIAN", "TOGOLESE", "SOUTH AFRICAN", "OTHER "})
        Me.nationality.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.nationality.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.nationality.BackColor = System.Drawing.Color.White
        Me.nationality.DropDownHeight = 35
        Me.nationality.DropDownWidth = 35
        Me.nationality.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.nationality.FormattingEnabled = True
        Me.nationality.IntegralHeight = False
        Me.nationality.Items.AddRange(New Object() {"GHANAIAN", "NON-GHANAIAN"})
        Me.nationality.Location = New System.Drawing.Point(439, 101)
        Me.nationality.Name = "nationality"
        Me.nationality.Size = New System.Drawing.Size(175, 23)
        Me.nationality.TabIndex = 44
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label13.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.Label13.Location = New System.Drawing.Point(559, 24)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(36, 17)
        Me.Label13.TabIndex = 54
        Me.Label13.Text = "Age:"
        '
        'lbl_StaffNationality
        '
        Me.lbl_StaffNationality.AutoSize = True
        Me.lbl_StaffNationality.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold)
        Me.lbl_StaffNationality.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_StaffNationality.Location = New System.Drawing.Point(349, 105)
        Me.lbl_StaffNationality.Name = "lbl_StaffNationality"
        Me.lbl_StaffNationality.Size = New System.Drawing.Size(85, 17)
        Me.lbl_StaffNationality.TabIndex = 42
        Me.lbl_StaffNationality.Text = "Nationality :"
        '
        'houseno
        '
        Me.houseno.BackColor = System.Drawing.Color.White
        Me.houseno.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.houseno.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.houseno.Location = New System.Drawing.Point(113, 190)
        Me.houseno.MaxLength = 300
        Me.houseno.Name = "houseno"
        Me.houseno.Size = New System.Drawing.Size(216, 21)
        Me.houseno.TabIndex = 53
        '
        'lbl_StaffHouseno
        '
        Me.lbl_StaffHouseno.AutoSize = True
        Me.lbl_StaffHouseno.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold)
        Me.lbl_StaffHouseno.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_StaffHouseno.Location = New System.Drawing.Point(16, 187)
        Me.lbl_StaffHouseno.Name = "lbl_StaffHouseno"
        Me.lbl_StaffHouseno.Size = New System.Drawing.Size(63, 17)
        Me.lbl_StaffHouseno.TabIndex = 52
        Me.lbl_StaffHouseno.Text = "House #:"
        '
        'lbl_StaffDOB
        '
        Me.lbl_StaffDOB.AutoSize = True
        Me.lbl_StaffDOB.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold)
        Me.lbl_StaffDOB.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_StaffDOB.Location = New System.Drawing.Point(349, 24)
        Me.lbl_StaffDOB.Name = "lbl_StaffDOB"
        Me.lbl_StaffDOB.Size = New System.Drawing.Size(92, 17)
        Me.lbl_StaffDOB.TabIndex = 50
        Me.lbl_StaffDOB.Text = "Date of Birth:"
        '
        'email
        '
        Me.email.BackColor = System.Drawing.Color.White
        Me.email.CharacterCasing = System.Windows.Forms.CharacterCasing.Lower
        Me.email.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.email.Location = New System.Drawing.Point(439, 74)
        Me.email.Name = "email"
        Me.email.Size = New System.Drawing.Size(176, 21)
        Me.email.TabIndex = 49
        '
        'lbl_StaffEmail
        '
        Me.lbl_StaffEmail.AutoSize = True
        Me.lbl_StaffEmail.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold)
        Me.lbl_StaffEmail.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_StaffEmail.Location = New System.Drawing.Point(349, 78)
        Me.lbl_StaffEmail.Name = "lbl_StaffEmail"
        Me.lbl_StaffEmail.Size = New System.Drawing.Size(46, 17)
        Me.lbl_StaffEmail.TabIndex = 48
        Me.lbl_StaffEmail.Text = "Email "
        '
        'phoneno
        '
        Me.phoneno.BackColor = System.Drawing.Color.White
        Me.phoneno.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.phoneno.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.phoneno.Location = New System.Drawing.Point(439, 49)
        Me.phoneno.MaxLength = 10
        Me.phoneno.Name = "phoneno"
        Me.phoneno.Size = New System.Drawing.Size(175, 21)
        Me.phoneno.TabIndex = 47
        '
        'lbl_StaffMobileno
        '
        Me.lbl_StaffMobileno.AutoSize = True
        Me.lbl_StaffMobileno.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold)
        Me.lbl_StaffMobileno.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_StaffMobileno.Location = New System.Drawing.Point(349, 53)
        Me.lbl_StaffMobileno.Name = "lbl_StaffMobileno"
        Me.lbl_StaffMobileno.Size = New System.Drawing.Size(73, 17)
        Me.lbl_StaffMobileno.TabIndex = 46
        Me.lbl_StaffMobileno.Text = "Phone No."
        '
        'hometown
        '
        Me.hometown.BackColor = System.Drawing.Color.White
        Me.hometown.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.hometown.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.hometown.Location = New System.Drawing.Point(113, 163)
        Me.hometown.MaxLength = 200
        Me.hometown.Name = "hometown"
        Me.hometown.Size = New System.Drawing.Size(216, 21)
        Me.hometown.TabIndex = 43
        '
        'lbl_StaffHometown
        '
        Me.lbl_StaffHometown.AutoSize = True
        Me.lbl_StaffHometown.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold)
        Me.lbl_StaffHometown.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_StaffHometown.Location = New System.Drawing.Point(16, 162)
        Me.lbl_StaffHometown.Name = "lbl_StaffHometown"
        Me.lbl_StaffHometown.Size = New System.Drawing.Size(84, 17)
        Me.lbl_StaffHometown.TabIndex = 42
        Me.lbl_StaffHometown.Text = "Hometown :"
        '
        'status
        '
        Me.status.AutoCompleteCustomSource.AddRange(New String() {"Attached", "Divorced", "Married", "Single"})
        Me.status.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.status.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.status.BackColor = System.Drawing.Color.White
        Me.status.DropDownHeight = 65
        Me.status.DropDownWidth = 65
        Me.status.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.status.FormattingEnabled = True
        Me.status.IntegralHeight = False
        Me.status.Items.AddRange(New Object() {"Attached", "Divorced", "Married", "Single"})
        Me.status.Location = New System.Drawing.Point(113, 134)
        Me.status.Name = "status"
        Me.status.Size = New System.Drawing.Size(215, 23)
        Me.status.Sorted = True
        Me.status.TabIndex = 27
        '
        'lbl_StaffMaritalStatus
        '
        Me.lbl_StaffMaritalStatus.AutoSize = True
        Me.lbl_StaffMaritalStatus.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold)
        Me.lbl_StaffMaritalStatus.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_StaffMaritalStatus.Location = New System.Drawing.Point(16, 136)
        Me.lbl_StaffMaritalStatus.Name = "lbl_StaffMaritalStatus"
        Me.lbl_StaffMaritalStatus.Size = New System.Drawing.Size(98, 17)
        Me.lbl_StaffMaritalStatus.TabIndex = 26
        Me.lbl_StaffMaritalStatus.Text = "Marital Status:"
        '
        'cboStafftitle
        '
        Me.cboStafftitle.AutoCompleteCustomSource.AddRange(New String() {"Miss", "Mr", "Mrs"})
        Me.cboStafftitle.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.cboStafftitle.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.cboStafftitle.BackColor = System.Drawing.Color.White
        Me.cboStafftitle.DropDownHeight = 50
        Me.cboStafftitle.DropDownWidth = 50
        Me.cboStafftitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.cboStafftitle.FormattingEnabled = True
        Me.cboStafftitle.IntegralHeight = False
        Me.cboStafftitle.Items.AddRange(New Object() {"Hajia", "Miss", "Mr", "Mrs"})
        Me.cboStafftitle.Location = New System.Drawing.Point(255, 105)
        Me.cboStafftitle.Name = "cboStafftitle"
        Me.cboStafftitle.Size = New System.Drawing.Size(73, 23)
        Me.cboStafftitle.Sorted = True
        Me.cboStafftitle.TabIndex = 25
        '
        'lbl_StaffTitle
        '
        Me.lbl_StaffTitle.AutoSize = True
        Me.lbl_StaffTitle.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaffTitle.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_StaffTitle.Location = New System.Drawing.Point(212, 107)
        Me.lbl_StaffTitle.Name = "lbl_StaffTitle"
        Me.lbl_StaffTitle.Size = New System.Drawing.Size(40, 17)
        Me.lbl_StaffTitle.TabIndex = 24
        Me.lbl_StaffTitle.Text = "Title:"
        '
        'gender
        '
        Me.gender.AutoCompleteCustomSource.AddRange(New String() {"FEMALE", "MALE"})
        Me.gender.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.gender.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.gender.BackColor = System.Drawing.Color.White
        Me.gender.DropDownHeight = 35
        Me.gender.DropDownWidth = 35
        Me.gender.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.gender.FormattingEnabled = True
        Me.gender.IntegralHeight = False
        Me.gender.Items.AddRange(New Object() {"FEMALE", "MALE"})
        Me.gender.Location = New System.Drawing.Point(113, 105)
        Me.gender.Name = "gender"
        Me.gender.Size = New System.Drawing.Size(93, 23)
        Me.gender.TabIndex = 23
        '
        'lbl_StaffGender
        '
        Me.lbl_StaffGender.AutoSize = True
        Me.lbl_StaffGender.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold)
        Me.lbl_StaffGender.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_StaffGender.Location = New System.Drawing.Point(19, 107)
        Me.lbl_StaffGender.Name = "lbl_StaffGender"
        Me.lbl_StaffGender.Size = New System.Drawing.Size(60, 17)
        Me.lbl_StaffGender.TabIndex = 22
        Me.lbl_StaffGender.Text = "Gender :"
        '
        'txtStaffmiddlename
        '
        Me.txtStaffmiddlename.BackColor = System.Drawing.Color.White
        Me.txtStaffmiddlename.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtStaffmiddlename.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.txtStaffmiddlename.Location = New System.Drawing.Point(113, 78)
        Me.txtStaffmiddlename.MaxLength = 200
        Me.txtStaffmiddlename.Name = "txtStaffmiddlename"
        Me.txtStaffmiddlename.Size = New System.Drawing.Size(216, 21)
        Me.txtStaffmiddlename.TabIndex = 12
        '
        'txtStafffirstname
        '
        Me.txtStafffirstname.BackColor = System.Drawing.Color.White
        Me.txtStafffirstname.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtStafffirstname.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.txtStafffirstname.Location = New System.Drawing.Point(113, 51)
        Me.txtStafffirstname.MaxLength = 200
        Me.txtStafffirstname.Name = "txtStafffirstname"
        Me.txtStafffirstname.Size = New System.Drawing.Size(216, 21)
        Me.txtStafffirstname.TabIndex = 11
        '
        'txtStaffsurname
        '
        Me.txtStaffsurname.BackColor = System.Drawing.Color.White
        Me.txtStaffsurname.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtStaffsurname.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.txtStaffsurname.Location = New System.Drawing.Point(113, 24)
        Me.txtStaffsurname.MaxLength = 200
        Me.txtStaffsurname.Name = "txtStaffsurname"
        Me.txtStaffsurname.Size = New System.Drawing.Size(216, 21)
        Me.txtStaffsurname.TabIndex = 10
        '
        'lbl_StaffFirstname
        '
        Me.lbl_StaffFirstname.AutoSize = True
        Me.lbl_StaffFirstname.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold)
        Me.lbl_StaffFirstname.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_StaffFirstname.Location = New System.Drawing.Point(16, 51)
        Me.lbl_StaffFirstname.Name = "lbl_StaffFirstname"
        Me.lbl_StaffFirstname.Size = New System.Drawing.Size(83, 17)
        Me.lbl_StaffFirstname.TabIndex = 9
        Me.lbl_StaffFirstname.Text = "First Name :"
        '
        'lbl_StaffMiddlename
        '
        Me.lbl_StaffMiddlename.AutoSize = True
        Me.lbl_StaffMiddlename.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold)
        Me.lbl_StaffMiddlename.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_StaffMiddlename.Location = New System.Drawing.Point(16, 78)
        Me.lbl_StaffMiddlename.Name = "lbl_StaffMiddlename"
        Me.lbl_StaffMiddlename.Size = New System.Drawing.Size(99, 17)
        Me.lbl_StaffMiddlename.TabIndex = 8
        Me.lbl_StaffMiddlename.Text = "Middle Name :"
        '
        'lbl_StaffSurname
        '
        Me.lbl_StaffSurname.AutoSize = True
        Me.lbl_StaffSurname.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold)
        Me.lbl_StaffSurname.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_StaffSurname.Location = New System.Drawing.Point(16, 24)
        Me.lbl_StaffSurname.Name = "lbl_StaffSurname"
        Me.lbl_StaffSurname.Size = New System.Drawing.Size(70, 17)
        Me.lbl_StaffSurname.TabIndex = 7
        Me.lbl_StaffSurname.Text = "Surname :"
        '
        'GroupBox7
        '
        Me.GroupBox7.Controls.Add(Me.Label9)
        Me.GroupBox7.Controls.Add(Me.Label7)
        Me.GroupBox7.Controls.Add(Me.cboContactRelation)
        Me.GroupBox7.Controls.Add(Me.cboContactoccupation)
        Me.GroupBox7.Controls.Add(Me.txtContacthouse)
        Me.GroupBox7.Controls.Add(Me.lbl_Staffcontactno)
        Me.GroupBox7.Controls.Add(Me.lbl_StaffOccup)
        Me.GroupBox7.Controls.Add(Me.locality)
        Me.GroupBox7.Controls.Add(Me.lbl_Staffcontown)
        Me.GroupBox7.Controls.Add(Me.txtContactphone)
        Me.GroupBox7.Controls.Add(Me.Label2)
        Me.GroupBox7.Controls.Add(Me.lbl_Staffconphone)
        Me.GroupBox7.Controls.Add(Me.txtContactname)
        Me.GroupBox7.Controls.Add(Me.lbl_StaffConName)
        Me.GroupBox7.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox7.Location = New System.Drawing.Point(659, 343)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(310, 220)
        Me.GroupBox7.TabIndex = 39
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "Contact Information"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.Red
        Me.Label9.Location = New System.Drawing.Point(80, 51)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(15, 19)
        Me.Label9.TabIndex = 69
        Me.Label9.Text = "*"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.Red
        Me.Label7.Location = New System.Drawing.Point(71, 22)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(15, 19)
        Me.Label7.TabIndex = 69
        Me.Label7.Text = "*"
        '
        'cboContactRelation
        '
        Me.cboContactRelation.AutoCompleteCustomSource.AddRange(New String() {"ACCOUNTANT", "APPRENTICE", "ARCHITECT", "ARMY OFFICER", "ARTISAN", "ASSEMBLYMAN", "AUDITOR", "BAKER", "BANKER", "BEAUTY PRACTITIONER", "BUSINESSMAN", "BUSINESS ANALYST", "CARPENTOR", "CATERER", "CHEF", "CIVIL SERVANT", "CLERGY", "COMPUTER SCIENTIST", "CONSTRUCTION ENGINEER", "DATABASE ADMINISTRATOR", "DESIGNER", "DISPENSING ASSISTANT", "DOCTOR", "DRIVER", "ELECTRICIAN", "FARMER", "FASHION DESIGNER", "FISHERMAN", "FISH MONGER", "FOOD VENDOR", "FOOTBALLER", "FOREIGN DIPLOMAT", "HAIR DRESSER", "HEALTH AID ", "HOUSE WIFE", "IMMIGRATION OFFICER", "LABOURER", "LAWYER", "LEGAL PRACTITIONER", "MASON", "MATRON", "MEDICAL PRACTITIONER", "MINER", "MINING ENGINEER", "MUSICIAN", "NETWORK ADMINISTRATOR", "NETWORK ENGINEER", "NURSE", "OTHER", "PAINTER", "PASTOR", "PENSIONER", "PHARMACIST", "PHARMACY TECHNICIAN", "POLICE OFFICER", "PROGRAMMER", "PUBLIC SERVANT", "RADIO PRESENTER", "REAL ESTATE AGENT", "RECEPTIONIST", "SALES PERSON", "SEAMSTRESS", "SECRETARY", "SECURITY", "STATE MINSTER", "STOCK BROKER", "STORE KEEPER", "SYSTEM ADMINISTRATOR", "TAILOR", "TEACHER", "TRADER", "TRAVEL AGENT", "TYPIST", "UNEMPLOYED"})
        Me.cboContactRelation.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.cboContactRelation.BackColor = System.Drawing.Color.White
        Me.cboContactRelation.DropDownHeight = 105
        Me.cboContactRelation.DropDownWidth = 105
        Me.cboContactRelation.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.cboContactRelation.FormattingEnabled = True
        Me.cboContactRelation.IntegralHeight = False
        Me.cboContactRelation.Items.AddRange(New Object() {"Aunt", "Brother", "Father", "GrandFather", "GrandMother", "Mother", "Other", "Sister", "StepFather", "StepMother", "Uncle"})
        Me.cboContactRelation.Location = New System.Drawing.Point(94, 132)
        Me.cboContactRelation.Name = "cboContactRelation"
        Me.cboContactRelation.Size = New System.Drawing.Size(210, 23)
        Me.cboContactRelation.Sorted = True
        Me.cboContactRelation.TabIndex = 46
        '
        'cboContactoccupation
        '
        Me.cboContactoccupation.AutoCompleteCustomSource.AddRange(New String() {"ACCOUNTANT", "APPRENTICE", "ARCHITECT", "ARMY OFFICER", "ARTISAN", "ASSEMBLYMAN", "AUDITOR", "BAKER", "BANKER", "BEAUTY PRACTITIONER", "BUSINESSMAN", "BUSINESS ANALYST", "CARPENTOR", "CATERER", "CHEF", "CIVIL SERVANT", "CLERGY", "COMPUTER SCIENTIST", "CONSTRUCTION ENGINEER", "DATABASE ADMINISTRATOR", "DESIGNER", "DISPENSING ASSISTANT", "DOCTOR", "DRIVER", "ELECTRICIAN", "FARMER", "FASHION DESIGNER", "FISHERMAN", "FISH MONGER", "FOOD VENDOR", "FOOTBALLER", "FOREIGN DIPLOMAT", "HAIR DRESSER", "HEALTH AID ", "HOUSE WIFE", "IMMIGRATION OFFICER", "LABOURER", "LAWYER", "LEGAL PRACTITIONER", "MASON", "MATRON", "MEDICAL PRACTITIONER", "MINER", "MINING ENGINEER", "MUSICIAN", "NETWORK ADMINISTRATOR", "NETWORK ENGINEER", "NURSE", "OTHER", "PAINTER", "PASTOR", "PENSIONER", "PHARMACIST", "PHARMACY TECHNICIAN", "POLICE OFFICER", "PROGRAMMER", "PUBLIC SERVANT", "RADIO PRESENTER", "REAL ESTATE AGENT", "RECEPTIONIST", "SALES PERSON", "SEAMSTRESS", "SECRETARY", "SECURITY", "STATE MINSTER", "STOCK BROKER", "STORE KEEPER", "SYSTEM ADMINISTRATOR", "TAILOR", "TEACHER", "TRADER", "TRAVEL AGENT", "TYPIST", "UNEMPLOYED"})
        Me.cboContactoccupation.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.cboContactoccupation.BackColor = System.Drawing.Color.White
        Me.cboContactoccupation.DropDownHeight = 105
        Me.cboContactoccupation.DropDownWidth = 105
        Me.cboContactoccupation.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.cboContactoccupation.FormattingEnabled = True
        Me.cboContactoccupation.IntegralHeight = False
        Me.cboContactoccupation.Items.AddRange(New Object() {"ACCOUNTANT", "APPRENTICE", "ARCHITECT", "ARMY OFFICER", "ARTISAN", "ASSEMBLYMAN", "AUDITOR", "BAKER", "BANKER", "BEAUTY PRACTITIONER", "BUSINESS ANALYST", "BUSINESSMAN", "CARPENTOR", "CATERER", "CHEF", "CIVIL SERVANT", "CLERGY", "COMPUTER SCIENTIST", "CONSTRUCTION ENGINEER", "DATABASE ADMINISTRATOR", "DESIGNER", "DISPENSING ASSISTANT", "DOCTOR", "DRIVER", "ELECTRICIAN", "FARMER", "FASHION DESIGNER", "FISH MONGER", "FISHERMAN", "FOOD VENDOR", "FOOTBALLER", "FOREIGN DIPLOMAT", "HAIR DRESSER", "HEALTH AID ", "HOUSE WIFE", "IMMIGRATION OFFICER", "LABOURER", "LAWYER", "LEGAL PRACTITIONER", "MASON", "MATRON", "MEDICAL PRACTITIONER", "MINER", "MINING ENGINEER", "MUSICIAN", "NETWORK ADMINISTRATOR", "NETWORK ENGINEER", "NURSE", "OTHER", "PAINTER", "PASTOR", "PENSIONER", "PHARMACIST", "PHARMACY TECHNICIAN", "POLICE OFFICER", "PROGRAMMER", "PUBLIC SERVANT", "RADIO PRESENTER", "REAL ESTATE AGENT", "RECEPTIONIST", "SALES PERSON", "SEAMSTRESS", "SECRETARY", "SECURITY", "STATE MINSTER", "STOCK BROKER", "STORE KEEPER", "SYSTEM ADMINISTRATOR", "TAILOR", "TEACHER", "TRADER", "TRAVEL AGENT", "TYPIST", "UNEMPLOYED"})
        Me.cboContactoccupation.Location = New System.Drawing.Point(94, 161)
        Me.cboContactoccupation.Name = "cboContactoccupation"
        Me.cboContactoccupation.Size = New System.Drawing.Size(210, 23)
        Me.cboContactoccupation.Sorted = True
        Me.cboContactoccupation.TabIndex = 47
        '
        'txtContacthouse
        '
        Me.txtContacthouse.BackColor = System.Drawing.Color.White
        Me.txtContacthouse.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtContacthouse.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.txtContacthouse.Location = New System.Drawing.Point(95, 104)
        Me.txtContacthouse.MaxLength = 100
        Me.txtContacthouse.Name = "txtContacthouse"
        Me.txtContacthouse.Size = New System.Drawing.Size(210, 21)
        Me.txtContacthouse.TabIndex = 45
        '
        'lbl_Staffcontactno
        '
        Me.lbl_Staffcontactno.AutoSize = True
        Me.lbl_Staffcontactno.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold)
        Me.lbl_Staffcontactno.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_Staffcontactno.Location = New System.Drawing.Point(13, 106)
        Me.lbl_Staffcontactno.Name = "lbl_Staffcontactno"
        Me.lbl_Staffcontactno.Size = New System.Drawing.Size(77, 17)
        Me.lbl_Staffcontactno.TabIndex = 44
        Me.lbl_Staffcontactno.Text = "House No :"
        '
        'lbl_StaffOccup
        '
        Me.lbl_StaffOccup.AutoSize = True
        Me.lbl_StaffOccup.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold)
        Me.lbl_StaffOccup.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_StaffOccup.Location = New System.Drawing.Point(13, 164)
        Me.lbl_StaffOccup.Name = "lbl_StaffOccup"
        Me.lbl_StaffOccup.Size = New System.Drawing.Size(86, 17)
        Me.lbl_StaffOccup.TabIndex = 43
        Me.lbl_StaffOccup.Text = "Occupation :"
        '
        'locality
        '
        Me.locality.BackColor = System.Drawing.Color.White
        Me.locality.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.locality.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.locality.Location = New System.Drawing.Point(95, 76)
        Me.locality.MaxLength = 100
        Me.locality.Name = "locality"
        Me.locality.Size = New System.Drawing.Size(210, 21)
        Me.locality.TabIndex = 42
        '
        'lbl_Staffcontown
        '
        Me.lbl_Staffcontown.AutoSize = True
        Me.lbl_Staffcontown.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold)
        Me.lbl_Staffcontown.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_Staffcontown.Location = New System.Drawing.Point(13, 79)
        Me.lbl_Staffcontown.Name = "lbl_Staffcontown"
        Me.lbl_Staffcontown.Size = New System.Drawing.Size(49, 17)
        Me.lbl_Staffcontown.TabIndex = 41
        Me.lbl_Staffcontown.Text = "Town :"
        '
        'txtContactphone
        '
        Me.txtContactphone.BackColor = System.Drawing.Color.White
        Me.txtContactphone.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtContactphone.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.txtContactphone.Location = New System.Drawing.Point(95, 48)
        Me.txtContactphone.MaxLength = 10
        Me.txtContactphone.Name = "txtContactphone"
        Me.txtContactphone.Size = New System.Drawing.Size(210, 21)
        Me.txtContactphone.TabIndex = 40
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label2.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.Label2.Location = New System.Drawing.Point(13, 136)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(67, 17)
        Me.Label2.TabIndex = 38
        Me.Label2.Text = "Relation :"
        '
        'lbl_Staffconphone
        '
        Me.lbl_Staffconphone.AutoSize = True
        Me.lbl_Staffconphone.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold)
        Me.lbl_Staffconphone.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_Staffconphone.Location = New System.Drawing.Point(13, 51)
        Me.lbl_Staffconphone.Name = "lbl_Staffconphone"
        Me.lbl_Staffconphone.Size = New System.Drawing.Size(73, 17)
        Me.lbl_Staffconphone.TabIndex = 39
        Me.lbl_Staffconphone.Text = "Phone No."
        '
        'txtContactname
        '
        Me.txtContactname.BackColor = System.Drawing.Color.White
        Me.txtContactname.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtContactname.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.txtContactname.Location = New System.Drawing.Point(94, 20)
        Me.txtContactname.MaxLength = 250
        Me.txtContactname.Name = "txtContactname"
        Me.txtContactname.Size = New System.Drawing.Size(211, 21)
        Me.txtContactname.TabIndex = 37
        '
        'lbl_StaffConName
        '
        Me.lbl_StaffConName.AutoSize = True
        Me.lbl_StaffConName.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold)
        Me.lbl_StaffConName.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_StaffConName.Location = New System.Drawing.Point(13, 22)
        Me.lbl_StaffConName.Name = "lbl_StaffConName"
        Me.lbl_StaffConName.Size = New System.Drawing.Size(52, 17)
        Me.lbl_StaffConName.TabIndex = 36
        Me.lbl_StaffConName.Text = "Name :"
        '
        'GroupBox8
        '
        Me.GroupBox8.Controls.Add(Me.cboKinRelation)
        Me.GroupBox8.Controls.Add(Me.lbl_Staffnextrel)
        Me.GroupBox8.Controls.Add(Me.Nextkinno)
        Me.GroupBox8.Controls.Add(Me.lbl_Staffnextno)
        Me.GroupBox8.Controls.Add(Me.nextofkin)
        Me.GroupBox8.Controls.Add(Me.lbl_Staffnextkin)
        Me.GroupBox8.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox8.Location = New System.Drawing.Point(15, 569)
        Me.GroupBox8.Name = "GroupBox8"
        Me.GroupBox8.Size = New System.Drawing.Size(635, 83)
        Me.GroupBox8.TabIndex = 40
        Me.GroupBox8.TabStop = False
        Me.GroupBox8.Text = "Next Of Kin Information"
        '
        'cboKinRelation
        '
        Me.cboKinRelation.AutoCompleteCustomSource.AddRange(New String() {"ATHEISM", "BUDHISM", "CHRISTIANITY", "JUDAISM", "ISLAM", "TRADITIONALIST"})
        Me.cboKinRelation.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.cboKinRelation.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.cboKinRelation.BackColor = System.Drawing.Color.White
        Me.cboKinRelation.DropDownHeight = 75
        Me.cboKinRelation.DropDownWidth = 75
        Me.cboKinRelation.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.cboKinRelation.FormattingEnabled = True
        Me.cboKinRelation.IntegralHeight = False
        Me.cboKinRelation.Items.AddRange(New Object() {"Brother", "Cousin", "Daughter", "Husband", "Nephew", "Niece", "Sister", "Son", "Wife"})
        Me.cboKinRelation.Location = New System.Drawing.Point(116, 48)
        Me.cboKinRelation.Name = "cboKinRelation"
        Me.cboKinRelation.Size = New System.Drawing.Size(213, 23)
        Me.cboKinRelation.Sorted = True
        Me.cboKinRelation.TabIndex = 41
        '
        'lbl_Staffnextrel
        '
        Me.lbl_Staffnextrel.AutoSize = True
        Me.lbl_Staffnextrel.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold)
        Me.lbl_Staffnextrel.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_Staffnextrel.Location = New System.Drawing.Point(23, 52)
        Me.lbl_Staffnextrel.Name = "lbl_Staffnextrel"
        Me.lbl_Staffnextrel.Size = New System.Drawing.Size(67, 17)
        Me.lbl_Staffnextrel.TabIndex = 40
        Me.lbl_Staffnextrel.Text = "Relation :"
        '
        'Nextkinno
        '
        Me.Nextkinno.BackColor = System.Drawing.Color.White
        Me.Nextkinno.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.Nextkinno.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.Nextkinno.Location = New System.Drawing.Point(440, 18)
        Me.Nextkinno.MaxLength = 10
        Me.Nextkinno.Name = "Nextkinno"
        Me.Nextkinno.Size = New System.Drawing.Size(176, 21)
        Me.Nextkinno.TabIndex = 39
        '
        'lbl_Staffnextno
        '
        Me.lbl_Staffnextno.AutoSize = True
        Me.lbl_Staffnextno.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold)
        Me.lbl_Staffnextno.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_Staffnextno.Location = New System.Drawing.Point(354, 22)
        Me.lbl_Staffnextno.Name = "lbl_Staffnextno"
        Me.lbl_Staffnextno.Size = New System.Drawing.Size(77, 17)
        Me.lbl_Staffnextno.TabIndex = 38
        Me.lbl_Staffnextno.Text = "Phone No :"
        '
        'nextofkin
        '
        Me.nextofkin.BackColor = System.Drawing.Color.White
        Me.nextofkin.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.nextofkin.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.nextofkin.Location = New System.Drawing.Point(116, 19)
        Me.nextofkin.MaxLength = 350
        Me.nextofkin.Name = "nextofkin"
        Me.nextofkin.Size = New System.Drawing.Size(213, 21)
        Me.nextofkin.TabIndex = 37
        '
        'lbl_Staffnextkin
        '
        Me.lbl_Staffnextkin.AutoSize = True
        Me.lbl_Staffnextkin.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold)
        Me.lbl_Staffnextkin.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_Staffnextkin.Location = New System.Drawing.Point(27, 23)
        Me.lbl_Staffnextkin.Name = "lbl_Staffnextkin"
        Me.lbl_Staffnextkin.Size = New System.Drawing.Size(79, 17)
        Me.lbl_Staffnextkin.TabIndex = 36
        Me.lbl_Staffnextkin.Text = "Full Name :"
        '
        'GroupBox9
        '
        Me.GroupBox9.Controls.Add(Me.txtEID)
        Me.GroupBox9.Controls.Add(Me.Label3)
        Me.GroupBox9.Controls.Add(Me.Label1)
        Me.GroupBox9.Controls.Add(Me.txtEmpID)
        Me.GroupBox9.Controls.Add(Me.Label11)
        Me.GroupBox9.Controls.Add(Me.txtSalary)
        Me.GroupBox9.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox9.Location = New System.Drawing.Point(659, 569)
        Me.GroupBox9.Name = "GroupBox9"
        Me.GroupBox9.Size = New System.Drawing.Size(310, 83)
        Me.GroupBox9.TabIndex = 65
        Me.GroupBox9.TabStop = False
        Me.GroupBox9.Text = "Job && Salary Information"
        '
        'txtEID
        '
        Me.txtEID.BackColor = System.Drawing.Color.White
        Me.txtEID.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtEID.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.txtEID.Location = New System.Drawing.Point(275, 49)
        Me.txtEID.Name = "txtEID"
        Me.txtEID.ReadOnly = True
        Me.txtEID.Size = New System.Drawing.Size(27, 21)
        Me.txtEID.TabIndex = 42
        Me.txtEID.Visible = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.Label3.Location = New System.Drawing.Point(22, 49)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(94, 17)
        Me.Label3.TabIndex = 38
        Me.Label3.Text = "Employee ID :"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.Label1.Location = New System.Drawing.Point(22, 23)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(89, 17)
        Me.Label1.TabIndex = 38
        Me.Label1.Text = "Basic Salary :"
        '
        'txtEmpID
        '
        Me.txtEmpID.BackColor = System.Drawing.Color.White
        Me.txtEmpID.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtEmpID.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.txtEmpID.Location = New System.Drawing.Point(136, 48)
        Me.txtEmpID.Name = "txtEmpID"
        Me.txtEmpID.ReadOnly = True
        Me.txtEmpID.Size = New System.Drawing.Size(130, 21)
        Me.txtEmpID.TabIndex = 39
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label11.ForeColor = System.Drawing.Color.DarkRed
        Me.Label11.Location = New System.Drawing.Point(269, 22)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(32, 17)
        Me.Label11.TabIndex = 54
        Me.Label11.Text = "Gh¢"
        '
        'txtSalary
        '
        Me.txtSalary.BackColor = System.Drawing.Color.White
        Me.txtSalary.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtSalary.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.txtSalary.Location = New System.Drawing.Point(136, 20)
        Me.txtSalary.MaxLength = 10
        Me.txtSalary.Name = "txtSalary"
        Me.txtSalary.Size = New System.Drawing.Size(130, 21)
        Me.txtSalary.TabIndex = 39
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.SteelBlue
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(981, 35)
        Me.Panel1.TabIndex = 86
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Trebuchet MS", 18.0!, System.Drawing.FontStyle.Bold)
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(340, 5)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(301, 29)
        Me.Label4.TabIndex = 12
        Me.Label4.Text = "Employee Profile Mastery"
        '
        'StaffSearch
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(981, 720)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.GroupBox9)
        Me.Controls.Add(Me.GroupBox8)
        Me.Controls.Add(Me.GroupBox7)
        Me.Controls.Add(Me.GroupBox6)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.gbostfresult)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "StaffSearch"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "SIMS"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.gbostfresult.ResumeLayout(False)
        CType(Me.dgv, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        Me.GroupBox7.ResumeLayout(False)
        Me.GroupBox7.PerformLayout()
        Me.GroupBox8.ResumeLayout(False)
        Me.GroupBox8.PerformLayout()
        Me.GroupBox9.ResumeLayout(False)
        Me.GroupBox9.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents gbostfresult As System.Windows.Forms.GroupBox
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents DataGridView2 As Image
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents txtCode As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents txtDept As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents txtStaffName As System.Windows.Forms.TextBox
    Friend WithEvents btnrefresh As System.Windows.Forms.Button
    Friend WithEvents btncancel As System.Windows.Forms.Button
    Friend WithEvents dgv As System.Windows.Forms.DataGridView
    Friend WithEvents btnUpdate As System.Windows.Forms.Button
    Friend WithEvents btnDelete As System.Windows.Forms.Button
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents dtpDOB As System.Windows.Forms.DateTimePicker
    Friend WithEvents ssnit As System.Windows.Forms.TextBox
    Friend WithEvents lbl_Staffssnit As System.Windows.Forms.Label
    Friend WithEvents religion As System.Windows.Forms.ComboBox
    Friend WithEvents lblregion As System.Windows.Forms.Label
    Friend WithEvents lbl_StaffReligion As System.Windows.Forms.Label
    Friend WithEvents txtstaffage As System.Windows.Forms.TextBox
    Friend WithEvents region As System.Windows.Forms.ComboBox
    Friend WithEvents nationality As System.Windows.Forms.ComboBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents lbl_StaffNationality As System.Windows.Forms.Label
    Friend WithEvents houseno As System.Windows.Forms.TextBox
    Friend WithEvents lbl_StaffHouseno As System.Windows.Forms.Label
    Friend WithEvents lbl_StaffDOB As System.Windows.Forms.Label
    Friend WithEvents email As System.Windows.Forms.TextBox
    Friend WithEvents lbl_StaffEmail As System.Windows.Forms.Label
    Friend WithEvents phoneno As System.Windows.Forms.TextBox
    Friend WithEvents lbl_StaffMobileno As System.Windows.Forms.Label
    Friend WithEvents hometown As System.Windows.Forms.TextBox
    Friend WithEvents lbl_StaffHometown As System.Windows.Forms.Label
    Friend WithEvents status As System.Windows.Forms.ComboBox
    Friend WithEvents lbl_StaffMaritalStatus As System.Windows.Forms.Label
    Friend WithEvents cboStafftitle As System.Windows.Forms.ComboBox
    Friend WithEvents lbl_StaffTitle As System.Windows.Forms.Label
    Friend WithEvents gender As System.Windows.Forms.ComboBox
    Friend WithEvents lbl_StaffGender As System.Windows.Forms.Label
    Friend WithEvents txtStaffmiddlename As System.Windows.Forms.TextBox
    Friend WithEvents txtStafffirstname As System.Windows.Forms.TextBox
    Friend WithEvents txtStaffsurname As System.Windows.Forms.TextBox
    Friend WithEvents lbl_StaffFirstname As System.Windows.Forms.Label
    Friend WithEvents lbl_StaffMiddlename As System.Windows.Forms.Label
    Friend WithEvents lbl_StaffSurname As System.Windows.Forms.Label
    Friend WithEvents GroupBox7 As System.Windows.Forms.GroupBox
    Friend WithEvents cboContactRelation As System.Windows.Forms.ComboBox
    Friend WithEvents cboContactoccupation As System.Windows.Forms.ComboBox
    Friend WithEvents txtContacthouse As System.Windows.Forms.TextBox
    Friend WithEvents lbl_Staffcontactno As System.Windows.Forms.Label
    Friend WithEvents lbl_StaffOccup As System.Windows.Forms.Label
    Friend WithEvents locality As System.Windows.Forms.TextBox
    Friend WithEvents lbl_Staffcontown As System.Windows.Forms.Label
    Friend WithEvents txtContactphone As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents lbl_Staffconphone As System.Windows.Forms.Label
    Friend WithEvents txtContactname As System.Windows.Forms.TextBox
    Friend WithEvents lbl_StaffConName As System.Windows.Forms.Label
    Friend WithEvents GroupBox8 As System.Windows.Forms.GroupBox
    Friend WithEvents cboKinRelation As System.Windows.Forms.ComboBox
    Friend WithEvents lbl_Staffnextrel As System.Windows.Forms.Label
    Friend WithEvents Nextkinno As System.Windows.Forms.TextBox
    Friend WithEvents lbl_Staffnextno As System.Windows.Forms.Label
    Friend WithEvents nextofkin As System.Windows.Forms.TextBox
    Friend WithEvents lbl_Staffnextkin As System.Windows.Forms.Label
    Friend WithEvents GroupBox9 As System.Windows.Forms.GroupBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtEmpID As System.Windows.Forms.TextBox
    Friend WithEvents txtSalary As System.Windows.Forms.TextBox
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Column1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column28 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column29 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column22 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column6 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column7 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column5 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column8 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column9 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column10 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column13 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column12 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column24 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column21 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column11 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column23 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column14 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column15 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column26 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column16 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column17 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column18 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column19 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column20 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column27 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column25 As System.Windows.Forms.DataGridViewTextBoxColumn
    Private WithEvents Label6 As System.Windows.Forms.Label
    Private WithEvents Label5 As System.Windows.Forms.Label
    Private WithEvents Label8 As System.Windows.Forms.Label
    Private WithEvents Label9 As System.Windows.Forms.Label
    Private WithEvents Label7 As System.Windows.Forms.Label
    Private WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents txtEID As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
End Class
