﻿Imports System.Data.SqlClient

Public Class EmployeeAccountDetails

    Private Sub EmployeeAccountDetails_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        GetData()
        ActiveControl = txtfname
    End Sub
    Private Sub GetData()
        Try
            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            query = "select distinct userid, firstname + space(1) + middlename + space(1) + lastname as empname, username, password, role, regdate, status from Users,Staff where staff.StaffID = users.staffID"
            com = New SqlCommand(query, con)
            dr = com.ExecuteReader()
            dgv.Rows.Clear()
            While dr.Read()
                dgv.Rows.Add(dr(0), dr(1), dr(2), dr(3), dr(4), dr(5), dr(6))
            End While
            dr.Close()
            con.Close()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Public Sub AddDesignation()
        Try
            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            dset = New Data.DataSet()
            adapter = New SqlDataAdapter()
            adapter.SelectCommand = New SqlCommand("select distinct(desgname) from designation order by desgname asc", ConnectionModule.con)
            dset.Clear()
            adapter.Fill(dset, "designation")
            cboType.DataSource = dset.Tables("designation")
            cboType.DisplayMember = "desgname"
            cboType.Refresh()
            cboType.SelectedIndex = -1
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at get designation")
            con.Close()
        End Try
    End Sub

    Private Sub dgv_CellDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv.CellDoubleClick
        Try
            'pass gridview values to respective textfields/controls
            txtID.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(0).Value.ToString()
            txtfname.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(1).Value.ToString()
            txtuname.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(2).Value.ToString()
            txtpass.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(3).Value.ToString()
            cboType.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(4).Value.ToString()
            btnDelete.Enabled = True
            btnUpdate.Enabled = True
            btnSave.Enabled = False
            'enable the lock button and disable reset button if current status of system user is active
            If dgv.Rows(dgv.CurrentRow.Index).Cells(6).Value = "ACTIVE" Then
                btnReset.Enabled = False
                btnLock.Enabled = True
                Exit Sub
            End If
            'enable the reset button and disable lock button if current status of system user is inactive/locked
            If dgv.Rows(dgv.CurrentRow.Index).Cells(6).Value = "INACTIVE" Then
                btnLock.Enabled = False
                btnReset.Enabled = True
                Exit Sub
            End If
            'btnReset.Enabled = True
            'btnLock.Enabled = True
        Catch ex As Exception

        End Try

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        Try
            GetData()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        If txtID.Text = "" Then MsgBox("Invalid record selection, please check..", MsgBoxStyle.OkOnly + MsgBoxStyle.Exclamation, "Error") : Exit Sub

        Dim newUsername As String = txtuname.Text.Trim()
        Dim newRole As String = cboType.Text.Trim()
        If MsgBox("Do you really want to update system user's record?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "Confirmation") = MsgBoxResult.Yes Then
            Try
                If con.State = ConnectionState.Open Then con.Close()
                con.Open()
                com1 = New SqlCommand("update users set username=@d1, role=@d2 where userid='" & dgv.SelectedRows(0).Cells(0).Value & "'", con)
                com1.Parameters.Add("@d1", SqlDbType.VarChar).Value = newUsername
                com1.Parameters.Add("@d2", SqlDbType.VarChar).Value = newRole
                com1.ExecuteNonQuery()
                MessageBox.Show("Updated successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                ResetMe()
                com1.Dispose()
                con.Close()
                'clear controls
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End If
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        If txtID.Text = "" Then MsgBox("Invalid record selection, please check..", MsgBoxStyle.OkOnly + MsgBoxStyle.Exclamation, "Error") : Exit Sub
        If MsgBox("Do you really want to delete selected system user-'" + txtuname.Text + "'?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "Confirmation") = MsgBoxResult.Yes Then
            Try
                If con.State = ConnectionState.Open Then con.Close()
                con.Open()
                com1 = New SqlCommand("delete from users where userid='" & dgv.SelectedRows(0).Cells(0).Value & "'", ConnectionModule.con)
                com1.ExecuteNonQuery()
                MessageBox.Show("Deleted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                ResetMe()
                com1.Dispose()
                con.Close()
                'clear controls
            Catch ex As Exception
                MessageBox.Show(ex.Message)
            End Try
        End If

    End Sub

    Private Sub dgv_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv.CellContentClick

    End Sub
    Sub ResetMe()
        txtID.Clear()
        txtfname.Clear()
        txtpass.Clear()
        txtuname.Clear()
        cboType.ResetText()
        btnDelete.Enabled = False
        btnUpdate.Enabled = False
        btnLock.Enabled = False
        btnReset.Enabled = False
        GetData()
    End Sub
    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        ResetMe()
    End Sub

    Private Sub registrationinfo_gb_Enter(sender As Object, e As EventArgs) Handles registrationinfo_gb.Enter

    End Sub

    Private Sub cboType_DropDown(sender As Object, e As EventArgs) Handles cboType.DropDown
        AddDesignation()
    End Sub

    Private Sub cboType_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboType.SelectedIndexChanged

    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        ''Dim mdate As New DateTime(2014, 12, 25)
        ''Dim mdn = mdate.ToString("yy")
        ''MsgBox(DateTime.Now.ToString("yy"))

        Const activated As String = "ACTIVE"
        If MsgBox("Do you really want to Reset the selected system user account?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "Confirmation") = MsgBoxResult.Yes Then
            Try
                If con.State = ConnectionState.Open Then con.Close()
                con.Open()
                com1 = New SqlCommand("update users set status=@d1 where userid='" & dgv.SelectedRows(0).Cells(0).Value & "'", con)
                com1.Parameters.Add("@d1", SqlDbType.VarChar).Value = activated
                com1.ExecuteNonQuery()
                MessageBox.Show("Reset successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                'clear controls
                ResetMe()
                com1.Dispose()
                con.Close()
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End If
    End Sub

    Private Sub btnLock_Click(sender As Object, e As EventArgs) Handles btnLock.Click
        Const inactivated As String = "INACTIVE"
        If MsgBox("Do you really want to Lock the selected system user account?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "Confirmation") = MsgBoxResult.Yes Then
            Try
                If con.State = ConnectionState.Open Then con.Close()
                con.Open()
                com1 = New SqlCommand("update users set status=@d1 where userid='" & dgv.SelectedRows(0).Cells(0).Value & "'", con)
                com1.Parameters.Add("@d1", SqlDbType.VarChar).Value = inactivated
                com1.ExecuteNonQuery()
                MessageBox.Show("Successfully locked user..." + vbNewLine + "NB: The user account is de-activated; user cannot access/log into the system again.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                ResetMe()
                com1.Dispose()
                con.Close()
                'clear controls
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End If
    End Sub
End Class