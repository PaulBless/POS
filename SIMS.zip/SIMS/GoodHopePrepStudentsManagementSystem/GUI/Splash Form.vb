﻿Public Class Splash_Form
    Private Declare Function Sendmessage Lib "user32" Alias "SendMessageA" (ByVal hwnd As Integer, ByVal wMsg As Integer, ByVal wParam As Integer, ByVal aParam As Integer) As Integer
    Dim myprogress As Integer

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Try

            Sendmessage(ProgressBar1.Handle, 1040, 3, 0)
            'ProgressBar1.Increment(+1)
          'ProgressBar1.Value += 1
            ProgressBar1.Value = ProgressBar1.Value + 1
            Label7.Text = ProgressBar1.Value & "%" & "complete"
            If ProgressBar1.Value = 30 Then
                Label8.Text = "Loading Tools and Preferences.."
            End If
            If ProgressBar1.Value = 50 Then
                Label8.Text = "Reading Add-In and Extensions.."
            End If
            If ProgressBar1.Value = 70 Then
                Label8.Text = "Initializing Tools and Preferences.."
            End If
            If ProgressBar1.Value = 90 Then
                Label8.Text = "Setting Application Environment For Use.."
            End If
            If ProgressBar1.Value = 100 Then
                frmLog.Show()
                Me.Hide()
            End If

        Catch ex As ArgumentOutOfRangeException
            MessageBox.Show(ex.Message())
        Catch ex As ArgumentNullException
            MessageBox.Show(ex.Message())
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Splash_Form_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub


    Private Sub Label8_Click(sender As Object, e As EventArgs) Handles Label8.Click

    End Sub
End Class