﻿Imports System.Windows.Forms
Imports System.Text
Imports System.Collections.Generic
Imports System.Linq
Imports System.Runtime.InteropServices
Imports System.Data.SqlClient

Public Class AdminSection
    Dim m As String
    Dim ll, pp As Integer
    Dim txt As String
    Dim ii As Integer = 1

    Private Declare Function LockWorkStation Lib "user32.dll" () As Long
    Private Sub Main_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ''Timer1.Enabled = True
        ''text moving from left to right in middle
        ''txt = "STUDENT MANAGEMENT INFORMATION SYSTEM"
        ''ll = Len(txt)
        ''ii = 1
        ''lblAnimation.ForeColor = Color.Blue

      
        ''display current user name and role
        ' lblUser.Text = LogName
        ' lblUserType.Text = LogURole

    End Sub
    Private Sub ShowNewForm(ByVal sender As Object, ByVal e As EventArgs)
        ' Create a new instance of the child form.
        Dim ChildForm As New System.Windows.Forms.Form
        ' Make it a child of this MDI form before showing it.
        ChildForm.MdiParent = Me

        m_ChildFormNumber += 1
        ChildForm.Text = "Window " & m_ChildFormNumber

        ChildForm.Show()
    End Sub

    Private Sub CloseAllChildForm_Try()
        ' Close all child forms of the parent.
        For Each ChildForm As Form In Me.MdiChildren
            ChildForm.Close()
        Next
    End Sub
 Private m_ChildFormNumber As Integer

    Private Sub TeachersToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EmployeeToolStrip.Click

    End Sub

    Private Sub NewStudentRegistrationToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles NewStudentRegistrationToolStripMenuItem.Click
        Dim frm As New frmConfirm_Student_Admission
        CloseAllChildForm_Try()
        Try
            If Application.OpenForms.OfType(Of frmConfirm_Student_Admission).Any Then
                Application.OpenForms.Item("frmConfirm_Student_Admission").Activate()
            Else
                frm.MdiParent = Me
                frm.Show()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub ManageStudentsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ManageStudentsToolStripMenuItem.Click
        'ManageStudent.Show()
        'ManageStudent.MdiParent = Me
    End Sub

    Private Sub AddNewStaffToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EmployeeRegistration.Click
        Dim frm As New frmAddNewStaff
        Try
            If Application.OpenForms.OfType(Of frmAddNewStaff).Any Then
                Application.OpenForms.Item("frmAddNewStaff").Activate()
            Else
                frm.MdiParent = Me
                frm.Show()
            End If
        Catch ex As Exception

        End Try

        'old form
        'Dim frmm As New NewStaffRegistration
        'Try
        '    If Application.OpenForms.OfType(Of NewStaffRegistration).Any Then
        '        Application.OpenForms.Item("newstaffregistration").Activate()
        '    Else
        '        frm.MdiParent = Me
        '        frm.Show()
        '    End If
        'Catch ex As Exception

        'End Try
    End Sub

    Private Sub ManageStaffToolStripMenuItem_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub ViewStudentProfileToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ViewStudentProfileToolStripMenuItem.Click
        Dim frm As New AdvancedSearch
        Try
            If Application.OpenForms.OfType(Of AdvancedSearch).Any Then
                Application.OpenForms.Item("AdvancedSearch").Activate()
            Else
                frm.MdiParent = Me
                frm.Show()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub ViewHelpToolStripMenuItem_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub SearchStudentToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SearchStudentToolStripMenuItem.Click
        Dim frm As New ManageStudent
        Try
            If Application.OpenForms.OfType(Of ManageStudent).Any Then
                Application.OpenForms.Item("ManageStudent").Activate()
            Else
                frm.MdiParent = Me
                frm.Show()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub ViewStaffProfileToolStripMenuItem_Click(sender As Object, e As EventArgs)
        ''Dim frm As New StaffSearch
        ''Try
        ''    If Application.OpenForms.OfType(Of StaffSearch).Any Then
        ''        Application.OpenForms.Item("StaffSearch").Activate()
        ''    Else
        ''        frm.MdiParent = Me
        ''        frm.Show()
        ''    End If
        ''Catch ex As Exception

        ''End Try
    End Sub

    Private Sub AboutSIMSToolStripMenuItem1_Click(sender As Object, e As EventArgs)
        About_SIMS.Show()
        About_SIMS.MdiParent = Me
    End Sub

    Private Sub ViewrReportToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles AccountReportToolStripMenuItem1.Click


    End Sub

    Private Sub JecmasSolutionsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles JecmasSolutionsToolStripMenuItem.Click
        If MessageBox.Show("Do you want to visit www.jecmassolutions.wordpress.com", "Comfirm Webpage Visitation", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) = Windows.Forms.DialogResult.Yes Then
            'webAddress As String = "http://www.jecmassolutions.wordpress.com"
            'Process.Start(webAddress)
            System.Diagnostics.Process.Start("http://www.jecmassolutions.wordpress.com")
        End If
    End Sub

    Private Sub StatusStrip_ItemClicked(sender As Object, e As ToolStripItemClickedEventArgs)

    End Sub

    Private Sub ChangePasswordToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ChangePasswordToolStrip.Click
        PasswordChange.ShowDialog()
    End Sub

    Private Sub ExitApplicatiionToolStripMenuItem_Click(sender As Object, e As EventArgs)
        Dim dlg As DialogResult = MessageBox.Show("Are you sure you want to exit this section and log-off?", "Confirm Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Warning)
        If dlg = Windows.Forms.DialogResult.Yes Then
            Me.Close()
            Login_Form.Show()
        End If
        If dlg = Windows.Forms.DialogResult.No Then
            Me.Show()
        End If
    End Sub

    Private Sub ViewStaffProfileToolStripMenuItem1_Click(sender As Object, e As EventArgs)
        'Dim frm As New ManageStaff
        'Try
        '    If Application.OpenForms.OfType(Of ManageStaff).Any Then
        '        Application.OpenForms.Item("ManageStaff").Activate()
        '    Else
        '        frm.MdiParent = Me
        '        frm.Show()
        '    End If
        'Catch ex As Exception

        'End Try
    End Sub

    Private Sub PasswordRecoveryToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PasswordRecoveryToolStripMenuItem.Click
        Dim frm As New frmAccountSet
        Try
            If Application.OpenForms.OfType(Of frmAccountSet).Any Then
                Application.OpenForms.Item("frmaccountset").Activate()
            Else
                frm.MdiParent = Me
                frm.Show()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub CreateUserToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CreateNewUserToolStrip.Click
        Dim frm As New CreateEmployeeUser
        Try
            If Application.OpenForms.OfType(Of CreateEmployeeUser).Any Then
                Application.OpenForms.Item("createemployeeuser").Activate()
            Else
                frm.MdiParent = Me
                frm.Show()
            End If
        Catch ex As Exception

        End Try
    End Sub
    Private Sub CloseChildForms()
        For Each frm As Form In Me.MdiChildren
            If frm.Name = "Students Information Management System" Then
                'do nothing
            Else
                frm.Close()
            End If
        Next
    End Sub
    Sub LogOff()
        Dim st As String = "Successfully logged out"
        LogFunction(LogName, st)
        Me.Hide()
        frmLog.Show()
        frmLog.username.Text = ""
        frmLog.password.Text = ""
        frmLog.username.Focus()
    End Sub
    Private Sub LogOffToolStrip_Click(sender As Object, e As EventArgs) Handles LogOffToolStrip.Click
        'log user out
        'If lblUserType.Text = "ADMINISTRATOR" Then
        '    'allow database backup function

        'Else

        'End If

        Try
            If MessageBox.Show("Do you really want to logout from SMIS?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
                If MessageBox.Show("Do you want to backup system database before logout?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
                    'Backup()
                    CloseChildForms()
                    LogOff()
                Else
                    CloseChildForms()
                    LogOff()
                End If
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    'Sub Backup()
    '    Try
    '        If ModConnection.Connection.State = ConnectionState.Open Then ModConnection.Connection.Close()
    '        ModConnection.Connection.Open()
    '        Dim destdir As String = "POS" & DateTime.Now.ToString("dd-MM-yyyy_HH-mm-ss") & ".bak"
    '        Dim objdlg As New SaveFileDialog
    '        objdlg.FileName = destdir
    '        objdlg.ShowDialog()
    '        Filename = objdlg.FileName
    '        Cursor = Cursors.WaitCursor
    '        Timer3.Enabled = True
    '        Dim cb As String = "backup database POS to disk='" & Filename & "'with init,stats=10"
    '        Dim cmd As New SqlCommand(cb, ModConnection.Connection)
    '        cmd.ExecuteReader()
    '        Connection.Close()

    '    Catch ex As Exception
    '        MessageBox.Show(ex.Message, "Error at Backup", MessageBoxButtons.OK, MessageBoxIcon.Error)
    '    End Try
    'End Sub

    Private Sub ToolStripMenuItemExit_Click(sender As Object, e As EventArgs) Handles ExitToolStrip.Click
        'warns user of software close
        Dim close = MessageBox.Show("Close the application?", "Confirmation", MessageBoxButtons.OKCancel, MessageBoxIcon.Question)
        If close = Windows.Forms.DialogResult.OK Then
            'LogOff()
            Application.Exit()
        ElseIf close = Windows.Forms.DialogResult.Cancel Then
            Me.Show()
        End If
    End Sub

    Private Sub AboutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AboutToolStripMenuItem.Click
        'show about box
        About_SIMS.MdiParent = Me
        About_SIMS.Show()
    End Sub

    Private Sub JobDetailsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EmployeeDesignation.Click
        Dim frm As New frmStaffJobDetails
        Try
            If Application.OpenForms.OfType(Of frmStaffJobDetails).Any Then
                Application.OpenForms.Item("frmStaffJobDetails").Activate()
            Else
                frm.MdiParent = Me
                frm.Show()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub FeedingFeeToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CheckPaymentsToolStrip.Click

    End Sub

    Private Sub ConfirmStudentAdmissionToolStripMenuItem_Click(sender As Object, e As EventArgs)
        'Dim frm As New frmFeedingFeePayment
        'Try
        '    If Application.OpenForms.OfType(Of frmFeedingFeePayment).Any Then
        '        Application.OpenForms.Item("frmStudentBusFeePayment").Activate()
        '    Else
        '        frm.MdiParent = Me
        '        frm.Show()
        '    End If
        'Catch ex As Exception

        'End Try
    End Sub

    Private Sub PayBusFee_Click(sender As Object, e As EventArgs)
        Dim frm As New frmBusPayment
        Try
            If Application.OpenForms.OfType(Of frmBusPayment).Any Then
                Application.OpenForms.Item("frmBusPayment").Activate()
            Else
                frm.MdiParent = Me
                frm.Show()
            End If
        Catch ex As Exception

        End Try
    End Sub

    'Private Sub PayFeedingFee_Click(sender As Object, e As EventArgs)
    '    Dim frm As New frmFeedingFeePayment
    '    Try
    '        If Application.OpenForms.OfType(Of frmFeedingFeePayment).Any Then
    '            Application.OpenForms.Item("frmstudentbusfeepayment").Activate()
    '        Else
    '            frm.MdiParent = Me
    '            frm.Show()
    '        End If
    '    Catch ex As Exception

    '    End Try
    'End Sub

    Private Sub ManageStudentProfileToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ManageStudentProfileToolStripMenuItem.Click
        Dim frm As New frmManageStudentProfile
        Try
            If Application.OpenForms.OfType(Of frmManageStudentProfile).Any Then
                Application.OpenForms.Item("frmmanagestudentprofile").Activate()
            Else
                frm.MdiParent = Me
                frm.Show()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub TermlyAssessmentToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TermlyAssessmentToolStripMenuItem.Click

    End Sub

    Private Sub TerminalReportToolStripMenuItem_Click(sender As Object, e As EventArgs)
        Dim frm As New frmTerminalReport
        Try
            If Application.OpenForms.OfType(Of frmTerminalReport).Any Then
                Application.OpenForms.Item("frmterminalreport").Activate()
            Else
                frm.MdiParent = Me
                frm.Show()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub FeeSettingsToolStripMenuItem_Click(sender As Object, e As EventArgs)
        Dim frm As New frmFeeStructure
        Try
            If Application.OpenForms.OfType(Of frmFeeStructure).Any Then
                Application.OpenForms.Item("frmfeestructure").Activate()
            Else
                frm.MdiParent = Me
                frm.Show()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub InactiveEntryToolStripMenuItem_Click(sender As Object, e As EventArgs)
        Dim frm As New frmInactiveEntry
        Try
            If Application.OpenForms.OfType(Of frmInactiveEntry).Any Then
                Application.OpenForms.Item("frminactiveentry").Activate()
            Else
                frm.MdiParent = Me
                frm.Show()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub PromotionsToolStripMenuItem_Click(sender As Object, e As EventArgs)
        Dim frm As New frmTransfer
        Try
            If Application.OpenForms.OfType(Of frmTransfer).Any Then
                Application.OpenForms.Item("frmtransfer").Activate()
            Else
                frm.MdiParent = Me
                frm.Show()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub SchoolInfoToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SchoolInfoToolStripMenuItem.Click
        Dim frm As New frmSchoolInfo
        Try
            If Application.OpenForms.OfType(Of frmSchoolInfo).Any Then
                Application.OpenForms.Item("frmschoolinfo").Activate()
            Else
                frm.MdiParent = Me
                frm.Show()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub lbl_datetimeshow_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub DateTimeLabel_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        lblDateTime.Text = Now
    End Sub

    Private Sub AssessmentToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AcademicToolStrip.Click

    End Sub

    Private Sub StudentsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles StudentsToolStrip.Click

    End Sub

    Private Sub SystemToolStrip_Click(sender As Object, e As EventArgs) Handles SystemToolStrip.Click

    End Sub

    Private Sub GradingSystemToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles GradingSystemToolStripMenuItem.Click
        'Dim frm As New frmGradingSystem
        'Try
        '    If Application.OpenForms.OfType(Of frmGradingSystem).Any Then
        '        Application.OpenForms.Item("frmgradingsystem").Activate()
        '    Else
        '        frm.MdiParent = Me
        '        frm.Show()
        '    End If
        'Catch ex As Exception

        'End Try
    End Sub

    Private Sub SalaryAdvanceToolStripMenuItem_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub TotalSchoolFeesPaidToolStripMenuItem_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub SchoolFeesToolStripMenuItem_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub BusFeesToolStripMenuItem_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub CalculatorToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CalculatorToolStripMenuItem.Click
        Try
            System.Diagnostics.Process.Start("calc.exe")
        Catch ex As Exception

        End Try
    End Sub

    Private Sub MicrosoftWordToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MicrosoftWordToolStripMenuItem.Click
        Try
            System.Diagnostics.Process.Start("winword.exe")
        Catch ex As Exception
            MessageBox.Show("Microsoft Word is not installed on this machine")
        End Try
    End Sub

    Private Sub EditGradingSystemToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles GradingSystemToolStrip.Click
        Dim frm As New frmGradingSystem
        Try
            If Application.OpenForms.OfType(Of frmGradingSystem).Any Then
                Application.OpenForms.Item("frmgradingsystem").Activate()
            Else
                frm.MdiParent = Me
                frm.Show()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub SetAcademicYearToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AcademicYearToolStrip.Click
        ''frmAddAcademicYear.ShowDialog()
        Dim frm As New frmSession
        Try
            If Application.OpenForms.OfType(Of frmSession).Any Then
                Application.OpenForms.Item("frmsession").Activate()
            Else
                frm.MdiParent = Me
                frm.Show()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub TermlySessionsToolStripMenuItem_Click(sender As Object, e As EventArgs)
        'frmAddModifySession.ShowDialog()
    End Sub

    Private Sub TotalBusFeesPaidToolStripMenuItem_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub SalaryPaymentRecordToolStripMenuItem_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub TerminalBillToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TerminalBillToolStripMenuItem.Click
        Dim frm As New frmTerminalBill
        Try
            If Application.OpenForms.OfType(Of frmTerminalBill).Any Then
                Application.OpenForms.Item("frmterminalbill").Activate()
            Else
                frm.MdiParent = Me
                frm.Show()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub AccountSettingsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AccountSettingsToolStripMenuItem.Click
        Dim frm As New frmAccountSet
        Try
            If Application.OpenForms.OfType(Of frmAccountSet).Any Then
                Application.OpenForms.Item("frmaccountset").Activate()
            Else
                frm.MdiParent = Me
                frm.Show()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub PaymentsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PaymentsToolStripMenuItem.Click
        Dim frm As New FeePayment
        Try
            If Application.OpenForms.OfType(Of FeePayment).Any Then
                Application.OpenForms.Item("FeePayment").Activate()
            Else
                frm.MdiParent = Me
                frm.Show()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub BillingToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles BillingToolStripMenuItem.Click

    End Sub

    'Private Sub SchoolFeesStructureToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SchoolFeesStructureToolStripMenuItem.Click
    '    Dim frm As New frmFeeStructure
    '    Try
    '        If Application.OpenForms.OfType(Of frmFeeStructure).Any Then
    '            Application.OpenForms.Item("frmfeestructure").Activate()
    '        Else
    '            frm.MdiParent = Me
    '            frm.Show()
    '        End If
    '    Catch ex As Exception

    '    End Try
    'End Sub


    'Private Sub DefineStudentClassesToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DefineStudentClassesToolStripMenuItem.Click
    '    Dim frm As New frmTransfer
    '    Try
    '        If Application.OpenForms.OfType(Of frmTransfer).Any Then
    '            Application.OpenForms.Item("frmtransfer").Activate()
    '        Else
    '            frm.MdiParent = Me
    '            frm.Show()
    '        End If
    '    Catch ex As Exception

    '    End Try
    'End Sub

    Private Sub DefineStatusOfStudentsToolStripMenuItem_Click(sender As Object, e As EventArgs)
        Dim frm As New frmInactiveEntry
        Try
            If Application.OpenForms.OfType(Of frmInactiveEntry).Any Then
                Application.OpenForms.Item("frminactiveentry").Activate()
            Else
                frm.MdiParent = Me
                frm.Show()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub SubjectAssignmentForJHSTeachersToolStripMenuItem_Click(sender As Object, e As EventArgs)
        Dim frm As New frmSubjectAssignment
        Try
            If Application.OpenForms.OfType(Of frmSubjectAssignment).Any Then
                Application.OpenForms.Item("frmsubjectassignment").Activate()
            Else
                frm.MdiParent = Me
                frm.Show()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub BusFeesStructureToolStripMenuItem_Click(sender As Object, e As EventArgs)
        'Dim frm As New frmBusFeeStructure
        'Try
        '    If Application.OpenForms.OfType(Of frmBusFeeStructure).Any Then
        '        Application.OpenForms.Item("frmbusfeestructure").Activate()
        '    Else
        '        frm.MdiParent = Me
        '        frm.Show()
        '    End If
        'Catch ex As Exception

        'End Try
    End Sub

    Private Sub TermlyAssessmentRecordingSheetToolStripMenuItem_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub DepartmentsAndClassTypesToolStripMenuItem_Click(sender As Object, e As EventArgs)
        'Dim frm As New frmDeptClass
        'Try
        '    If Application.OpenForms.OfType(Of frmDeptClass).Any Then
        '        Application.OpenForms.Item("frmdeptclass").Activate()
        '    Else
        '        frm.MdiParent = Me
        '        frm.Show()
        '    End If
        'Catch ex As Exception

        'End Try
    End Sub

    Private Sub OptionToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles OptionToolStrip.Click

    End Sub

    Private Sub JobProfileMastery_Click(sender As Object, e As EventArgs) Handles JobProfileMastery.Click
        Dim frm As New ManageStaff
        Try
            If Application.OpenForms.OfType(Of ManageStaff).Any Then
                Application.OpenForms.Item("ManageStaff").Activate()
            Else
                frm.MdiParent = Me
                frm.Show()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub EmployeeProfileMastery_Click(sender As Object, e As EventArgs) Handles EmployeeProfileMastery.Click
        Dim frm As New StaffSearch
        Try
            If Application.OpenForms.OfType(Of StaffSearch).Any Then
                Application.OpenForms.Item("StaffSearch").Activate()
            Else
                frm.MdiParent = Me
                frm.Show()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub EmployeeInfoSheet_Click(sender As Object, e As EventArgs) Handles EmployeeInfoSheet.Click
        Dim frm As New EmployeeInfoSheet
        Try
            If Application.OpenForms.OfType(Of EmployeeInfoSheet).Any Then
                Application.OpenForms.Item("employeeinfosheet").Activate()
            Else
                frm.MdiParent = Me
                frm.Show()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub SBAToolStrip_Click(sender As Object, e As EventArgs) Handles SBAToolStrip.Click
        Dim frm As New frmSBA
        Try
            If Application.OpenForms.OfType(Of frmSBA).Any Then
                Application.OpenForms.Item("frmsba").Activate()
            Else
                frm.MdiParent = Me
                frm.Show()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub TSAToolStrip_Click(sender As Object, e As EventArgs) Handles TSAToolStrip.Click
        Dim frm As New frmStudentBehaviour
        Try
            If Application.OpenForms.OfType(Of frmStudentBehaviour).Any Then
                Application.OpenForms.Item("frmstudentbehaviour").Activate()
            Else
                frm.MdiParent = Me
                frm.Show()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub TerminalReportToolStrip_Click(sender As Object, e As EventArgs) Handles TerminalReportToolStrip.Click
        Dim frm As New frmTerminalReport
        Try
            If Application.OpenForms.OfType(Of frmTerminalReport).Any Then
                Application.OpenForms.Item("frmterminalreport").Activate()
            Else
                frm.MdiParent = Me
                frm.Show()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        ''lblAnimation.Text = lblAnimation.Text + Mid(txt, ii, 1)
        ''If ii > ll Then
        ''    ii = 0
        ''    lblAnimation.Text = ""
        ''End If
        ''ii += 1
    End Sub

    Private Sub ClassRoomToolStrip_Click(sender As Object, e As EventArgs) Handles ClassRoomToolStrip.Click
        Dim frm As New frmClassRoom
        Try
            If Application.OpenForms.OfType(Of frmClassRoom).Any Then
                Application.OpenForms.Item("frmclassroom").Activate()
            Else
                frm.MdiParent = Me
                frm.Show()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub SubjectsToolStrip_Click(sender As Object, e As EventArgs) Handles SubjectsToolStrip.Click
        Dim frm As New frmSubjects
        Try
            If Application.OpenForms.OfType(Of frmSubjects).Any Then
                Application.OpenForms.Item("frmsubjects").Activate()
            Else
                frm.MdiParent = Me
                frm.Show()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub FeesToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles FeesToolStrip.Click
        Dim frm As New FeeSettings
        Try
            If Application.OpenForms.OfType(Of FeeSettings).Any Then
                Application.OpenForms.Item("feesettings").Activate()
            Else
                frm.MdiParent = Me
                frm.Show()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub ClassTeacherAssignmentToolStrip_Click(sender As Object, e As EventArgs)
    End Sub

    Private Sub ClassTeacherAssignmentToolStrip_Click_1(sender As Object, e As EventArgs) Handles ClassTeacherAssignmentToolStrip.Click
        Dim frm As New frmTeacherAssignment
        Try
            If Application.OpenForms.OfType(Of frmTeacherAssignment).Any Then
                Application.OpenForms.Item("frmteacherassignment").Activate()
            Else
                frm.MdiParent = Me
                frm.Show()
            End If
        Catch ex As Exception

        End Try

    End Sub

    Private Sub AttendanceToolStrip_Click(sender As Object, e As EventArgs) Handles AttendanceToolStrip.Click
        Dim frm As New frmAttendance
        Try
            If Application.OpenForms.OfType(Of frmAttendance).Any Then
                Application.OpenForms.Item("frmattendance").Activate()
            Else
                frm.MdiParent = Me
                frm.Show()
            End If
        Catch ex As Exception

        End Try

    End Sub

    Private Sub StudentAttendanceToolStrip_Click(sender As Object, e As EventArgs) Handles StudentAttendanceToolStrip.Click
        Dim frm As New frmStudAttendance
        Try
            If Application.OpenForms.OfType(Of frmStudAttendance).Any Then
                Application.OpenForms.Item("frmstudattendance").Activate()
            Else
                frm.MdiParent = Me
                frm.Show()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub DesignationToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DesignationToolStripMenuItem.Click
        Dim frm As New frmDesignation
        Try
            If Application.OpenForms.OfType(Of frmDesignation).Any Then
                Application.OpenForms.Item("frmdesignation").Activate()
            Else
                frm.MdiParent = Me
                frm.Show()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub BillSettingsToolStrip_Click(sender As Object, e As EventArgs) Handles BillSettingsToolStrip.Click
        Dim frm As New BillSettings
        Try
            If Application.OpenForms.OfType(Of BillSettings).Any Then
                Application.OpenForms.Item("billsettings").Activate()
            Else
                frm.MdiParent = Me
                frm.Show()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub SalaryPaymentToolStrip_Click(sender As Object, e As EventArgs) Handles SalaryPaymentToolStrip.Click
        Dim frm As New SalaryPayment
        Try
            If Application.OpenForms.OfType(Of SalaryPayment).Any Then
                Application.OpenForms.Item("SalaryPayment").Activate()
            Else
                frm.MdiParent = Me
                frm.Show()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub UseMaintenanceToolstrip_Click(sender As Object, e As EventArgs) Handles UseMaintenanceToolstrip.Click
        Dim frm As New EmployeeAccountDetails
        Try
            If Application.OpenForms.OfType(Of EmployeeAccountDetails).Any Then
                Application.OpenForms.Item("employeeaccountdetails").Activate()
            Else
                frm.MdiParent = Me
                frm.Show()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub StudentsIDToolStrip_Click(sender As Object, e As EventArgs) Handles StudentsIDToolStrip.Click
        'StudentIDCard.ShowDialog()
        Dim frm As New StudentIDCard
        Try
            If Application.OpenForms.OfType(Of StudentIDCard).Any Then
                Application.OpenForms.Item("studentidcard").Activate()
            Else
                frm.MdiParent = Me
                frm.Show()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub LockToolStrip_Click(sender As Object, e As EventArgs) Handles LockToolStrip.Click
        Try
            If MsgBox("Do you want to lock workstation?", MsgBoxStyle.YesNo + MsgBoxStyle.Question, "Confirmation") = DialogResult.Yes Then
                LockWorkStation()
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub OtherFeesPaymentsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles OtherFeesPaymentsToolStripMenuItem.Click
        Dim frm As New OtherFeePayments
        Try
            If Application.OpenForms.OfType(Of OtherFeePayments).Any Then
                Application.OpenForms.Item("otherfeepayments").Activate()
            Else
                frm.MdiParent = Me
                frm.Show()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub OtherFeesSettingsToolStrip_Click(sender As Object, e As EventArgs) Handles OtherFeesSettingsToolStrip.Click
        Dim frm As New OtherFeesSettings
        Try
            If Application.OpenForms.OfType(Of OtherFeesSettings).Any Then
                Application.OpenForms.Item("otherfeessettings").Activate()
            Else
                frm.MdiParent = Me
                frm.Show()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub SchoolFeesHistoryToolStrip_Click(sender As Object, e As EventArgs) Handles SchoolFeesHistoryToolStrip.Click
        Dim frm As New frmCheckFees
        Try
            If Application.OpenForms.OfType(Of frmCheckFees).Any Then
                Application.OpenForms.Item("frmcheckfees").Activate()
            Else
                frm.MdiParent = Me
                frm.Show()
            End If
        Catch ex As Exception

        End Try

    End Sub

    Private Sub OtherFeesHistoryToolStrip_Click(sender As Object, e As EventArgs) Handles OtherFeesHistoryToolStrip.Click
        Dim frm As New frmCheckBusFees
        Try
            If Application.OpenForms.OfType(Of frmCheckBusFees).Any Then
                Application.OpenForms.Item("frmcheckbusfees").Activate()
            Else
                frm.MdiParent = Me
                frm.Show()
            End If
        Catch ex As Exception

        End Try

    End Sub

    Private Sub SalaryPaymentRecordTooStrip_Click(sender As Object, e As EventArgs) Handles SalaryPaymentRecordTooStrip.Click
        Dim frm As New frmSalaryRecord
        Try
            If Application.OpenForms.OfType(Of frmSalaryRecord).Any Then
                Application.OpenForms.Item("frmsalaryrecord").Activate()
            Else
                frm.MdiParent = Me
                frm.Show()
            End If
        Catch ex As Exception

        End Try
    End Sub

   
    Private Sub CheckSchFeesPaidToolStrip_Click(sender As Object, e As EventArgs) Handles CheckSchFeesPaidToolStrip.Click
        Dim frm As New CheckFeesPaid
        Try
            If Application.OpenForms.OfType(Of CheckFeesPaid).Any Then
                Application.OpenForms.Item("checkfeespaid").Activate()
            Else
                frm.MdiParent = Me
                frm.Show()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub CheckOtherFeesPaidToolStrip_Click(sender As Object, e As EventArgs) Handles CheckOtherFeesPaidToolStrip.Click
        Dim frm As New frmCheckBusPayments
        Try
            If Application.OpenForms.OfType(Of frmCheckBusPayments).Any Then
                Application.OpenForms.Item("frmcheckbuspayments").Activate()
            Else
                frm.MdiParent = Me
                frm.Show()
            End If
        Catch ex As Exception

        End Try
    End Sub
End Class
