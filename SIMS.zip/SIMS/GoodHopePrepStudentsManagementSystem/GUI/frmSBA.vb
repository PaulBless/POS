﻿Imports System.Data.SqlClient
Imports System.Web.UI.WebControls

Public Class frmSBA

    Dim dt As New DataTable
    Dim tot As Decimal

    Private Sub txtRegNo_TextChanged(sender As Object, e As EventArgs) Handles txtRegNo.TextChanged
        If txtRegNo.Text <> "" Then
            Try
                If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                ConnectionModule.con.Open()

                com = New SqlCommand("select * from Students where RegistrationNumber='" & Me.txtRegNo.Text & "'", ConnectionModule.con)
                dr = com.ExecuteReader(CommandBehavior.CloseConnection)
                If (dr.Read()) Then
                    txtSID.Text = dr.GetValue(0)
                    txtName.Text = dr.GetValue(2) + " " + dr.GetValue(3) + " " + dr.GetValue(4)
                    txtGender.Text = dr.GetValue(20)
                    txtClass.Text = dr.GetValue(8)
                    txtDept.Text = dr.GetValue(7)
                End If
                com.Dispose()

            Catch ex As Exception
                MsgBox(ex.Message)
                con.Close()
            End Try
        Else
            txtName.Clear()
            txtGender.Clear()
            txtDept.Clear()
            txtClass.Clear()
        End If

    End Sub

    Private Sub txtExamsMark_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtExamsMark.KeyPress
        If Asc(e.KeyChar) <> 13 AndAlso Asc(e.KeyChar) <> 8 AndAlso Not IsNumeric(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub

    Private Sub txtExamsMark_Leave(sender As Object, e As EventArgs) Handles txtExamsMark.Leave
        'If RTrim(txtExamsMark.TextLength) <> 0 Then
        '    'do nothing
        '    txtExamsMark.Clear()
        'ElseIf Val(txtExamsMark.Text) > 100 Then
        '    'txtExamsMark.SelectAll()
        '    txtExamsMark.ForeColor = Color.Red
        '    txtExamsMark.Text = "Mark invalid"
        '    Exit Sub
        'Else
        '    txtTotalES.Text = ""
        '    txtPercentES.Text = ""
        'End If
    End Sub



    Private Sub txtExamsMark_TextChanged(sender As Object, e As EventArgs) Handles txtExamsMark.TextChanged
        txtTotalES.Text = Val(txtExamsMark.Text)
    End Sub

    Private Sub txtHomework_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtHomework.KeyPress
        If Asc(e.KeyChar) <> 13 AndAlso Asc(e.KeyChar) <> 8 AndAlso Not IsNumeric(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub

    Private Sub txtHomework_Leave(sender As Object, e As EventArgs) Handles txtHomework.Leave
        If Val(txtHomework.Text) > 20 Then
            'txtHomework.Text = "Invalid"
            txtHomework.ForeColor = Color.DarkRed
            txtHomework.SelectAll()
        End If
    End Sub

    Private Sub txtHomework_TextChanged(sender As Object, e As EventArgs) Handles txtHomework.TextChanged
        'Dim tot As Decimal
        tot = Val(txtTest1.Text) + Val(txtTest2.Text) + Val(txtProject.Text) + Val(txtHomework.Text)
        txtTotalCS.Text = tot
    End Sub

    Private Sub btnCalCS_Click(sender As Object, e As EventArgs) Handles btnCalCS.Click
        If (RTrim(txtTest1.TextLength) = 0) Then
            MsgBox("Enter 'Test 1' marks", MsgBoxStyle.Information, "SIMS")
            Exit Sub
        End If
        If (RTrim(txtTest1.TextLength) = 0) Then
            MsgBox("Enter 'Test 2' marks", MsgBoxStyle.Information, "SIMS")
            Exit Sub
        End If
        If (RTrim(txtTest1.TextLength) = 0) Then
            MsgBox("Enter 'project' marks", MsgBoxStyle.Information, "SIMS")
            Exit Sub
        End If
        If (RTrim(txtTest1.TextLength) = 0) Then
            MsgBox("Enter 'home work' marks", MsgBoxStyle.Information, "SIMS")
            Exit Sub
        End If
        If (Val(txtTest1.Text) > 10) Then
            MsgBox("Test 1 cannot be more than 10 marks.", MsgBoxStyle.Information, "SIMS")
            txtTest1.Focus()
            txtTest1.SelectAll()
            Exit Sub
        End If
        If (Val(txtTest2.Text) > 10) Then
            MsgBox("Test 2 cannot be more than 10 marks.", MsgBoxStyle.Information, "SIMS")
            txtTest2.Focus()
            txtTest2.SelectAll()
            Exit Sub
        End If
        If (Val(txtProject.Text) > 20) Then
            MsgBox("Project cannot exceed 20 marks.", MsgBoxStyle.Information, "SIMS")
            txtProject.Focus()
            txtProject.SelectAll()
            Exit Sub
        End If
        If (Val(txtHomework.Text) > 20) Then
            MsgBox("Homework cannot  exceed 20 marks.", MsgBoxStyle.Information, "SIMS")
            txtHomework.Focus()
            txtHomework.SelectAll()
            Exit Sub
        End If

        Dim percent As Double
        percent = Val(txtTotalCS.Text) / 60 * 50
        txtPercentCS.Text = Math.Round(percent, 0)

    End Sub

    Private Sub btnCalES_Click(sender As Object, e As EventArgs) Handles btnCalES.Click
        If (RTrim(txtExamsMark.TextLength) = 0) Then
            MsgBox("Enter examination marks", MsgBoxStyle.Information, "SIMS")
            Exit Sub
        End If

        Dim percent As Decimal
        percent = Val(txtTotalES.Text) / 100 * 50
        txtPercentES.Text = Math.Round(percent, 0)

    End Sub

    Public Sub MyDataTable()
        dt.Columns.Add("Year", GetType(String))
        dt.Columns.Add("Term", GetType(String))
        dt.Columns.Add("Subject", GetType(String))
        dt.Columns.Add("Test1", GetType(Integer))
        dt.Columns.Add("Test2", GetType(Integer))
        dt.Columns.Add("Project", GetType(Integer))
        dt.Columns.Add("Homework", GetType(Integer))
        dt.Columns.Add("SubTotal", GetType(Integer))
        dt.Columns.Add("ClassScore", GetType(Integer))
        dt.Columns.Add("ExamMark", GetType(Integer))
        dt.Columns.Add("ExamScore", GetType(Integer))
        dt.Columns.Add("Total", GetType(Integer))
        dt.Columns.Add("Position", GetType(String))

        dgvinfo.DataSource = dt

    End Sub

    Private Sub DeleteScores()
        txtTest1.Clear()
        txtTest2.Clear()
        txtProject.Clear()
        txtHomework.Clear()
        txtTotalCS.Clear()
        txtPercentCS.Clear()
        txtExamsMark.Clear()
        txtTotalES.Clear()
        txtPercentES.Clear()
        txtYear.Clear()
        cboTerm.ResetText()
        cboSubject.ResetText()
        txtPosition.Clear()
        cboYear.ResetText()
    End Sub

    Sub ClearForm()
        DeleteScores()
        txtRegNo.Clear()
        txtSID.Clear()
        txtName.Clear()
        txtGender.Clear()
        txtDept.Clear()
        txtClass.Clear()
        txtRegNo.Focus()
    End Sub

    Private Sub btnAddToGrid_Click(sender As Object, e As EventArgs) Handles btnAddToGrid.Click
        If txtRegNo.Text = "" Or txtSID.Text = "" Then MessageBox.Show("Incomplete student information, Please specify", "SIMS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Exit Sub
        If cboYear.Text = "" Or cboTerm.Text = "" Or cboSubject.Text = "" Then MessageBox.Show("Incomplete academic information, Please check", "SIMS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Exit Sub
        If txtPercentCS.Text = "" Or txtPercentES.Text = "" Then MsgBox("Provide scores information", MsgBoxStyle.Exclamation, "SIMS") : Exit Sub

        Dim i As Integer
        Dim itemloc As Integer = -1

        For i = 0 To dgvinfo.Rows.Count - 1
            If dgvinfo.Rows(i).Cells(0).Value = Me.cboYear.Text AndAlso dgvinfo.Rows(i).Cells(2).Value = Me.cboSubject.Text AndAlso dgvinfo.Rows(i).Cells(1).Value = Me.cboTerm.Text Then
                'item is found in gridview
                MsgBox("Sorry! This record is already added to Assessment Sheet", MsgBoxStyle.OkOnly + MsgBoxStyle.Exclamation, "SIMS") : Exit Sub
                itemloc = i
                Exit For
            End If
        Next

        If itemloc = -1 Then
            'if item not found, add value to gridview
            dgvinfo.Rows.Add(cboYear.Text, cboTerm.Text, cboSubject.Text, Val(txtTest1.Text), Val(txtTest2.Text), Val(txtProject.Text), Val(txtHomework.Text), Val(txtTotalCS.Text), Val(txtPercentCS.Text), Val(txtExamsMark.Text), Val(txtPercentES.Text), Val(txtPercentCS.Text) + Val(txtPercentES.Text), txtPosition.Text, Val(txtSID.Text))
            DeleteScores()
            txtRegNo.Focus()
        End If

    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        If dgvinfo.Rows.Count < 1 Then MsgBox("Invalid grade history, Please check", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "SIMS") : Exit Sub
        If txtSID.Text = "" Then MsgBox("You must enter student registration number", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "SIMS") : Exit Sub

        If MsgBox("Grade History will be saved to Student Based Assessment Recording Sheet." + vbCrLf + "Do you want to Continue?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "SIMS-Confirmation") = MsgBoxResult.Yes Then
            Try
                For Each row As DataGridViewRow In dgvinfo.Rows
                    If con.State = ConnectionState.Open Then con.Close()
                    com1 = New SqlCommand("insert into SBA(SID,Year,Term,Subject,Test1,Test2,Project,Homework,SubTotal,ClassScore,ExamMark,ExamScore,Total,Position) values (@d1,@d2,@d3,@d4,@d5,@d6,@d7,@d8,@d9,@d10,@d11,@d12,@d13,@d14)", ConnectionModule.con)
                    com1.Parameters.AddWithValue("@d1", row.Cells(13).Value)
                    com1.Parameters.AddWithValue("@d2", row.Cells(0).Value.ToString())
                    com1.Parameters.AddWithValue("@d3", row.Cells(1).Value.ToString())
                    com1.Parameters.AddWithValue("@d4", row.Cells(2).Value.ToString())
                    com1.Parameters.AddWithValue("@d5", row.Cells(3).Value)
                    com1.Parameters.AddWithValue("@d6", row.Cells(4).Value)
                    com1.Parameters.AddWithValue("@d7", row.Cells(5).Value)
                    com1.Parameters.AddWithValue("@d8", row.Cells(6).Value)
                    com1.Parameters.AddWithValue("@d9", row.Cells(7).Value)
                    com1.Parameters.AddWithValue("@d10", row.Cells(8).Value)
                    com1.Parameters.AddWithValue("@d11", row.Cells(9).Value)
                    com1.Parameters.AddWithValue("@d12", row.Cells(10).Value)
                    com1.Parameters.AddWithValue("@d13", row.Cells(11).Value)
                    com1.Parameters.AddWithValue("@d14", row.Cells(12).Value.ToString())
                    con.Open()
                    com1.ExecuteNonQuery()
                    com1.Dispose()
                    MessageBox.Show("Record successfully saved to Student's Assessment Sheet", "SIMS-Success", MessageBoxButtons.OK, MessageBoxIcon.Information) : Exit Sub
                Next
                dgvinfo.Rows.Clear()

            Catch ex As Exception
                MsgBox(ex.Message, MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "Error at sba")
                con.Close()
            End Try
        Else
            MsgBox("Operation cancelled by user", MsgBoxStyle.OkOnly + MsgBoxStyle.Exclamation, "SIMS")
        End If
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        If MsgBox("Clear the form?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "SIMS") = MsgBoxResult.Yes Then
            ClearForm()
        End If
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub

    Private Sub frmSBA_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ActiveControl = txtRegNo

    End Sub

    Public Sub AddAcademicYear()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            dset = New Data.DataSet()
            adapter = New SqlDataAdapter()
            adapter.SelectCommand = New SqlCommand("select ID,New from AcademicYear order by New", ConnectionModule.con)
            dset.Clear()
            adapter.Fill(dset, "AcademicYear")
            cboYear.DataSource = dset.Tables("AcademicYear")
            cboYear.DisplayMember = "New"
            cboYear.ValueMember = "ID"
            cboYear.Refresh()
            cboYear.SelectedIndex = -1
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at add academic info")
            con.Close()
        End Try
    End Sub

    Public Sub AddTerm()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            dset = New Data.DataSet()
            adapter = New SqlDataAdapter()
            adapter.SelectCommand = New SqlCommand("select ID,Term from Term order by Term", ConnectionModule.con)
            dset.Clear()
            adapter.Fill(dset, "Term")
            cboTerm.DataSource = dset.Tables("Term")
            cboTerm.DisplayMember = "Term"
            cboTerm.ValueMember = "ID"
            cboTerm.Refresh()
            cboTerm.SelectedIndex = -1
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at add term info")
            con.Close()
        End Try
    End Sub

    Private Sub txtSID_TextChanged(sender As Object, e As EventArgs) Handles txtSID.TextChanged

    End Sub
    
    Private Sub cboTerm_DropDown(sender As Object, e As EventArgs) Handles cboTerm.DropDown
        AddTerm()
    End Sub

    Private Sub ComboBox1_DropDown(sender As Object, e As EventArgs) Handles cboYear.DropDown
        AddAcademicYear()
    End Sub

    Private Sub cboTerm_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboTerm.SelectedIndexChanged

    End Sub

    Private Sub txtTest1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtTest1.KeyPress
        If Asc(e.KeyChar) <> 13 AndAlso Asc(e.KeyChar) <> 8 AndAlso Not IsNumeric(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub

    Private Sub txtTest1_Leave(sender As Object, e As EventArgs) Handles txtTest1.Leave
        If Val(txtTest1.Text) > 10 Then
            txtTest1.Text = "Invalid"
            txtTest1.ForeColor = Color.DarkRed
        End If
    End Sub

    Private Sub txtTest1_TextChanged(sender As Object, e As EventArgs) Handles txtTest1.TextChanged
        'Dim tot As Decimal
        tot = Val(txtTest1.Text) + Val(txtTest2.Text) + Val(txtProject.Text) + Val(txtHomework.Text)
        txtTotalCS.Text = tot
    End Sub

    Private Sub txtTest2_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtTest2.KeyPress
        If Asc(e.KeyChar) <> 13 AndAlso Asc(e.KeyChar) <> 8 AndAlso Not IsNumeric(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub

    Private Sub txtTest2_Leave(sender As Object, e As EventArgs) Handles txtTest2.Leave
        If Val(txtTest2.Text) > 10 Then
            txtTest2.Text = "Invalid"
            txtTest2.ForeColor = Color.DarkRed
        End If
    End Sub

    Private Sub txtTest2_TextChanged(sender As Object, e As EventArgs) Handles txtTest2.TextChanged
        'Dim tot As Decimal
        tot = Val(txtTest1.Text) + Val(txtTest2.Text) + Val(txtProject.Text) + Val(txtHomework.Text)
        txtTotalCS.Text = tot
    End Sub

    Private Sub txtProject_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtProject.KeyPress
        If Asc(e.KeyChar) <> 13 AndAlso Asc(e.KeyChar) <> 8 AndAlso Not IsNumeric(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub

    Private Sub txtProject_Leave(sender As Object, e As EventArgs) Handles txtProject.Leave
        If Val(txtProject.Text) > 20 Then
            txtProject.Text = "Data Error"
            txtProject.ForeColor = Color.DarkRed
        End If
    End Sub

    Private Sub txtProject_TextChanged(sender As Object, e As EventArgs) Handles txtProject.TextChanged
        'Dim tot As Decimal
        tot = Val(txtTest1.Text) + Val(txtTest2.Text) + Val(txtProject.Text) + Val(txtHomework.Text)
        txtTotalCS.Text = tot
    End Sub

    Private Sub btnRemove_Click(sender As Object, e As EventArgs) Handles btnRemove.Click
        If dgvinfo.SelectedRows.Count > 0 Then
            For Each r As DataGridViewRow In dgvinfo.SelectedRows
                Dim n As Decimal = dgvinfo.SelectedRows(n).Cells(6).Value
                dgvinfo.Rows.Remove(dgvinfo.SelectedRows(0))
                dgvinfo.EndEdit()
                Exit Sub
            Next
        End If
    End Sub

    Private Sub txtPercentES_Leave(sender As Object, e As EventArgs) Handles txtPercentES.Leave
        Dim inputFee As Integer = Val(txtPercentES.Text)
        txtPercentES.Text = Format(inputFee, "0.00")
    End Sub

    Private Sub txtPercentES_TextChanged(sender As Object, e As EventArgs) Handles txtPercentES.TextChanged

    End Sub
End Class