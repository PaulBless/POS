﻿Imports System.Data.SqlClient

Public Class frmTerminalBill

    Private Sub frmTerminalBill_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Me.Text = Me.Text + " - [Current User: " + frmLog.Logname + "]"
        GetBillData()
        ActiveControl = cboClass


    End Sub

    Private Sub Resetme()
        cboYear.ResetText()
        cboTerm.ResetText()
        cboClass.ResetText()
        'txtAmt.Clear()
    End Sub

    Public Sub AddAcademicYear()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            dset = New Data.DataSet()
            adapter = New SqlDataAdapter()
            adapter.SelectCommand = New SqlCommand("select ID,New from AcademicYear order by New", ConnectionModule.con)
            dset.Clear()
            adapter.Fill(dset, "AcademicYear")
            cboYear.DataSource = dset.Tables("AcademicYear")
            cboYear.DisplayMember = "New"
            cboYear.ValueMember = "ID"
            cboYear.Refresh()
            cboYear.SelectedIndex = -1
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at add academic info")
            con.Close()
        End Try
    End Sub

    Public Sub AddTerm()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            dset = New Data.DataSet()
            adapter = New SqlDataAdapter()
            adapter.SelectCommand = New SqlCommand("select ID,Term from Term order by Term", ConnectionModule.con)
            dset.Clear()
            adapter.Fill(dset, "Term")
            cboTerm.DataSource = dset.Tables("Term")
            cboTerm.DisplayMember = "Term"
            cboTerm.ValueMember = "ID"
            cboTerm.Refresh()
            cboTerm.SelectedIndex = -1
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at add term info")
            con.Close()
        End Try
    End Sub
    
    Private Sub btnremove_Click(sender As Object, e As EventArgs) Handles btnRemove.Click
        'Resetme()
        For Each myrow As DataGridViewRow In Me.dgvPending.SelectedRows
            'delete specific row if selected
            If myrow.Selected = True Then
                dgvPending.Rows.Remove(myrow)
                dgvPending.Update()
            ElseIf Not myrow.Selected Then
                'do nothing if row not selected
                MsgBox("Please, select a bill item from the pending bill section..", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "SMIS")
            End If
        Next
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs)
        Me.Close()
    End Sub

    Private Sub GetBillData()
        Try
            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            com1 = New SqlCommand("select * from bill1", ConnectionModule.con)
            dr = com1.ExecuteReader(CommandBehavior.CloseConnection)
            dgv.Rows.Clear()
            While dr.Read() = True
                dgvDirect.Rows.Add(dr(0), dr(1), dr(2))
            End While
            'dr.Close()
            con.Close()


            ''bind datatable to gridview
            'If con.State = ConnectionState.Open Then con.Close()
            'con.Open()
            'Dim dcolumn As New DataColumn   'variable to generate auto columns
            'dcolumn.AutoIncrement = True
            'dcolumn.AutoIncrementSeed = 1
            'query = "select * from Bill1 order by itemname asc"
            'com = New SqlCommand(query, con)
            'table = New DataTable()
            'adapter = New SqlDataAdapter(com)
            'table.Clear()
            'table.Columns.Add()
            'adapter.Fill(table)
            'dgvDirect.DataSource = table
            'dgvDirect.Refresh()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnPrint.Click
        'If Len(Trim(cboYear.Text)) = 0 Then
        '    MessageBox.Show("Please select academic year", "SIMS", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        '    cboClass.Focus()
        '    Exit Sub
        'End If
        'If Len(Trim(cboTerm.Text)) = 0 Then
        '    MessageBox.Show("Please select term", "SIMS", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        '    cboTerm.Focus()
        '    Exit Sub
        'End If
        'If Len(Trim(cboClass.Text)) = 0 Then
        '    MessageBox.Show("Please select specific class", "SIMS", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        '    cboClass.Focus()
        '    Exit Sub
        'End If


        Try
            For Each row As DataGridViewRow In dgv.Rows
                If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                ConnectionModule.con.Open()
                com = New SqlCommand("insert into Bill values(@d1,@d2,@d3,@d4,@d5,@d6)", con)
                'com.Parameters.AddWithValue("@d1", cboYear.Text)
                'com.Parameters.AddWithValue("@d2", cboTerm.Text)
                'com.Parameters.AddWithValue("@d3", cboClass.Text)
                SaveControls()
                com.Parameters.AddWithValue("@d4", row.Cells(0).Value)
                com.Parameters.AddWithValue("@d5", row.Cells(1).Value.ToString())
                com.Parameters.AddWithValue("@d6", row.Cells(2).Value)
                com.ExecuteNonQuery()
                MessageBox.Show("Bill successfully saved", "SIMS", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Resetme()
                Exit Sub
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub SaveControls()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            com = New SqlCommand("insert into Bill (Year,Term,Class) values(@d1,@d2,@d3)", con)
            com.Parameters.AddWithValue("@d1", cboYear.Text)
            com.Parameters.AddWithValue("@d2", cboTerm.Text)
            'com.Parameters.AddWithValue("@d3", cboClass.Text)
            com.ExecuteNonQuery()
        Catch ex As Exception
            MsgBox(ex.ToString())
        End Try
    End Sub

    Private Sub cboTerm_DropDown(sender As Object, e As EventArgs) Handles cboTerm.DropDown
        AddTerm()
    End Sub

    Private Sub cboYear_DropDown(sender As Object, e As EventArgs) Handles cboYear.DropDown
        AddAcademicYear()
    End Sub

    Private Sub GroupBox3_Enter(sender As Object, e As EventArgs) Handles GroupBox3.Enter

    End Sub
    Sub GetStudent()
        If txtStudID.Text <> "" Then
            Try
                If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                ConnectionModule.con.Open()
                query = "select ID, RegistrationNumber, FirstName + space(1) + MiddleName + space(1) + LastName AS Fullname, Department, Class, Gender from Students where RegistrationNumber='" & Me.txtStudID.Text & "'"
                com = New SqlCommand(query, ConnectionModule.con)
                table = New DataTable()
                adapter = New SqlDataAdapter(com)
                adapter.Fill(table)
                If table.Rows.Count < 1 Then MsgBox("Invalid student registration number, check..", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "SIMS") : txtStudID.SelectAll() : Exit Sub
                'fetch student values
                SearchId = table.Rows(0)(0).ToString()
                lbl_1.Text = table.Rows(0)(2).ToString()
                lbl_2.Text = table.Rows(0)(5).ToString()
                lbl_3.Text = table.Rows(0)(3).ToString()
                lbl_4.Text = table.Rows(0)(4).ToString()
                lbl_5.Text = table.Rows(0)(1).ToString()
                'show the labels for student info
                lbl_1.Visible = True
                lbl_2.Visible = True
                lbl_3.Visible = True
                lbl_4.Visible = True
                lbl_5.Visible = True
                'com.Dispose()
            Catch ex As Exception
                con.Close()
            End Try
        Else
            'ResetPanel()
            MsgBox("Student registration number is missing", MsgBoxStyle.OkOnly + MsgBoxStyle.Information, "SMIS")
        End If

    End Sub
    Private Sub btnHelp_Click(sender As Object, e As EventArgs) Handles btnHelp.Click
        If cboClass.Text = "" Then
            MsgBox("Select specific class.", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "SMIS")
            cboClass.Focus()
            Exit Sub
        End If

        Try
            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            query = "select ID, RegistrationNumber, FirstName + space(1) + MiddleName + space(1) + LastName AS Fullname, Gender, Department, Class from Students where Class='" & Me.cboClass.Text & "'"
            com = New SqlCommand(query, ConnectionModule.con)
            dr = com.ExecuteReader(CommandBehavior.CloseConnection)
            If dr.Read() Then
                dgv.Rows.Clear()
                While dr.Read()
                    SearchId = dr.GetValue(0)
                    dgv.Rows.Add(dr(1), dr(2), dr(3), dr(4), dr(5))
                End While
                Exit Sub
            Else
                MessageBox.Show("The selected class has no student record or data..", "SMIS", MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If
        Catch ex As Exception

        End Try
    End Sub
    Sub ResetPanel()
        'hide the labels for emp info
        lbl_1.Visible = False
        lbl_2.Visible = False
        lbl_3.Visible = False
        lbl_4.Visible = False
        lbl_5.Visible = False
        'set values to null
        lbl_1.Text = ""
        lbl_2.Text = ""
        lbl_3.Text = ""
        lbl_4.Text = ""
        lbl_5.Text = ""
    End Sub

    Private Sub txtEmpID_TextChanged(sender As Object, e As EventArgs) Handles txtStudID.TextChanged
        If txtStudID.Text = "" Then
            ResetPanel()
        Else
            'do nothing

        End If
    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        Dim tot As Integer
        Dim dr As System.Windows.Forms.DataGridViewRow
        Dim dc As New DataColumn
        Const colvalue As Integer = 1
        dc.AutoIncrement = True
        dc.AutoIncrementSeed = 1
        Try
            For Each myrow As DataGridViewRow In Me.dgvDirect.SelectedRows
                If myrow.Selected = True Then
                    ''check duplicate item
                    'For tot = 0 To dgvDirect.RowCount - 1
                    '    If dgvDirect.Rows(tot).Cells(1).Value = Me.dgvPending.Rows(0).Cells(1).Value Then
                    '        MsgBox("item exists") : Exit Sub
                    '    End If
                    'Next
                    'add specific row if to bill section

                    dgvPending.Rows.Add(dc, myrow.Cells(1).Value, myrow.Cells(2).Value)
                    txtSubTotal.Text = tot
                Else
                    'do nothing if row not selected
                    MsgBox("Please, select a bill item from the direct bill section..", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "SMIS")
                End If
            Next
            ''set auto column increment for gridview
            'For Each dr In Me.dgv.SelectedRows
            '    dc.AutoIncrement = True
            '    dc.AutoIncrementSeed = 1
            '    'dgv1.Rows.Add(dc, dr.Cells(1).Value, dr.Cells(2).Value)
            'Next
        Catch ex As Exception
            MsgBox(ex.Message)

        End Try

    End Sub
    Public Sub GetClassList()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            dset = New Data.DataSet()
            adapter = New SqlDataAdapter()
            adapter.SelectCommand = New SqlCommand("select distinct room from classroom order by room asc", ConnectionModule.con)
            dset.Clear()
            adapter.Fill(dset, "classroom")
            cboClass.DataSource = dset.Tables("classroom")
            cboClass.DisplayMember = "room"
            cboClass.Refresh()
            cboClass.SelectedIndex = -1
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at get class")
            con.Close()
        End Try
    End Sub

    Private Sub dgv1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs)

    End Sub

    Private Sub btnGet_Click(sender As Object, e As EventArgs)
        Try

        Catch ex As Exception

        End Try
    End Sub

    Private Sub cboClass_DropDown(sender As Object, e As EventArgs) Handles cboClass.DropDown
        GetClassList()
    End Sub

    Private Sub cboClass_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboClass.SelectedIndexChanged

    End Sub

    Private Sub dgvDirect_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvDirect.CellClick
        dgvDirect.SelectAll()
    End Sub

    Private Sub dgvDirect_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvDirect.CellContentClick

    End Sub

    Private Sub dgv_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv.CellContentClick

    End Sub

    Private Sub dgv_CellContentDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv.CellContentDoubleClick
        Try
            lbl_1.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(1).Value.ToString()
            lbl_2.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(2).Value
            lbl_3.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(3).Value.ToString()
            lbl_4.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(4).Value.ToString()
            lbl_5.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(0).Value.ToString()
            'show the labels for student info
            lbl_1.Visible = True
            lbl_2.Visible = True
            lbl_3.Visible = True
            lbl_4.Visible = True
            lbl_5.Visible = True
        Catch ex As Exception

        End Try
    End Sub
End Class