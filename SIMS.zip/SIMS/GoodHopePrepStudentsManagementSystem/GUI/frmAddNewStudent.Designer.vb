﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAddNewStudent
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.cbo_Student_Religion = New System.Windows.Forms.ComboBox()
        Me.lblregion = New System.Windows.Forms.Label()
        Me.txt_student_age = New System.Windows.Forms.TextBox()
        Me.dtpicker_Student_DateOfBirth = New System.Windows.Forms.DateTimePicker()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.lbl_StaffDOB = New System.Windows.Forms.Label()
        Me.txt_Student_House_Number = New System.Windows.Forms.TextBox()
        Me.txt_Student_Hometown = New System.Windows.Forms.TextBox()
        Me.cbo_Student_Gender = New System.Windows.Forms.ComboBox()
        Me.cbo_Student_Title = New System.Windows.Forms.ComboBox()
        Me.lbl_StaffHometown = New System.Windows.Forms.Label()
        Me.lbl_StaffHouseno = New System.Windows.Forms.Label()
        Me.lbl_StaffGender = New System.Windows.Forms.Label()
        Me.lbl_StaffTitle = New System.Windows.Forms.Label()
        Me.txt_Student_Middlename = New System.Windows.Forms.TextBox()
        Me.txt_Student_Firstname = New System.Windows.Forms.TextBox()
        Me.txt_Student_Surname = New System.Windows.Forms.TextBox()
        Me.lbl_StaffSurname = New System.Windows.Forms.Label()
        Me.lbl_StaffFirstname = New System.Windows.Forms.Label()
        Me.lbl_StaffMiddlename = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.cbo_Student_District = New System.Windows.Forms.ComboBox()
        Me.cbo_Student_Region = New System.Windows.Forms.ComboBox()
        Me.cbo_Student_Nationality = New System.Windows.Forms.ComboBox()
        Me.lbl_StaffNationality = New System.Windows.Forms.Label()
        Me.lbl_StaffReligion = New System.Windows.Forms.Label()
        Me.lbl_StaffEmail = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.txt_Student_Contact_Email = New System.Windows.Forms.TextBox()
        Me.cbo_Student_Contact_Occupation = New System.Windows.Forms.ComboBox()
        Me.txt_Student_Contact_Number = New System.Windows.Forms.TextBox()
        Me.cbo_Student_Contact_Relation = New System.Windows.Forms.ComboBox()
        Me.txt_Student_Contact_WorkNo = New System.Windows.Forms.TextBox()
        Me.txt_Student_Contact_Name = New System.Windows.Forms.TextBox()
        Me.txt_Student_Contact_Address = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lbl_Staffnextrel = New System.Windows.Forms.Label()
        Me.lbl_Staffconwork = New System.Windows.Forms.Label()
        Me.lbl_StaffAddress = New System.Windows.Forms.Label()
        Me.lbl_StaffOccup = New System.Windows.Forms.Label()
        Me.lbl_StaffConName = New System.Windows.Forms.Label()
        Me.lbl_Staffconphone = New System.Windows.Forms.Label()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.btn = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.cbo_Student_Religion)
        Me.GroupBox1.Controls.Add(Me.lblregion)
        Me.GroupBox1.Controls.Add(Me.txt_student_age)
        Me.GroupBox1.Controls.Add(Me.dtpicker_Student_DateOfBirth)
        Me.GroupBox1.Controls.Add(Me.Label13)
        Me.GroupBox1.Controls.Add(Me.lbl_StaffDOB)
        Me.GroupBox1.Controls.Add(Me.txt_Student_House_Number)
        Me.GroupBox1.Controls.Add(Me.txt_Student_Hometown)
        Me.GroupBox1.Controls.Add(Me.cbo_Student_Gender)
        Me.GroupBox1.Controls.Add(Me.cbo_Student_Title)
        Me.GroupBox1.Controls.Add(Me.lbl_StaffHometown)
        Me.GroupBox1.Controls.Add(Me.lbl_StaffHouseno)
        Me.GroupBox1.Controls.Add(Me.lbl_StaffGender)
        Me.GroupBox1.Controls.Add(Me.lbl_StaffTitle)
        Me.GroupBox1.Controls.Add(Me.txt_Student_Middlename)
        Me.GroupBox1.Controls.Add(Me.txt_Student_Firstname)
        Me.GroupBox1.Controls.Add(Me.txt_Student_Surname)
        Me.GroupBox1.Controls.Add(Me.lbl_StaffSurname)
        Me.GroupBox1.Controls.Add(Me.lbl_StaffFirstname)
        Me.GroupBox1.Controls.Add(Me.lbl_StaffMiddlename)
        Me.GroupBox1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(12, 42)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(992, 158)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "GroupBox1"
        '
        'cbo_Student_Religion
        '
        Me.cbo_Student_Religion.BackColor = System.Drawing.Color.White
        Me.cbo_Student_Religion.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbo_Student_Religion.FormattingEnabled = True
        Me.cbo_Student_Religion.Items.AddRange(New Object() {"CHRISTIANITY", "ISLAM", "TRADITIONALIST"})
        Me.cbo_Student_Religion.Location = New System.Drawing.Point(674, 67)
        Me.cbo_Student_Religion.Name = "cbo_Student_Religion"
        Me.cbo_Student_Religion.Size = New System.Drawing.Size(184, 23)
        Me.cbo_Student_Religion.TabIndex = 76
        '
        'lblregion
        '
        Me.lblregion.AutoSize = True
        Me.lblregion.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblregion.Location = New System.Drawing.Point(612, 73)
        Me.lblregion.Name = "lblregion"
        Me.lblregion.Size = New System.Drawing.Size(57, 15)
        Me.lblregion.TabIndex = 77
        Me.lblregion.Text = "Religion :"
        '
        'txt_student_age
        '
        Me.txt_student_age.BackColor = System.Drawing.Color.White
        Me.txt_student_age.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_student_age.Location = New System.Drawing.Point(547, 69)
        Me.txt_student_age.MaxLength = 50
        Me.txt_student_age.Name = "txt_student_age"
        Me.txt_student_age.ReadOnly = True
        Me.txt_student_age.Size = New System.Drawing.Size(32, 21)
        Me.txt_student_age.TabIndex = 75
        '
        'dtpicker_Student_DateOfBirth
        '
        Me.dtpicker_Student_DateOfBirth.CustomFormat = "dd-MM-yyyy"
        Me.dtpicker_Student_DateOfBirth.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtpicker_Student_DateOfBirth.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpicker_Student_DateOfBirth.Location = New System.Drawing.Point(421, 69)
        Me.dtpicker_Student_DateOfBirth.Name = "dtpicker_Student_DateOfBirth"
        Me.dtpicker_Student_DateOfBirth.Size = New System.Drawing.Size(114, 21)
        Me.dtpicker_Student_DateOfBirth.TabIndex = 74
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Times New Roman", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(535, 70)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(15, 21)
        Me.Label13.TabIndex = 73
        Me.Label13.Text = "/"
        '
        'lbl_StaffDOB
        '
        Me.lbl_StaffDOB.AutoSize = True
        Me.lbl_StaffDOB.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaffDOB.Location = New System.Drawing.Point(360, 73)
        Me.lbl_StaffDOB.Name = "lbl_StaffDOB"
        Me.lbl_StaffDOB.Size = New System.Drawing.Size(60, 15)
        Me.lbl_StaffDOB.TabIndex = 72
        Me.lbl_StaffDOB.Text = "DOB/Age"
        '
        'txt_Student_House_Number
        '
        Me.txt_Student_House_Number.BackColor = System.Drawing.Color.White
        Me.txt_Student_House_Number.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txt_Student_House_Number.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Student_House_Number.Location = New System.Drawing.Point(421, 110)
        Me.txt_Student_House_Number.Name = "txt_Student_House_Number"
        Me.txt_Student_House_Number.Size = New System.Drawing.Size(158, 21)
        Me.txt_Student_House_Number.TabIndex = 66
        '
        'txt_Student_Hometown
        '
        Me.txt_Student_Hometown.BackColor = System.Drawing.Color.White
        Me.txt_Student_Hometown.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txt_Student_Hometown.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Student_Hometown.Location = New System.Drawing.Point(152, 112)
        Me.txt_Student_Hometown.Name = "txt_Student_Hometown"
        Me.txt_Student_Hometown.Size = New System.Drawing.Size(158, 21)
        Me.txt_Student_Hometown.TabIndex = 71
        '
        'cbo_Student_Gender
        '
        Me.cbo_Student_Gender.BackColor = System.Drawing.Color.White
        Me.cbo_Student_Gender.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbo_Student_Gender.FormattingEnabled = True
        Me.cbo_Student_Gender.Items.AddRange(New Object() {"FEMALE", "MALE"})
        Me.cbo_Student_Gender.Location = New System.Drawing.Point(152, 69)
        Me.cbo_Student_Gender.Name = "cbo_Student_Gender"
        Me.cbo_Student_Gender.Size = New System.Drawing.Size(80, 23)
        Me.cbo_Student_Gender.TabIndex = 68
        '
        'cbo_Student_Title
        '
        Me.cbo_Student_Title.BackColor = System.Drawing.Color.White
        Me.cbo_Student_Title.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbo_Student_Title.FormattingEnabled = True
        Me.cbo_Student_Title.Items.AddRange(New Object() {"Master", "Miss"})
        Me.cbo_Student_Title.Location = New System.Drawing.Point(278, 69)
        Me.cbo_Student_Title.Name = "cbo_Student_Title"
        Me.cbo_Student_Title.Size = New System.Drawing.Size(61, 23)
        Me.cbo_Student_Title.TabIndex = 69
        '
        'lbl_StaffHometown
        '
        Me.lbl_StaffHometown.AutoSize = True
        Me.lbl_StaffHometown.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaffHometown.Location = New System.Drawing.Point(76, 116)
        Me.lbl_StaffHometown.Name = "lbl_StaffHometown"
        Me.lbl_StaffHometown.Size = New System.Drawing.Size(77, 15)
        Me.lbl_StaffHometown.TabIndex = 70
        Me.lbl_StaffHometown.Text = "Home Town :"
        '
        'lbl_StaffHouseno
        '
        Me.lbl_StaffHouseno.AutoSize = True
        Me.lbl_StaffHouseno.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaffHouseno.Location = New System.Drawing.Point(360, 112)
        Me.lbl_StaffHouseno.Name = "lbl_StaffHouseno"
        Me.lbl_StaffHouseno.Size = New System.Drawing.Size(55, 15)
        Me.lbl_StaffHouseno.TabIndex = 67
        Me.lbl_StaffHouseno.Text = "House #:"
        '
        'lbl_StaffGender
        '
        Me.lbl_StaffGender.AutoSize = True
        Me.lbl_StaffGender.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaffGender.Location = New System.Drawing.Point(98, 73)
        Me.lbl_StaffGender.Name = "lbl_StaffGender"
        Me.lbl_StaffGender.Size = New System.Drawing.Size(48, 15)
        Me.lbl_StaffGender.TabIndex = 64
        Me.lbl_StaffGender.Text = "Gender:"
        '
        'lbl_StaffTitle
        '
        Me.lbl_StaffTitle.AutoSize = True
        Me.lbl_StaffTitle.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaffTitle.Location = New System.Drawing.Point(240, 73)
        Me.lbl_StaffTitle.Name = "lbl_StaffTitle"
        Me.lbl_StaffTitle.Size = New System.Drawing.Size(34, 15)
        Me.lbl_StaffTitle.TabIndex = 65
        Me.lbl_StaffTitle.Text = "Title:"
        '
        'txt_Student_Middlename
        '
        Me.txt_Student_Middlename.BackColor = System.Drawing.Color.White
        Me.txt_Student_Middlename.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txt_Student_Middlename.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Student_Middlename.Location = New System.Drawing.Point(674, 23)
        Me.txt_Student_Middlename.Name = "txt_Student_Middlename"
        Me.txt_Student_Middlename.Size = New System.Drawing.Size(184, 21)
        Me.txt_Student_Middlename.TabIndex = 63
        '
        'txt_Student_Firstname
        '
        Me.txt_Student_Firstname.BackColor = System.Drawing.Color.White
        Me.txt_Student_Firstname.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txt_Student_Firstname.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Student_Firstname.Location = New System.Drawing.Point(421, 23)
        Me.txt_Student_Firstname.Name = "txt_Student_Firstname"
        Me.txt_Student_Firstname.Size = New System.Drawing.Size(158, 21)
        Me.txt_Student_Firstname.TabIndex = 62
        '
        'txt_Student_Surname
        '
        Me.txt_Student_Surname.BackColor = System.Drawing.Color.White
        Me.txt_Student_Surname.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txt_Student_Surname.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Student_Surname.Location = New System.Drawing.Point(152, 23)
        Me.txt_Student_Surname.Name = "txt_Student_Surname"
        Me.txt_Student_Surname.Size = New System.Drawing.Size(187, 21)
        Me.txt_Student_Surname.TabIndex = 61
        '
        'lbl_StaffSurname
        '
        Me.lbl_StaffSurname.AutoSize = True
        Me.lbl_StaffSurname.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaffSurname.Location = New System.Drawing.Point(95, 25)
        Me.lbl_StaffSurname.Name = "lbl_StaffSurname"
        Me.lbl_StaffSurname.Size = New System.Drawing.Size(59, 15)
        Me.lbl_StaffSurname.TabIndex = 58
        Me.lbl_StaffSurname.Text = "Surname :"
        '
        'lbl_StaffFirstname
        '
        Me.lbl_StaffFirstname.AutoSize = True
        Me.lbl_StaffFirstname.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaffFirstname.Location = New System.Drawing.Point(348, 25)
        Me.lbl_StaffFirstname.Name = "lbl_StaffFirstname"
        Me.lbl_StaffFirstname.Size = New System.Drawing.Size(70, 15)
        Me.lbl_StaffFirstname.TabIndex = 60
        Me.lbl_StaffFirstname.Text = "First Name :"
        '
        'lbl_StaffMiddlename
        '
        Me.lbl_StaffMiddlename.AutoSize = True
        Me.lbl_StaffMiddlename.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaffMiddlename.Location = New System.Drawing.Point(592, 25)
        Me.lbl_StaffMiddlename.Name = "lbl_StaffMiddlename"
        Me.lbl_StaffMiddlename.Size = New System.Drawing.Size(84, 15)
        Me.lbl_StaffMiddlename.TabIndex = 59
        Me.lbl_StaffMiddlename.Text = "Middle Name :"
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1016, 35)
        Me.Panel1.TabIndex = 64
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(411, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(198, 22)
        Me.Label1.TabIndex = 12
        Me.Label1.Text = "ADD NEW STUDENT"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.cbo_Student_District)
        Me.GroupBox3.Controls.Add(Me.cbo_Student_Region)
        Me.GroupBox3.Controls.Add(Me.cbo_Student_Nationality)
        Me.GroupBox3.Controls.Add(Me.lbl_StaffNationality)
        Me.GroupBox3.Controls.Add(Me.lbl_StaffReligion)
        Me.GroupBox3.Controls.Add(Me.lbl_StaffEmail)
        Me.GroupBox3.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.Location = New System.Drawing.Point(12, 208)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(992, 69)
        Me.GroupBox3.TabIndex = 66
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Address Details"
        '
        'cbo_Student_District
        '
        Me.cbo_Student_District.BackColor = System.Drawing.Color.White
        Me.cbo_Student_District.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbo_Student_District.FormattingEnabled = True
        Me.cbo_Student_District.Location = New System.Drawing.Point(718, 28)
        Me.cbo_Student_District.Name = "cbo_Student_District"
        Me.cbo_Student_District.Size = New System.Drawing.Size(196, 23)
        Me.cbo_Student_District.TabIndex = 53
        '
        'cbo_Student_Region
        '
        Me.cbo_Student_Region.BackColor = System.Drawing.Color.White
        Me.cbo_Student_Region.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbo_Student_Region.FormattingEnabled = True
        Me.cbo_Student_Region.Items.AddRange(New Object() {"ASHANTI", "BRONG AHAFO", "CENTRAL", "EASTERN", "GREATER ACCRA", "NORTHERN", "UPPER EAST", "UPPER WEST", "VOLTA", "WESTERN"})
        Me.cbo_Student_Region.Location = New System.Drawing.Point(421, 29)
        Me.cbo_Student_Region.Name = "cbo_Student_Region"
        Me.cbo_Student_Region.Size = New System.Drawing.Size(158, 23)
        Me.cbo_Student_Region.Sorted = True
        Me.cbo_Student_Region.TabIndex = 53
        '
        'cbo_Student_Nationality
        '
        Me.cbo_Student_Nationality.BackColor = System.Drawing.Color.White
        Me.cbo_Student_Nationality.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbo_Student_Nationality.FormattingEnabled = True
        Me.cbo_Student_Nationality.Items.AddRange(New Object() {"GHANAIAN", "NON-GHANAIAN"})
        Me.cbo_Student_Nationality.Location = New System.Drawing.Point(152, 28)
        Me.cbo_Student_Nationality.Name = "cbo_Student_Nationality"
        Me.cbo_Student_Nationality.Size = New System.Drawing.Size(187, 23)
        Me.cbo_Student_Nationality.TabIndex = 53
        '
        'lbl_StaffNationality
        '
        Me.lbl_StaffNationality.AutoSize = True
        Me.lbl_StaffNationality.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaffNationality.Location = New System.Drawing.Point(77, 31)
        Me.lbl_StaffNationality.Name = "lbl_StaffNationality"
        Me.lbl_StaffNationality.Size = New System.Drawing.Size(72, 15)
        Me.lbl_StaffNationality.TabIndex = 44
        Me.lbl_StaffNationality.Text = "Nationality :"
        '
        'lbl_StaffReligion
        '
        Me.lbl_StaffReligion.AutoSize = True
        Me.lbl_StaffReligion.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaffReligion.Location = New System.Drawing.Point(367, 31)
        Me.lbl_StaffReligion.Name = "lbl_StaffReligion"
        Me.lbl_StaffReligion.Size = New System.Drawing.Size(51, 15)
        Me.lbl_StaffReligion.TabIndex = 52
        Me.lbl_StaffReligion.Text = "Region :"
        '
        'lbl_StaffEmail
        '
        Me.lbl_StaffEmail.AutoSize = True
        Me.lbl_StaffEmail.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaffEmail.Location = New System.Drawing.Point(608, 32)
        Me.lbl_StaffEmail.Name = "lbl_StaffEmail"
        Me.lbl_StaffEmail.Size = New System.Drawing.Size(113, 15)
        Me.lbl_StaffEmail.TabIndex = 48
        Me.lbl_StaffEmail.Text = "District / Municipal:"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.txt_Student_Contact_Email)
        Me.GroupBox2.Controls.Add(Me.cbo_Student_Contact_Occupation)
        Me.GroupBox2.Controls.Add(Me.txt_Student_Contact_Number)
        Me.GroupBox2.Controls.Add(Me.cbo_Student_Contact_Relation)
        Me.GroupBox2.Controls.Add(Me.txt_Student_Contact_WorkNo)
        Me.GroupBox2.Controls.Add(Me.txt_Student_Contact_Name)
        Me.GroupBox2.Controls.Add(Me.txt_Student_Contact_Address)
        Me.GroupBox2.Controls.Add(Me.Label3)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Controls.Add(Me.lbl_Staffnextrel)
        Me.GroupBox2.Controls.Add(Me.lbl_Staffconwork)
        Me.GroupBox2.Controls.Add(Me.lbl_StaffAddress)
        Me.GroupBox2.Controls.Add(Me.lbl_StaffOccup)
        Me.GroupBox2.Controls.Add(Me.lbl_StaffConName)
        Me.GroupBox2.Controls.Add(Me.lbl_Staffconphone)
        Me.GroupBox2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.Location = New System.Drawing.Point(12, 283)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(992, 172)
        Me.GroupBox2.TabIndex = 65
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Contact Information"
        '
        'txt_Student_Contact_Email
        '
        Me.txt_Student_Contact_Email.BackColor = System.Drawing.Color.White
        Me.txt_Student_Contact_Email.CharacterCasing = System.Windows.Forms.CharacterCasing.Lower
        Me.txt_Student_Contact_Email.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Student_Contact_Email.Location = New System.Drawing.Point(476, 90)
        Me.txt_Student_Contact_Email.Name = "txt_Student_Contact_Email"
        Me.txt_Student_Contact_Email.Size = New System.Drawing.Size(161, 21)
        Me.txt_Student_Contact_Email.TabIndex = 48
        '
        'cbo_Student_Contact_Occupation
        '
        Me.cbo_Student_Contact_Occupation.BackColor = System.Drawing.Color.White
        Me.cbo_Student_Contact_Occupation.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbo_Student_Contact_Occupation.FormattingEnabled = True
        Me.cbo_Student_Contact_Occupation.Items.AddRange(New Object() {"ACCOUNTANT", "APPRENTICE", "ARCHITECT", "ARMY OFFICER", "ARTISAN", "ASSEMBLYMAN", "AUDITOR", "BAKER", "BANKER", "BEAUTY PRACTITIONER", "BUSINESS ANALYST", "BUSINESSMAN", "CARPENTOR", "CATERER", "CHEF", "CIVIL SERVANT", "CLERGY", "COMPUTER SCIENTIST", "CONSTRUCTION ENGINEER", "DATABASE ADMINISTRATOR", "DESIGNER", "DISPENSING ASSISTANT", "DOCTOR", "DRIVER", "ELECTRICIAN", "FARMER", "FASHION DESIGNER", "FISH MONGER", "FISHERMAN", "FOOD VENDOR", "FOOTBALLER", "FOREIGN DIPLOMAT", "HAIR DRESSER", "HEALTH AID ", "HOUSE WIFE", "IMMIGRATION OFFICER", "LABOURER", "LAWYER", "LEGAL PRACTITIONER", "MASON", "MATRON", "MEDICAL PRACTITIONER", "MINER", "MINING ENGINEER", "MUSICIAN", "NETWORK ADMINISTRATOR", "NETWORK ENGINEER", "NURSE", "OTHER", "PAINTER", "PASTOR", "PENSIONER", "PHARMACIST", "PHARMACY TECHNICIAN", "POLICE OFFICER", "PROGRAMMER", "PUBLIC SERVANT", "RADIO PRESENTER", "REAL ESTATE AGENT", "RECEPTIONIST", "SALES PERSON", "SEAMSTRESS", "SECRETARY", "SECURITY", "STATE MINSTER", "STOCK BROKER", "STORE KEEPER", "SYSTEM ADMINISTRATOR", "TAILOR", "TEACHER", "TRADER", "TRAVEL AGENT", "TYPIST", "UNEMPLOYED"})
        Me.cbo_Student_Contact_Occupation.Location = New System.Drawing.Point(188, 129)
        Me.cbo_Student_Contact_Occupation.Name = "cbo_Student_Contact_Occupation"
        Me.cbo_Student_Contact_Occupation.Size = New System.Drawing.Size(171, 23)
        Me.cbo_Student_Contact_Occupation.TabIndex = 53
        '
        'txt_Student_Contact_Number
        '
        Me.txt_Student_Contact_Number.BackColor = System.Drawing.Color.White
        Me.txt_Student_Contact_Number.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Student_Contact_Number.Location = New System.Drawing.Point(476, 51)
        Me.txt_Student_Contact_Number.Name = "txt_Student_Contact_Number"
        Me.txt_Student_Contact_Number.Size = New System.Drawing.Size(161, 21)
        Me.txt_Student_Contact_Number.TabIndex = 48
        '
        'cbo_Student_Contact_Relation
        '
        Me.cbo_Student_Contact_Relation.BackColor = System.Drawing.Color.White
        Me.cbo_Student_Contact_Relation.DropDownHeight = 75
        Me.cbo_Student_Contact_Relation.DropDownWidth = 75
        Me.cbo_Student_Contact_Relation.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbo_Student_Contact_Relation.FormattingEnabled = True
        Me.cbo_Student_Contact_Relation.IntegralHeight = False
        Me.cbo_Student_Contact_Relation.Items.AddRange(New Object() {"Brother", "Sister", "Father", "Mother", "StepMother", "StepFather", "Aunt", "Uncle", "GrandFather", "GrandMother", "Other", "GuardMother", "GuardFather"})
        Me.cbo_Student_Contact_Relation.Location = New System.Drawing.Point(476, 129)
        Me.cbo_Student_Contact_Relation.Name = "cbo_Student_Contact_Relation"
        Me.cbo_Student_Contact_Relation.Size = New System.Drawing.Size(161, 23)
        Me.cbo_Student_Contact_Relation.TabIndex = 53
        '
        'txt_Student_Contact_WorkNo
        '
        Me.txt_Student_Contact_WorkNo.BackColor = System.Drawing.Color.White
        Me.txt_Student_Contact_WorkNo.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Student_Contact_WorkNo.Location = New System.Drawing.Point(188, 90)
        Me.txt_Student_Contact_WorkNo.Name = "txt_Student_Contact_WorkNo"
        Me.txt_Student_Contact_WorkNo.Size = New System.Drawing.Size(170, 21)
        Me.txt_Student_Contact_WorkNo.TabIndex = 48
        '
        'txt_Student_Contact_Name
        '
        Me.txt_Student_Contact_Name.BackColor = System.Drawing.Color.White
        Me.txt_Student_Contact_Name.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txt_Student_Contact_Name.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Student_Contact_Name.Location = New System.Drawing.Point(188, 51)
        Me.txt_Student_Contact_Name.Name = "txt_Student_Contact_Name"
        Me.txt_Student_Contact_Name.Size = New System.Drawing.Size(170, 21)
        Me.txt_Student_Contact_Name.TabIndex = 48
        '
        'txt_Student_Contact_Address
        '
        Me.txt_Student_Contact_Address.BackColor = System.Drawing.Color.White
        Me.txt_Student_Contact_Address.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txt_Student_Contact_Address.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Student_Contact_Address.Location = New System.Drawing.Point(776, 52)
        Me.txt_Student_Contact_Address.Multiline = True
        Me.txt_Student_Contact_Address.Name = "txt_Student_Contact_Address"
        Me.txt_Student_Contact_Address.Size = New System.Drawing.Size(138, 61)
        Me.txt_Student_Contact_Address.TabIndex = 48
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.SystemColors.Control
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(6, 17)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(980, 18)
        Me.Label3.TabIndex = 45
        Me.Label3.Text = "Enter Father / Mother / Guardian Details in the Fields Provided Below"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(384, 91)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(86, 15)
        Me.Label2.TabIndex = 44
        Me.Label2.Text = "Email Address:"
        '
        'lbl_Staffnextrel
        '
        Me.lbl_Staffnextrel.AutoSize = True
        Me.lbl_Staffnextrel.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_Staffnextrel.Location = New System.Drawing.Point(416, 133)
        Me.lbl_Staffnextrel.Name = "lbl_Staffnextrel"
        Me.lbl_Staffnextrel.Size = New System.Drawing.Size(54, 15)
        Me.lbl_Staffnextrel.TabIndex = 43
        Me.lbl_Staffnextrel.Text = "Relation:"
        '
        'lbl_Staffconwork
        '
        Me.lbl_Staffconwork.AutoSize = True
        Me.lbl_Staffconwork.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_Staffconwork.Location = New System.Drawing.Point(101, 91)
        Me.lbl_Staffconwork.Name = "lbl_Staffconwork"
        Me.lbl_Staffconwork.Size = New System.Drawing.Size(84, 15)
        Me.lbl_Staffconwork.TabIndex = 42
        Me.lbl_Staffconwork.Text = "Work Number:"
        '
        'lbl_StaffAddress
        '
        Me.lbl_StaffAddress.AutoSize = True
        Me.lbl_StaffAddress.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaffAddress.Location = New System.Drawing.Point(676, 57)
        Me.lbl_StaffAddress.Name = "lbl_StaffAddress"
        Me.lbl_StaffAddress.Size = New System.Drawing.Size(94, 15)
        Me.lbl_StaffAddress.TabIndex = 43
        Me.lbl_StaffAddress.Text = "Postal Address :"
        '
        'lbl_StaffOccup
        '
        Me.lbl_StaffOccup.AutoSize = True
        Me.lbl_StaffOccup.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaffOccup.Location = New System.Drawing.Point(110, 131)
        Me.lbl_StaffOccup.Name = "lbl_StaffOccup"
        Me.lbl_StaffOccup.Size = New System.Drawing.Size(72, 15)
        Me.lbl_StaffOccup.TabIndex = 41
        Me.lbl_StaffOccup.Text = "Occupation:"
        '
        'lbl_StaffConName
        '
        Me.lbl_StaffConName.AutoSize = True
        Me.lbl_StaffConName.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaffConName.Location = New System.Drawing.Point(143, 54)
        Me.lbl_StaffConName.Name = "lbl_StaffConName"
        Me.lbl_StaffConName.Size = New System.Drawing.Size(40, 15)
        Me.lbl_StaffConName.TabIndex = 39
        Me.lbl_StaffConName.Text = "Name:"
        '
        'lbl_Staffconphone
        '
        Me.lbl_Staffconphone.AutoSize = True
        Me.lbl_Staffconphone.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_Staffconphone.Location = New System.Drawing.Point(416, 54)
        Me.lbl_Staffconphone.Name = "lbl_Staffconphone"
        Me.lbl_Staffconphone.Size = New System.Drawing.Size(54, 15)
        Me.lbl_Staffconphone.TabIndex = 40
        Me.lbl_Staffconphone.Text = "Phone #:"
        '
        'btnCancel
        '
        Me.btnCancel.BackColor = System.Drawing.SystemColors.Control
        Me.btnCancel.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnCancel.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCancel.ForeColor = System.Drawing.Color.Black
        Me.btnCancel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnCancel.Location = New System.Drawing.Point(670, 485)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(95, 30)
        Me.btnCancel.TabIndex = 68
        Me.btnCancel.Text = "Cancel"
        Me.btnCancel.UseVisualStyleBackColor = False
        '
        'btn
        '
        Me.btn.BackColor = System.Drawing.SystemColors.Control
        Me.btn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btn.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn.ForeColor = System.Drawing.Color.Black
        Me.btn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn.Location = New System.Drawing.Point(517, 485)
        Me.btn.Name = "btn"
        Me.btn.Size = New System.Drawing.Size(95, 30)
        Me.btn.TabIndex = 69
        Me.btn.Text = "Find"
        Me.btn.UseVisualStyleBackColor = False
        '
        'btnClear
        '
        Me.btnClear.BackColor = System.Drawing.SystemColors.Control
        Me.btnClear.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnClear.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnClear.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClear.ForeColor = System.Drawing.Color.Black
        Me.btnClear.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnClear.Location = New System.Drawing.Point(380, 485)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(95, 30)
        Me.btnClear.TabIndex = 70
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = False
        '
        'btnSave
        '
        Me.btnSave.BackColor = System.Drawing.SystemColors.Control
        Me.btnSave.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnSave.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSave.ForeColor = System.Drawing.Color.Black
        Me.btnSave.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnSave.Location = New System.Drawing.Point(226, 485)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(95, 30)
        Me.btnSave.TabIndex = 71
        Me.btnSave.Text = "Save"
        Me.btnSave.UseVisualStyleBackColor = False
        '
        'frmAddNewStudent
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1016, 537)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btn)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnSave)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.GroupBox1)
        Me.MaximizeBox = False
        Me.Name = "frmAddNewStudent"
        Me.Text = "frmAddNewStudent"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents txt_Student_Middlename As System.Windows.Forms.TextBox
    Friend WithEvents txt_Student_Firstname As System.Windows.Forms.TextBox
    Friend WithEvents txt_Student_Surname As System.Windows.Forms.TextBox
    Friend WithEvents lbl_StaffSurname As System.Windows.Forms.Label
    Friend WithEvents lbl_StaffFirstname As System.Windows.Forms.Label
    Friend WithEvents lbl_StaffMiddlename As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txt_Student_House_Number As System.Windows.Forms.TextBox
    Friend WithEvents txt_Student_Hometown As System.Windows.Forms.TextBox
    Friend WithEvents cbo_Student_Gender As System.Windows.Forms.ComboBox
    Friend WithEvents cbo_Student_Title As System.Windows.Forms.ComboBox
    Friend WithEvents lbl_StaffHometown As System.Windows.Forms.Label
    Friend WithEvents lbl_StaffHouseno As System.Windows.Forms.Label
    Friend WithEvents lbl_StaffGender As System.Windows.Forms.Label
    Friend WithEvents lbl_StaffTitle As System.Windows.Forms.Label
    Friend WithEvents txt_student_age As System.Windows.Forms.TextBox
    Friend WithEvents dtpicker_Student_DateOfBirth As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents lbl_StaffDOB As System.Windows.Forms.Label
    Friend WithEvents cbo_Student_Religion As System.Windows.Forms.ComboBox
    Friend WithEvents lblregion As System.Windows.Forms.Label
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents cbo_Student_District As System.Windows.Forms.ComboBox
    Friend WithEvents cbo_Student_Region As System.Windows.Forms.ComboBox
    Friend WithEvents cbo_Student_Nationality As System.Windows.Forms.ComboBox
    Friend WithEvents lbl_StaffNationality As System.Windows.Forms.Label
    Friend WithEvents lbl_StaffReligion As System.Windows.Forms.Label
    Friend WithEvents lbl_StaffEmail As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents txt_Student_Contact_Email As System.Windows.Forms.TextBox
    Friend WithEvents cbo_Student_Contact_Occupation As System.Windows.Forms.ComboBox
    Friend WithEvents txt_Student_Contact_Number As System.Windows.Forms.TextBox
    Friend WithEvents cbo_Student_Contact_Relation As System.Windows.Forms.ComboBox
    Friend WithEvents txt_Student_Contact_WorkNo As System.Windows.Forms.TextBox
    Friend WithEvents txt_Student_Contact_Name As System.Windows.Forms.TextBox
    Friend WithEvents txt_Student_Contact_Address As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents lbl_Staffnextrel As System.Windows.Forms.Label
    Friend WithEvents lbl_Staffconwork As System.Windows.Forms.Label
    Friend WithEvents lbl_StaffAddress As System.Windows.Forms.Label
    Friend WithEvents lbl_StaffOccup As System.Windows.Forms.Label
    Friend WithEvents lbl_StaffConName As System.Windows.Forms.Label
    Friend WithEvents lbl_Staffconphone As System.Windows.Forms.Label
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents btn As System.Windows.Forms.Button
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents btnSave As System.Windows.Forms.Button
End Class
