﻿Imports System.Data.SqlClient
'Imports System.Diagnostics.Eventing.Reader

Public Class frmConfirm_Student_Admission

    Dim studID As Integer
    Dim studNo As String
    Dim bus_status As String

    Dim manage As New ManageStudent

    Sub ReturnStudentNo()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()

            com = New SqlCommand("select * from Students where FirstName='" & Me.txt_Student_Firstname.Text & "' AND Middlename='" & Me.txt_Student_Middlename.Text & "' AND LastName='" & Me.txt_Student_Surname.Text & "' AND Gender='" & Me.cboGender.Text & "'", ConnectionModule.con)
            dr = com.ExecuteReader(CommandBehavior.CloseConnection)
            While dr.Read
                studNo = dr.GetValue(1)
            End While
            con.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub AddStudent()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            com = New SqlCommand("insert into Students(FirstName,MiddleName,LastName,DOB,Age,Department,Class,Region,District,Nationality,HouseAddress,ContactName,ContactNumber,ContactAddress,ContactOccupation,ContactRelation,ContactEmail,ContactWorkNo,Gender,Title,Hometown,RegistrationDate,Religion,Status,AdmitFee,BusStatus) values (@FirstName,@MiddleName,@LastName,@DOB,@Age,@Department,@Class,@Region,@District,@Nationality,@HouseAddress,@ContactName,@ContactNumber,@ContactAddress,@ContactOccupation,@ContactRelation,@ContactEmail,@ContactWorkNo,@Gender,@Title,@Hometown,@RegistrationDate,@Religion,@Status,@AdmitFee,@BusStatus)", ConnectionModule.con)
            com.Parameters.AddWithValue("@FirstName", txt_Student_Firstname.Text)
            com.Parameters.AddWithValue("@MiddleName", txt_Student_Middlename.Text)
            com.Parameters.AddWithValue("@LastName", txt_Student_Surname.Text)
            ''com.Parameters.AddWithValue("@RegistrationNumber", txt_Student_Registration_Number.Text)
            com.Parameters.AddWithValue("@DOB", dtpDOB.Text.ToString())
            com.Parameters.AddWithValue("@Age", txt_student_age.Text)
            com.Parameters.AddWithValue("@Department", cboDepartment.Text)
            com.Parameters.AddWithValue("@Class", cboClass.Text)
            com.Parameters.AddWithValue("@Region", cbo_Student_Region.Text)
            com.Parameters.AddWithValue("@District", cbo_Student_District.Text)
            com.Parameters.AddWithValue("@Nationality", cbo_Student_Nationality.Text)
            com.Parameters.AddWithValue("@HouseAddress", txt_StudentLocation.Text)
            com.Parameters.AddWithValue("@ContactName", txt_Student_Contact_Name.Text)
            com.Parameters.AddWithValue("@ContactNumber", txt_Student_Contact_Number.Text)
            com.Parameters.AddWithValue("@ContactAddress", txt_Student_Contact_Address.Text)
            com.Parameters.AddWithValue("@ContactOccupation", cboContact_Occupation.Text)
            com.Parameters.AddWithValue("@ContactRelation", cboContact_Relation.Text)
            com.Parameters.AddWithValue("@ContactEmail", txt_Contact_Email.Text)
            com.Parameters.AddWithValue("@ContactWorkNo", txt_Student_Contact_WorkNo.Text)
            com.Parameters.AddWithValue("@Gender", cboGender.Text)
            com.Parameters.AddWithValue("@Title", cboTitle.Text)
            com.Parameters.AddWithValue("@Hometown", txt_Student_Hometown.Text)
            com.Parameters.AddWithValue("@RegistrationDate", Date.Now)
            com.Parameters.AddWithValue("@Religion", cbo_Student_Religion.Text)
            com.Parameters.AddWithValue("@Status", Status)
            com.Parameters.AddWithValue("@AdmitFee", Val(txtFee.Text))
            com.Parameters.AddWithValue("@BusStatus", bus_status)
            'studID = com.ExecuteScalar()
            com.ExecuteNonQuery()

            ReturnStudentNo()   'retrieve student reg_no

            MsgBox("Registration successfully saved." + vbCrLf + vbCrLf + "The Student Registration Number is : '" + studNo.ToString & "' " + vbCrLf + vbCrLf + "Please, Keep the student number for future refrences and quote for all payment transactions..", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Success")
            'dispose the command
            com.Dispose()
            Clearform()

        Catch ex As SqlException
            MsgBox(ex.ToString(), MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Sql Exception")
            Exit Sub
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Exception")
            Exit Sub
        Finally
            con.Close()            'close the db connection
        End Try
        'End If
    End Sub

    Private Sub btn_SaveStudentRecord_Click(sender As Object, e As EventArgs) Handles btn_SaveStudentRecord.Click
        'check input errors
        If txt_Student_Firstname.Text = "" Then MsgBox("Enter firstname", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Error") : txt_Student_Firstname.Focus() : Exit Sub
        If txt_Student_Surname.Text = "" Then MsgBox("Enter surname", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Error") : txt_Student_Surname.Focus() : Exit Sub
        If cboGender.Text = "" Then MsgBox("Select gender of student", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Error") : Exit Sub
        If txt_student_age.Text = "" Then MsgBox("Enter date of birth of student", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Error") : Exit Sub
        If cboTitle.Text = "" Then MsgBox("Select title", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Error") : cboTitle.Focus() : Exit Sub
        If txt_Student_Hometown.Text = "" Then MsgBox("Enter hometown of student", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Error") : txt_Student_Hometown.Focus() : Exit Sub
        If txt_StudentLocation.Text = "" Then MsgBox("Enter house number or location", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Error") : txt_StudentLocation.Focus() : Exit Sub
        If cbo_Student_Religion.Text = "" Then MsgBox("Select religion", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Error") : Exit Sub
        If cbo_Student_Nationality.Text = "" Then MsgBox("Select nationality of student", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Error") : txt_Student_Hometown.Focus() : Exit Sub
        If cbo_Student_District.Text = "" Then MsgBox("Select district", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Error") : Exit Sub
        If txt_Student_Contact_Name.Text = "" Then MsgBox("Enter contact name", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Error") : txt_Student_Contact_Name.Focus() : Exit Sub
        If txt_Student_Contact_Number.Text = "" Then MsgBox("Enter contact phone number", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Error") : txt_Student_Contact_Number.Focus() : Exit Sub
        If _txt_Student_Contact_Address.Text = "" Then MsgBox("Enter contact postal address", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Error") : txt_Student_Contact_Address.Focus() : Exit Sub
        If cboContact_Relation.Text = "" Then MsgBox("Select contact relation", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Error") : Exit Sub
        If cboDepartment.Text = "" Then MsgBox("Invalid department designated, please check", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Error") : Exit Sub
        If cboClass.Text = "" Then MsgBox("Invalid class of student, please check", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Errror") : Exit Sub
        'validate entered phone number
        If Not txt_Student_Contact_Number.Text.StartsWith("0") Then
            'do nothing if text begins with zero (0)
            MsgBox("Invalid Phone number, must start with zero(0)", MsgBoxStyle.Exclamation, "Error") : txt_Student_Contact_Number.ForeColor = Color.Red : txt_Student_Contact_Number.Focus() : Exit Sub
        ElseIf txt_Student_Contact_Number.Text.Length < 10 Then
            'do nothing if textlength not less than 10 characters
            MsgBox("Incomplete Phone number, must be 10 digits", MsgBoxStyle.Exclamation, "Error") : txt_Student_Contact_Number.ForeColor = Color.Red : txt_Student_Contact_Number.Focus() : Exit Sub
        End If
        If radYes.Checked = CheckState.Unchecked AndAlso radNo.Checked = CheckState.Unchecked Then
            MsgBox("Please specify bus status of the student", MsgBoxStyle.Exclamation, "SIMS-Error")
            Exit Sub
        End If
        'validate email address
        'If txt_Student_Contact_Email.Text.Contains("abcdefghijklmnopqrstuvwxyz0123456789") Or txt_Student_Contact_Email.Text.Contains(".com") Or txt_Student_Contact_Email.Text.Contains("@") Then

        'End If
        '1st try block statement check if student record exist or not
        If MsgBox("Are you sure you want to save new student registration?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "Confirmation") = MsgBoxResult.Yes Then
            Try
                If con.State = ConnectionState.Open Then con.Close()
                con.Open()
                com1 = New SqlCommand("select 'FirstName', 'MiddleName', 'LastName', 'Gender' from Students where FirstName='" & Me.txt_Student_Firstname.Text & "' AND Middlename='" & Me.txt_Student_Middlename.Text & "' AND LastName='" & Me.txt_Student_Surname.Text & "' AND Gender='" & Me.cboGender.Text & "'", ConnectionModule.con)
                dr = com1.ExecuteReader(CommandBehavior.CloseConnection)
                dr.Read()
                If Not dr.HasRows = True Then
                    AddStudent()
                    manage.GetData()
                    Exit Sub
                Else
                    If MsgBox("Duplicate Record Found.." & vbNewLine & vbNewLine & " A student with the Name : '" + Me.txt_Student_Firstname.Text + " " + Me.txt_Student_Middlename.Text & " " + Me.txt_Student_Surname.Text + "' " + " and Gender : '" + Me.cboGender.Text & "' is already registered." + vbCrLf + vbCrLf + "Are you sure this record represent a different student?", MsgBoxStyle.Exclamation + MsgBoxStyle.YesNo, "Duplicate Found") = MsgBoxResult.Yes Then
                        AddStudent()
                        manage.GetData()
                        Exit Sub
                    End If
                End If
                com1.Dispose()
                dr.Close()

            Catch ex As SqlException
                MsgBox(ex.Message, MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Sql Exception 1")
            Catch ex As Exception
                MsgBox(ex.Message, MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Exception 1")
            Finally
                con.Close()
            End Try
        End If


        'If reader.HasRows = True Then
        '    If MsgBox("Record Save Error." & vbNewLine & " A student with the Name : '" + Me.txt_Student_Firstname.Text + " " + Me.txt_Student_Middlename.Text & " " + Me.txt_Student_Surname.Text + "' " + " and Gender : '" + Me.cbo_Student_Gender.Text & "' is already registered." + vbCrLf + "Are you sure the record represent a new student. Do you really want to save information?", MsgBoxStyle.Exclamation + MsgBoxStyle.YesNo, "Record Exist") = MsgBoxResult.Yes Then
        '        AddStudent()
        '        'ManageStudent.GetData()
        '    End If
        'End If


        '2nd try statement checks if studentID exist in studentsnumbers table
        'if not exits, insert studentID and then read the student registration number 
        'Try
        '    If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
        '    ConnectionModule.con.Open()

        '    Dim table As New DataTable
        '    Dim da As SqlDataAdapter = New SqlDataAdapter("select * from StudentNumbers where StudentID='" & studID & "'", ConnectionModule.con)
        '    da.Fill(table)
        '    If table.Rows.Count > 0 Then
        '        MsgBox("Sorry! This Student has been already registered.", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly)
        '        Exit Sub
        '    Else
        '        'this code fires to insert data into the studentnumbers table 
        '        'retrieve the student registration nos & display in messagebox

        '        Dim ins As SqlCommand = New SqlCommand("com1 into StudentNumbers(StudentID) values(@d1)", ConnectionModule.con)
        '        ins.Parameters.AddWithValue("@d1", studID)
        '        ins.ExecuteNonQuery()

        '        ReturnStudentNo()

        '        'MsgBox("Registration successful" + vbCrLf + " The Student Registration Number is : " + studNo.ToString & " Keep the student number for future refrences and quote for all payment transactions..", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Success")
        '        Clearform()

        '    End If


        'Catch ex As Exception
        '    MsgBox(ex.Message)
        'End Try

    End Sub

    Private Sub dtpDate_KeyPress(sender As Object, e As KeyPressEventArgs)
        If Asc(e.KeyChar) <> 13 AndAlso Asc(e.KeyChar) <> 8 AndAlso Not IsNumeric(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub

    Private Sub dtpicker_Student_DateOfBirth_ValueChanged(sender As Object, e As EventArgs) Handles dtpDOB.ValueChanged
        'calculate student age from DOB
        Dim studentAge As New Integer
        'studentAge = DateTime.Today.Month - dtpDOB.Value.Month
        studentAge = DateTime.Today.Year - dtpDOB.Value.Year
        txt_student_age.Text = studentAge.ToString
    End Sub

    Private Sub Clearform()
        txt_Student_Contact_Address.Clear()
        txt_Contact_Email.Clear()
        txt_Student_Contact_Name.Clear()
        txt_Student_Contact_Number.Clear()
        txt_Student_Contact_WorkNo.Clear()
        txt_Student_Firstname.Clear()
        txt_Student_Hometown.Clear()
        txt_StudentLocation.Clear()
        txt_Student_Middlename.Clear()
        txt_Student_Surname.Clear()
        txt_student_age.Text = ""
       cbo_Student_District.ResetText()
        cbo_Student_Religion.ResetText()
        cboClass.ResetText()
        cboDepartment.ResetText()
        cboContact_Occupation.ResetText()
        cboTitle.ResetText()
        cboGender.ResetText()
        cbo_Student_Nationality.ResetText()
        cbo_Student_Region.ResetText()
        txt_Contact_Email.Clear()
        txt_StudentLocation.Clear()
        dtpDOB.Text = Today
        dtpDate.Text = Today
        dtpDOB.Checked = False
        cboContact_Relation.ResetText()
        radYes.Checked = False
        radNo.Checked = False
        txtFee.Text = ""
        txt_Student_Surname.Focus()
    End Sub

    Private Sub btn_Clear_Student_Record_Click(sender As Object, e As EventArgs) Handles btn_Clear_Student_Record.Click
        If MsgBox("Clear the form?", MsgBoxStyle.YesNo + MsgBoxStyle.Question, "SIMS") = MsgBoxResult.Yes Then
            Clearform()
        End If
    End Sub

    Private Sub btn_Find_student_Record_Click(sender As Object, e As EventArgs) Handles btn_Find_student_Record.Click
        Try
            Dim Msg As String
            Msg = InputBox("Enter the Admission or Registration Number of Student in the box below and click OK button.", "Search Student")

            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()

            Dim cmd As SqlCommand = New SqlCommand("select firstname,middlename,lastname,Registrationnumber,dob,age,department,class,region,district,nationality,houseaddress,contactname,contactnumber,contactaddress,contactoccupation,contactrelation,contactemail,contactworkno,gender,title,hometown,religion from students where RegistrationNumber='" & Msg.ToString() & "'", ConnectionModule.con)
            Dim dr As SqlDataReader = cmd.ExecuteReader(CommandBehavior.CloseConnection)
            If dr.HasRows Then
                While dr.Read()
                    MsgBox("STUDENT REGISTRATION INFORMATION" + vbCrLf + ".............................................................................." + vbCrLf + vbCrLf + "Registration Number : " + Msg.ToString.ToUpper + " '" & vbNewLine & "Student Name : " + dr(0).ToString & " " & dr(1).ToString & " " & dr(2).ToString() + " " & vbNewLine + "Current Class : " & dr(7).ToString() + "", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "SIMS")
                End While
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
            con.Close()
        End Try


    End Sub

    Sub GetStudentInfo()
        'Try
        '    Dim msg As String
        ' msg = Interaction.InputBox("Enter all characters of Student Admission No in the box below and click OK button.", "SEARCH STUDENT")
        '    If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
        '    ConnectionModule.con.Open()
        '    Try
        '        cmdd = New SqlCommand("select * from Students where RegistrationNumber='" & msg.ToString() & "'", ConnectionModule.con)
        '        dr = cmdd.ExecuteReader(CommandBehavior.CloseConnection)
        '        If dr.HasRows() = True Then
        '            While dr.Read()
        '                txt_Student_Firstname.Text = dr.GetValue(2)
        '                txt_Student_Middlename.Text = dr.GetValue(3)
        '                txt_Student_Surname.Text = dr.GetValue(4)
        '                dtpicker_Student_DateOfBirth.Text = dr.GetValue(5).ToString()
        '                txt_student_age.Text = dr.GetValue(6)
        '                cbo_Student_Department.Text = dr.GetValue(7)
        '                cbo_Student_Class.Text = dr.GetValue(8)
        '                cbo_Student_Region.Text = dr.GetValue(9)
        '                cbo_Student_District.Text = dr.GetValue(10)
        '                cbo_Student_Nationality.Text = dr.GetValue(11)
        '                txt_Student_House_Number.Text = dr.GetValue(12).ToString()
        '                txt_Student_Contact_Name.Text = dr.GetValue(13).ToString()
        '                txt_Student_Contact_Number.Text = dr.GetValue(14)
        '                txt_Student_Contact_Address.Text = dr.GetByte(15).ToString()
        '                cbo_Student_Contact_Occupation.Text = dr.GetValue(16).ToString()
        '                cbo_Student_Contact_Relation.Text = dr.GetValue(17).ToString()
        '                txt_Student_Contact_Email.Text = dr.GetValue(18).ToString()
        '                txt_Student_Contact_WorkNo.Text = dr.GetValue(19)
        '                cbo_Student_Gender.Text = dr.GetValue(20).ToString()
        '                cbo_Student_Title.Text = dr.GetValue(21).ToString()
        '                txt_Student_Hometown.Text = dr.GetValue(22).ToString()
        '                dtpDate.Text = dr.GetValue(23).ToString()
        '                cbo_Student_Religion.Text = dr.GetValue(24).ToString()
        '            End While
        '            dr.Close()
        '            cmdd.Dispose()
        '        End If

        '        If Not dr.Read() Then
        '            MsgBox("Please, the Admission No you entered is not valid. No such number is assigned to any student..", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "SIMS - Error")
        '            Exit Sub
        '        End If
        '    Catch ex As Exception
        '        MessageBox.Show(ex.Message, "at read")
        '    End Try


        'Catch ex As Exception
        '    MessageBox.Show(ex.Message, "at try")
        'End Try

    End Sub

    Private Sub btn_Cancel_Student_Form_Click(sender As Object, e As EventArgs) Handles btn_Cancel_Student_Form.Click
        Me.Close()
    End Sub

    Private Sub cbo_Student_Title_Click(sender As Object, e As EventArgs) Handles cboTitle.Click
        If cboGender.Text = "" Then
            MsgBox("You must select gender", MsgBoxStyle.Information, "SIMS")
            cboGender.Focus()
        End If
    End Sub

    Private Sub cboDepartment_DropDown(sender As Object, e As EventArgs) Handles cboDepartment.DropDown
        GetDeptList()
    End Sub

    Private Sub cbo_Student_Department_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboDepartment.SelectedIndexChanged
        ''If cboDepartment.SelectedItem = "KINDERGARTEN" Then
        ''    cboClass.Items.Clear()
        ''    cboClass.Items.Add("CRECHE")
        ''    cboClass.Items.Add("NURSERY 1")
        ''    cboClass.Items.Add("NURSERY 2")
        ''    cboClass.Items.Add("KG 1")
        ''    cboClass.Items.Add("KG 2")
        ''    Exit Sub
        ''End If

        ''If cboDepartment.SelectedItem = "LOWER PRIMARY" Then
        ''    cboClass.Items.Clear()
        ''    cboClass.Items.Add("PRIMARY 1")
        ''    cboClass.Items.Add("PRIMARY 2")
        ''    cboClass.Items.Add("PRIMARY 3")
        ''    Exit Sub
        ''End If

        ''If cboDepartment.SelectedItem = "UPPER PRIMARY" Then
        ''    cboClass.Items.Clear()
        ''    cboClass.Items.Add("PRIMARY 4")
        ''    cboClass.Items.Add("PRIMARY 5")
        ''    cboClass.Items.Add("PRIMARY 6")
        ''    Exit Sub
        ''End If

        ''If cboDepartment.SelectedItem = "JUNIOR HIGH SCHOOL" Then
        ''    cboClass.Items.Clear()
        ''    cboClass.Items.Add("JHS 1")
        ''    cboClass.Items.Add("JHS 2")
        ''    cboClass.Items.Add("JHS 3")
        ''    Exit Sub
        ''End If


        'cbo_Student_Class.Items.Clear()
        'cbo_Student_Class.Refresh()

        'If cbo_Student_Department.SelectedIndex = 0 Then
        '    cbo_Student_Class.Items.Add("CRECHE")
        '    cbo_Student_Class.Items.Add("NURSERY 1")
        '    cbo_Student_Class.Items.Add("NURSERY 2")
        '    cbo_Student_Class.Items.Add("K.G 1")
        '    cbo_Student_Class.Items.Add("K.G 2")
        '    Exit Sub
        'ElseIf cbo_Student_Department.SelectedIndex = 1 Then
        '    cbo_Student_Class.Items.Add("PRIMARY 1")
        '    cbo_Student_Class.Items.Add("PRIMARY 2")
        '    cbo_Student_Class.Items.Add("PRIMARY 3")
        '    Exit Sub
        'ElseIf cbo_Student_Department.SelectedIndex = 2 Then
        '    cbo_Student_Class.Items.Add("PRIMARY 4")
        '    cbo_Student_Class.Items.Add("PRIMARY 5")
        '    cbo_Student_Class.Items.Add("PRIMARY 6")
        '    Exit Sub
        'ElseIf cbo_Student_Department.SelectedIndex = 3 Then
        '    cbo_Student_Class.Items.Add("J.H.S 1")
        '    cbo_Student_Class.Items.Add("J.H.S 2")
        '    cbo_Student_Class.Items.Add("J.H.S 3")
        '    Exit Sub
        'End If

    End Sub

    Private Sub frmConfirm_Student_Admission_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ActiveControl = txt_Student_Surname

        ' cbo_Student_Region.SelectedIndex = 9
        ' cbo_Student_Nationality.SelectedIndex = 0
        cbo_Student_District.ResetText()

    End Sub

    Private Sub cbo_Student_Gender_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboGender.SelectedIndexChanged
        If cboGender.SelectedItem = "MALE" Then
            cboTitle.Items.Clear()
            cboTitle.Items.Add("Master")
            Exit Sub
        End If

        If cboGender.SelectedItem = "FEMALE" Then
            cboTitle.Items.Clear()
            cboTitle.Items.Add("Miss")
            Exit Sub
        End If

        'cbo_Student_Title.Items.Clear()
        'If cbo_Student_Gender.SelectedIndex = 0 Then
        '    cbo_Student_Title.Items.Add("Miss")
        '    Exit Sub
        'ElseIf cbo_Student_Gender.SelectedIndex = 1 Then
        '    cbo_Student_Title.Items.Add("Master")
        '    Exit Sub
        'End If
    End Sub

    Private Sub txt_student_age_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txt_student_age.KeyPress
        If Asc(e.KeyChar) <> 13 AndAlso Asc(e.KeyChar) <> 8 AndAlso Not IsNumeric(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub

    Private Sub txt_Student_Firstname_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txt_Student_Firstname.KeyPress
        Select Case Asc(e.KeyChar)
            Case 8, 32, 65 To 90, 97 To 122
                e.Handled = False
            Case Else
                e.Handled = True
        End Select
    End Sub

    Private Sub txt_Student_Contact_Address_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txt_Student_Contact_Address.KeyPress
        Select Case Asc(e.KeyChar)
            Case 48 To 57, 8, 32, 65 To 90, 97 To 122
                e.Handled = False
            Case Else
                e.Handled = True
        End Select
    End Sub

    Private Sub txt_Student_Contact_Name_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txt_Student_Contact_Name.KeyPress
        Select Case Asc(e.KeyChar)
            Case 8, 32, 65 To 90, 97 To 122
                e.Handled = False
            Case Else
                e.Handled = True
        End Select
    End Sub

    Private Sub txt_Student_Hometown_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txt_Student_Hometown.KeyPress
        Select Case Asc(e.KeyChar)
            Case 8, 32, 65 To 90, 97 To 122
                e.Handled = False
            Case Else
                e.Handled = True
        End Select
    End Sub

    Private Sub txt_Student_Middlename_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txt_Student_Middlename.KeyPress
        Select Case Asc(e.KeyChar)
            Case 8, 32, 65 To 90, 97 To 122
                e.Handled = False
            Case Else
                e.Handled = True
        End Select
    End Sub

    Private Sub txt_Student_Surname_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txt_Student_Surname.KeyPress
        Select Case Asc(e.KeyChar)
            Case 8, 32, 45, 65 To 90, 97 To 122
                e.Handled = False
            Case Else
                e.Handled = True
        End Select
    End Sub

    Private Sub txt_Student_Contact_Number_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txt_Student_Contact_Number.KeyPress
        'accepts only numbers/digits
        If Asc(e.KeyChar) <> 13 AndAlso Asc(e.KeyChar) <> 8 AndAlso Not IsNumeric(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub

    Private Sub txt_Student_Contact_WorkNo_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txt_Student_Contact_WorkNo.KeyPress
        'accepts only numbers/digits
        If Asc(e.KeyChar) <> 13 AndAlso Asc(e.KeyChar) <> 8 AndAlso Not IsNumeric(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub

    Private Sub txt_StudentLocation_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txt_StudentLocation.KeyPress
        Select Case Asc(e.KeyChar)
            Case 8, 32, 65 To 90, 97 To 122, 13
                e.Handled = False
            Case Else
                e.Handled = True
        End Select
    End Sub

    Private Sub txt_Student_Contact_Email_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txt_Contact_Email.KeyPress
       Select Case Asc(e.KeyChar)
            Case 8, 45, 46, 64, 127, 48 To 57, 65 To 90, 97 To 122
                e.Handled = False
            Case Else
                e.Handled = True
        End Select
    End Sub

    Private Sub txt_student_age_TextChanged(sender As Object, e As EventArgs) Handles txt_student_age.TextChanged

    End Sub

#Region "get district of each region"
    Sub AddDistricts_Ashanti()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            Dim dst As Data.DataSet = New Data.DataSet
            Dim dtAdpt As SqlDataAdapter = New SqlDataAdapter
            dst.Clear()

            dtAdpt.SelectCommand = New SqlCommand("SELECT ID,Name FROM tblAshantiRegion", ConnectionModule.con)
            dtAdpt.Fill(dst, "tblAshantiRegion")
            cbo_Student_District.DataSource = dst.Tables("tblAshantiRegion")
            cbo_Student_District.DisplayMember = "Name"
            cbo_Student_District.ValueMember = "ID"
            cbo_Student_District.SelectedIndex = -1
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        con.Close()
    End Sub
    Sub AddDistricts_Eastern()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            Dim dst As Data.DataSet = New Data.DataSet
            Dim dtAdpt As SqlDataAdapter = New SqlDataAdapter
            dst.Clear()

            dtAdpt.SelectCommand = New SqlCommand("SELECT ID,Name FROM tblEasternRegion", ConnectionModule.con)
            dtAdpt.Fill(dst, "tblEasternRegion")
            cbo_Student_District.DataSource = dst.Tables("tblEasternRegion")
            cbo_Student_District.DisplayMember = "Name"
            cbo_Student_District.ValueMember = "ID"
            cbo_Student_District.SelectedIndex = -1
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        con.Close()
    End Sub
    Sub AddDistricts_Central()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            Dim dst As Data.DataSet = New Data.DataSet
            Dim dtAdpt As SqlDataAdapter = New SqlDataAdapter
            dst.Clear()

            dtAdpt.SelectCommand = New SqlCommand("SELECT ID,Name FROM tblCentralRegion", ConnectionModule.con)
            dtAdpt.Fill(dst, "tblCentralRegion")
            cbo_Student_District.DataSource = dst.Tables("tblCentralRegion")
            cbo_Student_District.DisplayMember = "Name"
            cbo_Student_District.ValueMember = "ID"
            cbo_Student_District.SelectedIndex = -1
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        con.Close()
    End Sub
    Sub AddDistricts_UpperEast()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            Dim dst As Data.DataSet = New Data.DataSet
            Dim dtAdpt As SqlDataAdapter = New SqlDataAdapter
            dst.Clear()

            dtAdpt.SelectCommand = New SqlCommand("SELECT ID,Name FROM tblUERegion", ConnectionModule.con)
            dtAdpt.Fill(dst, "tblUERegion")
            cbo_Student_District.DataSource = dst.Tables("tblUERegion")
            cbo_Student_District.DisplayMember = "Name"
            cbo_Student_District.ValueMember = "ID"
            cbo_Student_District.SelectedIndex = -1
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        con.Close()
    End Sub
    Sub AddDistricts_BrongAhafo()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            Dim dst As Data.DataSet = New Data.DataSet
            Dim dtAdpt As SqlDataAdapter = New SqlDataAdapter
            dst.Clear()

            dtAdpt.SelectCommand = New SqlCommand("SELECT ID,Name FROM tblBARegion", ConnectionModule.con)
            dtAdpt.Fill(dst, "tblBARegion")
            cbo_Student_District.DataSource = dst.Tables("tblBARegion")
            cbo_Student_District.DisplayMember = "Name"
            cbo_Student_District.ValueMember = "ID"
            cbo_Student_District.SelectedIndex = -1
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        con.Close()
    End Sub
    Sub AddDistricts_Northern()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            Dim dst As Data.DataSet = New Data.DataSet
            Dim dtAdpt As SqlDataAdapter = New SqlDataAdapter
            dst.Clear()

            dtAdpt.SelectCommand = New SqlCommand("SELECT ID,Name FROM tblNorthernRegion", ConnectionModule.con)
            dtAdpt.Fill(dst, "tblNorthernRegion")
            cbo_Student_District.DataSource = dst.Tables("tblNorthernRegion")
            cbo_Student_District.DisplayMember = "Name"
            cbo_Student_District.ValueMember = "ID"
            cbo_Student_District.SelectedIndex = -1
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        con.Close()
    End Sub
    Sub AddDistricts_UpperWest()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            Dim dst As Data.DataSet = New Data.DataSet
            Dim dtAdpt As SqlDataAdapter = New SqlDataAdapter
            dst.Clear()

            dtAdpt.SelectCommand = New SqlCommand("SELECT ID,Name FROM tblUWRegion", ConnectionModule.con)
            dtAdpt.Fill(dst, "tblUWRegion")
            cbo_Student_District.DataSource = dst.Tables("tblUWRegion")
            cbo_Student_District.DisplayMember = "Name"
            cbo_Student_District.ValueMember = "ID"
            cbo_Student_District.SelectedIndex = -1
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        con.Close()
    End Sub
    Sub AddDistricts_Volta()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            Dim dst As Data.DataSet = New Data.DataSet
            Dim dtAdpt As SqlDataAdapter = New SqlDataAdapter
            dst.Clear()

            dtAdpt.SelectCommand = New SqlCommand("SELECT ID,Name FROM tblVoltaRegion", ConnectionModule.con)
            dtAdpt.Fill(dst, "tblVoltaRegion")
            cbo_Student_District.DataSource = dst.Tables("tblVoltaRegion")
            cbo_Student_District.DisplayMember = "Name"
            cbo_Student_District.ValueMember = "ID"
            cbo_Student_District.SelectedIndex = -1
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        con.Close()
    End Sub
    Sub AddDistricts_GreaterAccra()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            Dim dst As Data.DataSet = New Data.DataSet
            Dim dtAdpt As SqlDataAdapter = New SqlDataAdapter
            dst.Clear()

            dtAdpt.SelectCommand = New SqlCommand("SELECT ID,Name FROM tblGARegion", ConnectionModule.con)
            dtAdpt.Fill(dst, "tblGARegion")
            cbo_Student_District.DataSource = dst.Tables("tblGARegion")
            cbo_Student_District.DisplayMember = "Name"
            cbo_Student_District.ValueMember = "ID"
            cbo_Student_District.SelectedIndex = -1
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        con.Close()
    End Sub
    Sub AddDistricts_Western()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            Dim dst As Data.DataSet = New Data.DataSet
            Dim dtAdpt As SqlDataAdapter = New SqlDataAdapter
            dst.Clear()

            dtAdpt.SelectCommand = New SqlCommand("SELECT ID,Name FROM tblWesternRegion", ConnectionModule.con)
            dtAdpt.Fill(dst, "tblWesternRegion")
            cbo_Student_District.DataSource = dst.Tables("tblWesternRegion")
            cbo_Student_District.DisplayMember = "Name"
            cbo_Student_District.ValueMember = "ID"
            cbo_Student_District.SelectedIndex = -1
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        con.Close()
    End Sub

#End Region

    Private Sub cbo_Student_Region_Click(sender As Object, e As EventArgs) Handles cbo_Student_Region.Click
        If cbo_Student_District.Text <> "" Then
            cbo_Student_District.ResetText()
        End If
        If cbo_Student_Nationality.Text = "" Then
            MsgBox("You must select nationality", MsgBoxStyle.Information, "SIMS")
            Exit Sub
        End If
        
    End Sub

    Private Sub cbo_Student_Region_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbo_Student_Region.SelectedIndexChanged
        'code fires to check selected region of student
        'and add respective districts to dropdown
        ''If cbo_Student_Region.Text = "ASHANTI" Then
        ''    cbo_Student_District.Items.Clear()
        ''    cbo_Student_District.Items.Add("")
        ''    Exit Sub
        ''End If
    End Sub

    Private Sub cbo_Student_District_Click(sender As Object, e As EventArgs) Handles cbo_Student_District.Click
        If cbo_Student_Region.Text = "" Then
            MsgBox("You must select region", MsgBoxStyle.Information, "SIMS")
            Exit Sub
        End If
    End Sub

    Private Sub cbo_Student_District_DropDown(sender As Object, e As EventArgs) Handles cbo_Student_District.DropDown
        'set datasource to selected region/district
        If cbo_Student_Region.Text = "ASHANTI" Then
            cbo_Student_District.ResetText()
            AddDistricts_Ashanti()
            Exit Sub
        ElseIf cbo_Student_Region.Text = "BRONG AHAFO" Then
            cbo_Student_District.ResetText()
            AddDistricts_BrongAhafo()
            Exit Sub
        ElseIf cbo_Student_Region.Text = "CENTRAL" Then
            cbo_Student_District.ResetText()
            AddDistricts_Central()
            Exit Sub
        ElseIf cbo_Student_Region.Text = "EASTERN" Then
            cbo_Student_District.ResetText()
            AddDistricts_Eastern()
            Exit Sub
        ElseIf cbo_Student_Region.Text = "GREATER ACCRA" Then
            cbo_Student_District.ResetText()
            AddDistricts_GreaterAccra()
            Exit Sub
        ElseIf cbo_Student_Region.Text = "NORTHERN" Then
            cbo_Student_District.ResetText()
            AddDistricts_Northern()
            Exit Sub
        ElseIf cbo_Student_Region.Text = "UPPER EAST" Then
            cbo_Student_District.ResetText()
            AddDistricts_UpperEast()
            Exit Sub
        ElseIf cbo_Student_Region.Text = "UPPER WEST" Then
            cbo_Student_District.ResetText()
            AddDistricts_UpperWest()
            Exit Sub
        ElseIf cbo_Student_Region.Text = "VOLTA" Then
            cbo_Student_District.ResetText()
            AddDistricts_Volta()
            Exit Sub
        ElseIf cbo_Student_Region.Text = "WESTERN" Then
            cbo_Student_District.ResetText()
            AddDistricts_Western()
            Exit Sub
        End If

    End Sub

    Private Sub txt_Student_Contact_Number_Leave(sender As Object, e As EventArgs) Handles txt_Student_Contact_Number.Leave
        If txt_Student_Contact_Number.Text.StartsWith("0") And Not txt_Student_Contact_Number.Text.Length < 10 Then
            'do nothing if text begins with zero (0)
            txt_Student_Contact_Number.ForeColor = Color.Black
            'Else
            '     txt_Student_Contact_Number.ForeColor = Color.Red
        End If
    End Sub
    
    Private Sub cboClass_Click(sender As Object, e As EventArgs) Handles cboClass.Click
        If cboDepartment.Text = "" Then
            MsgBox("You must select department", MsgBoxStyle.Information, "SIMS")
            Exit Sub
        End If
    End Sub

    Private Sub cbo_Student_Nationality_Click(sender As Object, e As EventArgs) Handles cbo_Student_Nationality.Click

    End Sub

    Private Sub txtFee_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtFee.KeyPress
        'accepts only numbers/digits
        If Asc(e.KeyChar) <> 13 AndAlso Asc(e.KeyChar) <> 8 AndAlso Not IsNumeric(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub

    Private Sub txtFee_TextChanged(sender As Object, e As EventArgs) Handles txtFee.TextChanged

    End Sub

    Private Sub txtFee_Leave(sender As Object, e As EventArgs) Handles txtFee.Leave
        Dim inputFee As Integer = Val(txtFee.Text)
        txtFee.Text = Format(inputFee, "0.00")
    End Sub

    Private Sub txtFee_LostFocus(sender As Object, e As EventArgs) Handles txtFee.LostFocus

    End Sub
    Public Sub ClassListKg()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            dset = New Data.DataSet()
            adapter = New SqlDataAdapter()
            adapter.SelectCommand = New SqlCommand("select distinct room from classroom where Dept='KINDERGARTEN' order by room asc", ConnectionModule.con)
            dset.Clear()
            adapter.Fill(dset, "classroom")
            cboClass.DataSource = dset.Tables("classroom")
            cboClass.DisplayMember = "room"
            ''cboYear.ValueMember = "ID"
            cboClass.Refresh()
            cboClass.SelectedIndex = -1
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at get academic year")
            con.Close()
        End Try
    End Sub
    Public Sub ClassListLp()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            dset = New Data.DataSet()
            adapter = New SqlDataAdapter()
            adapter.SelectCommand = New SqlCommand("select distinct room from classroom where Dept='LOWER PRIMARY' order by room asc", ConnectionModule.con)
            dset.Clear()
            adapter.Fill(dset, "classroom")
            cboClass.DataSource = dset.Tables("classroom")
            cboClass.DisplayMember = "room"
            ''cboYear.ValueMember = "ID"
            cboClass.Refresh()
            cboClass.SelectedIndex = -1
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at get academic year")
            con.Close()
        End Try
    End Sub
    Public Sub ClassListUp()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            dset = New Data.DataSet()
            adapter = New SqlDataAdapter()
            adapter.SelectCommand = New SqlCommand("select distinct room from classroom where Dept='UPPER PRIMARY' order by room asc", ConnectionModule.con)
            dset.Clear()
            adapter.Fill(dset, "classroom")
            cboClass.DataSource = dset.Tables("classroom")
            cboClass.DisplayMember = "room"
            ''cboYear.ValueMember = "ID"
            cboClass.Refresh()
            cboClass.SelectedIndex = -1
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at get academic year")
            con.Close()
        End Try
    End Sub
    Public Sub ClassListJhs()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            dset = New Data.DataSet()
            adapter = New SqlDataAdapter()
            adapter.SelectCommand = New SqlCommand("select distinct room from classroom where Dept='JUNIOR HIGH SCHOOL' order by room asc", ConnectionModule.con)
            dset.Clear()
            adapter.Fill(dset, "classroom")
            cboClass.DataSource = dset.Tables("classroom")
            cboClass.DisplayMember = "room"
            cboClass.Refresh()
            cboClass.SelectedIndex = -1
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at get academic year")
            con.Close()
        End Try
    End Sub

    Public Sub GetDeptList()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            dset = New Data.DataSet()
            adapter = New SqlDataAdapter()
            adapter.SelectCommand = New SqlCommand("select name from tbldepartment order by deptid asc", ConnectionModule.con)
            dset.Clear()
            adapter.Fill(dset, "tbldepartment")
            cboDepartment.DataSource = dset.Tables("tbldepartment")
            cboDepartment.DisplayMember = "name"
            cboDepartment.Refresh()
            cboDepartment.SelectedIndex = -1
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at get school dept")
            con.Close()
        End Try
    End Sub

    Private Sub cboClass_DropDown(sender As Object, e As EventArgs) Handles cboClass.DropDown
        If cboDepartment.Text = "KINDERGARTEN" Then
            cboClass.ResetText()
            ClassListKg()
            Exit Sub
        ElseIf cboDepartment.Text = "LOWER PRIMARY" Then
            cboClass.ResetText()
            ClassListLp()
            Exit Sub
        ElseIf cboDepartment.Text = "UPPER PRIMARY" Then
            cboClass.ResetText()
            ClassListUp()
            Exit Sub
        ElseIf cboDepartment.Text = "JUNIOR HIGH SCHOOL" Then
            cboClass.ResetText()
            ClassListJhs()
            Exit Sub
        End If
    End Sub

    Private Sub cboClass_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboClass.SelectedIndexChanged

    End Sub

    Private Sub txt_Student_Contact_Address_TextChanged(sender As Object, e As EventArgs) Handles txt_Student_Contact_Address.TextChanged

    End Sub

    Private Sub radYes_CheckedChanged(sender As Object, e As EventArgs) Handles radYes.CheckedChanged
        bus_status = "Yes"
    End Sub

    Private Sub radNo_CheckedChanged(sender As Object, e As EventArgs) Handles radNo.CheckedChanged
        bus_status = "No"
    End Sub
End Class