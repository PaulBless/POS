﻿Imports System.Data.SqlClient
Imports System.IO
Public Class frmStaffJobDetails

    Dim opfile As New OpenFileDialog

    Sub Showrecord()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()

            Dim dataset As Data.DataSet = New Data.DataSet
            dataset.Clear()

            Dim adap As New SqlDataAdapter("SELECT StaffID, StaffCode FROM Staff order by StaffID Desc", ConnectionModule.con)
            adap.Fill(dataset, "Staff")
            cboCode.DataSource = dataset.Tables("Staff")
            cboCode.ValueMember = "StaffID"
            cboCode.DisplayMember = "StaffCode"
            cboCode.SelectedIndex = -1

            cboCode.Refresh()

        Catch ex As Exception
            con.Close()

        End Try
    End Sub

    Private Sub frmStaffJobDetails_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ActiveControl = txtEmpID
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        If txtEmpID.Text = "" Then MsgBox("Invalid Employee ID, Please check.", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "SIMS - Error") : txtEmpID.Focus() : Exit Sub
        If cboBackground.Text = "" Then MsgBox("Invalid educational status.", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "SIMS - Error") : Exit Sub
        If cboStaffqualification.Text = "" Then MsgBox("Invalid employee qualification.", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "SIMS - Error") : Exit Sub
        If cboSaffdepartment.Text = "" Then MsgBox("Select department of designation.", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "SIMS - Error") : Exit Sub
        If cboStaffcategory.Text = "" Then MsgBox("Category is required.", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "SIMS - Error") : Exit Sub
        If cboDesignation.Text = "" Then MsgBox("Designation is required.", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "SIMS - Error") : Exit Sub
        If cboStatus.Text = "" Then MsgBox("Select status of Staff.", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "SIMS - Error") : Exit Sub
        If cboType.Text = "" Then MsgBox("Select appointment type.", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "SIMS - Error") : Exit Sub
        If lblFile.Text = "F" Then MsgBox("Please attach necessary documents(cv or resume) of the selected employee.. ", MsgBoxStyle.OkOnly + MsgBoxStyle.Exclamation, "SIMS Error") : Exit Sub

        'extract the file location/name
        Dim myfilename() As String = opfile.FileName.Split("\")
        Dim actualfile As String = myfilename.Last.ToString
        'read file data
        Dim fileData() As Byte
        Dim fileStream As New FileStream(opfile.FileName, FileMode.Open)
        Dim bReader As New BinaryReader(fileStream)
        fileData = bReader.ReadBytes(fileStream.Length)
        fileStream.Close()
        bReader.Close()

        If MsgBox("Do you really want to save employee job designation details?", MsgBoxStyle.YesNo + MsgBoxStyle.Question, "Confirmation") = MsgBoxResult.Yes Then
            Try
                If con.State = ConnectionState.Open Then con.Close()
                con.Open()
                com = New SqlCommand("SELECT RTRIM(StaffID) FROM JobDetails1 where StaffID='" & SearchId & "'", ConnectionModule.con)
                dr = com.ExecuteReader()
                If Not dr.Read() Then
                    dr.Close()
                    com = New SqlCommand("insert into JobDetails1 (StaffID,Background,Qualification,Category,Department,Designation,Portfolio,Type,Status,Date,FileName,Resume) values(@d1,@d2,@d3,@d4,@d5,@d6,@d7,@d8,@d9,@d10,@d11,@d12)", ConnectionModule.con)
                    com.Parameters.AddWithValue("@d1", SearchId)
                    com.Parameters.AddWithValue("@d2", cboBackground.Text)
                    com.Parameters.AddWithValue("@d3", cboStaffqualification.Text)
                    com.Parameters.AddWithValue("@d4", cboStaffcategory.Text)
                    com.Parameters.AddWithValue("@d5", cboSaffdepartment.Text)
                    com.Parameters.AddWithValue("@d6", cboDesignation.Text)
                    com.Parameters.AddWithValue("@d7", cboPortfolio.Text)
                    com.Parameters.AddWithValue("@d8", cboType.Text)
                    com.Parameters.AddWithValue("@d9", cboStatus.Text)
                    com.Parameters.AddWithValue("@d10", Date.Now)
                    com.Parameters.AddWithValue("@d11", actualfile)
                    com.Parameters.AddWithValue("@d12", fileData)
                    com.ExecuteNonQuery()
                    MessageBox.Show("Employee job designation successfully saved!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    ClearFields()
                    Exit Sub
                ElseIf dr.Read() = True Then
                    MsgBox("Record exists! Cannot save duplicate record." + vbCrLf + "This employee has been assigned job already. NB:- You can edit job details using the 'Job Profile Mastery'", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "Duplicate") : Exit Sub
                End If

            Catch ex As Exception
                MsgBox(ex.Message.ToString())
                con.Close()
            End Try
        End If


    End Sub

    Sub ClearFields()
        cboSaffdepartment.ResetText()
        cboStaffcategory.ResetText()
        cboStaffqualification.ResetText()
        cboCode.ResetText()
        cboBackground.ResetText()
        cboStatus.ResetText()
        cboType.ResetText()
        txtEmpID.Clear()
        cboPortfolio.ResetText()
        cboDesignation.ResetText()
        lblFile.Text = "F"
    End Sub
    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        Dim c As MsgBoxResult = MsgBox("Clear the form?", MsgBoxStyle.YesNo + MsgBoxStyle.Question, "SIMS")
        If c = MsgBoxResult.Yes Then
            ClearFields()
        End If
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub

    Private Sub cboBackground_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboBackground.SelectedIndexChanged
        cboStaffqualification.Items.Clear()
        If cboBackground.SelectedIndex = 0 Then
            cboStaffqualification.Items.Add("BASIC EDUCATION CERTIFICATE EXAMINATION(BECE)")
            Exit Sub
        ElseIf cboBackground.SelectedIndex = 3 Then
            cboStaffqualification.Items.Add("NATIONAL VOCATIONAL TRAINING INSTITUTE(N.V.T.I)")
            cboStaffqualification.Items.Add("CERTIFICATE IN SECRETARIALSHIP")
            cboStaffqualification.Items.Add("CERTIFICATE IN JOURNALISM")
            cboStaffqualification.Items.Add("CERTIFICATE IN NURSING")
            cboStaffqualification.Items.Add("OTHER")
            Exit Sub
        ElseIf cboBackground.SelectedIndex = 1 Then
            cboStaffqualification.Items.Add("SECONDARY SCHOOL CERTIFICATE EXAMINATION(SSCE)")
            cboStaffqualification.Items.Add("WEST AFRICAN SECONDARY SCHOOL CERTIFICATE EXAMINATION(WASSCE)")
            Exit Sub
        ElseIf cboBackground.SelectedIndex = 2 Then
            cboStaffqualification.Items.Add("MASTER OF PHILOSOPHY(M PHIL)")
            cboStaffqualification.Items.Add("HIGHER NATIONAL DIPLOMA(HND)")
            cboStaffqualification.Items.Add("DIPLOMA IN EDUCATION")
            cboStaffqualification.Items.Add("BACHELOR OF EDUCATION(BED)")
            cboStaffqualification.Items.Add("BACHELOR OF TECHNOLOGY(B TECH)")
            cboStaffqualification.Items.Add("BACHELOR OF SCIENCE(BSC)")
            cboStaffqualification.Items.Add("BACHELOR OF ARTS(BA)")
            Exit Sub
        End If
    End Sub

    Private Sub cboStaffcategory_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboStaffcategory.SelectedIndexChanged
        cboSaffdepartment.Items.Clear()
        If cboStaffcategory.SelectedItem = "Non-Teaching" Then
            cboSaffdepartment.Items.Add("ADMINISTRATION")
            cboSaffdepartment.Items.Add("OTHER SERVICES")
            Exit Sub
        ElseIf cboStaffcategory.SelectedItem = "Teaching" Then
            cboSaffdepartment.Items.Add("KINDERGARTEN")
            cboSaffdepartment.Items.Add("LOWER PRIMARY")
            cboSaffdepartment.Items.Add("UPPER PRIMARY")
            cboSaffdepartment.Items.Add("JUNIOR HIGH SCHOOL")
            Exit Sub
        End If
    End Sub

    Private Sub cboCode_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboCode.SelectedIndexChanged

    End Sub

    Private Sub txtCode_TextChanged(sender As Object, e As EventArgs) Handles txtEmpID.TextChanged
        If txtEmpID.Text <> "" Then
            Try
                If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                ConnectionModule.con.Open()
                query = "select StaffID,FirstName + space(1) + MiddleName + space(1) + LastName AS Fullname, Gender, Age, PhoneNumber,Nationality,SSNIT from Staff where StaffCode='" & Me.txtEmpID.Text & "'"
                com = New SqlCommand(query, ConnectionModule.con)
                table = New DataTable()
                adapter = New SqlDataAdapter(com)
                adapter.Fill(table)
                'fetch employee values
                SearchId = table.Rows(0)(0).ToString()
                lbl_1.Text = table.Rows(0)(1).ToString()
                lbl_2.Text = table.Rows(0)(2).ToString()
                lbl_5.Text = table.Rows(0)(3).ToString()
                lbl_3.Text = table.Rows(0)(4).ToString()
                lbl_4.Text = table.Rows(0)(5).ToString()
                lbl_6.Text = Format(table.Rows(0)(6).ToString())
                'show the labels for emp info
                lbl_1.Visible = True
                lbl_2.Visible = True
                lbl_3.Visible = True
                lbl_4.Visible = True
                lbl_5.Visible = True
                lbl_6.Visible = True

                'com.Dispose()
            Catch ex As Exception
                con.Close()
            End Try
        Else
            ResetPanel()
        End If

    End Sub
    Sub ResetPanel()
        'hide the labels for emp info
        lbl_1.Visible = False
        lbl_2.Visible = False
        lbl_3.Visible = False
        lbl_4.Visible = False
        lbl_5.Visible = False
        lbl_6.Visible = False
        'set values to null
        lbl_1.Text = ""
        lbl_2.Text = ""
        lbl_3.Text = ""
        lbl_4.Text = ""
        lbl_5.Text = ""
        lbl_6.Text = ""
    End Sub

    Private Sub cboSaffdepartment_Click(sender As Object, e As EventArgs) Handles cboSaffdepartment.Click
        If cboStaffcategory.Text = "" Then
            MsgBox("Select category", MsgBoxStyle.Information, "SIMS") : Exit Sub
        End If
    End Sub

    Private Sub cboSaffdepartment_DropDown(sender As Object, e As EventArgs) Handles cboSaffdepartment.DropDown
        cboSaffdepartment.ResetText()
    End Sub
    Private Sub cboSaffdepartment_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboSaffdepartment.SelectedIndexChanged
        'cboDesignation.Items.Clear()
        'If cboSaffdepartment.SelectedItem = "ADMINISTRATION" Then
        '    cboDesignation.Items.Add("DIRECTOR")
        '    cboDesignation.Items.Add("PROPRIETOR")
        '    cboDesignation.Items.Add("HEAD TEACHER")
        '    cboDesignation.Items.Add("SECRETARY")
        '    cboDesignation.Items.Add("LIBRARIAN")
        '    cboDesignation.Items.Add("BURSAR")
        '    cboDesignation.Items.Add("ACCOUNTANT")
        '    Exit Sub
        'ElseIf cboSaffdepartment.SelectedItem = "OTHER SERVICES" Then
        '    cboDesignation.Items.Add("DRIVER")
        '    cboDesignation.Items.Add("COOK")
        '    cboDesignation.Items.Add("ORDERLY")
        '    cboDesignation.Items.Add("SECURITY")
        '    Exit Sub
        'End If

        'If cboSaffdepartment.SelectedItem = "KINDERGARTEN" Then
        '    cboDesignation.Items.Add("CRECHE")
        '    cboDesignation.Items.Add("NURSERY 1")
        '    cboDesignation.Items.Add("NURSERY 2")
        '    cboDesignation.Items.Add("KG 1")
        '    cboDesignation.Items.Add("KG 2")
        '    Exit Sub
        'End If

        'If cboSaffdepartment.SelectedItem = "LOWER PRIMARY" Then
        '    cboDesignation.Items.Add("PRIMARY 1")
        '    cboDesignation.Items.Add("PRIMARY 2")
        '    cboDesignation.Items.Add("PRIMARY 3")
        '   Exit Sub
        'End If

        'If cboSaffdepartment.SelectedItem = "UPPER PRIMARY" Then
        '    cboDesignation.Items.Add("PRIMARY 4")
        '    cboDesignation.Items.Add("PRIMARY 5")
        '    cboDesignation.Items.Add("PRIMARY 6")
        '   Exit Sub
        'End If

        'If cboSaffdepartment.SelectedItem = "JUNIOR HIGH SCHOOL" Then
        '    cboDesignation.Items.Add("JHS 1")
        '    cboDesignation.Items.Add("JHS 2")
        '    cboDesignation.Items.Add("JHS 3")
        '    Exit Sub
        'End If

    End Sub
    
    'save into jobdetails table_old code
    'Dim cmd As SqlCommand = New SqlCommand("SELECT * FROM JobDetails where StaffID='" & Me.txtSID.Text & "'", ConnectionModule.con)
    'Dim dr As SqlDataReader = cmd.ExecuteReader(CommandBehavior.CloseConnection)
    'If dr.Read() Then
    '    MsgBox("Request Failed! This Staff has been assigned job already.", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly)
    '    ' dr.Close()
    'Else
    '    Dim comdIns As SqlCommand = New SqlCommand("insert into JobDetails(StaffID,Background,Qualification,Department,Category,Job,Type,Status,DateEmployed) values(@d1,@d2,@d3,@d4,@d5,@d6,@d7,@d8,@d9)", ConnectionModule.con)
    '    comdIns.Parameters.AddWithValue("@d1", txtSID.Text)
    '    comdIns.Parameters.AddWithValue("@d2", cboBackground.SelectedItem)
    '    comdIns.Parameters.AddWithValue("@d3", cboStaffqualification.SelectedItem)
    '    comdIns.Parameters.AddWithValue("@d4", cboSaffdepartment.SelectedItem)
    '    comdIns.Parameters.AddWithValue("@d5", cboStaffcategory.SelectedItem)
    '    comdIns.Parameters.AddWithValue("@d6", cbostaffjob.SelectedItem)
    '    comdIns.Parameters.AddWithValue("@d7", cboType.SelectedItem)
    '    comdIns.Parameters.AddWithValue("@d8", cboStatus.SelectedItem)
    '    comdIns.Parameters.AddWithValue("@d9", Date.Today)
    '    comdIns.ExecuteNonQuery()

    '    MessageBox.Show("Employment Details Successfully Saved!", "SIMS - Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
    '    clear()
    '    dr.Close()

    'End If

    Private Sub cboStaffqualification_Click(sender As Object, e As EventArgs) Handles cboStaffqualification.Click
        If cboBackground.Text = "" Then MsgBox("You must select educational status first", MsgBoxStyle.OkOnly + MsgBoxStyle.Information, "SIMS") : Exit Sub

    End Sub

    Private Sub cboDesignation_Click(sender As Object, e As EventArgs) Handles cboDesignation.Click
        If cboSaffdepartment.Text = "" Then MsgBox("You must select department first", MsgBoxStyle.OkOnly + MsgBoxStyle.Information, "SIMS") : Exit Sub

    End Sub
    Public Sub GetDepartment_Teaching()
        Try
            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            dset = New Data.DataSet()
            adapter = New SqlDataAdapter()
            adapter.SelectCommand = New SqlCommand("select name from tbldepartment order by deptid asc", ConnectionModule.con)
            dset.Clear()
            adapter.Fill(dset, "tbldepartment")
            cboSaffdepartment.DataSource = dset.Tables("tbldepartment")
            cboSaffdepartment.DisplayMember = "name"
            cboSaffdepartment.Refresh()
            cboSaffdepartment.SelectedIndex = -1
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at get dept")
            con.Close()
        End Try
    End Sub
    Public Sub GetDepartment_NonTeaching()
        Try
            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            dset = New Data.DataSet()
            adapter = New SqlDataAdapter()
            adapter.SelectCommand = New SqlCommand("select name from tbldepartment_nt order by deptid asc", ConnectionModule.con)
            dset.Clear()
            adapter.Fill(dset, "tbldepartment_nt")
            cboSaffdepartment.DataSource = dset.Tables("tbldepartment_nt")
            cboSaffdepartment.DisplayMember = "name"
            cboSaffdepartment.Refresh()
            cboSaffdepartment.SelectedIndex = -1
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at get dept")
            con.Close()
        End Try
    End Sub
    Public Sub ClassListKg()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            dset = New Data.DataSet()
            adapter = New SqlDataAdapter()
            adapter.SelectCommand = New SqlCommand("select distinct room from classroom where Dept='KINDERGARTEN' order by room asc", ConnectionModule.con)
            dset.Clear()
            adapter.Fill(dset, "classroom")
            cboDesignation.DataSource = dset.Tables("classroom")
            cboDesignation.DisplayMember = "room"
            cboDesignation.Refresh()
            cboDesignation.SelectedIndex = -1
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at get academic year")
            con.Close()
        End Try
    End Sub
    Public Sub ClassListLp()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            dset = New Data.DataSet()
            adapter = New SqlDataAdapter()
            adapter.SelectCommand = New SqlCommand("select distinct room from classroom where Dept='LOWER PRIMARY' order by room asc", ConnectionModule.con)
            dset.Clear()
            adapter.Fill(dset, "classroom")
            cboDesignation.DataSource = dset.Tables("classroom")
            cboDesignation.DisplayMember = "room"
            cboDesignation.Refresh()
            cboDesignation.SelectedIndex = -1
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at get academic year")
            con.Close()
        End Try
    End Sub
    Public Sub ClassListUp()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            dset = New Data.DataSet()
            adapter = New SqlDataAdapter()
            adapter.SelectCommand = New SqlCommand("select distinct room from classroom where Dept='UPPER PRIMARY' order by room asc", ConnectionModule.con)
            dset.Clear()
            adapter.Fill(dset, "classroom")
            cboDesignation.DataSource = dset.Tables("classroom")
            cboDesignation.DisplayMember = "room"
            cboDesignation.Refresh()
            cboDesignation.SelectedIndex = -1
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at get academic year")
            con.Close()
        End Try
    End Sub
    Public Sub ClassListJhs()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            dset = New Data.DataSet()
            adapter = New SqlDataAdapter()
            adapter.SelectCommand = New SqlCommand("select distinct room from classroom where Dept='JUNIOR HIGH SCHOOL' order by room asc", ConnectionModule.con)
            dset.Clear()
            adapter.Fill(dset, "classroom")
            cboDesignation.DataSource = dset.Tables("classroom")
            cboDesignation.DisplayMember = "room"
            cboDesignation.Refresh()
            cboDesignation.SelectedIndex = -1
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at get academic year")
            con.Close()
        End Try
    End Sub

    Private Sub btnAddFile_Click(sender As Object, e As EventArgs) Handles btnAddFile.Click
        'OpenFileDialog1.ShowDialog()
        'lblFile.Text = OpenFileDialog1.FileName
        opfile.Filter = "Choose document(*.doc;*.pdf;*.docx)|*.docx;*.pdf;'.docx"
        opfile.Title = "Add CV/Resume"
        opfile.Multiselect = False
        If opfile.ShowDialog = Windows.Forms.DialogResult.OK Then
            lblFile.Text = opfile.FileName
        End If
    End Sub

    Private Sub btnHelp_Click(sender As Object, e As EventArgs) Handles btnHelp.Click
        Try
            
        Catch ex As Exception

        End Try

    End Sub

    Private Sub cboDesignation_DropDown(sender As Object, e As EventArgs) Handles cboDesignation.DropDown
        If cboSaffdepartment.Text = "ADMINISTRATION" Then
            cboDesignation.ResetText()
            GetTypes_Administration()
            Exit Sub
        ElseIf cboSaffdepartment.Text = "OTHER SERVICES" Then
            cboDesignation.ResetText()
            GetTypes_OtherServices()
            Exit Sub
        ElseIf cboSaffdepartment.Text = "KINDERGARTEN" Then
            cboDesignation.ResetText()
            ClassListKg()
            Exit Sub
        ElseIf cboSaffdepartment.Text = "LOWER PRIMARY" Then
            cboDesignation.ResetText()
            ClassListLp()
            Exit Sub
        ElseIf cboSaffdepartment.Text = "UPPER PRIMARY" Then
            cboDesignation.ResetText()
            ClassListUp()
            Exit Sub
        ElseIf cboSaffdepartment.Text = "JUNIOR HIGH SCHOOL" Then
            cboDesignation.ResetText()
            ClassListJhs()
            Exit Sub
        End If
    End Sub

    Private Sub GetTypes_Administration()
        Try
            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            dset = New Data.DataSet()
            adapter = New SqlDataAdapter()
            adapter.SelectCommand = New SqlCommand("select name from tbladministration order by adid asc", ConnectionModule.con)
            dset.Clear()
            adapter.Fill(dset, "tbladministration")
            cboDesignation.DataSource = dset.Tables("tbladministration")
            cboDesignation.DisplayMember = "name"
            cboDesignation.Refresh()
            cboDesignation.SelectedIndex = -1
        Catch ex As Exception
            MessageBox.Show(ex.Message(), "error at get administration")
            con.Close()
        End Try
    End Sub
    Private Sub GetTypes_OtherServices()
        Try
            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            dset = New Data.DataSet()
            adapter = New SqlDataAdapter()
            adapter.SelectCommand = New SqlCommand("select name from tblotherservices order by osid asc", ConnectionModule.con)
            dset.Clear()
            adapter.Fill(dset, "tblotherservices")
            cboDesignation.DataSource = dset.Tables("tblotherservices")
            cboDesignation.DisplayMember = "name"
            cboDesignation.Refresh()
            cboDesignation.SelectedIndex = -1
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at get otherservices")
            con.Close()
        End Try
    End Sub
    Private Sub GetPortfolio()
        Try
            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            dset = New Data.DataSet()
            adapter = New SqlDataAdapter()
            adapter.SelectCommand = New SqlCommand("select name from tblportfolio order by name asc", ConnectionModule.con)
            dset.Clear()
            adapter.Fill(dset, "tblportfolio")
            cboDesignation.DataSource = dset.Tables("tblportfolio")
            cboDesignation.DisplayMember = "name"
            cboDesignation.Refresh()
            cboDesignation.SelectedIndex = -1
        Catch ex As Exception
            MessageBox.Show(ex.Message(), "error at portfolio")
            con.Close()
        End Try
    End Sub


    Private Sub cboDesignation_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboDesignation.SelectedIndexChanged

    End Sub

    Private Sub GroupBox3_Enter(sender As Object, e As EventArgs) Handles GroupBox3.Enter

    End Sub

    Private Sub cboPortfolio_DropDown(sender As Object, e As EventArgs) Handles cboPortfolio.DropDown
        GetPortfolio()
    End Sub

    Private Sub cboPortfolio_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboPortfolio.SelectedIndexChanged

    End Sub
End Class