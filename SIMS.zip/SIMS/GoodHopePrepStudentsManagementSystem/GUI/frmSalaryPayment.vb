﻿Imports System.Data.SqlClient

Public Class frmSalaryPayment

    Dim paid As String = "Yes"

    Private Sub txtCode_TextChanged(sender As Object, e As EventArgs) Handles txtCode.TextChanged
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            com1 = New SqlCommand("SELECT * from vwStaffJobDetails1 where StaffCode='" & Me.txtCode.Text & "'", ConnectionModule.con)
            dr = com1.ExecuteReader(CommandBehavior.CloseConnection)
            If (dr.Read()) Then
                txtSID.Text = dr.GetValue(0)
                txtTitle.Text = dr.GetValue(6)
                txtName.Text = dr.GetValue(2) + " " + dr.GetValue(3) + " " + dr.GetValue(4)
                txtGender.Text = dr.GetValue(5)
                txtPhone.Text = dr.GetValue(7)
                txtBackground.Text = dr.GetValue(8)
                txtQualification.Text = dr.GetValue(9)
                txtCategory.Text = dr.GetValue(10)
                txtDept.Text = dr.GetValue(11)
                txtJob.Text = dr.GetValue(12)
                txtStatus.Text = dr.GetValue(15)
                txtBasicSalary.Text = dr.GetValue(17)
            End If
            com1.Dispose()

        Catch ex As Exception
            MsgBox(ex.Message)
            con.Close()
        End Try
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub

    Sub Clearme()
        txtSID.Clear()
        txtName.Clear()
        txtGender.Clear()
        txtJob.Clear()
        txtPhone.Clear()
        txtQualification.Clear()
        txtBackground.Clear()
        txtCategory.Clear()
        txtCode.Clear()
        txtDept.Clear()
        txtTitle.Clear()
        txtStatus.Clear()
        txtBasicSalary.Clear()
        cboMonth.ResetText()
        txtYear.Clear()
        txtSalary.Clear()
        cboTerm.ResetText()
        txtCode.Focus()
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        Clearme()
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        If txtCode.Text = "" Then MsgBox("Enter Staff Code", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "SIMS") : txtCode.Focus() : Exit Sub
        If txtYear.Text = "" Then MsgBox("Enter year", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "SIMS") : txtYear.Focus() : Exit Sub
        If cboTerm.Text = "" Then MsgBox("Select term", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "SIMS") : Exit Sub
        If cboMonth.Text = "" Then MsgBox("Select month of payment", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "SIMS") : Exit Sub
        If txtSalary.Text = "" Then MsgBox("Enter salary amount", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "SIMS") : txtSalary.Focus() : Exit Sub
        If Not IsNumeric(txtYear.Text) Then MsgBox("Year should be numeric/figures. eg. (2010)", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "SIMS") : txtYear.Focus() : txtYear.SelectAll() : Exit Sub
        If Not IsNumeric(txtSalary.Text) Then MsgBox("Salary should be figures.", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "SIMS") : txtSalary.Focus() : txtSalary.SelectAll() : Exit Sub
        If Val(txtSalary.Text > Val(txtBasicSalary.Text)) Then MsgBox("Payment amount cannot be more than 'Basic Salary' of staff", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "SIMS") : txtSalary.SelectAll() : txtBasicSalary.SelectAll() : Exit Sub
        If Val(txtSalary.Text < Val(txtBasicSalary.Text)) Then MsgBox("Payment amount cannot be less than 'Basic Salary' of staff", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "SIMS") : txtSalary.SelectAll() : txtBasicSalary.SelectAll() : Exit Sub
        If txtStatus.Text = "INACTIVE" Then MsgBox("Staff status is currently 'INACTIVE', Cannot continue payment", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "SIMS") : Exit Sub

        If MsgBox("Do you really want to save this payment record", MsgBoxStyle.YesNo + MsgBoxStyle.Question, "SIMS") = MsgBoxResult.Yes Then
            Try
                If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                ConnectionModule.con.Open()
                com = New SqlCommand("insert into SalaryPayment(StaffID,Year,Month,Salary,DatePaid,IsPaid,Term) values(@d1,@d2,@d3,@d4,@d5, '" & paid & "', @d6)", ConnectionModule.con)
                com.Parameters.AddWithValue("@d1", txtSID.Text)
                com.Parameters.AddWithValue("@d2", txtYear.Text)
                com.Parameters.AddWithValue("@d3", cboMonth.SelectedItem)
                com.Parameters.AddWithValue("@d4", Val(txtSalary.Text))
                com.Parameters.AddWithValue("@d5", Date.Now)
                com.Parameters.AddWithValue("@d6", cboTerm.Text)
                com.ExecuteNonQuery()
                MessageBox.Show("Payment Successfully Saved!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                ' Clearme()
                btnClear_Click(sender, e)

            Catch ex As Exception
                MessageBox.Show(ex.Message)
            Finally
                con.Close()
            End Try

        End If
    End Sub

  
    Private Sub txtPhone_TextChanged(sender As Object, e As EventArgs) Handles txtPhone.TextChanged

    End Sub


    Public Sub AddTerm()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            dset = New Data.DataSet()
            adapter = New SqlDataAdapter()
            adapter.SelectCommand = New SqlCommand("select ID,Term from Term order by Term", ConnectionModule.con)
            dset.Clear()
            adapter.Fill(dset, "Term")
            cboTerm.DataSource = dset.Tables("Term")
            cboTerm.DisplayMember = "Term"
            cboTerm.ValueMember = "ID"
            cboTerm.Refresh()
            cboTerm.SelectedIndex = -1
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at add term info")
            con.Close()
        End Try
    End Sub


    Private Sub frmSalaryPayment_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Me.Text = Me.Text + "-[Current User: " + frmLog.Logname.Trim() + "]"

    End Sub

    Private Sub cboTerm_DragDrop(sender As Object, e As DragEventArgs) Handles cboTerm.DragDrop
        AddTerm()
    End Sub
End Class