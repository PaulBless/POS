﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class NewStaffRegistration
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(NewStaffRegistration))
        Me.gbostaffinfo = New System.Windows.Forms.GroupBox()
        Me.cbostaffreligion = New System.Windows.Forms.ComboBox()
        Me.lblregion = New System.Windows.Forms.Label()
        Me.txtStaffaddress = New System.Windows.Forms.TextBox()
        Me.lbl_StaffAddress = New System.Windows.Forms.Label()
        Me.gbopictureupload = New System.Windows.Forms.GroupBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.btnClearStaffpic = New System.Windows.Forms.Button()
        Me.btnUploadStaffpic = New System.Windows.Forms.Button()
        Me.pboStaffimage = New System.Windows.Forms.PictureBox()
        Me.lbl_StaffReligion = New System.Windows.Forms.Label()
        Me.txtstaffage = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.txthouseno = New System.Windows.Forms.TextBox()
        Me.lbl_StaffHouseno = New System.Windows.Forms.Label()
        Me.dtpStaff = New System.Windows.Forms.DateTimePicker()
        Me.lbl_StaffDOB = New System.Windows.Forms.Label()
        Me.txtStaffemail = New System.Windows.Forms.TextBox()
        Me.lbl_StaffEmail = New System.Windows.Forms.Label()
        Me.txtStaffphone = New System.Windows.Forms.TextBox()
        Me.lbl_StaffMobileno = New System.Windows.Forms.Label()
        Me.cboStaffmaritalstatus = New System.Windows.Forms.ComboBox()
        Me.lbl_StaffMaritalStatus = New System.Windows.Forms.Label()
        Me.cboStafftitle = New System.Windows.Forms.ComboBox()
        Me.lbl_StaffTitle = New System.Windows.Forms.Label()
        Me.cboStaffgender = New System.Windows.Forms.ComboBox()
        Me.lbl_StaffGender = New System.Windows.Forms.Label()
        Me.cboStaffregion = New System.Windows.Forms.ComboBox()
        Me.cboStaffnationality = New System.Windows.Forms.ComboBox()
        Me.lbl_StaffNationality = New System.Windows.Forms.Label()
        Me.txtStaffbirthplace = New System.Windows.Forms.TextBox()
        Me.lbl_StaffBirthplace = New System.Windows.Forms.Label()
        Me.txtStaffhometown = New System.Windows.Forms.TextBox()
        Me.lbl_StaffHometown = New System.Windows.Forms.Label()
        Me.txtStaffmiddlename = New System.Windows.Forms.TextBox()
        Me.txtStafffirstname = New System.Windows.Forms.TextBox()
        Me.txtStaffsurname = New System.Windows.Forms.TextBox()
        Me.lbl_StaffFirstname = New System.Windows.Forms.Label()
        Me.lbl_StaffMiddlename = New System.Windows.Forms.Label()
        Me.lbl_StaffSurname = New System.Windows.Forms.Label()
        Me.gbocontactinfo = New System.Windows.Forms.GroupBox()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.cboContactoccupation = New System.Windows.Forms.ComboBox()
        Me.txtContacthouse = New System.Windows.Forms.TextBox()
        Me.lbl_Staffcontactno = New System.Windows.Forms.Label()
        Me.lbl_StaffOccup = New System.Windows.Forms.Label()
        Me.txlocality = New System.Windows.Forms.TextBox()
        Me.lbl_Staffcontown = New System.Windows.Forms.Label()
        Me.txtContactphone = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lbl_Staffconphone = New System.Windows.Forms.Label()
        Me.txtContactname = New System.Windows.Forms.TextBox()
        Me.lbl_StaffConName = New System.Windows.Forms.Label()
        Me.gbonextofkininfo = New System.Windows.Forms.GroupBox()
        Me.cbostaffrel = New System.Windows.Forms.ComboBox()
        Me.lbl_Staffnextrel = New System.Windows.Forms.Label()
        Me.txtNextkinno = New System.Windows.Forms.TextBox()
        Me.lbl_Staffnextno = New System.Windows.Forms.Label()
        Me.txtNextofkin = New System.Windows.Forms.TextBox()
        Me.lbl_Staffnextkin = New System.Windows.Forms.Label()
        Me.gbojobdetails = New System.Windows.Forms.GroupBox()
        Me.cbostaffjob = New System.Windows.Forms.ComboBox()
        Me.cboSaffdepartment = New System.Windows.Forms.ComboBox()
        Me.txtStaffSsnit = New System.Windows.Forms.TextBox()
        Me.lbl_Staffssnit = New System.Windows.Forms.Label()
        Me.lbl_Staffdepartment = New System.Windows.Forms.Label()
        Me.lbl_Staffjob = New System.Windows.Forms.Label()
        Me.cboStaffcategory = New System.Windows.Forms.ComboBox()
        Me.cboStaffqualification = New System.Windows.Forms.ComboBox()
        Me.lbl_Staffcategory = New System.Windows.Forms.Label()
        Me.lbl_Staffqualification = New System.Windows.Forms.Label()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.b = New System.Windows.Forms.Button()
        Me.btnClearStaff = New System.Windows.Forms.Button()
        Me.btnFindStaff = New System.Windows.Forms.Button()
        Me.btnSaveStaff = New System.Windows.Forms.Button()
        Me.gbostaffinfo.SuspendLayout()
        Me.gbopictureupload.SuspendLayout()
        CType(Me.pboStaffimage, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gbocontactinfo.SuspendLayout()
        Me.gbonextofkininfo.SuspendLayout()
        Me.gbojobdetails.SuspendLayout()
        Me.SuspendLayout()
        '
        'gbostaffinfo
        '
        Me.gbostaffinfo.Controls.Add(Me.cbostaffreligion)
        Me.gbostaffinfo.Controls.Add(Me.lblregion)
        Me.gbostaffinfo.Controls.Add(Me.txtStaffaddress)
        Me.gbostaffinfo.Controls.Add(Me.lbl_StaffAddress)
        Me.gbostaffinfo.Controls.Add(Me.gbopictureupload)
        Me.gbostaffinfo.Controls.Add(Me.lbl_StaffReligion)
        Me.gbostaffinfo.Controls.Add(Me.txtstaffage)
        Me.gbostaffinfo.Controls.Add(Me.Label13)
        Me.gbostaffinfo.Controls.Add(Me.txthouseno)
        Me.gbostaffinfo.Controls.Add(Me.lbl_StaffHouseno)
        Me.gbostaffinfo.Controls.Add(Me.dtpStaff)
        Me.gbostaffinfo.Controls.Add(Me.lbl_StaffDOB)
        Me.gbostaffinfo.Controls.Add(Me.txtStaffemail)
        Me.gbostaffinfo.Controls.Add(Me.lbl_StaffEmail)
        Me.gbostaffinfo.Controls.Add(Me.txtStaffphone)
        Me.gbostaffinfo.Controls.Add(Me.lbl_StaffMobileno)
        Me.gbostaffinfo.Controls.Add(Me.cboStaffmaritalstatus)
        Me.gbostaffinfo.Controls.Add(Me.lbl_StaffMaritalStatus)
        Me.gbostaffinfo.Controls.Add(Me.cboStafftitle)
        Me.gbostaffinfo.Controls.Add(Me.lbl_StaffTitle)
        Me.gbostaffinfo.Controls.Add(Me.cboStaffgender)
        Me.gbostaffinfo.Controls.Add(Me.lbl_StaffGender)
        Me.gbostaffinfo.Controls.Add(Me.cboStaffregion)
        Me.gbostaffinfo.Controls.Add(Me.cboStaffnationality)
        Me.gbostaffinfo.Controls.Add(Me.lbl_StaffNationality)
        Me.gbostaffinfo.Controls.Add(Me.txtStaffbirthplace)
        Me.gbostaffinfo.Controls.Add(Me.lbl_StaffBirthplace)
        Me.gbostaffinfo.Controls.Add(Me.txtStaffhometown)
        Me.gbostaffinfo.Controls.Add(Me.lbl_StaffHometown)
        Me.gbostaffinfo.Controls.Add(Me.txtStaffmiddlename)
        Me.gbostaffinfo.Controls.Add(Me.txtStafffirstname)
        Me.gbostaffinfo.Controls.Add(Me.txtStaffsurname)
        Me.gbostaffinfo.Controls.Add(Me.lbl_StaffFirstname)
        Me.gbostaffinfo.Controls.Add(Me.lbl_StaffMiddlename)
        Me.gbostaffinfo.Controls.Add(Me.lbl_StaffSurname)
        Me.gbostaffinfo.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold)
        Me.gbostaffinfo.Location = New System.Drawing.Point(5, 12)
        Me.gbostaffinfo.Name = "gbostaffinfo"
        Me.gbostaffinfo.Size = New System.Drawing.Size(1098, 296)
        Me.gbostaffinfo.TabIndex = 0
        Me.gbostaffinfo.TabStop = False
        Me.gbostaffinfo.Text = "PERSONAL INFORMATION"
        '
        'cbostaffreligion
        '
        Me.cbostaffreligion.AutoCompleteCustomSource.AddRange(New String() {"ATHEISM", "BUDHISM", "CHRISTIANITY", "JUDAISM", "ISLAM", "TRADITIONALIST"})
        Me.cbostaffreligion.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.cbostaffreligion.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.cbostaffreligion.BackColor = System.Drawing.Color.White
        Me.cbostaffreligion.DropDownHeight = 50
        Me.cbostaffreligion.DropDownWidth = 50
        Me.cbostaffreligion.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.cbostaffreligion.FormattingEnabled = True
        Me.cbostaffreligion.IntegralHeight = False
        Me.cbostaffreligion.Items.AddRange(New Object() {"CHRISTIANITY", "ISLAM", "TRADITIONALIST"})
        Me.cbostaffreligion.Location = New System.Drawing.Point(653, 238)
        Me.cbostaffreligion.Name = "cbostaffreligion"
        Me.cbostaffreligion.Size = New System.Drawing.Size(179, 23)
        Me.cbostaffreligion.TabIndex = 41
        '
        'lblregion
        '
        Me.lblregion.AutoSize = True
        Me.lblregion.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblregion.Location = New System.Drawing.Point(593, 242)
        Me.lblregion.Name = "lblregion"
        Me.lblregion.Size = New System.Drawing.Size(57, 15)
        Me.lblregion.TabIndex = 40
        Me.lblregion.Text = "Religion :"
        '
        'txtStaffaddress
        '
        Me.txtStaffaddress.BackColor = System.Drawing.Color.White
        Me.txtStaffaddress.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtStaffaddress.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.txtStaffaddress.Location = New System.Drawing.Point(391, 226)
        Me.txtStaffaddress.Multiline = True
        Me.txtStaffaddress.Name = "txtStaffaddress"
        Me.txtStaffaddress.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtStaffaddress.Size = New System.Drawing.Size(179, 45)
        Me.txtStaffaddress.TabIndex = 39
        '
        'lbl_StaffAddress
        '
        Me.lbl_StaffAddress.AutoSize = True
        Me.lbl_StaffAddress.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaffAddress.Location = New System.Drawing.Point(311, 241)
        Me.lbl_StaffAddress.Name = "lbl_StaffAddress"
        Me.lbl_StaffAddress.Size = New System.Drawing.Size(59, 15)
        Me.lbl_StaffAddress.TabIndex = 38
        Me.lbl_StaffAddress.Text = "Address :"
        '
        'gbopictureupload
        '
        Me.gbopictureupload.Controls.Add(Me.TextBox1)
        Me.gbopictureupload.Controls.Add(Me.btnClearStaffpic)
        Me.gbopictureupload.Controls.Add(Me.btnUploadStaffpic)
        Me.gbopictureupload.Controls.Add(Me.pboStaffimage)
        Me.gbopictureupload.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbopictureupload.Location = New System.Drawing.Point(837, 0)
        Me.gbopictureupload.Name = "gbopictureupload"
        Me.gbopictureupload.Size = New System.Drawing.Size(260, 290)
        Me.gbopictureupload.TabIndex = 37
        Me.gbopictureupload.TabStop = False
        Me.gbopictureupload.Text = "Upload Staff Picture"
        '
        'TextBox1
        '
        Me.TextBox1.BackColor = System.Drawing.Color.White
        Me.TextBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox1.Location = New System.Drawing.Point(2, 228)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(255, 21)
        Me.TextBox1.TabIndex = 37
        '
        'btnClearStaffpic
        '
        Me.btnClearStaffpic.BackColor = System.Drawing.Color.LightSkyBlue
        Me.btnClearStaffpic.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnClearStaffpic.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClearStaffpic.ForeColor = System.Drawing.Color.Black
        Me.btnClearStaffpic.Image = CType(resources.GetObject("btnClearStaffpic.Image"), System.Drawing.Image)
        Me.btnClearStaffpic.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnClearStaffpic.Location = New System.Drawing.Point(137, 257)
        Me.btnClearStaffpic.Name = "btnClearStaffpic"
        Me.btnClearStaffpic.Size = New System.Drawing.Size(95, 30)
        Me.btnClearStaffpic.TabIndex = 36
        Me.btnClearStaffpic.Text = "Clear"
        Me.btnClearStaffpic.UseVisualStyleBackColor = False
        '
        'btnUploadStaffpic
        '
        Me.btnUploadStaffpic.BackColor = System.Drawing.Color.LightSkyBlue
        Me.btnUploadStaffpic.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnUploadStaffpic.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnUploadStaffpic.ForeColor = System.Drawing.Color.Black
        Me.btnUploadStaffpic.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnUploadStaffpic.Location = New System.Drawing.Point(32, 257)
        Me.btnUploadStaffpic.Name = "btnUploadStaffpic"
        Me.btnUploadStaffpic.Size = New System.Drawing.Size(95, 30)
        Me.btnUploadStaffpic.TabIndex = 35
        Me.btnUploadStaffpic.Text = "Upload"
        Me.btnUploadStaffpic.UseVisualStyleBackColor = False
        '
        'pboStaffimage
        '
        Me.pboStaffimage.BackColor = System.Drawing.Color.White
        Me.pboStaffimage.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pboStaffimage.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.pboStaffimage.Location = New System.Drawing.Point(32, 16)
        Me.pboStaffimage.Name = "pboStaffimage"
        Me.pboStaffimage.Size = New System.Drawing.Size(200, 199)
        Me.pboStaffimage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pboStaffimage.TabIndex = 22
        Me.pboStaffimage.TabStop = False
        '
        'lbl_StaffReligion
        '
        Me.lbl_StaffReligion.AutoSize = True
        Me.lbl_StaffReligion.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaffReligion.Location = New System.Drawing.Point(12, 242)
        Me.lbl_StaffReligion.Name = "lbl_StaffReligion"
        Me.lbl_StaffReligion.Size = New System.Drawing.Size(51, 15)
        Me.lbl_StaffReligion.TabIndex = 33
        Me.lbl_StaffReligion.Text = "Region :"
        '
        'txtstaffage
        '
        Me.txtstaffage.BackColor = System.Drawing.Color.White
        Me.txtstaffage.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.txtstaffage.Location = New System.Drawing.Point(543, 87)
        Me.txtstaffage.Name = "txtstaffage"
        Me.txtstaffage.Size = New System.Drawing.Size(24, 21)
        Me.txtstaffage.TabIndex = 32
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(516, 90)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(33, 15)
        Me.Label13.TabIndex = 31
        Me.Label13.Text = "Age:"
        '
        'txthouseno
        '
        Me.txthouseno.BackColor = System.Drawing.Color.White
        Me.txthouseno.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txthouseno.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.txthouseno.Location = New System.Drawing.Point(673, 89)
        Me.txthouseno.Name = "txthouseno"
        Me.txthouseno.Size = New System.Drawing.Size(159, 21)
        Me.txthouseno.TabIndex = 30
        '
        'lbl_StaffHouseno
        '
        Me.lbl_StaffHouseno.AutoSize = True
        Me.lbl_StaffHouseno.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaffHouseno.Location = New System.Drawing.Point(616, 90)
        Me.lbl_StaffHouseno.Name = "lbl_StaffHouseno"
        Me.lbl_StaffHouseno.Size = New System.Drawing.Size(55, 15)
        Me.lbl_StaffHouseno.TabIndex = 29
        Me.lbl_StaffHouseno.Text = "House #:"
        '
        'dtpStaff
        '
        Me.dtpStaff.CustomFormat = "dd-MM-yyyy"
        Me.dtpStaff.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.dtpStaff.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpStaff.Location = New System.Drawing.Point(391, 87)
        Me.dtpStaff.MaxDate = New Date(2500, 12, 31, 0, 0, 0, 0)
        Me.dtpStaff.MinDate = New Date(1925, 1, 1, 0, 0, 0, 0)
        Me.dtpStaff.Name = "dtpStaff"
        Me.dtpStaff.ShowCheckBox = True
        Me.dtpStaff.Size = New System.Drawing.Size(123, 21)
        Me.dtpStaff.TabIndex = 28
        '
        'lbl_StaffDOB
        '
        Me.lbl_StaffDOB.AutoSize = True
        Me.lbl_StaffDOB.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaffDOB.Location = New System.Drawing.Point(306, 90)
        Me.lbl_StaffDOB.Name = "lbl_StaffDOB"
        Me.lbl_StaffDOB.Size = New System.Drawing.Size(78, 15)
        Me.lbl_StaffDOB.TabIndex = 27
        Me.lbl_StaffDOB.Text = "Date of Birth:"
        '
        'txtStaffemail
        '
        Me.txtStaffemail.BackColor = System.Drawing.Color.White
        Me.txtStaffemail.CharacterCasing = System.Windows.Forms.CharacterCasing.Lower
        Me.txtStaffemail.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.txtStaffemail.Location = New System.Drawing.Point(672, 136)
        Me.txtStaffemail.Name = "txtStaffemail"
        Me.txtStaffemail.Size = New System.Drawing.Size(159, 21)
        Me.txtStaffemail.TabIndex = 26
        '
        'lbl_StaffEmail
        '
        Me.lbl_StaffEmail.AutoSize = True
        Me.lbl_StaffEmail.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaffEmail.Location = New System.Drawing.Point(585, 140)
        Me.lbl_StaffEmail.Name = "lbl_StaffEmail"
        Me.lbl_StaffEmail.Size = New System.Drawing.Size(86, 15)
        Me.lbl_StaffEmail.TabIndex = 25
        Me.lbl_StaffEmail.Text = "Email Address:"
        '
        'txtStaffphone
        '
        Me.txtStaffphone.BackColor = System.Drawing.Color.White
        Me.txtStaffphone.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtStaffphone.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.txtStaffphone.Location = New System.Drawing.Point(392, 134)
        Me.txtStaffphone.Name = "txtStaffphone"
        Me.txtStaffphone.Size = New System.Drawing.Size(175, 21)
        Me.txtStaffphone.TabIndex = 24
        '
        'lbl_StaffMobileno
        '
        Me.lbl_StaffMobileno.AutoSize = True
        Me.lbl_StaffMobileno.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaffMobileno.Location = New System.Drawing.Point(300, 138)
        Me.lbl_StaffMobileno.Name = "lbl_StaffMobileno"
        Me.lbl_StaffMobileno.Size = New System.Drawing.Size(89, 15)
        Me.lbl_StaffMobileno.TabIndex = 23
        Me.lbl_StaffMobileno.Text = "Phone Number:"
        '
        'cboStaffmaritalstatus
        '
        Me.cboStaffmaritalstatus.AutoCompleteCustomSource.AddRange(New String() {"Attached", "Divorced", "Married", "Single"})
        Me.cboStaffmaritalstatus.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.cboStaffmaritalstatus.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.cboStaffmaritalstatus.BackColor = System.Drawing.Color.White
        Me.cboStaffmaritalstatus.DropDownHeight = 65
        Me.cboStaffmaritalstatus.DropDownWidth = 65
        Me.cboStaffmaritalstatus.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.cboStaffmaritalstatus.FormattingEnabled = True
        Me.cboStaffmaritalstatus.IntegralHeight = False
        Me.cboStaffmaritalstatus.Items.AddRange(New Object() {"Attached", "Divorced", "Married", "Single"})
        Me.cboStaffmaritalstatus.Location = New System.Drawing.Point(726, 36)
        Me.cboStaffmaritalstatus.Name = "cboStaffmaritalstatus"
        Me.cboStaffmaritalstatus.Size = New System.Drawing.Size(106, 23)
        Me.cboStaffmaritalstatus.Sorted = True
        Me.cboStaffmaritalstatus.TabIndex = 21
        '
        'lbl_StaffMaritalStatus
        '
        Me.lbl_StaffMaritalStatus.AutoSize = True
        Me.lbl_StaffMaritalStatus.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaffMaritalStatus.Location = New System.Drawing.Point(639, 42)
        Me.lbl_StaffMaritalStatus.Name = "lbl_StaffMaritalStatus"
        Me.lbl_StaffMaritalStatus.Size = New System.Drawing.Size(85, 15)
        Me.lbl_StaffMaritalStatus.TabIndex = 20
        Me.lbl_StaffMaritalStatus.Text = "Marital Status:"
        '
        'cboStafftitle
        '
        Me.cboStafftitle.AutoCompleteCustomSource.AddRange(New String() {"Miss", "Mr", "Mrs"})
        Me.cboStafftitle.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.cboStafftitle.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.cboStafftitle.BackColor = System.Drawing.Color.White
        Me.cboStafftitle.DropDownHeight = 50
        Me.cboStafftitle.DropDownWidth = 50
        Me.cboStafftitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.cboStafftitle.FormattingEnabled = True
        Me.cboStafftitle.IntegralHeight = False
        Me.cboStafftitle.Items.AddRange(New Object() {"Hajia", "Mr", "Miss", "Mrs"})
        Me.cboStafftitle.Location = New System.Drawing.Point(550, 36)
        Me.cboStafftitle.Name = "cboStafftitle"
        Me.cboStafftitle.Size = New System.Drawing.Size(73, 23)
        Me.cboStafftitle.TabIndex = 19
        '
        'lbl_StaffTitle
        '
        Me.lbl_StaffTitle.AutoSize = True
        Me.lbl_StaffTitle.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaffTitle.Location = New System.Drawing.Point(515, 42)
        Me.lbl_StaffTitle.Name = "lbl_StaffTitle"
        Me.lbl_StaffTitle.Size = New System.Drawing.Size(34, 15)
        Me.lbl_StaffTitle.TabIndex = 18
        Me.lbl_StaffTitle.Text = "Title:"
        '
        'cboStaffgender
        '
        Me.cboStaffgender.AutoCompleteCustomSource.AddRange(New String() {"FEMALE", "MALE"})
        Me.cboStaffgender.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.cboStaffgender.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.cboStaffgender.BackColor = System.Drawing.Color.White
        Me.cboStaffgender.DropDownHeight = 35
        Me.cboStaffgender.DropDownWidth = 35
        Me.cboStaffgender.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.cboStaffgender.FormattingEnabled = True
        Me.cboStaffgender.IntegralHeight = False
        Me.cboStaffgender.Items.AddRange(New Object() {"FEMALE", "MALE"})
        Me.cboStaffgender.Location = New System.Drawing.Point(391, 36)
        Me.cboStaffgender.Name = "cboStaffgender"
        Me.cboStaffgender.Size = New System.Drawing.Size(111, 23)
        Me.cboStaffgender.TabIndex = 17
        '
        'lbl_StaffGender
        '
        Me.lbl_StaffGender.AutoSize = True
        Me.lbl_StaffGender.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaffGender.Location = New System.Drawing.Point(328, 40)
        Me.lbl_StaffGender.Name = "lbl_StaffGender"
        Me.lbl_StaffGender.Size = New System.Drawing.Size(48, 15)
        Me.lbl_StaffGender.TabIndex = 16
        Me.lbl_StaffGender.Text = "Gender:"
        '
        'cboStaffregion
        '
        Me.cboStaffregion.AutoCompleteCustomSource.AddRange(New String() {"AMERICAN", "BURKINABE", "CHINESE", "GHANAIAN", "IVORIAN", "JAPANESE", "NIGERIAN", "TOGOLESE", "SOUTH AFRICAN", "OTHER "})
        Me.cboStaffregion.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.cboStaffregion.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.cboStaffregion.BackColor = System.Drawing.Color.White
        Me.cboStaffregion.DropDownHeight = 35
        Me.cboStaffregion.DropDownWidth = 35
        Me.cboStaffregion.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.cboStaffregion.FormattingEnabled = True
        Me.cboStaffregion.IntegralHeight = False
        Me.cboStaffregion.Items.AddRange(New Object() {"ASHANTI", "BRONG AHAFO", "CENTRAL", "EASTERN", "GREATER ACCRA", "NORTHERN", "UPPER EAST", "UPPER WEST", "VOLTA", "WESTERN"})
        Me.cboStaffregion.Location = New System.Drawing.Point(98, 237)
        Me.cboStaffregion.Name = "cboStaffregion"
        Me.cboStaffregion.Size = New System.Drawing.Size(179, 23)
        Me.cboStaffregion.Sorted = True
        Me.cboStaffregion.TabIndex = 15
        '
        'cboStaffnationality
        '
        Me.cboStaffnationality.AutoCompleteCustomSource.AddRange(New String() {"AMERICAN", "BURKINABE", "CHINESE", "GHANAIAN", "IVORIAN", "JAPANESE", "NIGERIAN", "TOGOLESE", "SOUTH AFRICAN", "OTHER "})
        Me.cboStaffnationality.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.cboStaffnationality.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.cboStaffnationality.BackColor = System.Drawing.Color.White
        Me.cboStaffnationality.DropDownHeight = 35
        Me.cboStaffnationality.DropDownWidth = 35
        Me.cboStaffnationality.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.cboStaffnationality.FormattingEnabled = True
        Me.cboStaffnationality.IntegralHeight = False
        Me.cboStaffnationality.Items.AddRange(New Object() {"GHANAIAN", "NON-GHANAIAN"})
        Me.cboStaffnationality.Location = New System.Drawing.Point(98, 187)
        Me.cboStaffnationality.Name = "cboStaffnationality"
        Me.cboStaffnationality.Size = New System.Drawing.Size(179, 23)
        Me.cboStaffnationality.TabIndex = 15
        '
        'lbl_StaffNationality
        '
        Me.lbl_StaffNationality.AutoSize = True
        Me.lbl_StaffNationality.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaffNationality.Location = New System.Drawing.Point(12, 191)
        Me.lbl_StaffNationality.Name = "lbl_StaffNationality"
        Me.lbl_StaffNationality.Size = New System.Drawing.Size(72, 15)
        Me.lbl_StaffNationality.TabIndex = 11
        Me.lbl_StaffNationality.Text = "Nationality :"
        '
        'txtStaffbirthplace
        '
        Me.txtStaffbirthplace.BackColor = System.Drawing.Color.White
        Me.txtStaffbirthplace.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtStaffbirthplace.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.txtStaffbirthplace.Location = New System.Drawing.Point(673, 187)
        Me.txtStaffbirthplace.Name = "txtStaffbirthplace"
        Me.txtStaffbirthplace.Size = New System.Drawing.Size(159, 21)
        Me.txtStaffbirthplace.TabIndex = 10
        '
        'lbl_StaffBirthplace
        '
        Me.lbl_StaffBirthplace.AutoSize = True
        Me.lbl_StaffBirthplace.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaffBirthplace.Location = New System.Drawing.Point(588, 191)
        Me.lbl_StaffBirthplace.Name = "lbl_StaffBirthplace"
        Me.lbl_StaffBirthplace.Size = New System.Drawing.Size(83, 15)
        Me.lbl_StaffBirthplace.TabIndex = 9
        Me.lbl_StaffBirthplace.Text = "Place Of Birth:"
        '
        'txtStaffhometown
        '
        Me.txtStaffhometown.BackColor = System.Drawing.Color.White
        Me.txtStaffhometown.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtStaffhometown.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.txtStaffhometown.Location = New System.Drawing.Point(391, 188)
        Me.txtStaffhometown.Name = "txtStaffhometown"
        Me.txtStaffhometown.Size = New System.Drawing.Size(176, 21)
        Me.txtStaffhometown.TabIndex = 8
        '
        'lbl_StaffHometown
        '
        Me.lbl_StaffHometown.AutoSize = True
        Me.lbl_StaffHometown.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaffHometown.Location = New System.Drawing.Point(310, 191)
        Me.lbl_StaffHometown.Name = "lbl_StaffHometown"
        Me.lbl_StaffHometown.Size = New System.Drawing.Size(77, 15)
        Me.lbl_StaffHometown.TabIndex = 7
        Me.lbl_StaffHometown.Text = "Home Town :"
        '
        'txtStaffmiddlename
        '
        Me.txtStaffmiddlename.BackColor = System.Drawing.Color.White
        Me.txtStaffmiddlename.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtStaffmiddlename.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.txtStaffmiddlename.Location = New System.Drawing.Point(98, 136)
        Me.txtStaffmiddlename.Name = "txtStaffmiddlename"
        Me.txtStaffmiddlename.Size = New System.Drawing.Size(179, 21)
        Me.txtStaffmiddlename.TabIndex = 6
        '
        'txtStafffirstname
        '
        Me.txtStafffirstname.BackColor = System.Drawing.Color.White
        Me.txtStafffirstname.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtStafffirstname.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.txtStafffirstname.Location = New System.Drawing.Point(98, 86)
        Me.txtStafffirstname.Name = "txtStafffirstname"
        Me.txtStafffirstname.Size = New System.Drawing.Size(179, 21)
        Me.txtStafffirstname.TabIndex = 5
        '
        'txtStaffsurname
        '
        Me.txtStaffsurname.BackColor = System.Drawing.Color.White
        Me.txtStaffsurname.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtStaffsurname.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.txtStaffsurname.Location = New System.Drawing.Point(98, 38)
        Me.txtStaffsurname.Name = "txtStaffsurname"
        Me.txtStaffsurname.Size = New System.Drawing.Size(179, 21)
        Me.txtStaffsurname.TabIndex = 4
        '
        'lbl_StaffFirstname
        '
        Me.lbl_StaffFirstname.AutoSize = True
        Me.lbl_StaffFirstname.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaffFirstname.Location = New System.Drawing.Point(12, 90)
        Me.lbl_StaffFirstname.Name = "lbl_StaffFirstname"
        Me.lbl_StaffFirstname.Size = New System.Drawing.Size(70, 15)
        Me.lbl_StaffFirstname.TabIndex = 3
        Me.lbl_StaffFirstname.Text = "First Name :"
        '
        'lbl_StaffMiddlename
        '
        Me.lbl_StaffMiddlename.AutoSize = True
        Me.lbl_StaffMiddlename.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaffMiddlename.Location = New System.Drawing.Point(12, 140)
        Me.lbl_StaffMiddlename.Name = "lbl_StaffMiddlename"
        Me.lbl_StaffMiddlename.Size = New System.Drawing.Size(84, 15)
        Me.lbl_StaffMiddlename.TabIndex = 2
        Me.lbl_StaffMiddlename.Text = "Middle Name :"
        '
        'lbl_StaffSurname
        '
        Me.lbl_StaffSurname.AutoSize = True
        Me.lbl_StaffSurname.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaffSurname.Location = New System.Drawing.Point(12, 42)
        Me.lbl_StaffSurname.Name = "lbl_StaffSurname"
        Me.lbl_StaffSurname.Size = New System.Drawing.Size(59, 15)
        Me.lbl_StaffSurname.TabIndex = 1
        Me.lbl_StaffSurname.Text = "Surname :"
        '
        'gbocontactinfo
        '
        Me.gbocontactinfo.Controls.Add(Me.ComboBox1)
        Me.gbocontactinfo.Controls.Add(Me.cboContactoccupation)
        Me.gbocontactinfo.Controls.Add(Me.txtContacthouse)
        Me.gbocontactinfo.Controls.Add(Me.lbl_Staffcontactno)
        Me.gbocontactinfo.Controls.Add(Me.lbl_StaffOccup)
        Me.gbocontactinfo.Controls.Add(Me.txlocality)
        Me.gbocontactinfo.Controls.Add(Me.lbl_Staffcontown)
        Me.gbocontactinfo.Controls.Add(Me.txtContactphone)
        Me.gbocontactinfo.Controls.Add(Me.Label1)
        Me.gbocontactinfo.Controls.Add(Me.lbl_Staffconphone)
        Me.gbocontactinfo.Controls.Add(Me.txtContactname)
        Me.gbocontactinfo.Controls.Add(Me.lbl_StaffConName)
        Me.gbocontactinfo.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold)
        Me.gbocontactinfo.Location = New System.Drawing.Point(5, 312)
        Me.gbocontactinfo.Name = "gbocontactinfo"
        Me.gbocontactinfo.Size = New System.Drawing.Size(1096, 98)
        Me.gbocontactinfo.TabIndex = 1
        Me.gbocontactinfo.TabStop = False
        Me.gbocontactinfo.Text = "CONTACT INFORMATION"
        '
        'ComboBox1
        '
        Me.ComboBox1.AutoCompleteCustomSource.AddRange(New String() {"ACCOUNTANT", "APPRENTICE", "ARCHITECT", "ARMY OFFICER", "ARTISAN", "ASSEMBLYMAN", "AUDITOR", "BAKER", "BANKER", "BEAUTY PRACTITIONER", "BUSINESSMAN", "BUSINESS ANALYST", "CARPENTOR", "CATERER", "CHEF", "CIVIL SERVANT", "CLERGY", "COMPUTER SCIENTIST", "CONSTRUCTION ENGINEER", "DATABASE ADMINISTRATOR", "DESIGNER", "DISPENSING ASSISTANT", "DOCTOR", "DRIVER", "ELECTRICIAN", "FARMER", "FASHION DESIGNER", "FISHERMAN", "FISH MONGER", "FOOD VENDOR", "FOOTBALLER", "FOREIGN DIPLOMAT", "HAIR DRESSER", "HEALTH AID ", "HOUSE WIFE", "IMMIGRATION OFFICER", "LABOURER", "LAWYER", "LEGAL PRACTITIONER", "MASON", "MATRON", "MEDICAL PRACTITIONER", "MINER", "MINING ENGINEER", "MUSICIAN", "NETWORK ADMINISTRATOR", "NETWORK ENGINEER", "NURSE", "OTHER", "PAINTER", "PASTOR", "PENSIONER", "PHARMACIST", "PHARMACY TECHNICIAN", "POLICE OFFICER", "PROGRAMMER", "PUBLIC SERVANT", "RADIO PRESENTER", "REAL ESTATE AGENT", "RECEPTIONIST", "SALES PERSON", "SEAMSTRESS", "SECRETARY", "SECURITY", "STATE MINSTER", "STOCK BROKER", "STORE KEEPER", "SYSTEM ADMINISTRATOR", "TAILOR", "TEACHER", "TRADER", "TRAVEL AGENT", "TYPIST", "UNEMPLOYED"})
        Me.ComboBox1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.ComboBox1.BackColor = System.Drawing.Color.White
        Me.ComboBox1.DropDownHeight = 105
        Me.ComboBox1.DropDownWidth = 105
        Me.ComboBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.IntegralHeight = False
        Me.ComboBox1.Items.AddRange(New Object() {"ACCOUNTANT", "APPRENTICE", "ARCHITECT", "ARMY OFFICER", "ARTISAN", "ASSEMBLYMAN", "AUDITOR", "BAKER", "BANKER", "BEAUTY PRACTITIONER", "BUSINESS ANALYST", "BUSINESSMAN", "CARPENTOR", "CATERER", "CHEF", "CIVIL SERVANT", "CLERGY", "COMPUTER SCIENTIST", "CONSTRUCTION ENGINEER", "DATABASE ADMINISTRATOR", "DESIGNER", "DISPENSING ASSISTANT", "DOCTOR", "DRIVER", "ELECTRICIAN", "FARMER", "FASHION DESIGNER", "FISH MONGER", "FISHERMAN", "FOOD VENDOR", "FOOTBALLER", "FOREIGN DIPLOMAT", "HAIR DRESSER", "HEALTH AID ", "HOUSE WIFE", "IMMIGRATION OFFICER", "LABOURER", "LAWYER", "LEGAL PRACTITIONER", "MASON", "MATRON", "MEDICAL PRACTITIONER", "MINER", "MINING ENGINEER", "MUSICIAN", "NETWORK ADMINISTRATOR", "NETWORK ENGINEER", "NURSE", "OTHER", "PAINTER", "PASTOR", "PENSIONER", "PHARMACIST", "PHARMACY TECHNICIAN", "POLICE OFFICER", "PROGRAMMER", "PUBLIC SERVANT", "RADIO PRESENTER", "REAL ESTATE AGENT", "RECEPTIONIST", "SALES PERSON", "SEAMSTRESS", "SECRETARY", "SECURITY", "STATE MINSTER", "STOCK BROKER", "STORE KEEPER", "SYSTEM ADMINISTRATOR", "TAILOR", "TEACHER", "TRADER", "TRAVEL AGENT", "TYPIST", "UNEMPLOYED"})
        Me.ComboBox1.Location = New System.Drawing.Point(500, 65)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(215, 23)
        Me.ComboBox1.Sorted = True
        Me.ComboBox1.TabIndex = 35
        '
        'cboContactoccupation
        '
        Me.cboContactoccupation.AutoCompleteCustomSource.AddRange(New String() {"ACCOUNTANT", "APPRENTICE", "ARCHITECT", "ARMY OFFICER", "ARTISAN", "ASSEMBLYMAN", "AUDITOR", "BAKER", "BANKER", "BEAUTY PRACTITIONER", "BUSINESSMAN", "BUSINESS ANALYST", "CARPENTOR", "CATERER", "CHEF", "CIVIL SERVANT", "CLERGY", "COMPUTER SCIENTIST", "CONSTRUCTION ENGINEER", "DATABASE ADMINISTRATOR", "DESIGNER", "DISPENSING ASSISTANT", "DOCTOR", "DRIVER", "ELECTRICIAN", "FARMER", "FASHION DESIGNER", "FISHERMAN", "FISH MONGER", "FOOD VENDOR", "FOOTBALLER", "FOREIGN DIPLOMAT", "HAIR DRESSER", "HEALTH AID ", "HOUSE WIFE", "IMMIGRATION OFFICER", "LABOURER", "LAWYER", "LEGAL PRACTITIONER", "MASON", "MATRON", "MEDICAL PRACTITIONER", "MINER", "MINING ENGINEER", "MUSICIAN", "NETWORK ADMINISTRATOR", "NETWORK ENGINEER", "NURSE", "OTHER", "PAINTER", "PASTOR", "PENSIONER", "PHARMACIST", "PHARMACY TECHNICIAN", "POLICE OFFICER", "PROGRAMMER", "PUBLIC SERVANT", "RADIO PRESENTER", "REAL ESTATE AGENT", "RECEPTIONIST", "SALES PERSON", "SEAMSTRESS", "SECRETARY", "SECURITY", "STATE MINSTER", "STOCK BROKER", "STORE KEEPER", "SYSTEM ADMINISTRATOR", "TAILOR", "TEACHER", "TRADER", "TRAVEL AGENT", "TYPIST", "UNEMPLOYED"})
        Me.cboContactoccupation.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.cboContactoccupation.BackColor = System.Drawing.Color.White
        Me.cboContactoccupation.DropDownHeight = 105
        Me.cboContactoccupation.DropDownWidth = 105
        Me.cboContactoccupation.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.cboContactoccupation.FormattingEnabled = True
        Me.cboContactoccupation.IntegralHeight = False
        Me.cboContactoccupation.Items.AddRange(New Object() {"ACCOUNTANT", "APPRENTICE", "ARCHITECT", "ARMY OFFICER", "ARTISAN", "ASSEMBLYMAN", "AUDITOR", "BAKER", "BANKER", "BEAUTY PRACTITIONER", "BUSINESS ANALYST", "BUSINESSMAN", "CARPENTOR", "CATERER", "CHEF", "CIVIL SERVANT", "CLERGY", "COMPUTER SCIENTIST", "CONSTRUCTION ENGINEER", "DATABASE ADMINISTRATOR", "DESIGNER", "DISPENSING ASSISTANT", "DOCTOR", "DRIVER", "ELECTRICIAN", "FARMER", "FASHION DESIGNER", "FISH MONGER", "FISHERMAN", "FOOD VENDOR", "FOOTBALLER", "FOREIGN DIPLOMAT", "HAIR DRESSER", "HEALTH AID ", "HOUSE WIFE", "IMMIGRATION OFFICER", "LABOURER", "LAWYER", "LEGAL PRACTITIONER", "MASON", "MATRON", "MEDICAL PRACTITIONER", "MINER", "MINING ENGINEER", "MUSICIAN", "NETWORK ADMINISTRATOR", "NETWORK ENGINEER", "NURSE", "OTHER", "PAINTER", "PASTOR", "PENSIONER", "PHARMACIST", "PHARMACY TECHNICIAN", "POLICE OFFICER", "PROGRAMMER", "PUBLIC SERVANT", "RADIO PRESENTER", "REAL ESTATE AGENT", "RECEPTIONIST", "SALES PERSON", "SEAMSTRESS", "SECRETARY", "SECURITY", "STATE MINSTER", "STOCK BROKER", "STORE KEEPER", "SYSTEM ADMINISTRATOR", "TAILOR", "TEACHER", "TRADER", "TRAVEL AGENT", "TYPIST", "UNEMPLOYED"})
        Me.cboContactoccupation.Location = New System.Drawing.Point(155, 67)
        Me.cboContactoccupation.Name = "cboContactoccupation"
        Me.cboContactoccupation.Size = New System.Drawing.Size(215, 23)
        Me.cboContactoccupation.Sorted = True
        Me.cboContactoccupation.TabIndex = 35
        '
        'txtContacthouse
        '
        Me.txtContacthouse.BackColor = System.Drawing.Color.White
        Me.txtContacthouse.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtContacthouse.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.txtContacthouse.Location = New System.Drawing.Point(853, 67)
        Me.txtContacthouse.Name = "txtContacthouse"
        Me.txtContacthouse.Size = New System.Drawing.Size(179, 21)
        Me.txtContacthouse.TabIndex = 17
        '
        'lbl_Staffcontactno
        '
        Me.lbl_Staffcontactno.AutoSize = True
        Me.lbl_Staffcontactno.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_Staffcontactno.Location = New System.Drawing.Point(763, 71)
        Me.lbl_Staffcontactno.Name = "lbl_Staffcontactno"
        Me.lbl_Staffcontactno.Size = New System.Drawing.Size(90, 15)
        Me.lbl_Staffcontactno.TabIndex = 16
        Me.lbl_Staffcontactno.Text = "House Number:"
        '
        'lbl_StaffOccup
        '
        Me.lbl_StaffOccup.AutoSize = True
        Me.lbl_StaffOccup.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaffOccup.Location = New System.Drawing.Point(67, 71)
        Me.lbl_StaffOccup.Name = "lbl_StaffOccup"
        Me.lbl_StaffOccup.Size = New System.Drawing.Size(72, 15)
        Me.lbl_StaffOccup.TabIndex = 12
        Me.lbl_StaffOccup.Text = "Occupation:"
        '
        'txlocality
        '
        Me.txlocality.BackColor = System.Drawing.Color.White
        Me.txlocality.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txlocality.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.txlocality.Location = New System.Drawing.Point(853, 22)
        Me.txlocality.Name = "txlocality"
        Me.txlocality.Size = New System.Drawing.Size(179, 21)
        Me.txlocality.TabIndex = 11
        '
        'lbl_Staffcontown
        '
        Me.lbl_Staffcontown.AutoSize = True
        Me.lbl_Staffcontown.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_Staffcontown.Location = New System.Drawing.Point(764, 26)
        Me.lbl_Staffcontown.Name = "lbl_Staffcontown"
        Me.lbl_Staffcontown.Size = New System.Drawing.Size(87, 15)
        Me.lbl_Staffcontown.TabIndex = 10
        Me.lbl_Staffcontown.Text = "Town/Locality:"
        '
        'txtContactphone
        '
        Me.txtContactphone.BackColor = System.Drawing.Color.White
        Me.txtContactphone.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtContactphone.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.txtContactphone.Location = New System.Drawing.Point(499, 22)
        Me.txtContactphone.Name = "txtContactphone"
        Me.txtContactphone.Size = New System.Drawing.Size(215, 21)
        Me.txtContactphone.TabIndex = 9
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(440, 71)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(54, 15)
        Me.Label1.TabIndex = 8
        Me.Label1.Text = "Relation:"
        '
        'lbl_Staffconphone
        '
        Me.lbl_Staffconphone.AutoSize = True
        Me.lbl_Staffconphone.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_Staffconphone.Location = New System.Drawing.Point(399, 26)
        Me.lbl_Staffconphone.Name = "lbl_Staffconphone"
        Me.lbl_Staffconphone.Size = New System.Drawing.Size(99, 15)
        Me.lbl_Staffconphone.TabIndex = 8
        Me.lbl_Staffconphone.Text = "Contact Phone #:"
        '
        'txtContactname
        '
        Me.txtContactname.BackColor = System.Drawing.Color.White
        Me.txtContactname.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtContactname.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.txtContactname.Location = New System.Drawing.Point(156, 22)
        Me.txtContactname.Name = "txtContactname"
        Me.txtContactname.Size = New System.Drawing.Size(215, 21)
        Me.txtContactname.TabIndex = 7
        '
        'lbl_StaffConName
        '
        Me.lbl_StaffConName.AutoSize = True
        Me.lbl_StaffConName.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaffConName.Location = New System.Drawing.Point(67, 26)
        Me.lbl_StaffConName.Name = "lbl_StaffConName"
        Me.lbl_StaffConName.Size = New System.Drawing.Size(85, 15)
        Me.lbl_StaffConName.TabIndex = 6
        Me.lbl_StaffConName.Text = "Contact Name:"
        '
        'gbonextofkininfo
        '
        Me.gbonextofkininfo.Controls.Add(Me.cbostaffrel)
        Me.gbonextofkininfo.Controls.Add(Me.lbl_Staffnextrel)
        Me.gbonextofkininfo.Controls.Add(Me.txtNextkinno)
        Me.gbonextofkininfo.Controls.Add(Me.lbl_Staffnextno)
        Me.gbonextofkininfo.Controls.Add(Me.txtNextofkin)
        Me.gbonextofkininfo.Controls.Add(Me.lbl_Staffnextkin)
        Me.gbonextofkininfo.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold)
        Me.gbonextofkininfo.Location = New System.Drawing.Point(5, 413)
        Me.gbonextofkininfo.Name = "gbonextofkininfo"
        Me.gbonextofkininfo.Size = New System.Drawing.Size(1097, 47)
        Me.gbonextofkininfo.TabIndex = 2
        Me.gbonextofkininfo.TabStop = False
        Me.gbonextofkininfo.Text = "Next Of Kin"
        '
        'cbostaffrel
        '
        Me.cbostaffrel.AutoCompleteCustomSource.AddRange(New String() {"ATHEISM", "BUDHISM", "CHRISTIANITY", "JUDAISM", "ISLAM", "TRADITIONALIST"})
        Me.cbostaffrel.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.cbostaffrel.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.cbostaffrel.BackColor = System.Drawing.Color.White
        Me.cbostaffrel.DropDownHeight = 75
        Me.cbostaffrel.DropDownWidth = 75
        Me.cbostaffrel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.cbostaffrel.FormattingEnabled = True
        Me.cbostaffrel.IntegralHeight = False
        Me.cbostaffrel.Items.AddRange(New Object() {"Aunt", "Brother", "Cousin", "Daughter", "Father", "Father-In-Law", "Husband", "Mother", "Mother-In-Law", "Nephew", "Niece", "Sister", "Son", "Uncle", "Wife"})
        Me.cbostaffrel.Location = New System.Drawing.Point(853, 18)
        Me.cbostaffrel.Name = "cbostaffrel"
        Me.cbostaffrel.Size = New System.Drawing.Size(179, 23)
        Me.cbostaffrel.Sorted = True
        Me.cbostaffrel.TabIndex = 35
        '
        'lbl_Staffnextrel
        '
        Me.lbl_Staffnextrel.AutoSize = True
        Me.lbl_Staffnextrel.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_Staffnextrel.Location = New System.Drawing.Point(750, 22)
        Me.lbl_Staffnextrel.Name = "lbl_Staffnextrel"
        Me.lbl_Staffnextrel.Size = New System.Drawing.Size(77, 15)
        Me.lbl_Staffnextrel.TabIndex = 12
        Me.lbl_Staffnextrel.Text = "Relationship:"
        '
        'txtNextkinno
        '
        Me.txtNextkinno.BackColor = System.Drawing.Color.White
        Me.txtNextkinno.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtNextkinno.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.txtNextkinno.Location = New System.Drawing.Point(500, 18)
        Me.txtNextkinno.Name = "txtNextkinno"
        Me.txtNextkinno.Size = New System.Drawing.Size(215, 21)
        Me.txtNextkinno.TabIndex = 11
        '
        'lbl_Staffnextno
        '
        Me.lbl_Staffnextno.AutoSize = True
        Me.lbl_Staffnextno.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_Staffnextno.Location = New System.Drawing.Point(411, 22)
        Me.lbl_Staffnextno.Name = "lbl_Staffnextno"
        Me.lbl_Staffnextno.Size = New System.Drawing.Size(89, 15)
        Me.lbl_Staffnextno.TabIndex = 10
        Me.lbl_Staffnextno.Text = "Phone Number:"
        '
        'txtNextofkin
        '
        Me.txtNextofkin.BackColor = System.Drawing.Color.White
        Me.txtNextofkin.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtNextofkin.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.txtNextofkin.Location = New System.Drawing.Point(128, 18)
        Me.txtNextofkin.Name = "txtNextofkin"
        Me.txtNextofkin.Size = New System.Drawing.Size(215, 21)
        Me.txtNextofkin.TabIndex = 9
        '
        'lbl_Staffnextkin
        '
        Me.lbl_Staffnextkin.AutoSize = True
        Me.lbl_Staffnextkin.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_Staffnextkin.Location = New System.Drawing.Point(63, 22)
        Me.lbl_Staffnextkin.Name = "lbl_Staffnextkin"
        Me.lbl_Staffnextkin.Size = New System.Drawing.Size(63, 15)
        Me.lbl_Staffnextkin.TabIndex = 8
        Me.lbl_Staffnextkin.Text = "Full Name:"
        '
        'gbojobdetails
        '
        Me.gbojobdetails.Controls.Add(Me.cbostaffjob)
        Me.gbojobdetails.Controls.Add(Me.cboSaffdepartment)
        Me.gbojobdetails.Controls.Add(Me.txtStaffSsnit)
        Me.gbojobdetails.Controls.Add(Me.lbl_Staffssnit)
        Me.gbojobdetails.Controls.Add(Me.lbl_Staffdepartment)
        Me.gbojobdetails.Controls.Add(Me.lbl_Staffjob)
        Me.gbojobdetails.Controls.Add(Me.cboStaffcategory)
        Me.gbojobdetails.Controls.Add(Me.cboStaffqualification)
        Me.gbojobdetails.Controls.Add(Me.lbl_Staffcategory)
        Me.gbojobdetails.Controls.Add(Me.lbl_Staffqualification)
        Me.gbojobdetails.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold)
        Me.gbojobdetails.Location = New System.Drawing.Point(5, 463)
        Me.gbojobdetails.Name = "gbojobdetails"
        Me.gbojobdetails.Size = New System.Drawing.Size(1097, 106)
        Me.gbojobdetails.TabIndex = 3
        Me.gbojobdetails.TabStop = False
        Me.gbojobdetails.Text = "JOB DETAILS/DESCRIPTION"
        '
        'cbostaffjob
        '
        Me.cbostaffjob.AutoCompleteCustomSource.AddRange(New String() {"Administration", "Non-Teaching", "Teaching"})
        Me.cbostaffjob.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.cbostaffjob.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.cbostaffjob.BackColor = System.Drawing.Color.White
        Me.cbostaffjob.DropDownHeight = 77
        Me.cbostaffjob.DropDownWidth = 77
        Me.cbostaffjob.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.cbostaffjob.FormattingEnabled = True
        Me.cbostaffjob.IntegralHeight = False
        Me.cbostaffjob.Items.AddRange(New Object() {"Accountant", "Assistant HeadTeacher", "Class Teacher", "Cook", "Director", "Driver", "Form Master", "Form Mistress", "Head Teacher", "Orderly", "Proprietor", "Secretary", "Security"})
        Me.cbostaffjob.Location = New System.Drawing.Point(567, 66)
        Me.cbostaffjob.Name = "cbostaffjob"
        Me.cbostaffjob.Size = New System.Drawing.Size(170, 23)
        Me.cbostaffjob.Sorted = True
        Me.cbostaffjob.TabIndex = 47
        '
        'cboSaffdepartment
        '
        Me.cboSaffdepartment.AutoCompleteCustomSource.AddRange(New String() {"J.H.S", "Lower Primary", "Upper Primary", "Kindergarten"})
        Me.cboSaffdepartment.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.cboSaffdepartment.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.cboSaffdepartment.BackColor = System.Drawing.Color.White
        Me.cboSaffdepartment.DropDownHeight = 75
        Me.cboSaffdepartment.DropDownWidth = 75
        Me.cboSaffdepartment.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.cboSaffdepartment.FormattingEnabled = True
        Me.cboSaffdepartment.IntegralHeight = False
        Me.cboSaffdepartment.Items.AddRange(New Object() {"KINDERGARTEN", "LOWER PRIMARY", "UPPER PRIMARY", "JUNIOR HIGH SCHOOL"})
        Me.cboSaffdepartment.Location = New System.Drawing.Point(299, 66)
        Me.cboSaffdepartment.Name = "cboSaffdepartment"
        Me.cboSaffdepartment.Size = New System.Drawing.Size(170, 23)
        Me.cboSaffdepartment.TabIndex = 46
        '
        'txtStaffSsnit
        '
        Me.txtStaffSsnit.BackColor = System.Drawing.Color.White
        Me.txtStaffSsnit.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtStaffSsnit.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.txtStaffSsnit.Location = New System.Drawing.Point(837, 28)
        Me.txtStaffSsnit.Name = "txtStaffSsnit"
        Me.txtStaffSsnit.Size = New System.Drawing.Size(170, 21)
        Me.txtStaffSsnit.TabIndex = 45
        '
        'lbl_Staffssnit
        '
        Me.lbl_Staffssnit.AutoSize = True
        Me.lbl_Staffssnit.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_Staffssnit.Location = New System.Drawing.Point(772, 32)
        Me.lbl_Staffssnit.Name = "lbl_Staffssnit"
        Me.lbl_Staffssnit.Size = New System.Drawing.Size(55, 15)
        Me.lbl_Staffssnit.TabIndex = 44
        Me.lbl_Staffssnit.Text = "SSNIT #:"
        '
        'lbl_Staffdepartment
        '
        Me.lbl_Staffdepartment.AutoSize = True
        Me.lbl_Staffdepartment.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_Staffdepartment.Location = New System.Drawing.Point(227, 70)
        Me.lbl_Staffdepartment.Name = "lbl_Staffdepartment"
        Me.lbl_Staffdepartment.Size = New System.Drawing.Size(72, 15)
        Me.lbl_Staffdepartment.TabIndex = 42
        Me.lbl_Staffdepartment.Text = "Department:"
        '
        'lbl_Staffjob
        '
        Me.lbl_Staffjob.AutoSize = True
        Me.lbl_Staffjob.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_Staffjob.Location = New System.Drawing.Point(492, 70)
        Me.lbl_Staffjob.Name = "lbl_Staffjob"
        Me.lbl_Staffjob.Size = New System.Drawing.Size(76, 15)
        Me.lbl_Staffjob.TabIndex = 40
        Me.lbl_Staffjob.Text = "Job Position:"
        '
        'cboStaffcategory
        '
        Me.cboStaffcategory.AutoCompleteCustomSource.AddRange(New String() {"Administration", "Non-Teaching", "Teaching"})
        Me.cboStaffcategory.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.cboStaffcategory.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.cboStaffcategory.BackColor = System.Drawing.Color.White
        Me.cboStaffcategory.DropDownHeight = 75
        Me.cboStaffcategory.DropDownWidth = 75
        Me.cboStaffcategory.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.cboStaffcategory.FormattingEnabled = True
        Me.cboStaffcategory.IntegralHeight = False
        Me.cboStaffcategory.Items.AddRange(New Object() {"Administration", "Non-Teaching", "Teaching"})
        Me.cboStaffcategory.Location = New System.Drawing.Point(566, 26)
        Me.cboStaffcategory.Name = "cboStaffcategory"
        Me.cboStaffcategory.Size = New System.Drawing.Size(170, 23)
        Me.cboStaffcategory.TabIndex = 37
        '
        'cboStaffqualification
        '
        Me.cboStaffqualification.AutoCompleteCustomSource.AddRange(New String() {"BACHELOR OF SCIENCE(BSC)", "BACHELOR OF TECHNOLOGY(B TECH)", "BACHELOR OF ARTS(BA)", "BACHELOR OF EDUCATION(BED)", "CERTIFICATE IN NURSING", "CERTIFICATE IN SECRETARIALSHIP", "DIPLOMA IN EDUCATION", "HIGHER NATIONAL DIPLOMA(HND)", "NATIONAL VOCATIONAL TRAINING INSTITUTE(N.V.T.I)", "SECONDARY SCHOOL CERTIFICATE EXAMINATION(SSCE)", "WEST AFRICAN SECONDARY SCHOOL CERTIFICATE EXAMINATION(WASSCE)", "MASTER OF PHILOSOPHY(M PHIL)"})
        Me.cboStaffqualification.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.cboStaffqualification.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.cboStaffqualification.BackColor = System.Drawing.Color.White
        Me.cboStaffqualification.DropDownHeight = 107
        Me.cboStaffqualification.DropDownWidth = 105
        Me.cboStaffqualification.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.cboStaffqualification.FormattingEnabled = True
        Me.cboStaffqualification.IntegralHeight = False
        Me.cboStaffqualification.Items.AddRange(New Object() {"BACHELOR OF ARTS(BA)", "BACHELOR OF EDUCATION(BED)", "BACHELOR OF SCIENCE(BSC)", "BACHELOR OF TECHNOLOGY(B TECH)", "CERTIFICATE IN JOURNALISM", "CERTIFICATE IN NURSING", "CERTIFICATE IN SECRETARIALSHIP", "DIPLOMA IN EDUCATION", "HIGHER NATIONAL DIPLOMA(HND)", "MASTER OF PHILOSOPHY(M PHIL)", "NATIONAL VOCATIONAL TRAINING INSTITUTE(N.V.T.I)", "SECONDARY SCHOOL CERTIFICATE EXAMINATION(SSCE)", "WEST AFRICAN SECONDARY SCHOOL CERTIFICATE EXAMINATION(WASSCE)"})
        Me.cboStaffqualification.Location = New System.Drawing.Point(228, 26)
        Me.cboStaffqualification.Name = "cboStaffqualification"
        Me.cboStaffqualification.Size = New System.Drawing.Size(242, 23)
        Me.cboStaffqualification.Sorted = True
        Me.cboStaffqualification.TabIndex = 36
        '
        'lbl_Staffcategory
        '
        Me.lbl_Staffcategory.AutoSize = True
        Me.lbl_Staffcategory.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_Staffcategory.Location = New System.Drawing.Point(508, 30)
        Me.lbl_Staffcategory.Name = "lbl_Staffcategory"
        Me.lbl_Staffcategory.Size = New System.Drawing.Size(59, 15)
        Me.lbl_Staffcategory.TabIndex = 12
        Me.lbl_Staffcategory.Text = "Category:"
        '
        'lbl_Staffqualification
        '
        Me.lbl_Staffqualification.AutoSize = True
        Me.lbl_Staffqualification.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_Staffqualification.Location = New System.Drawing.Point(149, 30)
        Me.lbl_Staffqualification.Name = "lbl_Staffqualification"
        Me.lbl_Staffqualification.Size = New System.Drawing.Size(78, 15)
        Me.lbl_Staffqualification.TabIndex = 10
        Me.lbl_Staffqualification.Text = "Qualification:"
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'b
        '
        Me.b.BackColor = System.Drawing.Color.LightSkyBlue
        Me.b.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.b.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold)
        Me.b.Image = CType(resources.GetObject("b.Image"), System.Drawing.Image)
        Me.b.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.b.Location = New System.Drawing.Point(812, 577)
        Me.b.Name = "b"
        Me.b.Size = New System.Drawing.Size(120, 35)
        Me.b.TabIndex = 7
        Me.b.Text = "Cancel"
        Me.b.UseVisualStyleBackColor = False
        '
        'btnClearStaff
        '
        Me.btnClearStaff.BackColor = System.Drawing.Color.LightSkyBlue
        Me.btnClearStaff.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnClearStaff.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold)
        Me.btnClearStaff.Image = CType(resources.GetObject("btnClearStaff.Image"), System.Drawing.Image)
        Me.btnClearStaff.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnClearStaff.Location = New System.Drawing.Point(382, 577)
        Me.btnClearStaff.Name = "btnClearStaff"
        Me.btnClearStaff.Size = New System.Drawing.Size(120, 35)
        Me.btnClearStaff.TabIndex = 5
        Me.btnClearStaff.Text = "Clear"
        Me.btnClearStaff.UseVisualStyleBackColor = False
        '
        'btnFindStaff
        '
        Me.btnFindStaff.BackColor = System.Drawing.Color.LightSkyBlue
        Me.btnFindStaff.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnFindStaff.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold)
        Me.btnFindStaff.Image = CType(resources.GetObject("btnFindStaff.Image"), System.Drawing.Image)
        Me.btnFindStaff.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnFindStaff.Location = New System.Drawing.Point(596, 577)
        Me.btnFindStaff.Name = "btnFindStaff"
        Me.btnFindStaff.Size = New System.Drawing.Size(120, 35)
        Me.btnFindStaff.TabIndex = 6
        Me.btnFindStaff.Text = "Find"
        Me.btnFindStaff.UseVisualStyleBackColor = False
        '
        'btnSaveStaff
        '
        Me.btnSaveStaff.BackColor = System.Drawing.Color.LightSkyBlue
        Me.btnSaveStaff.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnSaveStaff.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSaveStaff.Image = CType(resources.GetObject("btnSaveStaff.Image"), System.Drawing.Image)
        Me.btnSaveStaff.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnSaveStaff.Location = New System.Drawing.Point(181, 577)
        Me.btnSaveStaff.Name = "btnSaveStaff"
        Me.btnSaveStaff.Size = New System.Drawing.Size(120, 35)
        Me.btnSaveStaff.TabIndex = 9
        Me.btnSaveStaff.Text = "&Save "
        Me.btnSaveStaff.UseVisualStyleBackColor = False
        '
        'NewStaffRegistration
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1107, 615)
        Me.Controls.Add(Me.btnSaveStaff)
        Me.Controls.Add(Me.btnClearStaff)
        Me.Controls.Add(Me.btnFindStaff)
        Me.Controls.Add(Me.b)
        Me.Controls.Add(Me.gbojobdetails)
        Me.Controls.Add(Me.gbonextofkininfo)
        Me.Controls.Add(Me.gbocontactinfo)
        Me.Controls.Add(Me.gbostaffinfo)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "NewStaffRegistration"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "SIMS"
        Me.gbostaffinfo.ResumeLayout(False)
        Me.gbostaffinfo.PerformLayout()
        Me.gbopictureupload.ResumeLayout(False)
        Me.gbopictureupload.PerformLayout()
        CType(Me.pboStaffimage, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gbocontactinfo.ResumeLayout(False)
        Me.gbocontactinfo.PerformLayout()
        Me.gbonextofkininfo.ResumeLayout(False)
        Me.gbonextofkininfo.PerformLayout()
        Me.gbojobdetails.ResumeLayout(False)
        Me.gbojobdetails.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents gbostaffinfo As System.Windows.Forms.GroupBox
    Friend WithEvents txtStaffbirthplace As System.Windows.Forms.TextBox
    Friend WithEvents lbl_StaffBirthplace As System.Windows.Forms.Label
    Friend WithEvents txtStaffhometown As System.Windows.Forms.TextBox
    Friend WithEvents lbl_StaffHometown As System.Windows.Forms.Label
    Friend WithEvents txtStaffmiddlename As System.Windows.Forms.TextBox
    Friend WithEvents txtStafffirstname As System.Windows.Forms.TextBox
    Friend WithEvents txtStaffsurname As System.Windows.Forms.TextBox
    Friend WithEvents lbl_StaffFirstname As System.Windows.Forms.Label
    Friend WithEvents lbl_StaffMiddlename As System.Windows.Forms.Label
    Friend WithEvents lbl_StaffSurname As System.Windows.Forms.Label
    Friend WithEvents lbl_StaffNationality As System.Windows.Forms.Label
    Friend WithEvents cboStaffnationality As System.Windows.Forms.ComboBox
    Friend WithEvents cboStaffmaritalstatus As System.Windows.Forms.ComboBox
    Friend WithEvents lbl_StaffMaritalStatus As System.Windows.Forms.Label
    Friend WithEvents cboStafftitle As System.Windows.Forms.ComboBox
    Friend WithEvents lbl_StaffTitle As System.Windows.Forms.Label
    Friend WithEvents cboStaffgender As System.Windows.Forms.ComboBox
    Friend WithEvents lbl_StaffGender As System.Windows.Forms.Label
    Friend WithEvents pboStaffimage As System.Windows.Forms.PictureBox
    Friend WithEvents txtStaffemail As System.Windows.Forms.TextBox
    Friend WithEvents lbl_StaffEmail As System.Windows.Forms.Label
    Friend WithEvents txtStaffphone As System.Windows.Forms.TextBox
    Friend WithEvents lbl_StaffMobileno As System.Windows.Forms.Label
    Friend WithEvents dtpStaff As System.Windows.Forms.DateTimePicker
    Friend WithEvents lbl_StaffDOB As System.Windows.Forms.Label
    Friend WithEvents btnClearStaffpic As System.Windows.Forms.Button
    Friend WithEvents btnUploadStaffpic As System.Windows.Forms.Button
    Friend WithEvents lbl_StaffReligion As System.Windows.Forms.Label
    Friend WithEvents txtstaffage As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents txthouseno As System.Windows.Forms.TextBox
    Friend WithEvents lbl_StaffHouseno As System.Windows.Forms.Label
    Friend WithEvents gbopictureupload As System.Windows.Forms.GroupBox
    Friend WithEvents txtStaffaddress As System.Windows.Forms.TextBox
    Friend WithEvents lbl_StaffAddress As System.Windows.Forms.Label
    Friend WithEvents gbocontactinfo As System.Windows.Forms.GroupBox
    Friend WithEvents txtContactphone As System.Windows.Forms.TextBox
    Friend WithEvents lbl_Staffconphone As System.Windows.Forms.Label
    Friend WithEvents txtContactname As System.Windows.Forms.TextBox
    Friend WithEvents lbl_StaffConName As System.Windows.Forms.Label
    Friend WithEvents txtContacthouse As System.Windows.Forms.TextBox
    Friend WithEvents lbl_Staffcontactno As System.Windows.Forms.Label
    Friend WithEvents lbl_StaffOccup As System.Windows.Forms.Label
    Friend WithEvents txlocality As System.Windows.Forms.TextBox
    Friend WithEvents lbl_Staffcontown As System.Windows.Forms.Label
    Friend WithEvents cboContactoccupation As System.Windows.Forms.ComboBox
    Friend WithEvents gbonextofkininfo As System.Windows.Forms.GroupBox
    Friend WithEvents lbl_Staffnextrel As System.Windows.Forms.Label
    Friend WithEvents txtNextkinno As System.Windows.Forms.TextBox
    Friend WithEvents lbl_Staffnextno As System.Windows.Forms.Label
    Friend WithEvents txtNextofkin As System.Windows.Forms.TextBox
    Friend WithEvents lbl_Staffnextkin As System.Windows.Forms.Label
    Friend WithEvents gbojobdetails As System.Windows.Forms.GroupBox
    Friend WithEvents cboStaffcategory As System.Windows.Forms.ComboBox
    Friend WithEvents cboStaffqualification As System.Windows.Forms.ComboBox
    Friend WithEvents lbl_Staffcategory As System.Windows.Forms.Label
    Friend WithEvents lbl_Staffqualification As System.Windows.Forms.Label
    Friend WithEvents txtStaffSsnit As System.Windows.Forms.TextBox
    Friend WithEvents lbl_Staffssnit As System.Windows.Forms.Label
    Friend WithEvents lbl_Staffdepartment As System.Windows.Forms.Label
    Friend WithEvents lbl_Staffjob As System.Windows.Forms.Label
    Friend WithEvents btnClearStaff As System.Windows.Forms.Button
    Friend WithEvents b As System.Windows.Forms.Button
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents cboSaffdepartment As System.Windows.Forms.ComboBox
    Friend WithEvents cbostaffreligion As System.Windows.Forms.ComboBox
    Friend WithEvents lblregion As System.Windows.Forms.Label
    Friend WithEvents cbostaffjob As System.Windows.Forms.ComboBox
    Friend WithEvents cbostaffrel As System.Windows.Forms.ComboBox
    Friend WithEvents btnFindStaff As System.Windows.Forms.Button
    Friend WithEvents btnSaveStaff As System.Windows.Forms.Button
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents cboStaffregion As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
End Class
