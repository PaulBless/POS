﻿Imports System.Data.SqlClient

Public Class frmSalaryRecord

    Sub GetData()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            con.Open()
            com1 = New SqlCommand("SELECT dbo.Staff.StaffID, dbo.Staff.StaffCode, (dbo.Staff.FirstName + ' ' + dbo.Staff.MiddleName + ' ' + dbo.Staff.LastName) AS Name, dbo.Staff.Gender, dbo.JobDetails1.Category, dbo.JobDetails1.Department, dbo.JobDetails1.Designation, dbo.JobDetails1.Portfolio, dbo.JobDetails1.Type, dbo.JobDetails1.Status, dbo.SalaryPayment.Year, dbo.SalaryPayment.Term, dbo.SalaryPayment.Month, dbo.SalaryPayment.Salary, dbo.SalaryPayment.DatePaid, dbo.SalaryPayment.IsPaid FROM dbo.Staff INNER JOIN dbo.JobDetails1 ON dbo.Staff.StaffID = dbo.JobDetails1.StaffID INNER JOIN dbo.SalaryPayment ON dbo.Staff.StaffID=dbo.SalaryPayment.StaffID where JobDetails1.Status='ACTIVE' and SalaryPayment.IsPaid='Yes'", con)
            dr = com1.ExecuteReader(CommandBehavior.CloseConnection)
            dgv.Rows.Clear()
            If dr.HasRows = True Then
                While dr.Read()
                    dgv.Rows.Add(dr(0), dr(1), dr(2), dr(3), dr(4), dr(5), dr(6), dr(7), dr(8), dr(9), dr(10), dr(11), dr(12), dr(13), dr(14), dr(15))
                End While
                dr.Close()
            Else
                MsgBox("No salary payments record was found", MsgBoxStyle.OkOnly + MsgBoxStyle.Information, "SIMS")
            End If
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at getdata")
            con.Close()
        End Try
    End Sub

    Sub GetRecord()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            con.Open()
            com1 = New SqlCommand("SELECT dbo.Staff.StaffID, dbo.Staff.StaffCode, (dbo.Staff.FirstName + ' ' + dbo.Staff.MiddleName + ' ' + dbo.Staff.LastName) AS Name, dbo.Staff.Gender, dbo.JobDetails1.Category, dbo.JobDetails1.Department, dbo.JobDetails1.Designation, dbo.JobDetails1.Portfolio, dbo.JobDetails1.Type, dbo.JobDetails1.Status, dbo.SalaryPayment1.Year, dbo.SalaryPayment1.Term, dbo.SalaryPayment1.Month, dbo.SalaryPayment1.Salary, dbo.SalaryPayment1.PaymentDate, dbo.SalaryPayment1.IsPaid FROM dbo.Staff INNER JOIN dbo.JobDetails1 ON dbo.Staff.StaffID = dbo.JobDetails1.StaffID INNER JOIN dbo.SalaryPayment1 ON dbo.Staff.StaffID=dbo.SalaryPayment1.StaffID where JobDetails1.Status='ACTIVE' and SalaryPayment1.IsPaid='Yes'", con)
            dr = com1.ExecuteReader(CommandBehavior.CloseConnection)
            dgv.Rows.Clear()
            If dr.HasRows = True Then
                While dr.Read()
                    dgv.Rows.Add(dr(0), dr(1), dr(2), dr(3), dr(4), dr(5), dr(6), dr(7), dr(8), dr(9), dr(10), dr(11), dr(12), dr(13), dr(14), dr(15))
                End While
                dr.Close()
            Else
                MsgBox("No salary payments record was found", MsgBoxStyle.OkOnly + MsgBoxStyle.Information, "SIMS")
            End If
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at getdata")
            con.Close()
        End Try
    End Sub

    Private Sub frmSalaryRecord_FormClosed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed
        Reset()
    End Sub

    Private Sub frmSalaryRecord_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Me.Text = Me.Text + " - [Current User: " + frmLog.Logname + "]"
        'GetData()
        GetRecord()
        ActiveControl = txtName
    End Sub

    Private Sub txtMonth_TextChanged(sender As Object, e As EventArgs) Handles txtMonth.TextChanged
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            con.Open()
            com1 = New SqlCommand("SELECT dbo.Staff.StaffID, dbo.Staff.StaffCode, (dbo.Staff.FirstName + ' ' + dbo.Staff.MiddleName + ' ' + dbo.Staff.LastName) AS Name, dbo.Staff.Gender, dbo.JobDetails1.Category, dbo.JobDetails1.Department, dbo.JobDetails1.Designation, dbo.JobDetails1.Portfolio, dbo.JobDetails1.Type, dbo.JobDetails1.Status, dbo.SalaryPayment.Year, dbo.SalaryPayment.Term, dbo.SalaryPayment.Month, dbo.SalaryPayment.Salary, dbo.SalaryPayment.DatePaid, dbo.SalaryPayment.IsPaid FROM dbo.Staff INNER JOIN dbo.JobDetails1 ON dbo.Staff.StaffID = dbo.JobDetails1.StaffID INNER JOIN dbo.SalaryPayment ON dbo.Staff.StaffID=dbo.SalaryPayment.StaffID where JobDetails1.Status='ACTIVE' and SalaryPayment.IsPaid='Yes' and SalaryPayment.Month like '%" & txtMonth.Text & "%'", con)
            dr = com1.ExecuteReader(CommandBehavior.CloseConnection)
            dgv.Rows.Clear()
            If dr.HasRows = True Then
                While dr.Read()
                    dgv.Rows.Add(dr(0), dr(1), dr(2), dr(3), dr(4), dr(5), dr(6), dr(7), dr(8), dr(9), dr(10), dr(11), dr(12), dr(13), dr(14), dr(15))
                End While
                dr.Close()
            Else
                MsgBox("No salary payments record was found", MsgBoxStyle.OkOnly + MsgBoxStyle.Information, "SIMS")
            End If
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at month")
            con.Close()
        End Try
    End Sub

    Private Sub txtName_TextChanged(sender As Object, e As EventArgs) Handles txtName.TextChanged
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            con.Open()
            com1 = New SqlCommand("SELECT dbo.Staff.StaffID, dbo.Staff.StaffCode, (dbo.Staff.FirstName + ' ' + dbo.Staff.MiddleName + ' ' + dbo.Staff.LastName) AS Name, dbo.Staff.Gender, dbo.JobDetails1.Category, dbo.JobDetails1.Department, dbo.JobDetails1.Designation, dbo.JobDetails1.Portfolio, dbo.JobDetails1.Type, dbo.JobDetails1.Status, dbo.SalaryPayment.Year, dbo.SalaryPayment.Term, dbo.SalaryPayment.Month, dbo.SalaryPayment.Salary, dbo.SalaryPayment.DatePaid, dbo.SalaryPayment.IsPaid FROM dbo.Staff INNER JOIN dbo.JobDetails1 ON dbo.Staff.StaffID = dbo.JobDetails1.StaffID INNER JOIN dbo.SalaryPayment ON dbo.Staff.StaffID=dbo.SalaryPayment.StaffID where JobDetails1.Status='ACTIVE' and SalaryPayment.IsPaid='Yes' and Staff.FirstName like '%" & txtName.Text & "%'", con)
            dr = com1.ExecuteReader(CommandBehavior.CloseConnection)
            dgv.Rows.Clear()
            If dr.HasRows = True Then
                While dr.Read()
                    dgv.Rows.Add(dr(0), dr(1), dr(2), dr(3), dr(4), dr(5), dr(6), dr(7), dr(8), dr(9), dr(10), dr(11), dr(12), dr(13), dr(14), dr(15))
                End While
                dr.Close()
            Else
                MsgBox("No salary payments record was found", MsgBoxStyle.OkOnly + MsgBoxStyle.Information, "SIMS")
            End If
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at name")
            con.Close()
        End Try
    End Sub

    Private Sub txtTerm_TextChanged(sender As Object, e As EventArgs) Handles txtTerm.TextChanged
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            con.Open()
            com1 = New SqlCommand("SELECT dbo.Staff.StaffID, dbo.Staff.StaffCode, (dbo.Staff.FirstName + ' ' + dbo.Staff.MiddleName + ' ' + dbo.Staff.LastName) AS Name, dbo.Staff.Gender, dbo.JobDetails1.Category, dbo.JobDetails1.Department, dbo.JobDetails1.Designation, dbo.JobDetails1.Portfolio, dbo.JobDetails1.Type, dbo.JobDetails1.Status, dbo.SalaryPayment.Year, dbo.SalaryPayment.Term, dbo.SalaryPayment.Month, dbo.SalaryPayment.Salary, dbo.SalaryPayment.DatePaid, dbo.SalaryPayment.IsPaid FROM dbo.Staff INNER JOIN dbo.JobDetails1 ON dbo.Staff.StaffID = dbo.JobDetails1.StaffID INNER JOIN dbo.SalaryPayment ON dbo.Staff.StaffID=dbo.SalaryPayment.StaffID where JobDetails1.Status='ACTIVE' and SalaryPayment.IsPaid='Yes' and SalaryPayment.Term like '%" & txtTerm.Text & "%'", con)
            dr = com1.ExecuteReader(CommandBehavior.CloseConnection)
            dgv.Rows.Clear()
            If dr.HasRows = True Then
                While dr.Read()
                    dgv.Rows.Add(dr(0), dr(1), dr(2), dr(3), dr(4), dr(5), dr(6), dr(7), dr(8), dr(9), dr(10), dr(11), dr(12), dr(13), dr(14), dr(15))
                End While
                dr.Close()
            Else
                MsgBox("No salary payments record was found", MsgBoxStyle.OkOnly + MsgBoxStyle.Information, "SIMS")
            End If
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at term")
            con.Close()
        End Try
    End Sub

    Private Sub txtYear_TextChanged(sender As Object, e As EventArgs) Handles txtYear.TextChanged
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            con.Open()
            com1 = New SqlCommand("SELECT dbo.Staff.StaffID, dbo.Staff.StaffCode, (dbo.Staff.FirstName + ' ' + dbo.Staff.MiddleName + ' ' + dbo.Staff.LastName) AS Name, dbo.Staff.Gender, dbo.JobDetails1.Category, dbo.JobDetails1.Department, dbo.JobDetails1.Designation, dbo.JobDetails1.Portfolio, dbo.JobDetails1.Type, dbo.JobDetails1.Status, dbo.SalaryPayment.Year, dbo.SalaryPayment.Term, dbo.SalaryPayment.Month, dbo.SalaryPayment.Salary, dbo.SalaryPayment.DatePaid, dbo.SalaryPayment.IsPaid FROM dbo.Staff INNER JOIN dbo.JobDetails1 ON dbo.Staff.StaffID = dbo.JobDetails1.StaffID INNER JOIN dbo.SalaryPayment ON dbo.Staff.StaffID=dbo.SalaryPayment.StaffID where JobDetails1.Status='ACTIVE' and SalaryPayment.IsPaid='Yes' and SalaryPayment.Year like '%" & txtYear.Text & "'", con)
            dr = com1.ExecuteReader(CommandBehavior.CloseConnection)
            dgv.Rows.Clear()
            If dr.HasRows = True Then
                While dr.Read()
                    dgv.Rows.Add(dr(0), dr(1), dr(2), dr(3), dr(4), dr(5), dr(6), dr(7), dr(8), dr(9), dr(10), dr(11), dr(12), dr(13), dr(14), dr(15))
                End While
                dr.Close()
            Else
                MsgBox("No salary payments record was found", MsgBoxStyle.OkOnly + MsgBoxStyle.Information, "SIMS")
            End If
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at year")
            con.Close()
        End Try
    End Sub

    Private Sub Reset()
        txtYear.Clear()
        txtName.Clear()
        txtMonth.Clear()
        txtTerm.Clear()
        GetRecord()
    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        Reset()
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub
End Class