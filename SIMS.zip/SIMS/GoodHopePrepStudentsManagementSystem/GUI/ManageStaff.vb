﻿Imports System.Data.SqlClient

Public Class ManageStaff

   
    Private Sub btn_Cancel_ManageEmployee_Form_Click(sender As Object, e As EventArgs) Handles btn_Cancel.Click
        Me.Close()
    End Sub

    Sub Clearme()
        txtSID.Clear()
        txtcode.Clear()
        txtfirstname.Clear()
        txtothernames.Clear()
        txtphoneno.Clear()
        txtdesignation.Clear()
        txttitle.Clear()
        txtstaffcode.Clear()
        cbogender.ResetText()
        cboStatus.ResetText()
        cbobackground.ResetText()
        cbocategory.ResetText()
        cboSaffdepartment.ResetText()
        cboqualification.ResetText()

    End Sub

    Private Sub btnsearch_Click(sender As Object, e As EventArgs) Handles btnsearch.Click
        If txtcode.Text = "" Then MsgBox("Enter Staff Code", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "SIMS - Error") : Exit Sub
        'Try

        '    If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
        '    ConnectionModule.con.Open()

        '    Dim comdSearch As SqlCommand = New SqlCommand("select * from vwStaffJobDetails where StaffCode='" & Me.txtcode.Text & "'", ConnectionModule.con)
        '    Dim reader As SqlDataReader = comdSearch.ExecuteReader(CommandBehavior.CloseConnection)
        '    If reader.HasRows = True Then
        '        While reader.Read()
        '            txtstaffcode.Text = reader(0).ToString()
        '            txttitle.Text = reader(1).ToString()
        '            txtfirstname.Text = reader(2).ToString()
        '            txtothernames.Text = reader(3).ToString + " " & reader(4).ToString()
        '            cbogender.Text = reader(5).ToString()
        '            txtphoneno.Text = reader(6).ToString()
        '            cbobackground.Text = reader(7).ToString()
        '            cboqualification.Text = reader(8).ToString()
        '            cbodepartment.Text = reader(9).ToString()
        '            cbocategory.Text = reader(10).ToString()
        '            txtjobposition.Text = reader(11).ToString()
        '            txtdate.Text = reader(12).ToString()
        '            End While
        '    Else
        '        MessageBox.Show("Please, the staff code is not correct. It could be that this staff record is deleted.", "SIMS - Record Not Found", MessageBoxButtons.OK, MessageBoxIcon.Error)
        '        txtcode.Focus()
        '        txtcode.SelectAll()
        '        Exit Sub

        '    End If


        'Catch ex As Exception
        '    ' MessageBox.Show(ex.Message)
        'Finally
        '    con.Close()

        'End Try

    End Sub

    Private Sub btn_Delete_Employee_Record_Click(sender As Object, e As EventArgs) Handles btn_Delete.Click
        If txtSID.Text = "" Then MsgBox("Invalid employee record, Please check", MsgBoxStyle.OkOnly + MsgBoxStyle.Exclamation, "SIMS - Error") : Exit Sub

        If MsgBox("Do you really want to delete employee job information and/or history?", MsgBoxStyle.Critical + MsgBoxStyle.YesNo, "Confirmation") = MsgBoxResult.Yes Then
            Try
                If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                ConnectionModule.con.Open()
                com1 = New SqlCommand("delete from JobDetails1 where StaffID='" & Val(txtSID.Text) & "'", ConnectionModule.con)
                com1.ExecuteNonQuery()
                MsgBox("Employee Job Record Successfully Deleted!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Success")
                Refreshme()

            Catch ex As Exception
                MessageBox.Show(ex.Message)
            Finally
                con.Close()
            End Try
        End If

    End Sub

    Private Sub btn_Update_Employee_Info_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        If txtSID.Text = "" Then MsgBox("Invalid data id; specify employee record", MsgBoxStyle.OkOnly + MsgBoxStyle.Exclamation, "SIMS - Error") : Exit Sub

        If MsgBox("Are you sure you want to save employee job record?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "SIMS - Confirmation") = MsgBoxResult.Yes Then
            Try
                If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                ConnectionModule.con.Open()
                com = New SqlCommand("update JobDetails1 set Background=@Background, Qualification=@Qualification, Category=@Category, Department=@Department,  Designation=@Designation, Portfolio=@Portfolio, Type=@Type, Status=@Status where StaffID='" & Me.txtSID.Text & "'", ConnectionModule.con)
                com.Parameters.AddWithValue("@Background", cbobackground.Text.Trim())
                com.Parameters.AddWithValue("@Qualification", cboqualification.Text.Trim())
                com.Parameters.AddWithValue("@Category", cbocategory.Text)
                com.Parameters.AddWithValue("@Department", cboSaffdepartment.Text)
                com.Parameters.AddWithValue("@Designation", txtdesignation.Text.Trim())
                com.Parameters.AddWithValue("@Portfolio", portfolio.Text)
                com.Parameters.AddWithValue("@Type", cboType.Text)
                com.Parameters.AddWithValue("@Status", cboStatus.Text)
                'com.Parameters.AddWithValue("@Date", StartDate.Text.ToString())
                'com.Parameters.AddWithValue("@End_Date", EndDate.Text.ToString())
                com.ExecuteNonQuery()
                MsgBox("Employee Job profile successfully Saved!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "SIMS - Success")
                Refreshme()

            Catch ex As Exception
                MessageBox.Show(ex.Message)
            Finally
                con.Close()
            End Try
        End If

    End Sub

    Sub Refreshme()
        txtSID.Clear()
        txtNationality.Clear()
        txtstaffcode.Clear()
        cboType.ResetText()
        txtdesignation.Clear()
        txtfirstname.Clear()
        txtothernames.Clear()
        txtphoneno.Clear()
        txtSSNIT.Clear()
        StartDate.Text = Now
        EndDate.Text = Now
        cbobackground.ResetText()
        cbocategory.ResetText()
        cboSaffdepartment.ResetText()
        cboqualification.ResetText()
        cboStatus.ResetText()
        cbogender.ResetText()
        portfolio.ResetText()
        txttitle.Clear()
        txtdesignation.Clear()
        txtEmpID.Clear()
        txtEmpID.Focus()
    End Sub
    Private Sub btn_Refresh_form_Click(sender As Object, e As EventArgs) Handles btn_Refresh_form.Click
        Refreshme()
    End Sub

    Private Sub ManageStaff_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ActiveControl = txtcode

    End Sub

    Private Sub txtcode_TextChanged(sender As Object, e As EventArgs) Handles txtcode.TextChanged
        Try
            ' Dim comdSearch As SqlCommand = New SqlCommand("select * from vwStaffJobDetails where StaffCode='" & Me.txtcode.Text & "'", ConnectionModule.con)
            ' Dim reader As SqlDataReader = comdSearch.ExecuteReader(CommandBehavior.CloseConnection)
            ' If reader.HasRows = True Then
            '     While reader.Read()
            '         txtSID.Text = reader(0).ToString()
            '         txtstaffcode.Text = reader(1).ToString()
            '         txttitle.Text = reader(2).ToString()
            '         txtfirstname.Text = reader(3).ToString()
            '         txtothernames.Text = reader(4).ToString + " " & reader(5).ToString()
            '         cbogender.Text = reader(6).ToString()
            '         txtphoneno.Text = reader(7).ToString()
            '         cbobackground.Text = reader(8).ToString()
            '         cboqualification.Text = reader(9).ToString()
            '         cbodepartment.Text = reader(10).ToString()
            '         cbocategory.Text = reader(11).ToString()
            '         txtjobposition.Text = reader(12).ToString()
            '         DateEmployed.Text = reader(13).ToString()
            '         cboType.Text = reader(14).ToString()
            '         cboStatus.Text = reader(15).ToString()
            '     End While
            'End If
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            ' com = New SqlCommand("SELECT dbo.Staff.StaffID, dbo.Staff.StaffCode, dbo.Staff.FirstName, dbo.Staff.MiddleName, dbo.Staff.LastName, dbo.Staff.Gender, dbo.Staff.Title, dbo.Staff.PhoneNumber, dbo.JobDetails1.Background, dbo.JobDetails1.Qualification, dbo.JobDetails1.Category, dbo.JobDetails1.Department, dbo.JobDetails1.Designation, dbo.JobDetails1.Portfolio, dbo.JobDetails1.Type, dbo.JobDetails1.Status, dbo.JobDetails1.Date FROM dbo.JobDetails1 INNER JOIN dbo.Staff ON dbo.JobDetails1.StaffID = dbo.Staff.StaffID where StaffCode='" & txtcode.Text & "'", con)
            com = New SqlCommand("select * from vwStaffJobDetails1 where StaffCode='" & txtcode.Text & "'", con)
            dr = com.ExecuteReader()
            If dr.HasRows = True Then
                While dr.Read()
                    txtSID.Text = dr(0).ToString()
                    txtstaffcode.Text = dr(1).ToString()
                    txttitle.Text = dr(6).ToString()
                    txtfirstname.Text = dr(2).ToString()
                    txtothernames.Text = dr(3).ToString + " " & dr(4).ToString()
                    cbogender.Text = dr(5).ToString()
                    txtphoneno.Text = dr(7).ToString()
                    cbobackground.Text = dr(8).ToString()
                    cboqualification.Text = dr(9).ToString()
                    cbocategory.Text = dr(10).ToString()
                    cboSaffdepartment.Text = dr(11).ToString()
                    cboDesignation.Text = dr(11).ToString()
                    txtdesignation.Text = dr(12).ToString()
                    portfolio.Text = dr(13).ToString()
                    cboType.Text = dr(14).ToString()
                    cboStatus.Text = dr(15).ToString()
                    StartDate.Text = dr(16).ToString()
                    EndDate.Text = dr(17).ToString()
                    txtNationality.Text = dr(18).ToString()
                    txtSSNIT.Text = dr(19).ToString()
                    'enable button controls
                    btnSave.Enabled = True
                    btnTerminate.Enabled = True
                    btn_Delete.Enabled = True
                    btnDeactivate.Enabled = True
                End While
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            con.Close()

        End Try
    End Sub

    Private Sub btnDeactivate_Click(sender As Object, e As EventArgs) Handles btnDeactivate.Click
        If cboStatus.Text = "ACTIVE" AndAlso txtSID.Text = "" Then MsgBox("Invalid selection of employee status." + vbCrLf + "To de-activate an employee, you must set current status to 'INACTIVE'; before you can de-activate employee job profile-status", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "Invalid Selection") : cboStatus.Focus() : Exit Sub
        If MsgBox("Do you really want to 'DE-ACTIVATE' selected employee status?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "SIMS - Confirmation") = MsgBoxResult.Yes Then
            Try
                If con.State = ConnectionState.Open Then con.Close()
                con.Open()
                com1 = New SqlCommand("update JobDetails1 set Status=@d1 where StaffID=@d2", con)
                com1.Parameters.AddWithValue("@d1", cboStatus.Text.Trim())
                com1.Parameters.AddWithValue("@d2", Val(txtSID.Text))
                com1.ExecuteNonQuery()
                MsgBox("Successfully de-activated employee status.", MsgBoxStyle.OkOnly + MsgBoxStyle.Information, "Success")
                com1.Dispose()
                Refreshme()
            Catch ex As Exception
                MsgBox(ex.ToString(), MsgBoxStyle.OkOnly + MsgBoxStyle.Critical, "error at deactivate")
                con.Close()
            End Try
        End If

    End Sub

    Private Sub btnTerminate_Click(sender As Object, e As EventArgs) Handles btnTerminate.Click
        If StartDate.Text = Now AndAlso EndDate.Text = Now Then MsgBox("Please provide the Start date and End date of employee's employment history;" + vbNewLine + "before you can terminte employment.", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "Error") : Exit Sub

        Try

        Catch ex As Exception

        End Try
    End Sub

    Private Sub txtEmpID_TextChanged(sender As Object, e As EventArgs) Handles txtEmpID.TextChanged
        'If txtEmpID.Text <> "" Then
        '    Try
        '        If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
        '        ConnectionModule.con.Open()
        '        ' com = New SqlCommand("SELECT dbo.Staff.StaffID, dbo.Staff.StaffCode, dbo.Staff.FirstName, dbo.Staff.MiddleName, dbo.Staff.LastName, dbo.Staff.Gender, dbo.Staff.Title, dbo.Staff.PhoneNumber, dbo.JobDetails1.Background, dbo.JobDetails1.Qualification, dbo.JobDetails1.Category, dbo.JobDetails1.Department, dbo.JobDetails1.Designation, dbo.JobDetails1.Portfolio, dbo.JobDetails1.Type, dbo.JobDetails1.Status, dbo.JobDetails1.Date FROM dbo.JobDetails1 INNER JOIN dbo.Staff ON dbo.JobDetails1.StaffID = dbo.Staff.StaffID where StaffCode='" & txtcode.Text & "'", con)
        '        com = New SqlCommand("select * from vwStaffJobDetails1 where StaffCode='" & txtEmpID.Text & "'", con)
        '        dr = com.ExecuteReader()
        '        If dr.HasRows = True Then
        '            While dr.Read()
        '                txtSID.Text = dr(0).ToString()
        '                txtstaffcode.Text = dr(1).ToString()
        '                txttitle.Text = dr(6).ToString()
        '                txtfirstname.Text = dr(2).ToString()
        '                txtothernames.Text = dr(3).ToString + " " & dr(4).ToString()
        '                cbogender.Text = dr(5).ToString()
        '                txtphoneno.Text = dr(7).ToString()
        '                cbobackground.Text = dr(8).ToString()
        '                cboqualification.Text = dr(9).ToString()
        '                cbocategory.Text = dr(10).ToString()
        '                cboSaffdepartment.Text = dr(11).ToString()
        '                cboDesignation.Text = dr(11).ToString()
        '                txtdesignation.Text = dr(12).ToString()
        '                portfolio.Text = dr(13).ToString()
        '                cboType.Text = dr(14).ToString()
        '                cboStatus.Text = dr(15).ToString()
        '                StartDate.Text = dr(16).ToString()
        '                EndDate.Text = dr(17).ToString()
        '                txtNationality.Text = dr(18).ToString()
        '                txtSSNIT.Text = dr(19).ToString()
        '                'enable button controls
        '                btnSave.Enabled = True
        '                btnTerminate.Enabled = True
        '                btn_Delete.Enabled = True
        '                btnDeactivate.Enabled = True
        '            End While
        '        End If
        '    Catch ex As Exception

        '    End Try

        'Else
        '    'activate buttons controls
        '    btnDeactivate.Enabled = False
        '    btnSave.Enabled = False
        '    btnTerminate.Enabled = False
        '    btn_Delete.Enabled = False
        '    Clearme()
        'End If

    End Sub

    Private Sub cbodepartment_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboSaffdepartment.SelectedIndexChanged
        cboDesignation.Items.Clear()
        If cboSaffdepartment.Text = "ADMINISTRATION" Then
            cboDesignation.Items.Add("DIRECTOR")
            cboDesignation.Items.Add("PROPRIETOR")
            cboDesignation.Items.Add("HEAD TEACHER")
            cboDesignation.Items.Add("SECRETARY")
            cboDesignation.Items.Add("LIBRARIAN")
            cboDesignation.Items.Add("BURSAR")
            cboDesignation.Items.Add("ACCOUNTANT")
            Exit Sub
        ElseIf cboSaffdepartment.Text = "OTHER SERVICES" Then
            cboDesignation.Items.Add("DRIVER")
            cboDesignation.Items.Add("COOK")
            cboDesignation.Items.Add("ORDERLY")
            cboDesignation.Items.Add("SECURITY")
            Exit Sub
        End If

        If cboSaffdepartment.Text = "KINDERGARTEN" Then
            cboDesignation.Items.Add("CRECHE")
            cboDesignation.Items.Add("NURSERY 1")
            cboDesignation.Items.Add("NURSERY 2")
            cboDesignation.Items.Add("K.G 1")
            cboDesignation.Items.Add("K.G 2")
            Exit Sub
        End If

        If cboSaffdepartment.Text = "LOWER PRIMARY" Then
            cboDesignation.Items.Add("PRIMARY 1")
            cboDesignation.Items.Add("PRIMARY 2")
            cboDesignation.Items.Add("PRIMARY 3")
            Exit Sub
        End If

        If cboSaffdepartment.Text = "UPPER PRIMARY" Then
            cboDesignation.Items.Add("PRIMARY 4")
            cboDesignation.Items.Add("PRIMARY 5")
            cboDesignation.Items.Add("PRIMARY 6")
            Exit Sub
        End If

        If cboSaffdepartment.Text = "JUNIOR HIGH SCHOOL" Then
            cboDesignation.Items.Add("JHS 1")
            cboDesignation.Items.Add("JHS 2")
            cboDesignation.Items.Add("JHS 3")
            Exit Sub
        End If
    End Sub

    Private Sub btnHelp_Click(sender As Object, e As EventArgs) Handles btnHelp.Click
        If txtEmpID.Text = "" Then
            MessageBox.Show("Employee ID is missing, provide valid employee id for search..", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Exit Sub
        End If
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            ' com = New SqlCommand("SELECT dbo.Staff.StaffID, dbo.Staff.StaffCode, dbo.Staff.FirstName, dbo.Staff.MiddleName, dbo.Staff.LastName, dbo.Staff.Gender, dbo.Staff.Title, dbo.Staff.PhoneNumber, dbo.JobDetails1.Background, dbo.JobDetails1.Qualification, dbo.JobDetails1.Category, dbo.JobDetails1.Department, dbo.JobDetails1.Designation, dbo.JobDetails1.Portfolio, dbo.JobDetails1.Type, dbo.JobDetails1.Status, dbo.JobDetails1.Date FROM dbo.JobDetails1 INNER JOIN dbo.Staff ON dbo.JobDetails1.StaffID = dbo.Staff.StaffID where StaffCode='" & txtcode.Text & "'", con)
            com = New SqlCommand("select * from vwStaffJobDetails1 where StaffCode='" & txtEmpID.Text & "'", con)
            dr = com.ExecuteReader()
            If dr.HasRows() = True Then
                While dr.Read()
                    txtSID.Text = dr(0).ToString()
                    txtstaffcode.Text = dr(1).ToString()
                    txttitle.Text = dr(6).ToString()
                    txtfirstname.Text = dr(2).ToString()
                    txtothernames.Text = dr(3).ToString + " " & dr(4).ToString()
                    cbogender.Text = dr(5).ToString()
                    txtphoneno.Text = dr(7).ToString()
                    cbobackground.Text = dr(8).ToString()
                    cboqualification.Text = dr(9).ToString()
                    cbocategory.Text = dr(10).ToString()
                    cboSaffdepartment.Text = dr(11).ToString()
                    cboDesignation.Text = dr(12).ToString()
                    txtdesignation.Text = dr(12).ToString()
                    portfolio.Text = dr(13).ToString()
                    cboType.Text = dr(14).ToString()
                    cboStatus.Text = dr(15).ToString()
                    StartDate.Text = dr(16).ToString()
                    EndDate.Text = dr(17).ToString()
                    txtNationality.Text = dr(18).ToString()
                    txtSSNIT.Text = dr(19).ToString()
                    'enable button controls
                    btnSave.Enabled = True
                    btnTerminate.Enabled = True
                    btn_Delete.Enabled = True
                    btnDeactivate.Enabled = True
                End While
            Else
                MsgBox("The employee id you entered is incorrect; or has no job specifications for the search criteria..", MsgBoxStyle.OkOnly + MsgBoxStyle.Critical, "Error")
                txtEmpID.Focus()
                txtEmpID.SelectAll()
            End If
        Catch ex As Exception
            ErrorToString()
        End Try

    End Sub
End Class