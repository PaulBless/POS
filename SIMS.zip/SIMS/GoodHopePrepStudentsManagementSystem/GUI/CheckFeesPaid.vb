﻿Imports System.Data.SqlClient

Public Class CheckFeesPaid


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If txtRegNo.Text = "" Then MsgBox("Enter student Registration Number", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "SMIS") : txtRegNo.Focus() : Exit Sub
        If cboYear.Text = "" Then MsgBox("Select academic year", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "SMIS") : cboYear.Focus() : Exit Sub
        If cboTerm.Text = "" Then MsgBox("Select Academic Term", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "SMIS") : cboTerm.Focus() : Exit Sub
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            query = "select fullname, gender, class, acayear, term, SUM(feeamount) as FeesPaid from vwstudentfeespaid where registrationnumber=@d1 and acayear=@d2 and Term=@d3"
            'query = "select dbo.Students.FirstName + SPACE(1) + dbo.Students.MiddleName + SPACE(1) + dbo.Students.LastName AS Fullname, dbo.Students.Gender, dbo.Students.Class, dbo.FeesPayment.AcaYear, dbo.FeesPayment.Term, SUM(dbo.FeesPayment.FeeAmount) AS Total FROM dbo.FeesPayment INNER JOIN dbo.Students ON dbo.FeesPayment.StudID = dbo.Students.ID where registrationnumber=@d1 and acayear=@d2 and term=@d3"
            com = New SqlCommand(query, con)
            com.Parameters.AddWithValue("@d1", Val(txtRegNo.Text))
            com.Parameters.AddWithValue("@d2", cboYear.Text)
            com.Parameters.AddWithValue("@d3", cboTerm.Text)
            dr = com.ExecuteReader(CommandBehavior.CloseConnection)
            dgvinfo.Rows.Clear()
            If dr.HasRows() = True Then
                While dr.Read()
                    'MsgBox("Year: " + dr.GetValue(4) + "Term: " + dr.GetValue(5) + "Total: " + dr.GetValue(3))
                    'MsgBox("Total paid; " & dr.GetValue(0))
                    dgvinfo.Rows.Add(dr(0), dr(1), dr(2), dr(3), dr(4), dr(5))
                End While
                dr.Close()
            Else
                MsgBox("No payment record was found", MsgBoxStyle.OkOnly + MsgBoxStyle.Information, "SIMS")
            End If
            Exit Sub

        Catch ex As Exception
            MsgBox(ex.ToString(), MsgBoxStyle.OkOnly + MsgBoxStyle.Exclamation, "error at search")
            con.Close()
        End Try
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        txtSID.Clear()
        txtRegNo.Clear()
        cboTerm.ResetText()
        cboYear.ResetText()
    End Sub

    Private Sub txtRegNo_TextChanged(sender As Object, e As EventArgs) Handles txtRegNo.TextChanged
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()

            Dim cmd As SqlCommand = New SqlCommand("select * from Students where RegistrationNumber='" & Me.txtRegNo.Text & "'", ConnectionModule.con)
            Dim reader As SqlDataReader = cmd.ExecuteReader(CommandBehavior.CloseConnection)
            If (reader.Read()) Then
                txtSID.Text = reader.GetValue(0)
                SearchId = reader.GetValue(0)
            End If
            cmd.Dispose()

        Catch ex As Exception
            MsgBox(ex.Message)
            con.Close()
        End Try
    End Sub

    Public Sub AcademicYear()
        Try
            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            dset = New Data.DataSet()
            adapter = New SqlDataAdapter()
            adapter.SelectCommand = New SqlCommand("select distinct year from session order by year desc", ConnectionModule.con)
            dset.Clear()
            adapter.Fill(dset, "session")
            cboYear.DataSource = dset.Tables("session")
            cboYear.DisplayMember = "year"
            cboYear.Refresh()
            cboYear.SelectedIndex = -1
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at get academicyear")
            con.Close()
        End Try
    End Sub
    Public Sub AcademicTerm()
        Try
            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            dset = New Data.DataSet()
            adapter = New SqlDataAdapter()
            adapter.SelectCommand = New SqlCommand("select distinct term from session order by term asc", ConnectionModule.con)
            dset.Clear()
            adapter.Fill(dset, "session")
            cboTerm.DataSource = dset.Tables("session")
            cboTerm.DisplayMember = "term"
            cboTerm.Refresh()
            cboTerm.SelectedIndex = -1
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at get academicterm")
            con.Close()
        End Try
    End Sub

    Private Sub cboYear_DropDown(sender As Object, e As EventArgs) Handles cboYear.DropDown
        AcademicYear()
    End Sub

    Private Sub cboTerm_DropDown(sender As Object, e As EventArgs) Handles cboTerm.DropDown
        AcademicTerm()
    End Sub
End Class