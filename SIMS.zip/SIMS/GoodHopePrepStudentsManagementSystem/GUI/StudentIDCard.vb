﻿Imports System.Data.SqlClient
Imports System.Drawing.Imaging

Public Class StudentIDCard

    'instantiate object referenc to webcam
    Private mywebcam As WebCam
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnStart.Click
        mywebcam.Start()
    End Sub

    Private Sub btnStop_Click(sender As Object, e As EventArgs) Handles btnStop.Click
        mywebcam.Stop()
    End Sub

    Private Sub btnContinue_Click(sender As Object, e As EventArgs) Handles btnContinue.Click
        mywebcam.Continue()
    End Sub

    Private Sub btnCaptureImage_Click(sender As Object, e As EventArgs) Handles btnCaptureImage.Click
        imgCapture.Image = imgVideo.Image
    End Sub

    Private Sub StudentIDCard_FormClosed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed

    End Sub

    Private Sub StudentIDCard_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        mywebcam = New WebCam()
        mywebcam.InitializeWebCam(imgVideo)
    End Sub
    Private Sub SaveImage()
        Try
            If Not IsNothing(imgCapture.Image) Then
                'convert captured image and reference to memorystream object
                'imgCapture.Image.Save(myStream, imgCapture.Image.RawFormat)     'image in rawformat
                imgCapture.Image.Save(myStream, Imaging.ImageFormat.Jpeg)
            Else
                'clear picturebox content
                imgCapture.Image = Nothing
            End If

            If con.State = ConnectionState.Open Then con.Close()
            query = "insert into studentimages(studid,picture) values (@d1,@d2)"
            com = New SqlCommand(query, con)
            com.Parameters.Add("@d1", SqlDbType.Int).Value = SearchId
            com.Parameters.Add("@d2", SqlDbType.Image).Value = myStream.ToArray()
            con.Open()
            com.ExecuteNonQuery()
            con.Close()
            MsgBox("Student ID Card information successfully saved..", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Success")

        Catch ex As SqlException
            ErrorToString()
        Catch ex As ArgumentNullException
            ErrorToString()
        Catch ex As NullReferenceException
            ErrorToString()
        Catch ex As BadImageFormatException
            ErrorToString()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub
    Private Sub btnSave_to_DB_Click(sender As Object, e As EventArgs) Handles btnSaveImage_DB.Click, Button1.Click

    End Sub
End Class