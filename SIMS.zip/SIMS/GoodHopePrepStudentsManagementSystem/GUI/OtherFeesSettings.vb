﻿Imports System.Data.SqlClient

Public Class OtherFeesSettings

    Private Sub OtherFeesSettings_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        GetFeesData()
        ActiveControl = txtFeeType

    End Sub
    Private Sub txtAmount_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtAmount.KeyPress
        If Asc(e.KeyChar) <> 13 AndAlso Asc(e.KeyChar) <> 8 AndAlso Not IsNumeric(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub

    Private Sub TextBox1_Leave(sender As Object, e As EventArgs) Handles txtAmount.Leave
        'Dim inputFee As Integer = Val(txtAmount.Text)
        'txtAmount.Text = Format(inputFee, "0.00")

    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles txtAmount.TextChanged

    End Sub
    Private Sub GetFeesData()
        Try
            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            com1 = New SqlCommand("select * from OtherFees", ConnectionModule.con)
            dr = com1.ExecuteReader(CommandBehavior.CloseConnection)
            dgv.Rows.Clear()
            While dr.Read() = True
                dgv.Rows.Add(dr(0), dr(2), dr(1), dr(3))
            End While
            'dr.Close()
            con.Close()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        If txtFeeType.Text = "" Then MsgBox("Specify the fee type", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "Error") : Exit Sub
        If cboClass.Text = "" Then MsgBox("Please select the class or form", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "Error") : Exit Sub
        If txtAmount.Text = "" Then MsgBox("Specify the fee amount", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "Error") : Exit Sub
        'confirm saving
        If MsgBox("Do you really want to save this record?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "SMIS") = MsgBoxResult.Yes Then
            Try
                'check record exists
                If con.State = ConnectionState.Open Then con.Close()
                con.Open()
                com = New SqlCommand("select * from otherfees where sclass='" & (cboClass.Text) & "' and feename='" & txtFeeType.Text & "'", con)
                dr = com.ExecuteReader(CommandBehavior.CloseConnection)
                If dr.Read() = True Then
                    dr.Close()
                    'show error message
                    MessageBox.Show("Record Exists.. Cannot not save duplicate record. NB:- Please update the record.", "SMIS", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                Else
                    'insert new fees
                    If con.State = ConnectionState.Open Then con.Close()
                    con.Open()
                    com1 = New SqlCommand("insert into otherfees(sclass,feename,amount) values (@d1,@d2,@d3)", ConnectionModule.con)
                    com1.Parameters.Add("@d1", SqlDbType.NVarChar).Value = cboClass.Text
                    com1.Parameters.Add("@d2", SqlDbType.VarChar).Value = txtFeeType.Text
                    com1.Parameters.Add("@d3", SqlDbType.Real).Value = Format(Val(txtAmount.Text), "#,##0.00")
                    com1.ExecuteNonQuery()
                    MessageBox.Show("Successfully saved.", "SMIS", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    com1.Dispose()
                    con.Close()
                    'clear controls
                    ClearMe()
                    btnSave.Enabled = True
                    btnUpdate.Enabled = False
                    btnDelete.Enabled = False
                    Exit Sub
                End If

            Catch ex As Exception
                MessageBox.Show(ex.Message)
            End Try
        End If

    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        'If txtID.Text = String.Empty Then MsgBox("Invalid record selection, check..", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "SIMS Error") : Exit Sub
        If MsgBox("Do you really want to delete this record?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "SMIS") = MsgBoxResult.Yes Then
            Try
                'check record exists
                If con.State = ConnectionState.Open Then con.Close()
                con.Open()
                com = New SqlCommand("select * from otherfees where ofid='" & Val(txtID.Text) & "'", con)
                dr = com.ExecuteReader(CommandBehavior.CloseConnection)
                If dr.HasRows() = True Then
                    'delete record
                    If con.State = ConnectionState.Open Then con.Close()
                    con.Open()
                    com1 = New SqlCommand("delete from otherfees where ofid='" & dgv.SelectedRows(0).Cells(0).Value & "'", ConnectionModule.con)
                    com1.ExecuteNonQuery()
                    MessageBox.Show("Successfully deleted.", "SMIS", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    com1.Dispose()
                    con.Close()
                    'clear controls
                    ClearMe()
                    btnSave.Enabled = True
                    btnUpdate.Enabled = False
                    btnDelete.Enabled = False
                Else
                    'show error message
                    MessageBox.Show("Could not find specific record criteria to perform deletion.. ", "SMIS", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Exit Sub
                End If

            Catch ex As Exception
                MessageBox.Show(ex.Message)
            End Try
        End If

    End Sub

    Sub ClearMe()
        txtID.Text = ""
        txtFeeType.Text = ""
        txtAmount.Text = ""
        cboClass.Text = ""
        GetFeesData()
    End Sub
    Public Sub MyClassRooms()
        Try
            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            dset = New Data.DataSet()
            adapter = New SqlDataAdapter()
            adapter.SelectCommand = New SqlCommand("select distinct room from classroom order by room asc", ConnectionModule.con)
            dset.Clear()
            adapter.Fill(dset, "classroom")
            cboClass.DataSource = dset.Tables("classroom")
            cboClass.DisplayMember = "room"
            cboClass.Refresh()
            cboClass.SelectedIndex = -1
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at get class")
            con.Close()
        End Try
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        'If txtID.Text = String.Empty Then MsgBox("Invalid record selection, check..", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "SIMS Error") : Exit Sub
        If MsgBox("Do you really want to update this record?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "SMIS") = MsgBoxResult.Yes Then
            Try
                'check record exists
                If con.State = ConnectionState.Open Then con.Close()
                con.Open()
                com = New SqlCommand("select * from otherfees where ofid='" & Val(txtID.Text) & "'", con)
                dr = com.ExecuteReader(CommandBehavior.CloseConnection)
                If dr.HasRows() = True Then
                    'update the record
                    If con.State = ConnectionState.Open Then con.Close()
                    con.Open()
                    com1 = New SqlCommand("update otherfees set sclass=@d1, feename=@d2, amount=@d3 where ofid='" & dgv.SelectedRows(0).Cells(0).Value & "'", con)
                    com1.Parameters.Add("@d1", SqlDbType.NVarChar).Value = cboClass.Text
                    com1.Parameters.Add("@d2", SqlDbType.VarChar).Value = txtFeeType.Text
                    com1.Parameters.Add("@d3", SqlDbType.Real).Value = Format(Val(txtAmount.Text), "#,##0.00")
                    com1.ExecuteNonQuery()
                    MessageBox.Show("Successfully updated.", "SMIS", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    com1.Dispose()
                    con.Close()
                    'clear controls
                    ClearMe()
                    btnSave.Enabled = True
                    btnUpdate.Enabled = False
                    btnDelete.Enabled = False
                Else
                    'show error message
                    MessageBox.Show("Could not find specific record criteria to perform update.. ", "SMIS", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Exit Sub
                End If

            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End If

    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub FeeSettings_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        GetFeesData()

    End Sub


    Private Sub dgv_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv.CellClick
        dgv.SelectAll()
    End Sub

    Private Sub dgv_CellContentDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv.CellContentDoubleClick
        Try
            txtID.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(0).Value
            txtFeeType.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(1).Value.ToString()
            cboClass.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(2).Value.ToString()
            txtAmount.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(3).Value.ToString()
            btnUpdate.Enabled = True
            btnDelete.Enabled = True
            btnSave.Enabled = False
            'txtFeeType.Enabled = False
        Catch ex As Exception

        End Try
    End Sub

    Private Sub cboClass_DropDown(sender As Object, e As EventArgs) Handles cboClass.DropDown
        Try
            MyClassRooms()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub cboClass_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboClass.SelectedIndexChanged

    End Sub

    Private Sub dgv_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv.CellContentClick

    End Sub
End Class