﻿Imports System.Data.SqlClient

Public Class frmStudentBehaviour
    Private Sub  ResetControls()
        txtAttitude.Clear()
        txtclass.Clear()
        txtname.Clear()
        txtreg.Clear()
        txtgender.Clear()
        txtConduct.Clear()
        txtTeacherRemarks.Clear()
        txtInterest.Clear()
        cboTerm.ResetText()
        cboYear.ResetText()

    End Sub
    Private Sub frmStudentBehaviour_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ActiveControl = cboClass
    End Sub
    Public Sub GetClassList()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            dset = New Data.DataSet()
            adapter = New SqlDataAdapter()
            adapter.SelectCommand = New SqlCommand("select distinct room from classroom order by room asc", ConnectionModule.con)
            dset.Clear()
            adapter.Fill(dset, "classroom")
            cboClass.DataSource = dset.Tables("classroom")
            cboClass.DisplayMember = "room"
            cboClass.Refresh()
            cboClass.SelectedIndex = -1
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at get class")
            con.Close()
        End Try
    End Sub

    Private Sub btnHelp_Click(sender As Object, e As EventArgs) Handles btnHelp.Click
        If cboClass.Text = "" Then
            MsgBox("Select specific class.", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "SMIS")
            cboClass.Focus()
            Exit Sub
        End If

        Try
            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            query = "select ID, RegistrationNumber, FirstName + space(1) + MiddleName + space(1) + LastName AS Fullname, Gender, Class from Students where Class='" & Me.cboClass.Text & "'"
            com = New SqlCommand(query, ConnectionModule.con)
            dr = com.ExecuteReader(CommandBehavior.CloseConnection)
            If dr.Read() Then
                dgv.Rows.Clear()
                While dr.Read()
                    SearchId = dr.GetValue(0)
                    dgv.Rows.Add(dr(0), dr(1), dr(2), dr(3), dr(4))
                End While
                Exit Sub
            Else
                MessageBox.Show("The selected class has no student record or data..", "No Record Found", MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub dgv_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv.CellContentClick

    End Sub

    Private Sub dgv_CellContentDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv.CellContentDoubleClick
        Try
            SearchId = dgv.Rows(dgv.CurrentRow.Index).Cells(0).Value
            txtreg.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(1).Value.ToString()
            txtname.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(2).Value
            txtgender.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(3).Value.ToString()
            txtclass.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(4).Value.ToString()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub cboClass_DropDown(sender As Object, e As EventArgs) Handles cboClass.DropDown
        GetClassList()
    End Sub

    Private Sub cboClass_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboClass.SelectedIndexChanged

    End Sub

    Private Sub txtConduct_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtConduct.KeyPress
        Select Case Asc(e.KeyChar)
            Case 8, 32, 65 To 90, 97 To 122
                e.Handled = False
            Case Else
                e.Handled = True
        End Select
    End Sub

    Private Sub txtConduct_TextChanged(sender As Object, e As EventArgs) Handles txtConduct.TextChanged

    End Sub

    Private Sub txtAttitude_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtAttitude.KeyPress
        Select Case Asc(e.KeyChar)
            Case 8, 32, 65 To 90, 97 To 122
                e.Handled = False
            Case Else
                e.Handled = True
        End Select
    End Sub

    Private Sub txtInterest_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtInterest.KeyPress
        Select Case Asc(e.KeyChar)
            Case 8, 32, 65 To 90, 97 To 122
                e.Handled = False
            Case Else
                e.Handled = True
        End Select
    End Sub

    Private Sub txtTeacherRemarks_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtTeacherRemarks.KeyPress
        Select Case Asc(e.KeyChar)
            Case 8, 32, 65 To 90, 97 To 122
                e.Handled = False
            Case Else
                e.Handled = True
        End Select
    End Sub

    Private Sub btnPrint_Click(sender As Object, e As EventArgs) Handles btnPrint.Click
        If cboTerm.Text = "" Then
            MessageBox.Show("Select academic term", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1)
            Exit Sub
        End If
        If cboYear.Text = "" Then
            MessageBox.Show("Select academic year", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1)
            Exit Sub
        End If
        If txtAttitude.Text = "" Then
            MessageBox.Show("Enter attitude of pupil", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1)
            txtAttitude.Focus()
            Exit Sub
        End If
        If txtConduct.Text = "" Then
            MessageBox.Show("Enter conduct of pupils", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1)
            txtConduct.Focus()
            Exit Sub
        End If
        If txtInterest.Text = "" Then
            MessageBox.Show("Enter interest of pupil", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1)
            txtInterest.Focus()
            Exit Sub
        End If
        If txtTeacherRemarks.Text = "" Then
            MessageBox.Show("Enter the class teacher remarks", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1)
            txtTeacherRemarks.Focus()
            Exit Sub
        End If

        Try
            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            query = "select ayear, aterm from studbehaviour where sid=@d1 and ayear=@d2 and aterm=@d3"
            com = New SqlCommand(query, con)
            com.Parameters.AddWithValue("@d1", SearchId)
            com.Parameters.AddWithValue("@d2", cboYear.Text)
            com.Parameters.AddWithValue("@d3", cboTerm.Text)
            dr = com.ExecuteReader(CommandBehavior.CloseConnection)
            If dr.Read() = True Then
                dr.Close()
                MessageBox.Show("The academic year and term specified has existing record. Please re-check and specify correct parameters..", "Error")
                Exit Sub
            Else
                If con.State = ConnectionState.Open Then con.Close()
                com = New SqlCommand("insert into studbehaviour (sid,ayear,aterm,conduct,attitude,interest,remarks) values(@sid,@ayear,@aterm,@conduct,@attitude,@interest,@remarks)", con)
                com.Parameters.AddWithValue("@sid", SearchId)
                com.Parameters.AddWithValue("@ayear", cboYear.Text)
                com.Parameters.AddWithValue("@aterm", cboTerm.Text)
                com.Parameters.AddWithValue("@conduct", txtConduct.Text.Trim())
                com.Parameters.AddWithValue("@attitude", txtAttitude.Text.Trim())
                com.Parameters.AddWithValue("@interest", txtInterest.Text.Trim())
                com.Parameters.AddWithValue("@remarks", txtTeacherRemarks.Text.Trim())
                con.Open()
                com.ExecuteNonQuery()
                MsgBox("Record successfully saved.", MsgBoxStyle.OkOnly + MsgBoxStyle.Information, "Success")
                com.Dispose()
                ResetControls()
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Public Sub GetTerm()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            dset = New Data.DataSet()
            adapter = New SqlDataAdapter()
            adapter.SelectCommand = New SqlCommand("select distinct term from Session order by term asc", ConnectionModule.con)
            dset.Clear()
            adapter.Fill(dset, "Session")
            cboTerm.DataSource = dset.Tables("Session")
            cboTerm.DisplayMember = "Term"
            ''cboTerm.ValueMember = "ID"
            cboTerm.Refresh()
            cboTerm.SelectedIndex = -1
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at get academic year")
            con.Close()
        End Try
    End Sub
    Public Sub GetYear()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            dset = New Data.DataSet()
            adapter = New SqlDataAdapter()
            adapter.SelectCommand = New SqlCommand("select distinct Year from Session order by Year DESC", ConnectionModule.con)
            dset.Clear()
            adapter.Fill(dset, "Session")
            cboYear.DataSource = dset.Tables("Session")
            cboYear.DisplayMember = "Year"
            ''cboYear.ValueMember = "ID"
            cboYear.Refresh()
            cboYear.SelectedIndex = -1
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at get academic year")
            con.Close()
        End Try
    End Sub

    Private Sub cboTerm_DropDown(sender As Object, e As EventArgs) Handles cboTerm.DropDown
        GetTerm()
    End Sub
    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub

    Private Sub cboYear_DropDown(sender As Object, e As EventArgs) Handles cboYear.DropDown
        GetYear()
    End Sub
End Class