﻿Imports System.Data.SqlClient

Public Class frmCheckBusPayments

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        ClearControls()
    End Sub

    Sub ClearControls()
        txtRegNo.Clear()
        txtYear.Clear()
        cboTerm.ResetText()
        dgvinfo.Rows.Clear()
        'cboYear.ResetText()
        txtRegNo.Focus()
    End Sub


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If txtRegNo.Text = "" Then MsgBox("Enter student Registration Number", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "SIMS") : txtRegNo.Focus() : Exit Sub
        If txtYear.Text = "" Then MsgBox("Enter academic year", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "SIMS") : txtYear.Focus() : Exit Sub
        If cboTerm.Text = "" Then MsgBox("Select Academic Term", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "SIMS") : cboTerm.Focus() : Exit Sub
        ' If cboYear.Text = "" Then MsgBox("Select academic year", MsgBoxStyle.OkOnly + MsgBoxStyle.Information, "SIMS") : Exit Sub

        Try
            If cboTerm.Text = "Term 1" Then
                If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                ConnectionModule.con.Open()
                com = New SqlCommand("SELECT DISTINCT(dbo.Students.FirstName + ' ' + dbo.Students.MiddleName + ' ' + dbo.Students.LastName) AS FullName, dbo.Students.Class, dbo.BusFees.Year, dbo.BusFees.Term, dbo.FeesPaid.TotalPaid FROM dbo.BusFees INNER JOIN dbo.FeesPaid ON dbo.BusFees.ID = dbo.FeesPaid.ID INNER JOIN dbo.Students ON dbo.BusFees.ID = dbo.Students.ID where students.RegistrationNumber='" & txtRegNo.Text & "' and busfees.Year='" & txtYear.Text & "' and busfees.Term='Term 1' ", con)
                dr = com.ExecuteReader(CommandBehavior.CloseConnection)
                dgvinfo.Rows.Clear()
                If dr.HasRows() = True Then
                    While dr.Read()
                        dgvinfo.Rows.Add(dr(0), dr(1), dr(2), dr(3), dr(4))
                    End While
                    dr.Close()
                Else
                    MsgBox("No payment record found")
                End If
                Exit Sub
            End If
            If cboTerm.Text = "Term 2" Then
                If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                ConnectionModule.con.Open()
                com = New SqlCommand("SELECT DISTINCT(dbo.Students.FirstName + ' ' + dbo.Students.MiddleName + ' ' + dbo.Students.LastName) AS FullName, dbo.Students.Class, dbo.BusFees.Year, dbo.BusFees.Term, dbo.FeesPaid.TotalPaid FROM dbo.BusFees INNER JOIN dbo.FeesPaid ON dbo.BusFees.ID = dbo.FeesPaid.ID INNER JOIN dbo.Students ON dbo.BusFees.ID = dbo.Students.ID where students.RegistrationNumber='" & txtRegNo.Text & "' and busfees.Year='" & txtYear.Text & "' and busfees.Term='Term 2' ", con)
                dr = com.ExecuteReader(CommandBehavior.CloseConnection)
                dgvinfo.Rows.Clear()
                If dr.HasRows() = True Then
                    While dr.Read()
                        dgvinfo.Rows.Add(dr(0), dr(1), dr(2), dr(3), dr(4))
                    End While
                    dr.Close()
                Else
                    MsgBox("No payment record found")
                End If
                Exit Sub
            End If
            If cboTerm.Text = "Term 3" Then
                If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                ConnectionModule.con.Open()
                com = New SqlCommand("SELECT DISTINCT(dbo.Students.FirstName + ' ' + dbo.Students.MiddleName + ' ' + dbo.Students.LastName) AS FullName, dbo.Students.Class, dbo.BusFees.Year, dbo.BusFees.Term, dbo.FeesPaid.TotalPaid FROM dbo.BusFees INNER JOIN dbo.FeesPaid ON dbo.BusFees.ID = dbo.FeesPaid.ID INNER JOIN dbo.Students ON dbo.BusFees.ID = dbo.Students.ID where students.RegistrationNumber='" & txtRegNo.Text & "' and busfees.Year='" & txtYear.Text & "' and busfees.Term='Term 3' ", con)
                dr = com.ExecuteReader(CommandBehavior.CloseConnection)
                dgvinfo.Rows.Clear()
                If dr.HasRows() = True Then
                    While dr.Read()
                        dgvinfo.Rows.Add(dr(0), dr(1), dr(2), dr(3), dr(4))
                    End While
                    dr.Close()
                Else
                    MsgBox("No payment record found")
                End If
                Exit Sub
            End If

        Catch ex As Exception
            MsgBox(ex.ToString(), MsgBoxStyle.OkOnly + MsgBoxStyle.Exclamation, "error at search")
            con.Close()
        End Try
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub

    Private Sub frmCheckBusPayments_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ActiveControl = txtRegNo

    End Sub
End Class