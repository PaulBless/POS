﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmConfirm_Student_Admission
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmConfirm_Student_Admission))
        Me.demograhic_gb = New System.Windows.Forms.GroupBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.cbo_Student_Religion = New System.Windows.Forms.ComboBox()
        Me.txt_StudentLocation = New System.Windows.Forms.TextBox()
        Me.txt_Student_Hometown = New System.Windows.Forms.TextBox()
        Me.txt_student_age = New System.Windows.Forms.TextBox()
        Me.dtpDOB = New System.Windows.Forms.DateTimePicker()
        Me.cboGender = New System.Windows.Forms.ComboBox()
        Me.cboTitle = New System.Windows.Forms.ComboBox()
        Me.txt_Student_Middlename = New System.Windows.Forms.TextBox()
        Me.txt_Student_Firstname = New System.Windows.Forms.TextBox()
        Me.txt_Student_Surname = New System.Windows.Forms.TextBox()
        Me.lbl_StaffHometown = New System.Windows.Forms.Label()
        Me.lblregion = New System.Windows.Forms.Label()
        Me.lbl_StaffHouseno = New System.Windows.Forms.Label()
        Me.lbl_StaffSurname = New System.Windows.Forms.Label()
        Me.lbl_StaffFirstname = New System.Windows.Forms.Label()
        Me.lbl_StaffMiddlename = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.lbl_StaffDOB = New System.Windows.Forms.Label()
        Me.lbl_StaffGender = New System.Windows.Forms.Label()
        Me.lbl_StaffTitle = New System.Windows.Forms.Label()
        Me.lbl_StaffReligion = New System.Windows.Forms.Label()
        Me.lbl_StaffEmail = New System.Windows.Forms.Label()
        Me.lbl_StudDept = New System.Windows.Forms.Label()
        Me.lbl_StaffNationality = New System.Windows.Forms.Label()
        Me.contactinfo_gb = New System.Windows.Forms.GroupBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txt_Contact_Email = New System.Windows.Forms.TextBox()
        Me.cboContact_Occupation = New System.Windows.Forms.ComboBox()
        Me.cboContact_Relation = New System.Windows.Forms.ComboBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txt_Student_Contact_Name = New System.Windows.Forms.TextBox()
        Me.txt_Student_Contact_Address = New System.Windows.Forms.TextBox()
        Me.lbl_StaffConName = New System.Windows.Forms.Label()
        Me.lbl_StaffAddress = New System.Windows.Forms.Label()
        Me.txt_Student_Contact_Number = New System.Windows.Forms.TextBox()
        Me.lbl_Staffnextrel = New System.Windows.Forms.Label()
        Me.lbl_Staffconphone = New System.Windows.Forms.Label()
        Me.txt_Student_Contact_WorkNo = New System.Windows.Forms.TextBox()
        Me.lbl_StaffOccup = New System.Windows.Forms.Label()
        Me.lbl_Staffconwork = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.address_gb = New System.Windows.Forms.GroupBox()
        Me.cbo_Student_District = New System.Windows.Forms.ComboBox()
        Me.cbo_Student_Region = New System.Windows.Forms.ComboBox()
        Me.cbo_Student_Nationality = New System.Windows.Forms.ComboBox()
        Me.registrationinfo_gb = New System.Windows.Forms.GroupBox()
        Me.radNo = New System.Windows.Forms.RadioButton()
        Me.radYes = New System.Windows.Forms.RadioButton()
        Me.dtpDate = New System.Windows.Forms.DateTimePicker()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.txtFee = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lbl_StudClass = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.cboClass = New System.Windows.Forms.ComboBox()
        Me.cboDepartment = New System.Windows.Forms.ComboBox()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.btn_Cancel_Student_Form = New System.Windows.Forms.Button()
        Me.btn_Find_student_Record = New System.Windows.Forms.Button()
        Me.btn_Clear_Student_Record = New System.Windows.Forms.Button()
        Me.btn_SaveStudentRecord = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.demograhic_gb.SuspendLayout()
        Me.contactinfo_gb.SuspendLayout()
        Me.address_gb.SuspendLayout()
        Me.registrationinfo_gb.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'demograhic_gb
        '
        Me.demograhic_gb.Controls.Add(Me.Label7)
        Me.demograhic_gb.Controls.Add(Me.Label23)
        Me.demograhic_gb.Controls.Add(Me.Label22)
        Me.demograhic_gb.Controls.Add(Me.Label21)
        Me.demograhic_gb.Controls.Add(Me.Label6)
        Me.demograhic_gb.Controls.Add(Me.Label5)
        Me.demograhic_gb.Controls.Add(Me.Label30)
        Me.demograhic_gb.Controls.Add(Me.cbo_Student_Religion)
        Me.demograhic_gb.Controls.Add(Me.txt_StudentLocation)
        Me.demograhic_gb.Controls.Add(Me.txt_Student_Hometown)
        Me.demograhic_gb.Controls.Add(Me.txt_student_age)
        Me.demograhic_gb.Controls.Add(Me.dtpDOB)
        Me.demograhic_gb.Controls.Add(Me.cboGender)
        Me.demograhic_gb.Controls.Add(Me.cboTitle)
        Me.demograhic_gb.Controls.Add(Me.txt_Student_Middlename)
        Me.demograhic_gb.Controls.Add(Me.txt_Student_Firstname)
        Me.demograhic_gb.Controls.Add(Me.txt_Student_Surname)
        Me.demograhic_gb.Controls.Add(Me.lbl_StaffHometown)
        Me.demograhic_gb.Controls.Add(Me.lblregion)
        Me.demograhic_gb.Controls.Add(Me.lbl_StaffHouseno)
        Me.demograhic_gb.Controls.Add(Me.lbl_StaffSurname)
        Me.demograhic_gb.Controls.Add(Me.lbl_StaffFirstname)
        Me.demograhic_gb.Controls.Add(Me.lbl_StaffMiddlename)
        Me.demograhic_gb.Controls.Add(Me.Label13)
        Me.demograhic_gb.Controls.Add(Me.lbl_StaffDOB)
        Me.demograhic_gb.Controls.Add(Me.lbl_StaffGender)
        Me.demograhic_gb.Controls.Add(Me.lbl_StaffTitle)
        Me.demograhic_gb.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.demograhic_gb.Location = New System.Drawing.Point(17, 41)
        Me.demograhic_gb.Name = "demograhic_gb"
        Me.demograhic_gb.Size = New System.Drawing.Size(859, 149)
        Me.demograhic_gb.TabIndex = 0
        Me.demograhic_gb.TabStop = False
        Me.demograhic_gb.Text = "Student Demographics"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.Red
        Me.Label7.Location = New System.Drawing.Point(86, 65)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(15, 19)
        Me.Label7.TabIndex = 70
        Me.Label7.Text = "*"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.ForeColor = System.Drawing.Color.Red
        Me.Label23.Location = New System.Drawing.Point(641, 67)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(15, 19)
        Me.Label23.TabIndex = 69
        Me.Label23.Text = "*"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.ForeColor = System.Drawing.Color.Red
        Me.Label22.Location = New System.Drawing.Point(373, 105)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(15, 19)
        Me.Label22.TabIndex = 69
        Me.Label22.Text = "*"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.ForeColor = System.Drawing.Color.Red
        Me.Label21.Location = New System.Drawing.Point(376, 65)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(15, 19)
        Me.Label21.TabIndex = 69
        Me.Label21.Text = "*"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.Red
        Me.Label6.Location = New System.Drawing.Point(376, 33)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(15, 19)
        Me.Label6.TabIndex = 69
        Me.Label6.Text = "*"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.Red
        Me.Label5.Location = New System.Drawing.Point(78, 105)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(15, 19)
        Me.Label5.TabIndex = 68
        Me.Label5.Text = "*"
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.ForeColor = System.Drawing.Color.Red
        Me.Label30.Location = New System.Drawing.Point(83, 33)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(15, 19)
        Me.Label30.TabIndex = 67
        Me.Label30.Text = "*"
        '
        'cbo_Student_Religion
        '
        Me.cbo_Student_Religion.BackColor = System.Drawing.Color.White
        Me.cbo_Student_Religion.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbo_Student_Religion.FormattingEnabled = True
        Me.cbo_Student_Religion.Items.AddRange(New Object() {"CHRISTIANITY", "ISLAM", "TRADITIONALIST"})
        Me.cbo_Student_Religion.Location = New System.Drawing.Point(392, 104)
        Me.cbo_Student_Religion.Name = "cbo_Student_Religion"
        Me.cbo_Student_Religion.Size = New System.Drawing.Size(158, 23)
        Me.cbo_Student_Religion.TabIndex = 8
        '
        'txt_StudentLocation
        '
        Me.txt_StudentLocation.BackColor = System.Drawing.Color.White
        Me.txt_StudentLocation.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txt_StudentLocation.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_StudentLocation.Location = New System.Drawing.Point(658, 65)
        Me.txt_StudentLocation.MaxLength = 300
        Me.txt_StudentLocation.Multiline = True
        Me.txt_StudentLocation.Name = "txt_StudentLocation"
        Me.txt_StudentLocation.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txt_StudentLocation.Size = New System.Drawing.Size(185, 62)
        Me.txt_StudentLocation.TabIndex = 5
        '
        'txt_Student_Hometown
        '
        Me.txt_Student_Hometown.BackColor = System.Drawing.Color.White
        Me.txt_Student_Hometown.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txt_Student_Hometown.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Student_Hometown.Location = New System.Drawing.Point(392, 64)
        Me.txt_Student_Hometown.MaxLength = 200
        Me.txt_Student_Hometown.Name = "txt_Student_Hometown"
        Me.txt_Student_Hometown.Size = New System.Drawing.Size(158, 21)
        Me.txt_Student_Hometown.TabIndex = 4
        '
        'txt_student_age
        '
        Me.txt_student_age.BackColor = System.Drawing.Color.White
        Me.txt_student_age.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_student_age.Location = New System.Drawing.Point(254, 63)
        Me.txt_student_age.MaxLength = 50
        Me.txt_student_age.Name = "txt_student_age"
        Me.txt_student_age.ReadOnly = True
        Me.txt_student_age.Size = New System.Drawing.Size(32, 21)
        Me.txt_student_age.TabIndex = 59
        '
        'dtpDOB
        '
        Me.dtpDOB.CustomFormat = "dd/MM/yyyy"
        Me.dtpDOB.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtpDOB.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpDOB.Location = New System.Drawing.Point(99, 63)
        Me.dtpDOB.Name = "dtpDOB"
        Me.dtpDOB.ShowCheckBox = True
        Me.dtpDOB.Size = New System.Drawing.Size(123, 21)
        Me.dtpDOB.TabIndex = 58
        '
        'cboGender
        '
        Me.cboGender.BackColor = System.Drawing.Color.White
        Me.cboGender.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboGender.FormattingEnabled = True
        Me.cboGender.Items.AddRange(New Object() {"FEMALE", "MALE"})
        Me.cboGender.Location = New System.Drawing.Point(99, 104)
        Me.cboGender.Name = "cboGender"
        Me.cboGender.Size = New System.Drawing.Size(84, 23)
        Me.cboGender.TabIndex = 6
        '
        'cboTitle
        '
        Me.cboTitle.BackColor = System.Drawing.Color.White
        Me.cboTitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboTitle.FormattingEnabled = True
        Me.cboTitle.Location = New System.Drawing.Point(227, 104)
        Me.cboTitle.Name = "cboTitle"
        Me.cboTitle.Size = New System.Drawing.Size(59, 23)
        Me.cboTitle.TabIndex = 7
        '
        'txt_Student_Middlename
        '
        Me.txt_Student_Middlename.BackColor = System.Drawing.Color.White
        Me.txt_Student_Middlename.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txt_Student_Middlename.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Student_Middlename.Location = New System.Drawing.Point(658, 31)
        Me.txt_Student_Middlename.MaxLength = 200
        Me.txt_Student_Middlename.Name = "txt_Student_Middlename"
        Me.txt_Student_Middlename.Size = New System.Drawing.Size(185, 21)
        Me.txt_Student_Middlename.TabIndex = 3
        '
        'txt_Student_Firstname
        '
        Me.txt_Student_Firstname.BackColor = System.Drawing.Color.White
        Me.txt_Student_Firstname.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txt_Student_Firstname.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Student_Firstname.Location = New System.Drawing.Point(392, 31)
        Me.txt_Student_Firstname.MaxLength = 250
        Me.txt_Student_Firstname.Name = "txt_Student_Firstname"
        Me.txt_Student_Firstname.Size = New System.Drawing.Size(158, 21)
        Me.txt_Student_Firstname.TabIndex = 2
        '
        'txt_Student_Surname
        '
        Me.txt_Student_Surname.BackColor = System.Drawing.Color.White
        Me.txt_Student_Surname.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txt_Student_Surname.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Student_Surname.Location = New System.Drawing.Point(99, 31)
        Me.txt_Student_Surname.MaxLength = 300
        Me.txt_Student_Surname.Name = "txt_Student_Surname"
        Me.txt_Student_Surname.Size = New System.Drawing.Size(187, 21)
        Me.txt_Student_Surname.TabIndex = 1
        '
        'lbl_StaffHometown
        '
        Me.lbl_StaffHometown.AutoSize = True
        Me.lbl_StaffHometown.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaffHometown.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_StaffHometown.Location = New System.Drawing.Point(304, 65)
        Me.lbl_StaffHometown.Name = "lbl_StaffHometown"
        Me.lbl_StaffHometown.Size = New System.Drawing.Size(76, 17)
        Me.lbl_StaffHometown.TabIndex = 54
        Me.lbl_StaffHometown.Text = "Hometown"
        '
        'lblregion
        '
        Me.lblregion.AutoSize = True
        Me.lblregion.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblregion.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lblregion.Location = New System.Drawing.Point(316, 106)
        Me.lblregion.Name = "lblregion"
        Me.lblregion.Size = New System.Drawing.Size(59, 17)
        Me.lblregion.TabIndex = 53
        Me.lblregion.Text = "Religion"
        '
        'lbl_StaffHouseno
        '
        Me.lbl_StaffHouseno.AutoSize = True
        Me.lbl_StaffHouseno.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaffHouseno.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_StaffHouseno.Location = New System.Drawing.Point(579, 67)
        Me.lbl_StaffHouseno.Name = "lbl_StaffHouseno"
        Me.lbl_StaffHouseno.Size = New System.Drawing.Size(61, 17)
        Me.lbl_StaffHouseno.TabIndex = 50
        Me.lbl_StaffHouseno.Text = "Location"
        '
        'lbl_StaffSurname
        '
        Me.lbl_StaffSurname.AutoSize = True
        Me.lbl_StaffSurname.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaffSurname.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_StaffSurname.Location = New System.Drawing.Point(14, 32)
        Me.lbl_StaffSurname.Name = "lbl_StaffSurname"
        Me.lbl_StaffSurname.Size = New System.Drawing.Size(81, 17)
        Me.lbl_StaffSurname.TabIndex = 41
        Me.lbl_StaffSurname.Text = "Last Name :"
        '
        'lbl_StaffFirstname
        '
        Me.lbl_StaffFirstname.AutoSize = True
        Me.lbl_StaffFirstname.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaffFirstname.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_StaffFirstname.Location = New System.Drawing.Point(304, 33)
        Me.lbl_StaffFirstname.Name = "lbl_StaffFirstname"
        Me.lbl_StaffFirstname.Size = New System.Drawing.Size(83, 17)
        Me.lbl_StaffFirstname.TabIndex = 43
        Me.lbl_StaffFirstname.Text = "First Name :"
        '
        'lbl_StaffMiddlename
        '
        Me.lbl_StaffMiddlename.AutoSize = True
        Me.lbl_StaffMiddlename.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaffMiddlename.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_StaffMiddlename.Location = New System.Drawing.Point(561, 33)
        Me.lbl_StaffMiddlename.Name = "lbl_StaffMiddlename"
        Me.lbl_StaffMiddlename.Size = New System.Drawing.Size(91, 17)
        Me.lbl_StaffMiddlename.TabIndex = 42
        Me.lbl_StaffMiddlename.Text = "Middle Name"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.Label13.Location = New System.Drawing.Point(222, 65)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(36, 17)
        Me.Label13.TabIndex = 51
        Me.Label13.Text = "Age "
        '
        'lbl_StaffDOB
        '
        Me.lbl_StaffDOB.AutoSize = True
        Me.lbl_StaffDOB.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaffDOB.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_StaffDOB.Location = New System.Drawing.Point(3, 66)
        Me.lbl_StaffDOB.Name = "lbl_StaffDOB"
        Me.lbl_StaffDOB.Size = New System.Drawing.Size(88, 17)
        Me.lbl_StaffDOB.TabIndex = 49
        Me.lbl_StaffDOB.Text = "Date of Birth"
        '
        'lbl_StaffGender
        '
        Me.lbl_StaffGender.AutoSize = True
        Me.lbl_StaffGender.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaffGender.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_StaffGender.Location = New System.Drawing.Point(15, 107)
        Me.lbl_StaffGender.Name = "lbl_StaffGender"
        Me.lbl_StaffGender.Size = New System.Drawing.Size(60, 17)
        Me.lbl_StaffGender.TabIndex = 45
        Me.lbl_StaffGender.Text = "Gender :"
        '
        'lbl_StaffTitle
        '
        Me.lbl_StaffTitle.AutoSize = True
        Me.lbl_StaffTitle.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaffTitle.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_StaffTitle.Location = New System.Drawing.Point(189, 108)
        Me.lbl_StaffTitle.Name = "lbl_StaffTitle"
        Me.lbl_StaffTitle.Size = New System.Drawing.Size(36, 17)
        Me.lbl_StaffTitle.TabIndex = 46
        Me.lbl_StaffTitle.Text = "Title"
        '
        'lbl_StaffReligion
        '
        Me.lbl_StaffReligion.AutoSize = True
        Me.lbl_StaffReligion.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaffReligion.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_StaffReligion.Location = New System.Drawing.Point(329, 32)
        Me.lbl_StaffReligion.Name = "lbl_StaffReligion"
        Me.lbl_StaffReligion.Size = New System.Drawing.Size(59, 17)
        Me.lbl_StaffReligion.TabIndex = 52
        Me.lbl_StaffReligion.Text = "Region :"
        '
        'lbl_StaffEmail
        '
        Me.lbl_StaffEmail.AutoSize = True
        Me.lbl_StaffEmail.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaffEmail.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_StaffEmail.Location = New System.Drawing.Point(595, 31)
        Me.lbl_StaffEmail.Name = "lbl_StaffEmail"
        Me.lbl_StaffEmail.Size = New System.Drawing.Size(61, 17)
        Me.lbl_StaffEmail.TabIndex = 48
        Me.lbl_StaffEmail.Text = "District :"
        '
        'lbl_StudDept
        '
        Me.lbl_StudDept.AutoSize = True
        Me.lbl_StudDept.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StudDept.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_StudDept.Location = New System.Drawing.Point(61, 28)
        Me.lbl_StudDept.Name = "lbl_StudDept"
        Me.lbl_StudDept.Size = New System.Drawing.Size(82, 17)
        Me.lbl_StudDept.TabIndex = 47
        Me.lbl_StudDept.Text = "Department"
        '
        'lbl_StaffNationality
        '
        Me.lbl_StaffNationality.AutoSize = True
        Me.lbl_StaffNationality.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaffNationality.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_StaffNationality.Location = New System.Drawing.Point(38, 32)
        Me.lbl_StaffNationality.Name = "lbl_StaffNationality"
        Me.lbl_StaffNationality.Size = New System.Drawing.Size(85, 17)
        Me.lbl_StaffNationality.TabIndex = 44
        Me.lbl_StaffNationality.Text = "Nationality :"
        '
        'contactinfo_gb
        '
        Me.contactinfo_gb.Controls.Add(Me.Label12)
        Me.contactinfo_gb.Controls.Add(Me.Label11)
        Me.contactinfo_gb.Controls.Add(Me.Label10)
        Me.contactinfo_gb.Controls.Add(Me.Label9)
        Me.contactinfo_gb.Controls.Add(Me.Label8)
        Me.contactinfo_gb.Controls.Add(Me.txt_Contact_Email)
        Me.contactinfo_gb.Controls.Add(Me.cboContact_Occupation)
        Me.contactinfo_gb.Controls.Add(Me.cboContact_Relation)
        Me.contactinfo_gb.Controls.Add(Me.Label3)
        Me.contactinfo_gb.Controls.Add(Me.txt_Student_Contact_Name)
        Me.contactinfo_gb.Controls.Add(Me.txt_Student_Contact_Address)
        Me.contactinfo_gb.Controls.Add(Me.lbl_StaffConName)
        Me.contactinfo_gb.Controls.Add(Me.lbl_StaffAddress)
        Me.contactinfo_gb.Controls.Add(Me.txt_Student_Contact_Number)
        Me.contactinfo_gb.Controls.Add(Me.lbl_Staffnextrel)
        Me.contactinfo_gb.Controls.Add(Me.lbl_Staffconphone)
        Me.contactinfo_gb.Controls.Add(Me.txt_Student_Contact_WorkNo)
        Me.contactinfo_gb.Controls.Add(Me.lbl_StaffOccup)
        Me.contactinfo_gb.Controls.Add(Me.lbl_Staffconwork)
        Me.contactinfo_gb.Controls.Add(Me.Label1)
        Me.contactinfo_gb.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.contactinfo_gb.ForeColor = System.Drawing.Color.Black
        Me.contactinfo_gb.Location = New System.Drawing.Point(17, 262)
        Me.contactinfo_gb.Name = "contactinfo_gb"
        Me.contactinfo_gb.Size = New System.Drawing.Size(859, 152)
        Me.contactinfo_gb.TabIndex = 53
        Me.contactinfo_gb.TabStop = False
        Me.contactinfo_gb.Text = "Emergency Contact Information"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.Color.Red
        Me.Label12.Location = New System.Drawing.Point(726, 47)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(15, 19)
        Me.Label12.TabIndex = 71
        Me.Label12.Text = "*"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.Red
        Me.Label11.Location = New System.Drawing.Point(419, 81)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(15, 19)
        Me.Label11.TabIndex = 70
        Me.Label11.Text = "*"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.Red
        Me.Label10.Location = New System.Drawing.Point(418, 115)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(15, 19)
        Me.Label10.TabIndex = 69
        Me.Label10.Text = "*"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.Red
        Me.Label9.Location = New System.Drawing.Point(103, 81)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(15, 19)
        Me.Label9.TabIndex = 68
        Me.Label9.Text = "*"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.Red
        Me.Label8.Location = New System.Drawing.Point(106, 51)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(15, 19)
        Me.Label8.TabIndex = 67
        Me.Label8.Text = "*"
        '
        'txt_Contact_Email
        '
        Me.txt_Contact_Email.BackColor = System.Drawing.Color.White
        Me.txt_Contact_Email.CharacterCasing = System.Windows.Forms.CharacterCasing.Lower
        Me.txt_Contact_Email.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Contact_Email.Location = New System.Drawing.Point(434, 49)
        Me.txt_Contact_Email.MaxLength = 350
        Me.txt_Contact_Email.Name = "txt_Contact_Email"
        Me.txt_Contact_Email.Size = New System.Drawing.Size(170, 21)
        Me.txt_Contact_Email.TabIndex = 48
        '
        'cboContact_Occupation
        '
        Me.cboContact_Occupation.BackColor = System.Drawing.Color.White
        Me.cboContact_Occupation.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboContact_Occupation.FormattingEnabled = True
        Me.cboContact_Occupation.Items.AddRange(New Object() {"ACCOUNTANT", "APPRENTICE", "ARCHITECT", "ARMY OFFICER", "ARTISAN", "ASSEMBLYMAN", "AUDITOR", "BAKER", "BANKER", "BEAUTY PRACTITIONER", "BUSINESS ANALYST", "BUSINESSMAN", "CARPENTOR", "CATERER", "CHEF", "CIVIL SERVANT", "CLERGY", "COMPUTER SCIENTIST", "CONSTRUCTION ENGINEER", "DATABASE ADMINISTRATOR", "DESIGNER", "DISPENSING ASSISTANT", "DOCTOR", "DRIVER", "ELECTRICIAN", "FARMER", "FASHION DESIGNER", "FISH MONGER", "FISHERMAN", "FOOD VENDOR", "FOOTBALLER", "FOREIGN DIPLOMAT", "HAIR DRESSER", "HEALTH AID ", "HOUSE WIFE", "IMMIGRATION OFFICER", "LABOURER", "LAWYER", "LEGAL PRACTITIONER", "MASON", "MATRON", "MEDICAL PRACTITIONER", "MINER", "MINING ENGINEER", "MUSICIAN", "NETWORK ADMINISTRATOR", "NETWORK ENGINEER", "NURSE", "OTHER", "PAINTER", "PASTOR", "PENSIONER", "PHARMACIST", "PHARMACY TECHNICIAN", "POLICE OFFICER", "PROGRAMMER", "PUBLIC SERVANT", "RADIO PRESENTER", "REAL ESTATE AGENT", "RECEPTIONIST", "SALES PERSON", "SEAMSTRESS", "SECRETARY", "SECURITY", "STATE MINSTER", "STOCK BROKER", "STORE KEEPER", "SYSTEM ADMINISTRATOR", "TAILOR", "TEACHER", "TRADER", "TRAVEL AGENT", "TYPIST", "UNEMPLOYED"})
        Me.cboContact_Occupation.Location = New System.Drawing.Point(434, 79)
        Me.cboContact_Occupation.Name = "cboContact_Occupation"
        Me.cboContact_Occupation.Size = New System.Drawing.Size(170, 23)
        Me.cboContact_Occupation.TabIndex = 14
        '
        'cboContact_Relation
        '
        Me.cboContact_Relation.BackColor = System.Drawing.Color.White
        Me.cboContact_Relation.DropDownHeight = 75
        Me.cboContact_Relation.DropDownWidth = 75
        Me.cboContact_Relation.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboContact_Relation.FormattingEnabled = True
        Me.cboContact_Relation.IntegralHeight = False
        Me.cboContact_Relation.Items.AddRange(New Object() {"Brother", "Sister", "Father", "Mother", "StepMother", "StepFather", "Aunt", "Uncle", "GrandFather", "GrandMother", "Other"})
        Me.cboContact_Relation.Location = New System.Drawing.Point(435, 113)
        Me.cboContact_Relation.Name = "cboContact_Relation"
        Me.cboContact_Relation.Size = New System.Drawing.Size(170, 23)
        Me.cboContact_Relation.TabIndex = 15
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(7, 17)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(846, 22)
        Me.Label3.TabIndex = 45
        Me.Label3.Text = "Enter Parent / Guardian Details in the Fields Provided Below"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txt_Student_Contact_Name
        '
        Me.txt_Student_Contact_Name.BackColor = System.Drawing.Color.White
        Me.txt_Student_Contact_Name.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txt_Student_Contact_Name.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Student_Contact_Name.Location = New System.Drawing.Point(123, 49)
        Me.txt_Student_Contact_Name.MaxLength = 500
        Me.txt_Student_Contact_Name.Name = "txt_Student_Contact_Name"
        Me.txt_Student_Contact_Name.Size = New System.Drawing.Size(212, 21)
        Me.txt_Student_Contact_Name.TabIndex = 12
        '
        'txt_Student_Contact_Address
        '
        Me.txt_Student_Contact_Address.BackColor = System.Drawing.Color.White
        Me.txt_Student_Contact_Address.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txt_Student_Contact_Address.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Student_Contact_Address.Location = New System.Drawing.Point(625, 67)
        Me.txt_Student_Contact_Address.MaxLength = 500
        Me.txt_Student_Contact_Address.Multiline = True
        Me.txt_Student_Contact_Address.Name = "txt_Student_Contact_Address"
        Me.txt_Student_Contact_Address.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txt_Student_Contact_Address.Size = New System.Drawing.Size(218, 69)
        Me.txt_Student_Contact_Address.TabIndex = 16
        '
        'lbl_StaffConName
        '
        Me.lbl_StaffConName.AutoSize = True
        Me.lbl_StaffConName.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaffConName.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_StaffConName.Location = New System.Drawing.Point(8, 52)
        Me.lbl_StaffConName.Name = "lbl_StaffConName"
        Me.lbl_StaffConName.Size = New System.Drawing.Size(95, 17)
        Me.lbl_StaffConName.TabIndex = 39
        Me.lbl_StaffConName.Text = "Contact Name"
        '
        'lbl_StaffAddress
        '
        Me.lbl_StaffAddress.AutoSize = True
        Me.lbl_StaffAddress.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaffAddress.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_StaffAddress.Location = New System.Drawing.Point(622, 47)
        Me.lbl_StaffAddress.Name = "lbl_StaffAddress"
        Me.lbl_StaffAddress.Size = New System.Drawing.Size(99, 17)
        Me.lbl_StaffAddress.TabIndex = 43
        Me.lbl_StaffAddress.Text = "Postal Address"
        '
        'txt_Student_Contact_Number
        '
        Me.txt_Student_Contact_Number.BackColor = System.Drawing.Color.White
        Me.txt_Student_Contact_Number.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Student_Contact_Number.Location = New System.Drawing.Point(123, 79)
        Me.txt_Student_Contact_Number.MaxLength = 10
        Me.txt_Student_Contact_Number.Name = "txt_Student_Contact_Number"
        Me.txt_Student_Contact_Number.Size = New System.Drawing.Size(212, 21)
        Me.txt_Student_Contact_Number.TabIndex = 13
        '
        'lbl_Staffnextrel
        '
        Me.lbl_Staffnextrel.AutoSize = True
        Me.lbl_Staffnextrel.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_Staffnextrel.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_Staffnextrel.Location = New System.Drawing.Point(353, 114)
        Me.lbl_Staffnextrel.Name = "lbl_Staffnextrel"
        Me.lbl_Staffnextrel.Size = New System.Drawing.Size(67, 17)
        Me.lbl_Staffnextrel.TabIndex = 43
        Me.lbl_Staffnextrel.Text = "Relation :"
        '
        'lbl_Staffconphone
        '
        Me.lbl_Staffconphone.AutoSize = True
        Me.lbl_Staffconphone.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_Staffconphone.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_Staffconphone.Location = New System.Drawing.Point(29, 81)
        Me.lbl_Staffconphone.Name = "lbl_Staffconphone"
        Me.lbl_Staffconphone.Size = New System.Drawing.Size(69, 17)
        Me.lbl_Staffconphone.TabIndex = 40
        Me.lbl_Staffconphone.Text = "Phone No"
        '
        'txt_Student_Contact_WorkNo
        '
        Me.txt_Student_Contact_WorkNo.BackColor = System.Drawing.Color.White
        Me.txt_Student_Contact_WorkNo.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Student_Contact_WorkNo.Location = New System.Drawing.Point(123, 113)
        Me.txt_Student_Contact_WorkNo.MaxLength = 10
        Me.txt_Student_Contact_WorkNo.Name = "txt_Student_Contact_WorkNo"
        Me.txt_Student_Contact_WorkNo.Size = New System.Drawing.Size(212, 21)
        Me.txt_Student_Contact_WorkNo.TabIndex = 48
        '
        'lbl_StaffOccup
        '
        Me.lbl_StaffOccup.AutoSize = True
        Me.lbl_StaffOccup.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaffOccup.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_StaffOccup.Location = New System.Drawing.Point(345, 81)
        Me.lbl_StaffOccup.Name = "lbl_StaffOccup"
        Me.lbl_StaffOccup.Size = New System.Drawing.Size(82, 17)
        Me.lbl_StaffOccup.TabIndex = 41
        Me.lbl_StaffOccup.Text = "Occupation "
        '
        'lbl_Staffconwork
        '
        Me.lbl_Staffconwork.AutoSize = True
        Me.lbl_Staffconwork.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_Staffconwork.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_Staffconwork.Location = New System.Drawing.Point(23, 113)
        Me.lbl_Staffconwork.Name = "lbl_Staffconwork"
        Me.lbl_Staffconwork.Size = New System.Drawing.Size(89, 17)
        Me.lbl_Staffconwork.TabIndex = 42
        Me.lbl_Staffconwork.Text = "Work Tel No "
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.Label1.Location = New System.Drawing.Point(374, 51)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(60, 17)
        Me.Label1.TabIndex = 44
        Me.Label1.Text = "Email ID"
        '
        'address_gb
        '
        Me.address_gb.Controls.Add(Me.cbo_Student_District)
        Me.address_gb.Controls.Add(Me.cbo_Student_Region)
        Me.address_gb.Controls.Add(Me.cbo_Student_Nationality)
        Me.address_gb.Controls.Add(Me.lbl_StaffNationality)
        Me.address_gb.Controls.Add(Me.lbl_StaffReligion)
        Me.address_gb.Controls.Add(Me.lbl_StaffEmail)
        Me.address_gb.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.address_gb.ForeColor = System.Drawing.Color.Black
        Me.address_gb.Location = New System.Drawing.Point(17, 194)
        Me.address_gb.Name = "address_gb"
        Me.address_gb.Size = New System.Drawing.Size(859, 63)
        Me.address_gb.TabIndex = 54
        Me.address_gb.TabStop = False
        Me.address_gb.Text = "Address Details"
        '
        'cbo_Student_District
        '
        Me.cbo_Student_District.BackColor = System.Drawing.Color.White
        Me.cbo_Student_District.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbo_Student_District.FormattingEnabled = True
        Me.cbo_Student_District.Location = New System.Drawing.Point(658, 29)
        Me.cbo_Student_District.Name = "cbo_Student_District"
        Me.cbo_Student_District.Size = New System.Drawing.Size(185, 23)
        Me.cbo_Student_District.TabIndex = 11
        '
        'cbo_Student_Region
        '
        Me.cbo_Student_Region.BackColor = System.Drawing.Color.White
        Me.cbo_Student_Region.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbo_Student_Region.FormattingEnabled = True
        Me.cbo_Student_Region.Items.AddRange(New Object() {"ASHANTI", "BRONG AHAFO", "CENTRAL", "EASTERN", "GREATER ACCRA", "NORTHERN", "UPPER EAST", "UPPER WEST", "VOLTA", "WESTERN"})
        Me.cbo_Student_Region.Location = New System.Drawing.Point(393, 29)
        Me.cbo_Student_Region.Name = "cbo_Student_Region"
        Me.cbo_Student_Region.Size = New System.Drawing.Size(158, 23)
        Me.cbo_Student_Region.TabIndex = 10
        '
        'cbo_Student_Nationality
        '
        Me.cbo_Student_Nationality.BackColor = System.Drawing.Color.White
        Me.cbo_Student_Nationality.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbo_Student_Nationality.FormattingEnabled = True
        Me.cbo_Student_Nationality.Items.AddRange(New Object() {"GHANAIAN", "NON-GHANAIAN"})
        Me.cbo_Student_Nationality.Location = New System.Drawing.Point(125, 30)
        Me.cbo_Student_Nationality.Name = "cbo_Student_Nationality"
        Me.cbo_Student_Nationality.Size = New System.Drawing.Size(161, 23)
        Me.cbo_Student_Nationality.TabIndex = 9
        '
        'registrationinfo_gb
        '
        Me.registrationinfo_gb.Controls.Add(Me.radNo)
        Me.registrationinfo_gb.Controls.Add(Me.radYes)
        Me.registrationinfo_gb.Controls.Add(Me.dtpDate)
        Me.registrationinfo_gb.Controls.Add(Me.Label18)
        Me.registrationinfo_gb.Controls.Add(Me.Label16)
        Me.registrationinfo_gb.Controls.Add(Me.txtFee)
        Me.registrationinfo_gb.Controls.Add(Me.Label19)
        Me.registrationinfo_gb.Controls.Add(Me.Label17)
        Me.registrationinfo_gb.Controls.Add(Me.Label2)
        Me.registrationinfo_gb.Controls.Add(Me.lbl_StudClass)
        Me.registrationinfo_gb.Controls.Add(Me.Label15)
        Me.registrationinfo_gb.Controls.Add(Me.Label20)
        Me.registrationinfo_gb.Controls.Add(Me.Label14)
        Me.registrationinfo_gb.Controls.Add(Me.cboClass)
        Me.registrationinfo_gb.Controls.Add(Me.cboDepartment)
        Me.registrationinfo_gb.Controls.Add(Me.lbl_StudDept)
        Me.registrationinfo_gb.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.registrationinfo_gb.ForeColor = System.Drawing.Color.Black
        Me.registrationinfo_gb.Location = New System.Drawing.Point(17, 417)
        Me.registrationinfo_gb.Name = "registrationinfo_gb"
        Me.registrationinfo_gb.Size = New System.Drawing.Size(859, 119)
        Me.registrationinfo_gb.TabIndex = 55
        Me.registrationinfo_gb.TabStop = False
        Me.registrationinfo_gb.Text = "Admission / Registration Information"
        '
        'radNo
        '
        Me.radNo.AutoSize = True
        Me.radNo.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold)
        Me.radNo.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.radNo.Location = New System.Drawing.Point(654, 60)
        Me.radNo.Name = "radNo"
        Me.radNo.Size = New System.Drawing.Size(44, 21)
        Me.radNo.TabIndex = 75
        Me.radNo.TabStop = True
        Me.radNo.Text = "No"
        Me.radNo.UseVisualStyleBackColor = True
        '
        'radYes
        '
        Me.radYes.AutoSize = True
        Me.radYes.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold)
        Me.radYes.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.radYes.Location = New System.Drawing.Point(593, 60)
        Me.radYes.Name = "radYes"
        Me.radYes.Size = New System.Drawing.Size(46, 21)
        Me.radYes.TabIndex = 20
        Me.radYes.TabStop = True
        Me.radYes.Text = "Yes"
        Me.radYes.UseVisualStyleBackColor = True
        '
        'dtpDate
        '
        Me.dtpDate.Checked = False
        Me.dtpDate.CustomFormat = "dd/MM/yyyy"
        Me.dtpDate.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtpDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpDate.Location = New System.Drawing.Point(175, 88)
        Me.dtpDate.Name = "dtpDate"
        Me.dtpDate.ShowCheckBox = True
        Me.dtpDate.Size = New System.Drawing.Size(195, 21)
        Me.dtpDate.TabIndex = 74
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label18.ForeColor = System.Drawing.Color.Firebrick
        Me.Label18.Location = New System.Drawing.Point(372, 59)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(32, 17)
        Me.Label18.TabIndex = 73
        Me.Label18.Text = "Gh¢"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.ForeColor = System.Drawing.Color.Red
        Me.Label16.Location = New System.Drawing.Point(158, 60)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(15, 19)
        Me.Label16.TabIndex = 72
        Me.Label16.Text = "*"
        '
        'txtFee
        '
        Me.txtFee.BackColor = System.Drawing.Color.White
        Me.txtFee.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFee.Location = New System.Drawing.Point(175, 57)
        Me.txtFee.MaxLength = 10
        Me.txtFee.Name = "txtFee"
        Me.txtFee.Size = New System.Drawing.Size(195, 22)
        Me.txtFee.TabIndex = 19
        Me.txtFee.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.Label19.Location = New System.Drawing.Point(482, 61)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(72, 17)
        Me.Label19.TabIndex = 70
        Me.Label19.Text = "Bus Status"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.Label17.Location = New System.Drawing.Point(61, 59)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(106, 17)
        Me.Label17.TabIndex = 70
        Me.Label17.Text = "Admission Fee :"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.Label2.Location = New System.Drawing.Point(52, 92)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(116, 17)
        Me.Label2.TabIndex = 47
        Me.Label2.Text = "Registration Date"
        '
        'lbl_StudClass
        '
        Me.lbl_StudClass.AutoSize = True
        Me.lbl_StudClass.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StudClass.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_StudClass.Location = New System.Drawing.Point(482, 28)
        Me.lbl_StudClass.Name = "lbl_StudClass"
        Me.lbl_StudClass.Size = New System.Drawing.Size(87, 17)
        Me.lbl_StudClass.TabIndex = 47
        Me.lbl_StudClass.Text = "Class / Stage"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.Color.Red
        Me.Label15.Location = New System.Drawing.Point(159, 29)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(15, 19)
        Me.Label15.TabIndex = 69
        Me.Label15.Text = "*"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.ForeColor = System.Drawing.Color.Red
        Me.Label20.Location = New System.Drawing.Point(560, 64)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(15, 19)
        Me.Label20.TabIndex = 69
        Me.Label20.Text = "*"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.Color.Red
        Me.Label14.Location = New System.Drawing.Point(575, 26)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(15, 19)
        Me.Label14.TabIndex = 69
        Me.Label14.Text = "*"
        '
        'cboClass
        '
        Me.cboClass.BackColor = System.Drawing.Color.White
        Me.cboClass.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboClass.FormattingEnabled = True
        Me.cboClass.Location = New System.Drawing.Point(596, 26)
        Me.cboClass.Name = "cboClass"
        Me.cboClass.Size = New System.Drawing.Size(176, 23)
        Me.cboClass.Sorted = True
        Me.cboClass.TabIndex = 18
        '
        'cboDepartment
        '
        Me.cboDepartment.BackColor = System.Drawing.Color.White
        Me.cboDepartment.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboDepartment.FormattingEnabled = True
        Me.cboDepartment.Location = New System.Drawing.Point(175, 26)
        Me.cboDepartment.Name = "cboDepartment"
        Me.cboDepartment.Size = New System.Drawing.Size(233, 23)
        Me.cboDepartment.TabIndex = 17
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.btn_Cancel_Student_Form)
        Me.GroupBox5.Controls.Add(Me.btn_Find_student_Record)
        Me.GroupBox5.Controls.Add(Me.btn_Clear_Student_Record)
        Me.GroupBox5.Controls.Add(Me.btn_SaveStudentRecord)
        Me.GroupBox5.Location = New System.Drawing.Point(17, 542)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(859, 66)
        Me.GroupBox5.TabIndex = 56
        Me.GroupBox5.TabStop = False
        '
        'btn_Cancel_Student_Form
        '
        Me.btn_Cancel_Student_Form.BackColor = System.Drawing.SystemColors.Control
        Me.btn_Cancel_Student_Form.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_Cancel_Student_Form.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btn_Cancel_Student_Form.Font = New System.Drawing.Font("Tahoma", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Cancel_Student_Form.ForeColor = System.Drawing.Color.SteelBlue
        Me.btn_Cancel_Student_Form.Image = CType(resources.GetObject("btn_Cancel_Student_Form.Image"), System.Drawing.Image)
        Me.btn_Cancel_Student_Form.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_Cancel_Student_Form.Location = New System.Drawing.Point(614, 15)
        Me.btn_Cancel_Student_Form.Name = "btn_Cancel_Student_Form"
        Me.btn_Cancel_Student_Form.Size = New System.Drawing.Size(135, 40)
        Me.btn_Cancel_Student_Form.TabIndex = 13
        Me.btn_Cancel_Student_Form.Text = "&Close"
        Me.btn_Cancel_Student_Form.UseVisualStyleBackColor = False
        '
        'btn_Find_student_Record
        '
        Me.btn_Find_student_Record.BackColor = System.Drawing.SystemColors.Control
        Me.btn_Find_student_Record.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_Find_student_Record.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btn_Find_student_Record.Font = New System.Drawing.Font("Tahoma", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Find_student_Record.ForeColor = System.Drawing.Color.SteelBlue
        Me.btn_Find_student_Record.Image = CType(resources.GetObject("btn_Find_student_Record.Image"), System.Drawing.Image)
        Me.btn_Find_student_Record.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_Find_student_Record.Location = New System.Drawing.Point(446, 15)
        Me.btn_Find_student_Record.Name = "btn_Find_student_Record"
        Me.btn_Find_student_Record.Size = New System.Drawing.Size(135, 40)
        Me.btn_Find_student_Record.TabIndex = 12
        Me.btn_Find_student_Record.Text = "&Find?"
        Me.btn_Find_student_Record.UseVisualStyleBackColor = False
        '
        'btn_Clear_Student_Record
        '
        Me.btn_Clear_Student_Record.BackColor = System.Drawing.SystemColors.Control
        Me.btn_Clear_Student_Record.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_Clear_Student_Record.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btn_Clear_Student_Record.Font = New System.Drawing.Font("Tahoma", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Clear_Student_Record.ForeColor = System.Drawing.Color.SteelBlue
        Me.btn_Clear_Student_Record.Image = CType(resources.GetObject("btn_Clear_Student_Record.Image"), System.Drawing.Image)
        Me.btn_Clear_Student_Record.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_Clear_Student_Record.Location = New System.Drawing.Point(278, 15)
        Me.btn_Clear_Student_Record.Name = "btn_Clear_Student_Record"
        Me.btn_Clear_Student_Record.Size = New System.Drawing.Size(135, 40)
        Me.btn_Clear_Student_Record.TabIndex = 11
        Me.btn_Clear_Student_Record.Text = "&Clear"
        Me.btn_Clear_Student_Record.UseVisualStyleBackColor = False
        '
        'btn_SaveStudentRecord
        '
        Me.btn_SaveStudentRecord.BackColor = System.Drawing.SystemColors.Control
        Me.btn_SaveStudentRecord.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_SaveStudentRecord.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btn_SaveStudentRecord.Font = New System.Drawing.Font("Tahoma", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_SaveStudentRecord.ForeColor = System.Drawing.Color.SteelBlue
        Me.btn_SaveStudentRecord.Image = CType(resources.GetObject("btn_SaveStudentRecord.Image"), System.Drawing.Image)
        Me.btn_SaveStudentRecord.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_SaveStudentRecord.Location = New System.Drawing.Point(110, 15)
        Me.btn_SaveStudentRecord.Name = "btn_SaveStudentRecord"
        Me.btn_SaveStudentRecord.Size = New System.Drawing.Size(135, 40)
        Me.btn_SaveStudentRecord.TabIndex = 10
        Me.btn_SaveStudentRecord.Text = "&Save "
        Me.btn_SaveStudentRecord.UseVisualStyleBackColor = False
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.SteelBlue
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(896, 35)
        Me.Panel1.TabIndex = 86
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Trebuchet MS", 18.0!, System.Drawing.FontStyle.Bold)
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(235, 5)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(377, 29)
        Me.Label4.TabIndex = 12
        Me.Label4.Text = "Student Registration - Admission"
        '
        'frmConfirm_Student_Admission
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(896, 613)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.registrationinfo_gb)
        Me.Controls.Add(Me.address_gb)
        Me.Controls.Add(Me.contactinfo_gb)
        Me.Controls.Add(Me.demograhic_gb)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "frmConfirm_Student_Admission"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "SMIS"
        Me.demograhic_gb.ResumeLayout(False)
        Me.demograhic_gb.PerformLayout()
        Me.contactinfo_gb.ResumeLayout(False)
        Me.contactinfo_gb.PerformLayout()
        Me.address_gb.ResumeLayout(False)
        Me.address_gb.PerformLayout()
        Me.registrationinfo_gb.ResumeLayout(False)
        Me.registrationinfo_gb.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents demograhic_gb As System.Windows.Forms.GroupBox
    Friend WithEvents lblregion As System.Windows.Forms.Label
    Friend WithEvents lbl_StaffHouseno As System.Windows.Forms.Label
    Friend WithEvents lbl_StaffSurname As System.Windows.Forms.Label
    Friend WithEvents lbl_StaffFirstname As System.Windows.Forms.Label
    Friend WithEvents lbl_StaffMiddlename As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents lbl_StaffDOB As System.Windows.Forms.Label
    Friend WithEvents lbl_StaffGender As System.Windows.Forms.Label
    Friend WithEvents lbl_StaffTitle As System.Windows.Forms.Label
    Friend WithEvents lbl_StaffReligion As System.Windows.Forms.Label
    Friend WithEvents lbl_StaffEmail As System.Windows.Forms.Label
    Friend WithEvents lbl_StudDept As System.Windows.Forms.Label
    Friend WithEvents lbl_StaffNationality As System.Windows.Forms.Label
    Friend WithEvents lbl_StaffHometown As System.Windows.Forms.Label
    Friend WithEvents contactinfo_gb As System.Windows.Forms.GroupBox
    Friend WithEvents lbl_Staffconwork As System.Windows.Forms.Label
    Friend WithEvents lbl_StaffOccup As System.Windows.Forms.Label
    Friend WithEvents lbl_StaffConName As System.Windows.Forms.Label
    Friend WithEvents lbl_Staffconphone As System.Windows.Forms.Label
    Friend WithEvents lbl_StaffAddress As System.Windows.Forms.Label
    Friend WithEvents lbl_Staffnextrel As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents address_gb As System.Windows.Forms.GroupBox
    Friend WithEvents registrationinfo_gb As System.Windows.Forms.GroupBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents lbl_StudClass As System.Windows.Forms.Label
    Friend WithEvents txt_Student_Surname As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents txt_Student_Firstname As System.Windows.Forms.TextBox
    Friend WithEvents txt_Student_Hometown As System.Windows.Forms.TextBox
    Friend WithEvents dtpDOB As System.Windows.Forms.DateTimePicker
    Friend WithEvents txt_Student_Middlename As System.Windows.Forms.TextBox
    Friend WithEvents txt_Student_Contact_Name As System.Windows.Forms.TextBox
    Friend WithEvents txt_Student_Contact_Address As System.Windows.Forms.TextBox
    Friend WithEvents txt_StudentLocation As System.Windows.Forms.TextBox
    Friend WithEvents txt_Student_Contact_Number As System.Windows.Forms.TextBox
    Friend WithEvents txt_Student_Contact_WorkNo As System.Windows.Forms.TextBox
    Friend WithEvents txt_Contact_Email As System.Windows.Forms.TextBox
    Friend WithEvents btn_SaveStudentRecord As System.Windows.Forms.Button
    Friend WithEvents btn_Clear_Student_Record As System.Windows.Forms.Button
    Friend WithEvents btn_Find_student_Record As System.Windows.Forms.Button
    Friend WithEvents cbo_Student_Region As System.Windows.Forms.ComboBox
    Friend WithEvents cbo_Student_Nationality As System.Windows.Forms.ComboBox
    Friend WithEvents btn_Cancel_Student_Form As System.Windows.Forms.Button
    Friend WithEvents cbo_Student_Religion As System.Windows.Forms.ComboBox
    Friend WithEvents cboGender As System.Windows.Forms.ComboBox
    Friend WithEvents cboTitle As System.Windows.Forms.ComboBox
    Friend WithEvents cboContact_Occupation As System.Windows.Forms.ComboBox
    Friend WithEvents cboContact_Relation As System.Windows.Forms.ComboBox
    Friend WithEvents cbo_Student_District As System.Windows.Forms.ComboBox
    Friend WithEvents cboClass As System.Windows.Forms.ComboBox
    Friend WithEvents cboDepartment As System.Windows.Forms.ComboBox
    Friend WithEvents txt_student_age As System.Windows.Forms.TextBox
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Private WithEvents Label7 As System.Windows.Forms.Label
    Private WithEvents Label6 As System.Windows.Forms.Label
    Private WithEvents Label5 As System.Windows.Forms.Label
    Private WithEvents Label30 As System.Windows.Forms.Label
    Private WithEvents Label12 As System.Windows.Forms.Label
    Private WithEvents Label11 As System.Windows.Forms.Label
    Private WithEvents Label10 As System.Windows.Forms.Label
    Private WithEvents Label9 As System.Windows.Forms.Label
    Private WithEvents Label8 As System.Windows.Forms.Label
    Private WithEvents Label14 As System.Windows.Forms.Label
    Private WithEvents Label15 As System.Windows.Forms.Label
    Private WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents txtFee As System.Windows.Forms.TextBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents dtpDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents radNo As System.Windows.Forms.RadioButton
    Friend WithEvents radYes As System.Windows.Forms.RadioButton
    Private WithEvents Label20 As System.Windows.Forms.Label
    Private WithEvents Label23 As System.Windows.Forms.Label
    Private WithEvents Label22 As System.Windows.Forms.Label
    Private WithEvents Label21 As System.Windows.Forms.Label
End Class
