﻿Imports System.Data.SqlClient

Public Class frmCheckPayments

    Dim dt As New DataTable


    Public Sub MyDataTable()
        dt.Columns.Add("RegistrationNumber", GetType(String))
        dt.Columns.Add("FirstName", GetType(String))
        dt.Columns.Add("MiddleName", GetType(String))
        dt.Columns.Add("LastName", GetType(String))
        dt.Columns.Add("Year", GetType(String))
        dt.Columns.Add("Term", GetType(String))
        dt.Columns.Add("Amount", GetType(String))
        dt.Columns.Add("DatePaid", GetType(String))

        dgvinfo.DataSource = dt
        
    End Sub

    Sub Addnewrecordtogrid()
        For i = 0 To dgvinfo.Rows.Count - 1
            If i = -1 Then
                Dim dtCurrentTable As New DataTable
                Dim drCurrentRow As DataRow
                If (dtCurrentTable.Rows.Count > 0) Then
                    'add new row to grid
                    drCurrentRow = dtCurrentTable.NewRow()
                   drCurrentRow("Year") = txtYear.Text
                    drCurrentRow("Term") = cboTerm.Text
                    drCurrentRow("DatePaid") = txtYear.Text
                   
                End If
            End If
        Next
    End Sub

    Sub tri()
        'Dim table As New DataTable
        'Dim da As SqlDataAdapter = New SqlDataAdapter("select pID from temp_stock where pID='" & Me.cboproductname.SelectedValue & "'", ModConnection.Connection)
        'da.Fill(table)
        'If table.Rows.Count > 0 Then
        '    'update temporary stocks if productid already exists
        '    Dim commandUpdate As SqlCommand = New SqlCommand("update temp_stock set ReorderLevel=@ReorderLevel, StockOnHand=@StockOnHand  where pID='" & Me.cboproductname.SelectedValue & "'", ModConnection.Connection)
        '    commandUpdate.Parameters.AddWithValue("@ReorderLevel", Me.txtReorderLevel.Text)
        '    commandUpdate.Parameters.AddWithValue("@StockOnHand", Me.txtTotalStock.Text)
        '    commandUpdate.ExecuteNonQuery()
    End Sub

    Sub check()
        'If cboTerm.Text = "Term 1" And cboFeeType.Text = "School Fee" Then
        '    Try
        '        'search fees paid based on selected term
        '        If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
        '        ConnectionModule.con.Open()

        '        Dim cmd As SqlCommand = New SqlCommand("SELECT Year,Term,Amount,DatePaid from SchoolFees where StudentID='" & Me.txtSID.Text & "' and Year='" & Me.txtYear.Text & "' and Term='" & Me.cboTerm.Text & "'", ConnectionModule.con)
        '        Dim rdr As SqlDataReader = cmd.ExecuteReader(CommandBehavior.CloseConnection)
        '        If rdr.Read() Then
        '            While rdr.Read()
        '                dgvinfo.Rows.Add(rdr(0), rdr(1), rdr(2), rdr(3))
        '                DataGridView1.Rows.Add(rdr(0), rdr(1), rdr(2), rdr(3))
        '            End While

        '        End If

        '    Catch ex As Exception
        '        MsgBox(ex.Message)
        '        con.Close()
        '    End Try

        'ElseIf cboTerm.Text = "Term 2" And cboFeeType.Text = "School Fee" Then

        '    Try
        '        'search fees paid based on selected term
        '        If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
        '        ConnectionModule.con.Open()

        '        Dim cmd As SqlCommand = New SqlCommand("SELECT Year,Term,Amount,DatePaid from SchoolFees where StudentID='" & Me.txtSID.Text & "' and Year='" & Me.txtYear.Text & "' and Term='" & Me.cboTerm.Text & "'", ConnectionModule.con)
        '        Dim rdr As SqlDataReader = cmd.ExecuteReader(CommandBehavior.CloseConnection)
        '        If rdr.Read() = True Then
        '            While rdr.Read()
        '                dgvinfo.Rows.Add(rdr(0), rdr(1), rdr(2), rdr(3))
        '                DataGridView1.Rows.Add(rdr(0), rdr(1), rdr(2), rdr(3))

        '            End While
        '        End If



        '    Catch ex As Exception
        '        MsgBox(ex.Message)
        '        con.Close()
        '    End Try

        'ElseIf cboTerm.Text = "Term 3" And cboFeeType.Text = "School Fee" Then
        '    Try
        '        'search fees paid based on selected term
        '        If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
        '        ConnectionModule.con.Open()

        '        Dim cmd As SqlCommand = New SqlCommand("SELECT Year,Term,Amount,DatePaid from SchoolFees where StudentID='" & Me.txtSID.Text & "' and Year='" & Me.txtYear.Text & "' and Term='" & Me.cboTerm.Text & "'", ConnectionModule.con)
        '        Dim rdr As SqlDataReader = cmd.ExecuteReader(CommandBehavior.CloseConnection)
        '        If Not rdr.Read() = True Then
        '            While rdr.Read()
        '                dgvinfo.Rows.Add(rdr(0), rdr(1), rdr(2), rdr(3))
        '                DataGridView1.Rows.Add(rdr(0), rdr(1), rdr(2), rdr(3))

        '                Exit Sub
        '            End While
        '        End If



        '    Catch ex As Exception
        '        MsgBox(ex.Message)
        '        con.Close()
        '    End Try

        'End If

    End Sub

    Sub ClearControls()
        txtRegNo.Clear()
        txtYear.Clear()
        cboTerm.ResetText()
        dgvinfo.Rows.Clear()
        cboYear.ResetText()
        txtRegNo.Focus()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If txtRegNo.Text = "" Then MsgBox("Enter student Registration Number", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "SMIS") : txtRegNo.Focus() : Exit Sub
        'If cboYear.Text = "" Then MsgBox("Enter academic year", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "SIMS") : txtYear.Focus() : Exit Sub
        If cboTerm.Text = "" Then MsgBox("Select Academic Term", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "SMIS") : cboTerm.Focus() : Exit Sub
        If txtYear.Text = "" Then MsgBox("Enter academic year", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "SMIS") : txtYear.Focus() : Exit Sub

        Try
            If cboTerm.Text = "Term 1" Then
                If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                ConnectionModule.con.Open()
                com = New SqlCommand("SELECT DISTINCT(dbo.Students.FirstName + ' ' + dbo.Students.MiddleName + ' ' + dbo.Students.LastName) AS FullName, dbo.Students.Gender, dbo.Students.Class, dbo.SchoolFees.Year, dbo.SchoolFees.Term, dbo.FeesPaid.TotalPaid FROM dbo.Students INNER JOIN dbo.SchoolFees ON dbo.Students.ID = dbo.SchoolFees.StudentID INNER JOIN dbo.FeesPaid ON dbo.Students.ID=dbo.FeesPaid.StudentID where students.RegistrationNumber='" & txtRegNo.Text & "' and schoolfees.Year='" & txtYear.Text & "' and schoolfees.Term='Term 1' ", con)
                dr = com.ExecuteReader(CommandBehavior.CloseConnection)
                dgvinfo.Rows.Clear()
                If dr.HasRows() = True Then
                    While dr.Read()
                        dgvinfo.Rows.Add(dr(0), dr(1), dr(2), dr(3), dr(4), dr(5))
                    End While
                    dr.Close()
                Else
                    MsgBox("No payment record was found", MsgBoxStyle.OkOnly + MsgBoxStyle.Information, "SIMS")
                End If
                Exit Sub
            End If
            If cboTerm.Text = "Term 2" Then
                If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                ConnectionModule.con.Open()
                com = New SqlCommand("SELECT DISTINCT(dbo.Students.FirstName + ' ' + dbo.Students.MiddleName + ' ' + dbo.Students.LastName) AS FullName, dbo.Students.Gender, dbo.Students.Class, dbo.SchoolFees.Year, dbo.SchoolFees.Term, dbo.FeesPaid.TotalPaid FROM dbo.Students INNER JOIN dbo.SchoolFees ON dbo.Students.ID = dbo.SchoolFees.StudentID INNER JOIN dbo.FeesPaid ON dbo.Students.ID=dbo.FeesPaid.StudentID where students.RegistrationNumber='" & txtRegNo.Text & "' and schoolfees.Year='" & txtYear.Text & "' and schoolfees.Term='Term 2' ", con)
                dr = com.ExecuteReader(CommandBehavior.CloseConnection)
                dgvinfo.Rows.Clear()
                If dr.HasRows() = True Then
                    While dr.Read()
                        dgvinfo.Rows.Add(dr(0), dr(1), dr(2), dr(3), dr(4), dr(5))
                    End While
                    dr.Close()
                Else
                    MsgBox("No payment record was found", MsgBoxStyle.OkOnly + MsgBoxStyle.Information, "SIMS")
                End If
                Exit Sub
            End If
            If cboTerm.Text = "Term 3" Then
                If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                ConnectionModule.con.Open()
                com = New SqlCommand("SELECT DISTINCT(dbo.Students.FirstName + ' ' + dbo.Students.MiddleName + ' ' + dbo.Students.LastName) AS FullName, dbo.Students.Gender, dbo.Students.Class, dbo.SchoolFees.Year, dbo.SchoolFees.Term, dbo.FeesPaid.TotalPaid FROM dbo.Students INNER JOIN dbo.SchoolFees ON dbo.Students.ID = dbo.SchoolFees.StudentID INNER JOIN dbo.FeesPaid ON dbo.Students.ID=dbo.FeesPaid.StudentID where students.RegistrationNumber='" & txtRegNo.Text & "' and schoolfees.Year='" & txtYear.Text & "' and schoolfees.Term='Term 3' ", con)
                dr = com.ExecuteReader(CommandBehavior.CloseConnection)
                dgvinfo.Rows.Clear()
                If dr.HasRows() = True Then
                    While dr.Read()
                        dgvinfo.Rows.Add(dr(0), dr(1), dr(2), dr(3), dr(4), dr(5))
                    End While
                    dr.Close()
                Else
                    MsgBox("No payment record was found", MsgBoxStyle.OkOnly + MsgBoxStyle.Information, "SIMS")
                End If
                Exit Sub
            End If

        Catch ex As Exception
            MsgBox(ex.ToString(), MsgBoxStyle.OkOnly + MsgBoxStyle.Exclamation, "error at search")
            con.Close()
        End Try
    End Sub

    Sub examplecodes()

        'Dim table As New DataTable
        'Dim da As SqlDataAdapter = New SqlDataAdapter("select * from vwCheckBusFees where RegistrationNumber='" & Me.txtRegNo.Text & "'", ConnectionModule.con)
        'da.Fill(table)
        'If table.Rows.Count > 0 Then
        '    'search record
        '    Dim cmd As SqlCommand = New SqlCommand("SELECT RTRIM(RegistrationNumber),RTRIM(FirstName), RTRIM(MiddleName), RTRIM(LastName),RTRIM(Gender),RTRIM(Class),RTRIM(Year),RTRIM(Term),RTRIM(Amount),RTRIM(DatePaid) from vwCheckBusFees where RegistrationNumber like '%" & txtRegNo.Text & "%' and Year='" & Me.txtYear.Text & "' and Term='" & Me.cboTerm.Text & "'", ConnectionModule.con)
        '    Dim rdr As SqlDataReader = cmd.ExecuteReader(CommandBehavior.CloseConnection)
        '    If rdr.HasRows Then
        '        While rdr.Read() = True
        '            dgvinfo.Rows.Add(rdr(2) + " " + rdr(3) + "  " + rdr(4), rdr(5), rdr(6), rdr(7), rdr(8), rdr(9))

        '        End While
        '    Else
        '        MsgBox("Record Does Not Exists!")
        '    End If

        '    con.Close()
        'End If

        'Dim dst As Data.DataSet = New Data.DataSet
        'Dim dtAdpt As SqlDataAdapter = New SqlDataAdapter
        'dst.Clear()

        'dtAdpt.SelectCommand = New SqlCommand("SELECT FirstName,MiddleName,LastName,Gender,Class,Year,TermAmount,DatePaid FROM vwCheckSchoolFees where RegistrationNumber='" & Me.txtRegNo.Text & "' and Year='" & Me.txtYear.Text & "'", con)

        'dtAdpt.Fill(dst, "vwCheckSchoolFees")

        'dgvinfo.DataSource = dst.Tables("vwCheckSchoolFees")
        'dgvinfo.Refresh()

        'Dim cmd As SqlCommand = New SqlCommand("SELECT dbo.Students.ID, dbo.Students.RegistrationNumber, dbo.Students.FirstName, dbo.Students.MiddleName, dbo.Students.LastName, dbo.Students.Class, dbo.BusFees.Year, dbo.BusFees.Term, dbo.BusFees.Amount, dbo.BusFees.DatePaid FROM dbo.BusFees INNER JOIN dbo.Students ON dbo.BusFees.ID = dbo.Students.ID where RegistrationNumber like '%" & txtRegNo.Text & "%' and Year ='" & txtYear.Text & "' and Term='" & cboTerm.Text & "'", ConnectionModule.con)
        '' Dim cmd = New SqlCommand("SELECT RTRIM(RegistrationNumber),RTRIM(FirstName), RTRIM(MiddleName), RTRIM(LastName),RTRIM(Gender),RTRIM(Class),RTRIM(Year),RTRIM(Term),RTRIM(Amount),RTRIM(DatePaid) from vwCheckBusFees where RegistrationNumber like '%" & txtRegNo.Text & "%'", ConnectionModule.con)
        'Dim rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection)
        'dgvinfo.Rows.Clear()
        'While (rdr.Read() = True)
        '    dgvinfo.Rows.Add(rdr(2) + " " + rdr(3) + "  " + rdr(4), rdr(5), rdr(6), rdr(7), rdr(8), rdr(9))
        '    ' dgvinfo.Rows.Add(rdr("FirstName") + " " + rdr("MiddleName") + " " + rdr("LastName"), rdr("Age"), rdr("Class"), rdr("Year"), rdr("Term"), rdr("Amount"), rdr("DatePaid"))
        'End While
        'con.Close()


        'Dim table As New DataTable
        'Dim da As SqlDataAdapter = New SqlDataAdapter("select * from SchoolFees where StudentID='" & Me.txtSID.Text & "'", ConnectionModule.con)
        'da.Fill(table)
        'If table.Rows.Count > 0 Then
        'search record

        'select fee payment when school fee is selected
        'If cboFeeType.Text = "School Fee" Then
        '    Try
        '        If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
        '        ConnectionModule.con.Open()
        '        Dim cmd As SqlCommand = New SqlCommand("SELECT dbo.Students.ID, dbo.Students.RegistrationNumber, dbo.Students.FirstName, dbo.Students.MiddleName, dbo.Students.LastName, dbo.Students.Gender, dbo.Students.Class, dbo.SchoolFees.Year, dbo.SchoolFees.Term, dbo.SchoolFees.Amount, dbo.SchoolFees.DatePaid FROM dbo.SchoolFees INNER JOIN dbo.Students ON dbo.SchoolFees.ID = dbo.Students.ID where RegistrationNumber like '%" & txtRegNo.Text & "%' and Year like '%" & txtYear.Text & "%' and Term='" & cboTerm.Text & "'", ConnectionModule.con)
        '        ' Dim cmd = New SqlCommand("SELECT RTRIM(RegistrationNumber),RTRIM(FirstName), RTRIM(MiddleName), RTRIM(LastName),RTRIM(Gender),RTRIM(Class),RTRIM(Year),RTRIM(Term),RTRIM(Amount),RTRIM(DatePaid) from vwCheckSchoolFees where RegistrationNumber like '%" & txtRegNo.Text & "%'", ConnectionModule.con)
        '        Dim rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection)
        '        dgvinfo.Rows.Clear()
        '        While (rdr.Read() = True)
        '            dgvinfo.Rows.Add(rdr(1), rdr(2), +" " + rdr(3) + "  " + rdr(4), rdr(5), rdr(6), rdr(7), rdr(8), rdr(9))
        '        End While
        '        con.Close()

        '    Catch ex As Exception

        '    End Try
        'End If
    End Sub

    Private Sub frmCheckPayments_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ActiveControl = Me.txtRegNo

        'MyDataTable()
        Addnewrecordtogrid()

        
    End Sub

    Public Sub AddAcademicYear()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            dset = New Data.DataSet()
            adapter = New SqlDataAdapter()
            adapter.SelectCommand = New SqlCommand("select ID,New from AcademicYear order by New", ConnectionModule.con)
            dset.Clear()
            adapter.Fill(dset, "AcademicYear")
            cboYear.DataSource = dset.Tables("AcademicYear")
            cboYear.DisplayMember = "New"
            cboYear.ValueMember = "ID"
            cboYear.Refresh()
            cboYear.SelectedIndex = -1
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at add academic info")
            con.Close()
        End Try
    End Sub


    Private Sub txtRegNo_TextChanged(sender As Object, e As EventArgs) Handles txtRegNo.TextChanged
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()

            Dim cmd As SqlCommand = New SqlCommand("select * from Students where RegistrationNumber='" & Me.txtRegNo.Text & "'", ConnectionModule.con)
            Dim reader As SqlDataReader = cmd.ExecuteReader(CommandBehavior.CloseConnection)
            If (reader.Read()) Then
                txtSID.Text = reader.GetValue(0)
                SearchId = reader.GetValue(0)
            End If
            cmd.Dispose()

        Catch ex As Exception
            MsgBox(ex.Message)
            con.Close()
        End Try
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        ClearControls()
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub

    Private Sub cboYear_DropDown(sender As Object, e As EventArgs) Handles cboYear.DropDown
        AddAcademicYear()
    End Sub

  
    Private Sub cboYear_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboYear.SelectedIndexChanged
       
    End Sub

    
End Class