﻿Imports System.Data.SqlClient
Imports System.Threading

Public Class FeePayment
    Dim studid As Integer

    Private Sub FeePayment_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub GroupBox3_Enter(sender As Object, e As EventArgs) Handles GroupBox3.Enter

    End Sub

    Private Sub registrationinfo_gb_Enter(sender As Object, e As EventArgs) Handles registrationinfo_gb.Enter

    End Sub

    Private Sub btnHelp_Click(sender As Object, e As EventArgs) Handles btnHelp.Click
        If txtRegNo.Text = "" Then
            MsgBox("Please, enter the student registration number.", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "SIMS")
            txtRegNo.Focus()
            Exit Sub
        End If


        Try
            'clear textfields for new results
            'txtClass.Text = ""
            'txtDept.Text = ""
            'txtNationality.Text = ""
            'txtGender.Text = ""
            'txtStudentName.Text = ""
            Cursor = Cursors.WaitCursor
            Timer1.Enabled = True
            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            query = "select id, firstname + SPACE(1) + middlename + SPACE(1) + lastname as name, gender,nationality,department,class from Students where RegistrationNumber =@d1"
            com1 = New SqlCommand(query, con)
            com1.Parameters.AddWithValue("@d1", txtRegNo.Text)
            dr = com1.ExecuteReader(CommandBehavior.CloseConnection)
            If dr.Read() = True Then
                studid = dr(0).ToString()
                txtStudentName.Text = dr(1).ToString()
                txtGender.Text = dr(2).ToString()
                txtNationality.Text = dr(3).ToString()
                txtDept.Text = dr(4).ToString()
                txtClass.Text = dr(5).ToString()
                btnSave.Enabled = True
                Cursor = Cursors.Default
                Timer1.Enabled = False
                dr.Close()
                com1.Dispose()
                Exit Sub
            Else
                MsgBox("The student registration number you entered is invalid, please check..", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "Error")
                Exit Sub
            End If
            con.Close()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

        'End If

    End Sub

    Private Sub btnGetFee_Click(sender As Object, e As EventArgs) Handles btnGetFee.Click
        If txtClass.Text = "" Then
            MsgBox("Student information incomplete, please check and fill. NB- Specify the class of student.", MsgBoxStyle.OkOnly + MsgBoxStyle.Exclamation, "SIMS")
            Exit Sub
        End If
        'do nothing

        Try
            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            query = "select feename,amount from fees where class=@d1"
            com = New SqlCommand(query, con)
            com.Parameters.AddWithValue("@d1", txtClass.Text)
            dr = com.ExecuteReader(CommandBehavior.CloseConnection)
            If dr.Read() = True Then
                cboFeeType.Text = dr(0).ToString()
                'txtFee.Text = dr(1).ToString()
                txtFee.Text = Format(dr.GetValue(1), "#,##0.00")
                dr.Close()
                Exit Sub
            Else
                MsgBox("Sorry... No fees record could be fetched for the search criteria;" + vbNewLine + "Please make sure school fees specification of classes are set/save in the 'Fee Settings'..", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "Search Error") : Exit Sub
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub btnclear_Click(sender As Object, e As EventArgs) Handles btnclear.Click
        If MsgBox("Clear the form?", MsgBoxStyle.YesNo + MsgBoxStyle.Question, "SMIS") = MsgBoxResult.Yes Then
            Clearme()
        End If
    End Sub
    Sub CurrentFeesPaid()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            com = New SqlCommand("select StudID from FeesHistory where StudID='" & studid & "'", ConnectionModule.con)
            dr = com.ExecuteReader(CommandBehavior.CloseConnection)
            If dr.Read() = True Then
                dr.Close()
                con.Close()
                com1 = New SqlCommand("update FeesHistory set GrandTotal=GrandTotal + ('" & Format(Val(txtFee.Text), "#,##0.00") & "'), TotalPaid=TotalPaid + ('" & Format(Val(txtFeeAmount.Text), "#,##0.00") & "') where StudID=@d1", ConnectionModule.con)
                com1.Parameters.AddWithValue("@d1", studid)
                con.Open()
                com1.ExecuteNonQuery()
                con.Close()
            Else
                If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                ConnectionModule.con.Open()
                com = New SqlCommand("insert into FeesHistory (StudID,GrandTotal,TotalPaid) values (@d1,@d2,@d3)", ConnectionModule.con)
                com.Parameters.AddWithValue("@d1", studid)
                com.Parameters.AddWithValue("@d2", Format(Val(txtFee.Text), "#,##0.00"))
                com.Parameters.AddWithValue("@d3", Format(Val(txtFeeAmount.Text), "#,##0.00"))
                com.ExecuteNonQuery()
                con.Close()
            End If

        Catch ex As Exception
            MsgBox(ex.ToString(), MsgBoxStyle.OkOnly + MsgBoxStyle.Critical, "error at currentfeepaid")
        End Try
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        If txtPayeeName.Text = "" Then MsgBox("Enter the name of the payer", MsgBoxStyle.OkOnly + MsgBoxStyle.Exclamation, "Error") : txtPayeeName.Focus() : Exit Sub
        If txtPayeeMobile.Text = "" Then MsgBox("Enter the mobile number of the payer", MsgBoxStyle.OkOnly + MsgBoxStyle.Exclamation, "Error") : txtPayeeMobile.Focus() : Exit Sub
        If cboYear.Text = "" Then MsgBox("Specify academic year", MsgBoxStyle.OkOnly + MsgBoxStyle.Exclamation, "Error") : cboYear.Focus() : Exit Sub
        If cboTerm.Text = "" Then MsgBox("Specify school term", MsgBoxStyle.OkOnly + MsgBoxStyle.Exclamation, "Error") : cboTerm.Focus() : Exit Sub
        If txtFeeAmount.Text = "" Then MsgBox("Fee paying amount is required.", MsgBoxStyle.OkOnly + MsgBoxStyle.Exclamation, "Error") : txtFeeAmount.Focus() : Exit Sub
        If cboPayMode.Text = "" Then MsgBox("Specify the payment mode", MsgBoxStyle.OkOnly + MsgBoxStyle.Exclamation, "Error") : cboPayMode.Focus() : Exit Sub
        If Not txtPayeeMobile.Text.StartsWith("0") Then
            MessageBox.Show("Invalid payee mobile number, must start with zero(0)", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            txtPayeeMobile.Focus()
            txtPayeeMobile.SelectAll()
            Exit Sub
        End If
        If txtPayeeMobile.TextLength < 10 Then
            MessageBox.Show("Payee mobile number must be 10-digits", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            txtPayeeMobile.Focus()
            txtPayeeMobile.SelectAll()
            Exit Sub
        End If

        If MsgBox("Are you sure you want to save fees payment?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "Confirmation") = MsgBoxResult.Yes Then
            Try
                If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                ConnectionModule.con.Open()
                com = New SqlCommand("insert into FeesPayment (StudID,FeeAmount,AcaYear,Term,PaymentDate,PaymentMode,PayeeName,PayeeTel,ServicedBy) values (@d1,@d2,@d3,@d4,@d5,@d6,@d7,@d8,@d9)", ConnectionModule.con)
                com.Parameters.AddWithValue("@d1", studid)
                com.Parameters.AddWithValue("@d2", Format(Val(txtFeeAmount.Text), "#,##0.00"))
                com.Parameters.AddWithValue("@d3", cboYear.Text)
                com.Parameters.AddWithValue("@d4", cboTerm.Text)
                com.Parameters.AddWithValue("@d5", Date.Now)
                com.Parameters.AddWithValue("@d6", cboPayMode.Text)
                com.Parameters.AddWithValue("@d7", txtPayeeName.Text)
                com.Parameters.AddWithValue("@d8", txtPayeeMobile.Text)
                com.Parameters.AddWithValue("@d9", LogName)   'or logname
                com.ExecuteNonQuery()
                CurrentFeesPaid()
                MsgBox("Transaction successfully saved", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Success")
                Clearme()

            Catch ex As Exception
                MsgBox(ex.Message)
                con.Close()
            End Try
        End If
    End Sub

    Public Sub AcademicYear()
        Try
            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            dset = New Data.DataSet()
            adapter = New SqlDataAdapter()
            adapter.SelectCommand = New SqlCommand("select distinct year from session order by year desc", ConnectionModule.con)
            dset.Clear()
            adapter.Fill(dset, "session")
            cboYear.DataSource = dset.Tables("session")
            cboYear.DisplayMember = "year"
            cboYear.Refresh()
            cboYear.SelectedIndex = -1
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at get academicyear")
            con.Close()
        End Try
    End Sub
    Public Sub AcademicTerm()
        Try
            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            dset = New Data.DataSet()
            adapter = New SqlDataAdapter()
            adapter.SelectCommand = New SqlCommand("select distinct term from session order by term asc", ConnectionModule.con)
            dset.Clear()
            adapter.Fill(dset, "session")
            cboTerm.DataSource = dset.Tables("session")
            cboTerm.DisplayMember = "term"
            cboTerm.Refresh()
            cboTerm.SelectedIndex = -1
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at get academicterm")
            con.Close()
        End Try
    End Sub
    Private Sub PaymentMode()
        Try
            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            dset = New Data.DataSet()
            adapter = New SqlDataAdapter()
            adapter.SelectCommand = New SqlCommand("select distinct paymode from payment order by paymode asc", ConnectionModule.con)
            dset.Clear()
            adapter.Fill(dset, "paymentmode")
            cboTerm.DataSource = dset.Tables("paymentmode")
            cboTerm.DisplayMember = "paymode"
            cboTerm.Refresh()
            cboTerm.SelectedIndex = -1
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at get paymode")
            con.Close()
        End Try
    End Sub

    Sub Clearme()
        txtID.Clear()
        txtRegNo.Clear()
        txtStudentName.Clear()
        txtNationality.Clear()
        txtDept.Clear()
        txtClass.Clear()
        txtGender.Clear()
        txtFeeAmount.Clear()
        cboTerm.ResetText()
        txtPayeeName.Clear()
        txtPayeeMobile.Clear()
        txtFee.Clear()
        cboFeeType.ResetText()
        cboYear.ResetText()
        cboPayMode.ResetText()
        txtRegNo.Focus()
        btnSave.Enabled = False
    End Sub

    Private Sub txtFeeAmount_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtFeeAmount.KeyPress
        If Asc(e.KeyChar) <> 13 AndAlso Asc(e.KeyChar) <> 8 AndAlso Not IsNumeric(e.KeyChar) AndAlso Asc(e.KeyChar) <> 46 Then
            e.Handled = True
        Else
            e.Handled = False
        End If
    End Sub

    Private Sub txtFeeAmount_TextChanged(sender As Object, e As EventArgs) Handles txtFeeAmount.TextChanged
        If txtFeeAmount.TextLength <> 0 AndAlso cboYear.Text <> "" AndAlso cboTerm.Text <> "" Then
            btnReceipt.Enabled = True
        Else
            btnReceipt.Enabled = False
        End If
    End Sub

    Private Sub cboTerm_DropDown(sender As Object, e As EventArgs) Handles cboTerm.DropDown
        AcademicTerm()
    End Sub

    Private Sub cboTerm_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboTerm.SelectedIndexChanged

    End Sub

    Private Sub cboYear_DropDown(sender As Object, e As EventArgs) Handles cboYear.DropDown
        AcademicYear()
    End Sub

    Private Sub cboPayMode_DropDown(sender As Object, e As EventArgs) Handles cboPayMode.DropDown

    End Sub

    Private Sub txtPayeeMobile_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtPayeeMobile.KeyPress
        If Asc(e.KeyChar) <> 13 AndAlso Asc(e.KeyChar) <> 8 And Not IsNumeric(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub

    Private Sub txtPayeeMobile_TextChanged(sender As Object, e As EventArgs) Handles txtPayeeMobile.TextChanged

    End Sub

    Private Sub txtPayeeName_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtPayeeName.KeyPress
        Select Case Asc(e.KeyChar)
            Case 8, 32, 65 To 90, 97 To 122
                e.Handled = False
            Case Else
                e.Handled = True
        End Select
    End Sub

    Private Sub txtPayeeName_TextChanged(sender As Object, e As EventArgs) Handles txtPayeeName.TextChanged

    End Sub

    Private Sub txtRegNo_TextChanged(sender As Object, e As EventArgs) Handles txtRegNo.TextChanged
        If txtRegNo.Text <> "" Then
            'do nothing
        Else
            txtClass.Clear()
            txtDept.Clear()
            txtStudentName.Clear()
            txtGender.Clear()
            txtNationality.Clear()
            btnSave.Enabled = False
            Exit Sub
        End If
    End Sub

    Private Sub btnReceipt_Click(sender As Object, e As EventArgs) Handles btnReceipt.Click
        Try
            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            query = "select name,telephone,address from schoolinfo"
            Dim st As String
            com = New SqlCommand(query, con)
            dr = com.ExecuteReader(CommandBehavior.CloseConnection)
            dr.Read()
            'While dr.Read()
            Receipt.lblSchoolName.Text = dr.GetValue(0)
            Receipt.lblTelephone.Text = dr.GetValue(1)
            Receipt.lblAddress.Text = dr.GetValue(2)
            Receipt.lblName.Text = Me.txtStudentName.Text
            Receipt.lblClass.Text = Me.txtClass.Text
            Receipt.lblYear.Text = cboYear.Text
            Receipt.lblTerm.Text = cboTerm.Text
            Receipt.lblFeeType.Text = Me.cboFeeType.Text
            Receipt.lblDate.Text = System.DateTime.Now
            Receipt.ShowDialog()
            'End While

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub GroupBox2_Enter(sender As Object, e As EventArgs) Handles GroupBox2.Enter

    End Sub
End Class