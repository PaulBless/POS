﻿
Imports System.Data.SqlClient
'Imports System.Drawing.Bitmap
'Imports System.Drawing.Graphics
'Imports System.Drawing.Image


Public Class NewStaffRegistration

    Private Sub NewStaffRegistration_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'automatic set of combobox
        cboStaffnationality.SelectedIndex = 0
        cboStaffregion.SelectedIndex = 9
    End Sub
    Private Sub NewStaffRegistration_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        Dim res = MessageBox.Show("Are you sure you want to close form?", "SIMS Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Error)
        If res = Windows.Forms.DialogResult.Yes Then
            e.Cancel = False
        End If
        If res = Windows.Forms.DialogResult.No Then
            e.Cancel = True
        End If
    End Sub
    Private Sub dtpStaff_ValueChanged(sender As Object, e As EventArgs) Handles dtpStaff.ValueChanged
        'this code calculate age of staff from date of birth using the datetimepicker
        Dim staffage As New Integer
        staffage = DateTime.Today.Year - dtpStaff.Value.Year
        txtstaffage.Text = staffage.ToString()
    End Sub

    Private Sub btnClearStaffpic_Click(sender As Object, e As EventArgs) Handles btnClearStaffpic.Click
        'code to clear the staff image if not wanted in form
        pboStaffimage.Image = Nothing
        TextBox1.Clear()
    End Sub

    Private Sub btnUploadStaffpic_Click(sender As Object, e As EventArgs) Handles btnUploadStaffpic.Click
        'code to upload an image of staff
        With OpenFileDialog1
            .Title = "Select Employee Picture"
            .Filter = ("Images |*.png; *.bmp; *.jpg;*.jpeg; *.gif;")
            .Multiselect = False
            .InitialDirectory = "@C:\"
            .FileName = ""
            .ShowDialog()
            If .FileName <> "" Then
                pboStaffimage.Load(.FileName.ToString())
                TextBox1.Text = pboStaffimage.ImageLocation()
            End If
        End With

    End Sub
    Private Sub cboStaffgender_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboStaffgender.SelectedIndexChanged
        'If cboStaffgender.SelectedIndex = 0 Then
        '    Me.cboStafftitle.SelectedIndex = 1
        'ElseIf cboStaffcategory.SelectedIndex = 1 Then
        '    Me.cboStafftitle.SelectedIndex = 0
        'End If
    End Sub


    Private Sub b_Click(sender As Object, e As EventArgs) Handles b.Click
        'close the form
        Me.Close()
    End Sub

    Private Sub btnClearStaff_Click(sender As Object, e As EventArgs) Handles btnClearStaff.Click
        Dim clear As MsgBoxResult = MsgBox("Clear the form?", MsgBoxStyle.YesNo + MsgBoxStyle.Information)
        If clear = MsgBoxResult.Yes Then
           
            Dim ctrl As Control
            For Each ctrl In gbostaffinfo.Controls
                If TypeOf ctrl Is TextBox Then
                    ctrl.Text = ""
                ElseIf TypeOf ctrl Is DateTimePicker Then
                    ctrl.Text = DateTime.Today
                ElseIf TypeOf ctrl Is ComboBox Then
                    ctrl.Text = ""
                End If
            Next
            For Each ctrl In gbocontactinfo.Controls
                If TypeOf ctrl Is TextBox Then
                    ctrl.Text = ""
                ElseIf TypeOf ctrl Is ComboBox Then
                    ctrl.Text = ""
                End If
            Next
            For Each ctrl In gbonextofkininfo.Controls
                If TypeOf ctrl Is TextBox Then
                    ctrl.Text = String.Empty
                ElseIf TypeOf ctrl Is ComboBox Then
                    ctrl.ResetText()
                End If
            Next
            For Each ctrl In gbojobdetails.Controls
                If TypeOf ctrl Is TextBox Then
                    ctrl.Text = ""
                ElseIf TypeOf ctrl Is ComboBox Then
                    ctrl.ResetText()
                End If
            Next
        Else
            If clear = MsgBoxResult.No Then
                Me.Show()
            End If
        End If
    End Sub



    Private Sub cboStaffcategory_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboStaffcategory.SelectedIndexChanged
        'Select Case cboStaffcategory.SelectedIndex
        '    Case 0
        '        cbostaffjob.Items.Add("Accountant")
        '        cbostaffjob.Items.Add("Director")
        '        cbostaffjob.Items.Add("Head Teacher")
        '        cbostaffjob.Items.Add("Proprietor")
        '        cbostaffjob.Items.Add("Secretary")
        '        cbostaffjob.ResetText()
        '        Exit Select
        '    Case 1
        '        cbostaffjob.Items.Add("Cook")
        '        cbostaffjob.Items.Add("Driver")
        '        cbostaffjob.Items.Add("Orderly")
        '        cbostaffjob.Items.Add("Security")
        '        cbostaffjob.ResetText()
        '        Exit Select

        '    Case 2
        '        cbostaffjob.Items.Add("Assist HeadTeacher")
        '        cbostaffjob.Items.Add("Class Teacher")
        '        cbostaffjob.Items.Add("Form Master")
        '        cbostaffjob.ResetText()
        '        Exit Select
        'End Select
    End Sub

    Private Sub cboStafftitle_Enter(sender As Object, e As EventArgs) Handles cboStafftitle.Enter
        If cboStaffgender.Text = "" Then
            MsgBox("You must select gender", MsgBoxStyle.Information)
            cboStaffgender.Focus()
        End If
    End Sub

    Private Sub btnFindStaff_Click(sender As Object, e As EventArgs) Handles btnFindStaff.Click
        'open form to search for staff/employee
        StaffSearch.Show()
    End Sub
    Private Sub btnSaveStaff_Click_1(sender As Object, e As EventArgs) Handles btnSaveStaff.Click
        'check for empty fields in the form
        If txtStaffsurname.Text = "" Or txtStafffirstname.Text = "" Or txtStaffemail.Text = "" Or txtContactname.Text = "" Or txtStaffemail.Text = "" Then
            MsgBox("Please fill all required fields", MsgBoxStyle.Information + MsgBoxStyle.OkOnly)
            txtNextkinno.Focus()
            Exit Sub
        ElseIf cboStaffqualification.Text = "" Or cboStaffcategory.Text = "" Or cboSaffdepartment.Text = "" Or cbostaffjob.Text = "" Or cboStaffgender.Text = "" Or cboStaffmaritalstatus.Text = "" Then
            MsgBox("Provide all necessary information", MsgBoxStyle.OkOnly + MsgBoxStyle.Information)
            cboStaffgender.Focus()
            Exit Sub
        ElseIf dtpStaff.Value = DateTime.Today Then
            MsgBox("Enter staff date of birth", MsgBoxStyle.OkOnly + MsgBoxStyle.Information)
            dtpStaff.Focus()
            Exit Sub
            'ElseIf Not IsNumeric(txtStaffphone.Text) And (txtContactphone.Text) Then
            '    MsgBox("Please enter a numeric value for phone number", MsgBoxStyle.OkOnly + MsgBoxStyle.Exclamation)
            '    txtContactphone.Focus()
            '    Exit Sub
        Else

            'Dim imagebt As New Byte
            'Dim fs As FileStream = New FileStream(Me.TextBox1.Text, FileMode.Open, FileAccess.Read)
            'Dim br As BinaryReader = New BinaryReader(fs)
            ''imagebt = br.ReadBytes(fs.Length)

            Dim ans As DialogResult = MessageBox.Show("Are You Sure You Want To Save This Record?", "Confirm Save", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
            If ans = Windows.Forms.DialogResult.Yes Then
                Try
                    If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                    ConnectionModule.con.Open()

                    Dim comdSave As SqlCommand = New SqlCommand("insert into Staff(FirstName,MiddleName,LastName,StaffID,Gender,Title,DOB,Age,Email,PhoneNumber,HouseNo,BirthPlace,Hometown,Nationality,Religion,Address,Region,Qualification,Department,Position,SSNIT,DateEmployed,ContactName,ContactNumber,ContactOccupation,ContactHouseNo,MaritalStatus,Category,KinName,KinNumber,KinRelation) values (@FirstName,@MiddleName,@LastName,@StaffID,@Gender,@Title,@DOB,@Age,@Email,@PhoneNumber,@HouseNo,@BirthPlace,@Hometown,@Nationality,@Religion,@Address,@Region,@Qualification,@Department,@Position,@SSNIT,@DateEmployed,@ContactName,@ContactNumber,@ContactOccupation,@ContactHouseNo,@MaritalStatus,@Category,@KinName,@KinNumber,@KinRelation)", ConnectionModule.con)

                    comdSave.Parameters.AddWithValue("@FirstName", txtStafffirstname.Text)
                    comdSave.Parameters.AddWithValue("@MiddleName", txtStaffmiddlename.Text)
                    comdSave.Parameters.AddWithValue("@LastName", txtStaffsurname.Text)
                    ' comdSave.Parameters.AddWithValue("@StaffID", txtStaffid.Text)
                    comdSave.Parameters.AddWithValue("@Gender", cboStaffgender.Text)
                    comdSave.Parameters.AddWithValue("@Title", cboStafftitle.Text)
                    comdSave.Parameters.AddWithValue("@DOB", dtpStaff.Text)
                    comdSave.Parameters.AddWithValue("@Age", txtstaffage.Text)
                    comdSave.Parameters.AddWithValue("@Email", txtStaffemail.Text)
                    comdSave.Parameters.AddWithValue("@PhoneNumber", txtStaffphone.Text)
                    comdSave.Parameters.AddWithValue("@HouseNo", txthouseno.Text)
                    comdSave.Parameters.AddWithValue("@BirthPlace", txtStaffbirthplace.Text)
                    comdSave.Parameters.AddWithValue("@Hometown", txtStaffhometown.Text)
                    comdSave.Parameters.AddWithValue("@Nationality", cboStaffnationality.Text)
                    comdSave.Parameters.AddWithValue("@Religion", txtStaffhometown.Text)
                    comdSave.Parameters.AddWithValue("@Address", txtStaffaddress.Text)
                    comdSave.Parameters.AddWithValue("@Region", cboStaffregion.Text)
                    comdSave.Parameters.AddWithValue("@Qualification", cboStaffqualification.Text)
                    comdSave.Parameters.AddWithValue("@Department", cboSaffdepartment.Text)
                    comdSave.Parameters.AddWithValue("@Position", cbostaffjob.Text)
                    comdSave.Parameters.AddWithValue("@SSNIT", txtStaffSsnit.Text)
                    ' comdSave.Parameters.AddWithValue("@DateEmployed", dtpStaffemploydate.Text)
                    'comdSave.Parameters.AddWithValue("@Picture", pboStaffimage.Image)
                    'comdSave.Parameters.Add("@Picture", imaagebt)
                    comdSave.Parameters.AddWithValue("@ContactName", txtContactname.Text)
                    comdSave.Parameters.AddWithValue("@ContactNumber", txtContactphone.Text)
                    comdSave.Parameters.AddWithValue("@ContactOccupation", cboContactoccupation.Text)
                    comdSave.Parameters.AddWithValue("@ContactHouseNo", txtContacthouse.Text)
                    comdSave.Parameters.AddWithValue("@ContactTown", txlocality.Text)
                    comdSave.Parameters.AddWithValue("@MaritalStatus", cboStaffmaritalstatus.Text)
                    comdSave.Parameters.AddWithValue("@Category", cboStaffcategory.Text)
                    comdSave.Parameters.AddWithValue("@KinName", txtNextofkin.Text)
                    comdSave.Parameters.AddWithValue("@KinNumber", txtNextkinno.Text)
                    comdSave.Parameters.AddWithValue("@KinRelation", cbostaffrel.Text)

                    comdSave.ExecuteNonQuery()

                    MessageBox.Show("New Employee Record Saved Successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1)
                    

                    btnClearStaff_Click(sender, e)
                    cboStaffnationality.SelectedIndex = 0
                    comdSave.Dispose()
                Catch ex As Exception
                    MessageBox.Show(ex.Message)
                    'MsgBox("The new employee record was not saved.This may be due to some invalid entry of information (eg. wrong phone number,date of birth,etc) .Make sure you fill the form in the order of arrangement, input the appropriate information of employee and save it again..", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly)
                Finally
                    con.Close()
                End Try
            End If
        End If
    End Sub

    Private Sub txtstaffage_Click(sender As Object, e As EventArgs) Handles txtstaffage.Click
        MessageBox.Show("You must enter date of birth first!", "SIMS", MessageBoxButtons.OK, MessageBoxIcon.Information)
        dtpStaff.Focus()
    End Sub
End Class