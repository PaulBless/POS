﻿Imports System.Data.SqlClient

Public Class frmSchoolInfo



    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        If txtName.Text = "" Then MsgBox("Enter name of school", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "SIMS") : txtName.Focus() : Exit Sub
        If txtTelephone.Text = "" Then MsgBox("Enter telephone number", MsgBoxStyle.OkOnly + MsgBoxStyle.Exclamation, "SIMS") : txtTelephone.Focus() : Exit Sub
        If txtLocation.Text = "" Then MsgBox("Enter school location", MsgBoxStyle.OkOnly + MsgBoxStyle.Exclamation, "SIMS") : Exit Sub
        If txtAddress.Text = "" Then MsgBox("Enter school address", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "SIMS") : txtAddress.Focus() : Exit Sub
        If Not IsNumeric(txtTelephone.Text) Then MsgBox("Telephone should be numbers", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "SIMS") : Exit Sub

        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()

            Dim dt As New DataTable
            Dim adap As SqlDataAdapter = New SqlDataAdapter("select * from SchoolInfo", con)
            adap.Fill(dt)

            If dt.Rows.Count > 0 Then
                Dim command As SqlCommand = New SqlCommand("update SchoolInfo set Name=@d1, Telephone=@d2, Address=@d3, Location=@d4, Fax=@d5, Email=@d6, YearEst=@d7, RegNo=@d8 where Name='" & txtName.Text & "'", con)
                command.Parameters.AddWithValue("@d1", txtName.Text)
                command.Parameters.AddWithValue("@d2", txtTelephone.Text)
                command.Parameters.AddWithValue("@d3", txtAddress.Text)
                command.Parameters.AddWithValue("@d4", txtLocation.Text)
                command.Parameters.AddWithValue("@d5", txtFax.Text)
                command.Parameters.AddWithValue("@d6", txtEmail.Text)
                command.Parameters.AddWithValue("@d7", txtYear.Text)
                command.Parameters.AddWithValue("@d8", txtRegNo.Text)
                command.ExecuteNonQuery()

                MsgBox("Updated Successfully", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "SIMS")
                Clearme()

                Exit Sub
            End If
            
            If dt.Rows.Count < 1 Then
                Dim command As SqlCommand = New SqlCommand("insert into SchoolInfo (Name,Telephone,Address,Location,Fax,Email,YearEst,RegNo) values (@d1,@d2,@d3,@d4,@d5,@d6,@d7,@d8)", ConnectionModule.con)
                command.Parameters.AddWithValue("@d1", txtName.Text)
                command.Parameters.AddWithValue("@d2", txtTelephone.Text)
                command.Parameters.AddWithValue("@d3", txtAddress.Text)
                command.Parameters.AddWithValue("@d4", txtLocation.Text)
                command.Parameters.AddWithValue("@d5", txtFax.Text)
                command.Parameters.AddWithValue("@d6", txtEmail.Text)
                command.Parameters.AddWithValue("@d7", txtYear.Text)
                command.Parameters.AddWithValue("@d8", txtRegNo.Text)
                command.ExecuteNonQuery()

                MsgBox("Saved Successfully", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "SIMS")

                btnClear_Click(sender, e)
                Exit Sub
            End If



        Catch ex As Exception
            MsgBox(ex.Message)
            con.Close()
        End Try
    End Sub

    Sub Clearme()
        Dim ctr As Control
        For Each ctr In GroupBox1.Controls
            If TypeOf ctr Is TextBox Then
                ctr.Text = ""
            End If
        Next
        For Each ctr In GroupBox2.Controls
            If TypeOf ctr Is TextBox Then
                ctr.Text = ""
            End If
        Next
    End Sub
    
    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        Clearme()

    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub

    Private Sub frmSchoolInfo_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()

            Dim cmd As SqlCommand = New SqlCommand("Select * from SchoolInfo", ConnectionModule.con)
            Dim dr As SqlDataReader = cmd.ExecuteReader
            If dr.HasRows = True Then
                While dr.Read()
                    txtName.Text = dr(0).ToString
                    txtTelephone.Text = dr(1).ToString()
                    txtAddress.Text = dr(2).ToString()
                    txtLocation.Text = dr(3).ToString()
                    txtFax.Text = dr(4).ToString()
                    txtEmail.Text = dr(5).ToString()
                    txtYear.Text = dr(6).ToString()
                    txtRegNo.Text = dr(7).ToString()

                End While
                dr.Close()
                Exit Sub
            End If

            If Not dr.HasRows = True Then
                txtRegNo.Text = ""
                txtAddress.Text = ""
                txtEmail.Text = ""
                txtTelephone.Text = ""
                txtYear.Text = ""
                txtFax.Text = ""
                txtName.Text = ""
                txtLocation.Text = ""
                Exit Sub
            End If


        Catch ex As Exception
            MsgBox(ex.Message)
            con.Close()

        End Try


    End Sub
End Class