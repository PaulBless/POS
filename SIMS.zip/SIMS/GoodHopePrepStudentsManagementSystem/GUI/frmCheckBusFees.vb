﻿Imports System.Data.SqlClient

Public Class frmCheckBusFees

    Private Sub txtStudentName_TextChanged(sender As Object, e As EventArgs) Handles txtStudentName.TextChanged
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            com = New SqlCommand("SELECT dbo.Students.ID, dbo.Students.RegistrationNumber, (dbo.Students.FirstName + ' ' + dbo.Students.MiddleName + ' ' + dbo.Students.LastName) AS SName, dbo.Students.Class, dbo.BusFees.Year, dbo.BusFees.Term, dbo.BusFees.Amount, dbo.BusFees.DatePaid FROM  dbo.BusFees INNER JOIN dbo.Students ON dbo.BusFees.StudentID=dbo.Students.ID where Students.FirstName like '%" & txtStudentName.Text & "' order by [DatePaid] ASC", ConnectionModule.con)
            dr = com.ExecuteReader(CommandBehavior.CloseConnection)
            dgv.Rows.Clear()
            While dr.Read() = True
                dgv.Rows.Add(dr(0), dr(1), dr(2), dr(3), dr(4), dr(5), dr(6), dr(7))
            End While
            dr.Close()
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at name")
            con.Close()
        End Try
    End Sub

    Private Sub txtRegNo_TextChanged(sender As Object, e As EventArgs) Handles txtRegNo.TextChanged
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            com = New SqlCommand("SELECT dbo.Students.ID, dbo.Students.RegistrationNumber, (dbo.Students.FirstName + ' ' + dbo.Students.MiddleName + ' ' + dbo.Students.LastName) AS SName, dbo.Students.Class, dbo.BusFees.Year, dbo.BusFees.Term, dbo.BusFees.Amount, dbo.BusFees.DatePaid FROM  dbo.BusFees INNER JOIN dbo.Students ON dbo.BusFees.StudentID=dbo.Students.ID where Students.RegistrationNumber like '%" & txtRegNo.Text & "' order by [DatePaid] ASC", ConnectionModule.con)
            dr = com.ExecuteReader(CommandBehavior.CloseConnection)
            dgv.Rows.Clear()
            While dr.Read() = True
                dgv.Rows.Add(dr(0), dr(1), dr(2), dr(3), dr(4), dr(5), dr(6), dr(7))
            End While
            dr.Close()
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at regno")
            con.Close()
        End Try
    End Sub

    Private Sub txtYear_TextChanged(sender As Object, e As EventArgs) Handles txtYear.TextChanged
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            com = New SqlCommand("SELECT dbo.Students.ID, dbo.Students.RegistrationNumber, (dbo.Students.FirstName + ' ' + dbo.Students.MiddleName + ' ' + dbo.Students.LastName) AS SName, dbo.Students.Class, dbo.BusFees.Year, dbo.BusFees.Term, dbo.BusFees.Amount, dbo.BusFees.DatePaid FROM  dbo.BusFees INNER JOIN dbo.Students ON dbo.BusFees.StudentID=dbo.Students.ID where BusFees.Year like '%" & txtYear.Text & "' order by [DatePaid] ASC", ConnectionModule.con)
            dr = com.ExecuteReader(CommandBehavior.CloseConnection)
            dgv.Rows.Clear()
            While dr.Read() = True
                dgv.Rows.Add(dr(0), dr(1), dr(2), dr(3), dr(4), dr(5), dr(6), dr(7))
            End While
            dr.Close()
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at year")
            con.Close()
        End Try
    End Sub

    Private Sub txtTerm_TextChanged(sender As Object, e As EventArgs) Handles txtTerm.TextChanged
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            com = New SqlCommand("SELECT dbo.Students.ID, dbo.Students.RegistrationNumber, (dbo.Students.FirstName + ' ' + dbo.Students.MiddleName + ' ' + dbo.Students.LastName) AS SName, dbo.Students.Class, dbo.BusFees.Year, dbo.BusFees.Term, dbo.BusFees.Amount, dbo.BusFees.DatePaid FROM  dbo.BusFees INNER JOIN dbo.Students ON dbo.BusFees.StudentID=dbo.Students.ID where BusFees.Term like '%" & txtTerm.Text & "' order by [DatePaid] ASC", ConnectionModule.con)
            dr = com.ExecuteReader(CommandBehavior.CloseConnection)
            dgv.Rows.Clear()
            While dr.Read() = True
                dgv.Rows.Add(dr(0), dr(1), dr(2), dr(3), dr(4), dr(5), dr(6), dr(7))
            End While
            dr.Close()
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at term")
            con.Close()
        End Try
    End Sub

Public Sub  GetData()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            com = New SqlCommand("SELECT dbo.Students.ID, dbo.Students.RegistrationNumber, (dbo.Students.FirstName + ' ' + dbo.Students.MiddleName + ' ' + dbo.Students.LastName) AS SName, dbo.Students.Class, dbo.BusFees.Year, dbo.BusFees.Term, dbo.BusFees.Amount, dbo.BusFees.DatePaid FROM  dbo.BusFees INNER JOIN dbo.Students ON dbo.BusFees.StudentID=dbo.Students.ID order by [DatePaid] ASC", ConnectionModule.con)
            dr = com.ExecuteReader(CommandBehavior.CloseConnection)
            dgv.Rows.Clear()
            While dr.Read() = True
                dgv.Rows.Add(dr(0), dr(1), dr(2), dr(3), dr(4), dr(5), dr(6), dr(7))
            End While
            dr.Close()
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at gettdata")
            con.Close()
        End Try
    End Sub

    Private Sub frmCheckBusFees_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        GetData()

    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        txtYear.Clear()
        txtStudentName.Clear()
        txtTerm.Clear()
        txtRegNo.Clear()
        GetData()
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub
End Class