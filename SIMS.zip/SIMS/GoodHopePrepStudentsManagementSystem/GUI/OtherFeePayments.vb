﻿Imports System.Data.SqlClient

Public Class OtherFeePayments

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        If cboYear.Text = "" Then MsgBox("Specify academic year", MsgBoxStyle.OkOnly + MsgBoxStyle.Exclamation, "SMIS") : cboYear.Focus() : Exit Sub
        If cboTerm.Text = "" Then MsgBox("Specify school term", MsgBoxStyle.OkOnly + MsgBoxStyle.Exclamation, "SMIS") : cboTerm.Focus() : Exit Sub
        If txtFeeAmount.Text = "" Then MsgBox("Fee paying amount is required.", MsgBoxStyle.OkOnly + MsgBoxStyle.Exclamation, "SMIS") : txtFeeAmount.Focus() : Exit Sub
        If cboPayMode.Text = "" Then MsgBox("Specify the payment mode", MsgBoxStyle.OkOnly + MsgBoxStyle.Exclamation, "SMIS") : cboPayMode.Focus() : Exit Sub

        If MsgBox("Are you sure you want to save this payment?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "Confirmation") = MsgBoxResult.Yes Then
            Try
                If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                ConnectionModule.con.Open()
                com = New SqlCommand("insert into OtherFeesPayment(StudID,FeeType,FeeAmount,AcaYear,Term,PaymentDate,PaymentMode,ServicedBy) values (@d1,@d2,@d3,@d4,@d5,@d6,@d7,@d8)", ConnectionModule.con)
                com.Parameters.AddWithValue("@d1", SearchId)
                com.Parameters.AddWithValue("@d2", cboFeeType.Text)
                com.Parameters.AddWithValue("@d3", Format(Val(txtFeeAmount.Text), "#,##0.00"))
                com.Parameters.AddWithValue("@d4", cboYear.Text)
                com.Parameters.AddWithValue("@d5", cboTerm.Text)
                com.Parameters.AddWithValue("@d6", Date.Now)
                com.Parameters.AddWithValue("@d7", cboPayMode.Text)
                com.Parameters.AddWithValue("@d8", LogName)   'or logname
                com.ExecuteNonQuery()
                MsgBox("Transaction successfully saved", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Success")
                Clearme()

            Catch ex As Exception
                MsgBox(ex.Message)
                con.Close()
            End Try
        End If
    End Sub

    Private Sub btnclear_Click(sender As Object, e As EventArgs) Handles btnclear.Click
        Clearme()
    End Sub
    Sub Clearme()
        txtID.Clear()
        txtRegNo.Clear()
        txtStudentName.Clear()
        txtNationality.Clear()
        txtDept.Clear()
        txtClass.Clear()
        txtGender.Clear()
        txtFeeAmount.Clear()
        cboTerm.ResetText()
        txtFee.Clear()
        cboFeeType.ResetText()
        cboYear.ResetText()
        cboPayMode.ResetText()
        txtRegNo.Focus()
        btnSave.Enabled = False
    End Sub

    Private Sub btnHelp_Click(sender As Object, e As EventArgs) Handles btnHelp.Click
        If txtRegNo.Text = "" Then
            MsgBox("Please, enter the student registration number.", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "SMIS")
            txtRegNo.Focus()
            Exit Sub
        End If

        Try
            Cursor = Cursors.WaitCursor
            Timer1.Enabled = True
            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            query = "select id, firstname + SPACE(1) + middlename + SPACE(1) + lastname as name, gender,nationality,department,class from Students where RegistrationNumber =@d1"
            com1 = New SqlCommand(query, con)
            com1.Parameters.AddWithValue("@d1", txtRegNo.Text)
            dr = com1.ExecuteReader(CommandBehavior.CloseConnection)
            If dr.Read() = True Then
                SearchId = dr(0).ToString()
                txtStudentName.Text = dr(1).ToString()
                txtGender.Text = dr(2).ToString()
                txtNationality.Text = dr(3).ToString()
                txtDept.Text = dr(4).ToString()
                txtClass.Text = dr(5).ToString()
                btnSave.Enabled = True
                Cursor = Cursors.Default
                Timer1.Enabled = False
                dr.Close()
                com1.Dispose()
            Else
                MsgBox("The student registration number you entered is invalid, please check..", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "Error")
                Exit Sub
            End If
            con.Close()
        Catch ex As Exception

        End Try
    End Sub
    Public Sub GetFeeTypes()
        Try
            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            dset = New Data.DataSet()
            adapter = New SqlDataAdapter()
            adapter.SelectCommand = New SqlCommand("select distinct feename from otherfees order by feename asc", ConnectionModule.con)
            dset.Clear()
            adapter.Fill(dset, "otherfees")
            cboFeeType.DataSource = dset.Tables("otherfees")
            cboFeeType.DisplayMember = "feename"
            cboFeeType.Refresh()
            cboFeeType.SelectedIndex = -1
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at get feename")
            con.Close()
        End Try
    End Sub

    Private Sub cboFeeType_Click(sender As Object, e As EventArgs) Handles cboFeeType.Click
        If txtClass.Text = "" Then
            MsgBox("Invalid class of student..", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "SMIS")
            Exit Sub
        End If

    End Sub

    Private Sub cboFeeType_DropDown(sender As Object, e As EventArgs) Handles cboFeeType.DropDown
        GetFeeTypes()
    End Sub

    Private Sub cboFeeType_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboFeeType.SelectedIndexChanged
        FetchFee()
        'Try
        '    'Cursor = Cursors.WaitCursor
        '    'Timer1.Enabled = True
        '    If con.State = ConnectionState.Open Then con.Close()
        '    con.Open()
        '    query = "select amount from otherfees where feename=@d1 and sclass='" & txtClass.Text & "'"
        '    com1 = New SqlCommand(query, con)
        '    com1.Parameters.AddWithValue("@d1", cboFeeType.Text)
        '    dr = com1.ExecuteReader(CommandBehavior.CloseConnection)
        '    If dr.Read() = True Then
        '        txtFee.Text = dr(0).ToString()
        '        'Cursor = Cursors.Default
        '        'Timer1.Enabled = False
        '        dr.Close()
        '        com1.Dispose()
        '        'Else
        '        '    MsgBox("Your selection input is invalid, no fees amount to display.. please check..", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "Error")
        '        '    Exit Sub
        '    End If
        '    con.Close()
        'Catch ex As Exception

        'End Try
    End Sub
    Public Sub FetchFee()
        Try
           If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            query = "select amount from otherfees where sclass=@d1 and feename=@d2"
            com = New SqlCommand(query, con)
            com.Parameters.AddWithValue("@d1", txtClass.Text)
            com.Parameters.AddWithValue("@d2", cboFeeType.Text)
            dr = com.ExecuteReader(CommandBehavior.CloseConnection)
            If dr.Read() = True Then
                'txtFee.Text = dr(1).ToString()
                txtFee.Text = Format(dr.GetValue(0), "#,##0.00")
                dr.Close()
                Exit Sub
            Else
                txtFee.Text = "0.00"
                'MsgBox("Your selection input is invalid, no fees amount to display.. please check..", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "Error")
                'Exit Sub
            End If
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at get other fee")
            con.Close()
        End Try
    End Sub

    Private Sub OtherFeePayments_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub txtRegNo_TextChanged(sender As Object, e As EventArgs) Handles txtRegNo.TextChanged
        If txtRegNo.Text <> "" Then
            'do nothing
        Else
            txtClass.Clear()
            txtDept.Clear()
            txtStudentName.Clear()
            txtGender.Clear()
            txtNationality.Clear()
            btnSave.Enabled = False
            Exit Sub
        End If
    End Sub

    Private Sub txtFeeAmount_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtFeeAmount.KeyPress
        If Asc(e.KeyChar) <> 13 AndAlso Asc(e.KeyChar) <> 8 AndAlso Not IsNumeric(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub

    Private Sub txtFeeAmount_TextChanged(sender As Object, e As EventArgs) Handles txtFeeAmount.TextChanged

    End Sub

    Public Sub AcademicYear()
        Try
            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            dset = New Data.DataSet()
            adapter = New SqlDataAdapter()
            adapter.SelectCommand = New SqlCommand("select distinct year from session order by year desc", ConnectionModule.con)
            dset.Clear()
            adapter.Fill(dset, "session")
            cboYear.DataSource = dset.Tables("session")
            cboYear.DisplayMember = "year"
            cboYear.Refresh()
            cboYear.SelectedIndex = -1
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at get academicyear")
            con.Close()
        End Try
    End Sub
    Public Sub AcademicTerm()
        Try
            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            dset = New Data.DataSet()
            adapter = New SqlDataAdapter()
            adapter.SelectCommand = New SqlCommand("select distinct term from session order by term asc", ConnectionModule.con)
            dset.Clear()
            adapter.Fill(dset, "session")
            cboTerm.DataSource = dset.Tables("session")
            cboTerm.DisplayMember = "term"
            cboTerm.Refresh()
            cboTerm.SelectedIndex = -1
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at get academicterm")
            con.Close()
        End Try
    End Sub

    Private Sub cboYear_DropDown(sender As Object, e As EventArgs) Handles cboYear.DropDown
        AcademicYear()
    End Sub

    Private Sub cboYear_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboYear.SelectedIndexChanged

    End Sub

    Private Sub cboTerm_DropDown(sender As Object, e As EventArgs) Handles cboTerm.DropDown
        AcademicTerm()
    End Sub

    Private Sub cboTerm_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboTerm.SelectedIndexChanged

    End Sub
End Class