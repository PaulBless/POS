﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmManageStudentProfile
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmManageStudentProfile))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.txtSID = New System.Windows.Forms.TextBox()
        Me.cbo_Student_Religion = New System.Windows.Forms.ComboBox()
        Me.txt_Student_House_Number = New System.Windows.Forms.TextBox()
        Me.txt_Student_Hometown = New System.Windows.Forms.TextBox()
        Me.lbl_StaffHometown = New System.Windows.Forms.Label()
        Me.lbl_Staffcontown = New System.Windows.Forms.Label()
        Me.lblregion = New System.Windows.Forms.Label()
        Me.txtRegNo = New System.Windows.Forms.TextBox()
        Me.lbl_StaffHouseno = New System.Windows.Forms.Label()
        Me.txt_student_age = New System.Windows.Forms.TextBox()
        Me.dtpicker_Student_DateOfBirth = New System.Windows.Forms.DateTimePicker()
        Me.txtMDName = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.cboGender = New System.Windows.Forms.ComboBox()
        Me.cboTitle = New System.Windows.Forms.ComboBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.lbl_StaffDOB = New System.Windows.Forms.Label()
        Me.lbl_StaffGender = New System.Windows.Forms.Label()
        Me.lbl_StaffTitle = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtLastname = New System.Windows.Forms.TextBox()
        Me.txtFirstName = New System.Windows.Forms.TextBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.dgv = New System.Windows.Forms.DataGridView()
        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column8 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column9 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column10 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column11 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column12 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column13 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column14 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column15 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column16 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column17 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column18 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column19 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column20 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column21 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column22 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column23 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column24 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column25 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.cbo_Student_District = New System.Windows.Forms.ComboBox()
        Me.lbl_StaffEmail = New System.Windows.Forms.Label()
        Me.cbo_Student_Region = New System.Windows.Forms.ComboBox()
        Me.lbl_StaffReligion = New System.Windows.Forms.Label()
        Me.cbo_Student_Nationality = New System.Windows.Forms.ComboBox()
        Me.lbl_StaffNationality = New System.Windows.Forms.Label()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.txt_Student_Contact_Address = New System.Windows.Forms.TextBox()
        Me.lbl_StaffAddress = New System.Windows.Forms.Label()
        Me.txt_Student_Contact_Email = New System.Windows.Forms.TextBox()
        Me.cbo_Student_Contact_Occupation = New System.Windows.Forms.ComboBox()
        Me.cbo_Student_Contact_Relation = New System.Windows.Forms.ComboBox()
        Me.lbl_Staffnextrel = New System.Windows.Forms.Label()
        Me.lbl_StaffOccup = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txt_Student_Contact_Name = New System.Windows.Forms.TextBox()
        Me.lbl_StaffConName = New System.Windows.Forms.Label()
        Me.txt_Student_Contact_Number = New System.Windows.Forms.TextBox()
        Me.lbl_Staffconphone = New System.Windows.Forms.Label()
        Me.txt_Student_Contact_WorkNo = New System.Windows.Forms.TextBox()
        Me.lbl_Staffconwork = New System.Windows.Forms.Label()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.dtpDate = New System.Windows.Forms.DateTimePicker()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lbl_StudClass = New System.Windows.Forms.Label()
        Me.cboClass = New System.Windows.Forms.ComboBox()
        Me.cboDepartment = New System.Windows.Forms.ComboBox()
        Me.lbl_StudDept = New System.Windows.Forms.Label()
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.GroupBox2.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        CType(Me.dgv, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.txtSID)
        Me.GroupBox2.Controls.Add(Me.cbo_Student_Religion)
        Me.GroupBox2.Controls.Add(Me.txt_Student_House_Number)
        Me.GroupBox2.Controls.Add(Me.txt_Student_Hometown)
        Me.GroupBox2.Controls.Add(Me.lbl_StaffHometown)
        Me.GroupBox2.Controls.Add(Me.lbl_Staffcontown)
        Me.GroupBox2.Controls.Add(Me.lblregion)
        Me.GroupBox2.Controls.Add(Me.txtRegNo)
        Me.GroupBox2.Controls.Add(Me.lbl_StaffHouseno)
        Me.GroupBox2.Controls.Add(Me.txt_student_age)
        Me.GroupBox2.Controls.Add(Me.dtpicker_Student_DateOfBirth)
        Me.GroupBox2.Controls.Add(Me.txtMDName)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Controls.Add(Me.cboGender)
        Me.GroupBox2.Controls.Add(Me.cboTitle)
        Me.GroupBox2.Controls.Add(Me.Label13)
        Me.GroupBox2.Controls.Add(Me.lbl_StaffDOB)
        Me.GroupBox2.Controls.Add(Me.lbl_StaffGender)
        Me.GroupBox2.Controls.Add(Me.lbl_StaffTitle)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Controls.Add(Me.txtLastname)
        Me.GroupBox2.Controls.Add(Me.txtFirstName)
        Me.GroupBox2.Font = New System.Drawing.Font("Tahoma", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.Location = New System.Drawing.Point(13, 285)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(394, 298)
        Me.GroupBox2.TabIndex = 85
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Student Information"
        '
        'txtSID
        '
        Me.txtSID.BackColor = System.Drawing.Color.White
        Me.txtSID.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSID.Location = New System.Drawing.Point(18, 253)
        Me.txtSID.MaxLength = 50
        Me.txtSID.Name = "txtSID"
        Me.txtSID.Size = New System.Drawing.Size(42, 21)
        Me.txtSID.TabIndex = 96
        Me.txtSID.Visible = False
        '
        'cbo_Student_Religion
        '
        Me.cbo_Student_Religion.BackColor = System.Drawing.Color.White
        Me.cbo_Student_Religion.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbo_Student_Religion.FormattingEnabled = True
        Me.cbo_Student_Religion.Items.AddRange(New Object() {"CHRISTIANITY", "ISLAM", "TRADITIONALIST"})
        Me.cbo_Student_Religion.Location = New System.Drawing.Point(137, 253)
        Me.cbo_Student_Religion.Name = "cbo_Student_Religion"
        Me.cbo_Student_Religion.Size = New System.Drawing.Size(234, 23)
        Me.cbo_Student_Religion.TabIndex = 92
        '
        'txt_Student_House_Number
        '
        Me.txt_Student_House_Number.BackColor = System.Drawing.Color.White
        Me.txt_Student_House_Number.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txt_Student_House_Number.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Student_House_Number.Location = New System.Drawing.Point(137, 223)
        Me.txt_Student_House_Number.MaxLength = 100
        Me.txt_Student_House_Number.Name = "txt_Student_House_Number"
        Me.txt_Student_House_Number.Size = New System.Drawing.Size(234, 21)
        Me.txt_Student_House_Number.TabIndex = 90
        '
        'txt_Student_Hometown
        '
        Me.txt_Student_Hometown.BackColor = System.Drawing.Color.White
        Me.txt_Student_Hometown.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txt_Student_Hometown.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Student_Hometown.Location = New System.Drawing.Point(137, 194)
        Me.txt_Student_Hometown.MaxLength = 100
        Me.txt_Student_Hometown.Name = "txt_Student_Hometown"
        Me.txt_Student_Hometown.Size = New System.Drawing.Size(234, 21)
        Me.txt_Student_Hometown.TabIndex = 95
        '
        'lbl_StaffHometown
        '
        Me.lbl_StaffHometown.AutoSize = True
        Me.lbl_StaffHometown.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaffHometown.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_StaffHometown.Location = New System.Drawing.Point(43, 197)
        Me.lbl_StaffHometown.Name = "lbl_StaffHometown"
        Me.lbl_StaffHometown.Size = New System.Drawing.Size(90, 17)
        Me.lbl_StaffHometown.TabIndex = 94
        Me.lbl_StaffHometown.Text = "Home Town :"
        '
        'lbl_Staffcontown
        '
        Me.lbl_Staffcontown.AutoSize = True
        Me.lbl_Staffcontown.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_Staffcontown.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_Staffcontown.Location = New System.Drawing.Point(20, 20)
        Me.lbl_Staffcontown.Name = "lbl_Staffcontown"
        Me.lbl_Staffcontown.Size = New System.Drawing.Size(113, 17)
        Me.lbl_Staffcontown.TabIndex = 72
        Me.lbl_Staffcontown.Text = "Registration No :"
        '
        'lblregion
        '
        Me.lblregion.AutoSize = True
        Me.lblregion.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblregion.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lblregion.Location = New System.Drawing.Point(66, 257)
        Me.lblregion.Name = "lblregion"
        Me.lblregion.Size = New System.Drawing.Size(67, 17)
        Me.lblregion.TabIndex = 93
        Me.lblregion.Text = "Religion :"
        '
        'txtRegNo
        '
        Me.txtRegNo.BackColor = System.Drawing.Color.White
        Me.txtRegNo.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtRegNo.Enabled = False
        Me.txtRegNo.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.txtRegNo.Location = New System.Drawing.Point(137, 17)
        Me.txtRegNo.Name = "txtRegNo"
        Me.txtRegNo.Size = New System.Drawing.Size(234, 21)
        Me.txtRegNo.TabIndex = 73
        '
        'lbl_StaffHouseno
        '
        Me.lbl_StaffHouseno.AutoSize = True
        Me.lbl_StaffHouseno.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaffHouseno.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_StaffHouseno.Location = New System.Drawing.Point(66, 227)
        Me.lbl_StaffHouseno.Name = "lbl_StaffHouseno"
        Me.lbl_StaffHouseno.Size = New System.Drawing.Size(67, 17)
        Me.lbl_StaffHouseno.TabIndex = 91
        Me.lbl_StaffHouseno.Text = "House # :"
        '
        'txt_student_age
        '
        Me.txt_student_age.BackColor = System.Drawing.Color.White
        Me.txt_student_age.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_student_age.Location = New System.Drawing.Point(329, 162)
        Me.txt_student_age.MaxLength = 50
        Me.txt_student_age.Name = "txt_student_age"
        Me.txt_student_age.ReadOnly = True
        Me.txt_student_age.Size = New System.Drawing.Size(42, 21)
        Me.txt_student_age.TabIndex = 89
        '
        'dtpicker_Student_DateOfBirth
        '
        Me.dtpicker_Student_DateOfBirth.CalendarMonthBackground = System.Drawing.Color.White
        Me.dtpicker_Student_DateOfBirth.CustomFormat = "dd/MM/yyyy"
        Me.dtpicker_Student_DateOfBirth.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtpicker_Student_DateOfBirth.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpicker_Student_DateOfBirth.Location = New System.Drawing.Point(137, 162)
        Me.dtpicker_Student_DateOfBirth.Name = "dtpicker_Student_DateOfBirth"
        Me.dtpicker_Student_DateOfBirth.ShowCheckBox = True
        Me.dtpicker_Student_DateOfBirth.Size = New System.Drawing.Size(133, 21)
        Me.dtpicker_Student_DateOfBirth.TabIndex = 88
        '
        'txtMDName
        '
        Me.txtMDName.BackColor = System.Drawing.Color.White
        Me.txtMDName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtMDName.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.txtMDName.Location = New System.Drawing.Point(137, 75)
        Me.txtMDName.MaxLength = 200
        Me.txtMDName.Name = "txtMDName"
        Me.txtMDName.Size = New System.Drawing.Size(234, 21)
        Me.txtMDName.TabIndex = 73
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.Label5.Location = New System.Drawing.Point(34, 78)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(99, 17)
        Me.Label5.TabIndex = 81
        Me.Label5.Text = "Middle Name :"
        '
        'cboGender
        '
        Me.cboGender.BackColor = System.Drawing.Color.White
        Me.cboGender.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboGender.FormattingEnabled = True
        Me.cboGender.Items.AddRange(New Object() {"FEMALE", "MALE"})
        Me.cboGender.Location = New System.Drawing.Point(280, 129)
        Me.cboGender.Name = "cboGender"
        Me.cboGender.Size = New System.Drawing.Size(91, 23)
        Me.cboGender.TabIndex = 86
        '
        'cboTitle
        '
        Me.cboTitle.BackColor = System.Drawing.Color.White
        Me.cboTitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboTitle.FormattingEnabled = True
        Me.cboTitle.Items.AddRange(New Object() {"Master", "Miss"})
        Me.cboTitle.Location = New System.Drawing.Point(137, 129)
        Me.cboTitle.Name = "cboTitle"
        Me.cboTitle.Size = New System.Drawing.Size(81, 23)
        Me.cboTitle.TabIndex = 87
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.Label13.Location = New System.Drawing.Point(289, 164)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(40, 17)
        Me.Label13.TabIndex = 85
        Me.Label13.Text = "Age :"
        '
        'lbl_StaffDOB
        '
        Me.lbl_StaffDOB.AutoSize = True
        Me.lbl_StaffDOB.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaffDOB.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_StaffDOB.Location = New System.Drawing.Point(37, 165)
        Me.lbl_StaffDOB.Name = "lbl_StaffDOB"
        Me.lbl_StaffDOB.Size = New System.Drawing.Size(96, 17)
        Me.lbl_StaffDOB.TabIndex = 84
        Me.lbl_StaffDOB.Text = "Date of Birth :"
        '
        'lbl_StaffGender
        '
        Me.lbl_StaffGender.AutoSize = True
        Me.lbl_StaffGender.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaffGender.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_StaffGender.Location = New System.Drawing.Point(223, 131)
        Me.lbl_StaffGender.Name = "lbl_StaffGender"
        Me.lbl_StaffGender.Size = New System.Drawing.Size(60, 17)
        Me.lbl_StaffGender.TabIndex = 82
        Me.lbl_StaffGender.Text = "Gender :"
        '
        'lbl_StaffTitle
        '
        Me.lbl_StaffTitle.AutoSize = True
        Me.lbl_StaffTitle.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaffTitle.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_StaffTitle.Location = New System.Drawing.Point(89, 132)
        Me.lbl_StaffTitle.Name = "lbl_StaffTitle"
        Me.lbl_StaffTitle.Size = New System.Drawing.Size(44, 17)
        Me.lbl_StaffTitle.TabIndex = 83
        Me.lbl_StaffTitle.Text = "Title :"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.Label6.Location = New System.Drawing.Point(52, 102)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(81, 17)
        Me.Label6.TabIndex = 81
        Me.Label6.Text = "Last Name :"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.Label4.Location = New System.Drawing.Point(50, 49)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(83, 17)
        Me.Label4.TabIndex = 81
        Me.Label4.Text = "First Name :"
        '
        'txtLastname
        '
        Me.txtLastname.BackColor = System.Drawing.Color.White
        Me.txtLastname.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtLastname.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.txtLastname.Location = New System.Drawing.Point(137, 100)
        Me.txtLastname.MaxLength = 200
        Me.txtLastname.Name = "txtLastname"
        Me.txtLastname.Size = New System.Drawing.Size(234, 21)
        Me.txtLastname.TabIndex = 73
        '
        'txtFirstName
        '
        Me.txtFirstName.BackColor = System.Drawing.Color.White
        Me.txtFirstName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtFirstName.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.txtFirstName.Location = New System.Drawing.Point(137, 47)
        Me.txtFirstName.MaxLength = 200
        Me.txtFirstName.Name = "txtFirstName"
        Me.txtFirstName.Size = New System.Drawing.Size(234, 21)
        Me.txtFirstName.TabIndex = 73
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.SteelBlue
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1086, 35)
        Me.Panel1.TabIndex = 86
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Trebuchet MS", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(380, 5)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(274, 29)
        Me.Label1.TabIndex = 12
        Me.Label1.Text = "Manage Student Profile"
        '
        'btnCancel
        '
        Me.btnCancel.BackColor = System.Drawing.SystemColors.Control
        Me.btnCancel.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnCancel.Font = New System.Drawing.Font("Tahoma", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCancel.ForeColor = System.Drawing.Color.SteelBlue
        Me.btnCancel.Image = CType(resources.GetObject("btnCancel.Image"), System.Drawing.Image)
        Me.btnCancel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnCancel.Location = New System.Drawing.Point(693, 13)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(133, 40)
        Me.btnCancel.TabIndex = 87
        Me.btnCancel.Text = "Close"
        Me.btnCancel.UseVisualStyleBackColor = False
        '
        'btnSave
        '
        Me.btnSave.BackColor = System.Drawing.SystemColors.Control
        Me.btnSave.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnSave.Enabled = False
        Me.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnSave.Font = New System.Drawing.Font("Tahoma", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSave.ForeColor = System.Drawing.Color.SteelBlue
        Me.btnSave.Image = CType(resources.GetObject("btnSave.Image"), System.Drawing.Image)
        Me.btnSave.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnSave.Location = New System.Drawing.Point(205, 13)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(133, 40)
        Me.btnSave.TabIndex = 89
        Me.btnSave.Text = "&Save"
        Me.btnSave.UseVisualStyleBackColor = False
        '
        'btnClear
        '
        Me.btnClear.BackColor = System.Drawing.SystemColors.Control
        Me.btnClear.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnClear.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnClear.Font = New System.Drawing.Font("Tahoma", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClear.ForeColor = System.Drawing.Color.SteelBlue
        Me.btnClear.Image = CType(resources.GetObject("btnClear.Image"), System.Drawing.Image)
        Me.btnClear.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnClear.Location = New System.Drawing.Point(371, 15)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(133, 40)
        Me.btnClear.TabIndex = 88
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = False
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.dgv)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(12, 37)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(1060, 241)
        Me.GroupBox1.TabIndex = 90
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "List of Students"
        '
        'dgv
        '
        Me.dgv.AllowUserToAddRows = False
        Me.dgv.AllowUserToResizeColumns = False
        Me.dgv.AllowUserToResizeRows = False
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.MenuHighlight
        Me.dgv.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.dgv.BackgroundColor = System.Drawing.Color.White
        Me.dgv.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.DarkSlateGray
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgv.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.dgv.ColumnHeadersHeight = 30
        Me.dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.dgv.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1, Me.Column2, Me.Column3, Me.Column5, Me.Column4, Me.Column6, Me.Column7, Me.Column8, Me.Column9, Me.Column10, Me.Column11, Me.Column12, Me.Column13, Me.Column14, Me.Column15, Me.Column16, Me.Column17, Me.Column18, Me.Column19, Me.Column20, Me.Column21, Me.Column22, Me.Column23, Me.Column24, Me.Column25})
        Me.dgv.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.dgv.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgv.EnableHeadersVisualStyles = False
        Me.dgv.GridColor = System.Drawing.SystemColors.AppWorkspace
        Me.dgv.Location = New System.Drawing.Point(3, 17)
        Me.dgv.MultiSelect = False
        Me.dgv.Name = "dgv"
        Me.dgv.ReadOnly = True
        Me.dgv.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.Color.DarkSlateGray
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.MenuHighlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv.RowHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.dgv.RowHeadersWidth = 30
        Me.dgv.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle4.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.MenuHighlight
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgv.RowsDefaultCellStyle = DataGridViewCellStyle4
        Me.dgv.RowTemplate.Height = 18
        Me.dgv.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgv.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgv.Size = New System.Drawing.Size(1054, 221)
        Me.dgv.TabIndex = 51
        '
        'Column1
        '
        Me.Column1.HeaderText = "No."
        Me.Column1.Name = "Column1"
        Me.Column1.ReadOnly = True
        Me.Column1.Visible = False
        Me.Column1.Width = 70
        '
        'Column2
        '
        Me.Column2.HeaderText = "Registration No"
        Me.Column2.Name = "Column2"
        Me.Column2.ReadOnly = True
        Me.Column2.Width = 130
        '
        'Column3
        '
        Me.Column3.HeaderText = "First Name"
        Me.Column3.Name = "Column3"
        Me.Column3.ReadOnly = True
        Me.Column3.Width = 140
        '
        'Column5
        '
        Me.Column5.HeaderText = "Middle Name"
        Me.Column5.Name = "Column5"
        Me.Column5.ReadOnly = True
        Me.Column5.Width = 140
        '
        'Column4
        '
        Me.Column4.HeaderText = "Last Name"
        Me.Column4.Name = "Column4"
        Me.Column4.ReadOnly = True
        Me.Column4.Width = 160
        '
        'Column6
        '
        Me.Column6.HeaderText = "Date of Birth"
        Me.Column6.Name = "Column6"
        Me.Column6.ReadOnly = True
        '
        'Column7
        '
        Me.Column7.HeaderText = "Age"
        Me.Column7.Name = "Column7"
        Me.Column7.ReadOnly = True
        Me.Column7.Width = 80
        '
        'Column8
        '
        Me.Column8.HeaderText = "Department"
        Me.Column8.Name = "Column8"
        Me.Column8.ReadOnly = True
        Me.Column8.Width = 140
        '
        'Column9
        '
        Me.Column9.HeaderText = "Class"
        Me.Column9.Name = "Column9"
        Me.Column9.ReadOnly = True
        Me.Column9.Width = 140
        '
        'Column10
        '
        Me.Column10.HeaderText = "Region"
        Me.Column10.Name = "Column10"
        Me.Column10.ReadOnly = True
        Me.Column10.Width = 120
        '
        'Column11
        '
        Me.Column11.HeaderText = "District"
        Me.Column11.Name = "Column11"
        Me.Column11.ReadOnly = True
        Me.Column11.Width = 180
        '
        'Column12
        '
        Me.Column12.HeaderText = "Nationality"
        Me.Column12.Name = "Column12"
        Me.Column12.ReadOnly = True
        Me.Column12.Width = 120
        '
        'Column13
        '
        Me.Column13.HeaderText = "House Address"
        Me.Column13.Name = "Column13"
        Me.Column13.ReadOnly = True
        Me.Column13.Width = 130
        '
        'Column14
        '
        Me.Column14.HeaderText = "Contact Name"
        Me.Column14.Name = "Column14"
        Me.Column14.ReadOnly = True
        Me.Column14.Width = 150
        '
        'Column15
        '
        Me.Column15.HeaderText = "Contact No"
        Me.Column15.Name = "Column15"
        Me.Column15.ReadOnly = True
        Me.Column15.Width = 110
        '
        'Column16
        '
        Me.Column16.HeaderText = "Contact Address"
        Me.Column16.Name = "Column16"
        Me.Column16.ReadOnly = True
        Me.Column16.Width = 150
        '
        'Column17
        '
        Me.Column17.HeaderText = "Occupation"
        Me.Column17.Name = "Column17"
        Me.Column17.ReadOnly = True
        Me.Column17.Width = 150
        '
        'Column18
        '
        Me.Column18.HeaderText = "Relationship"
        Me.Column18.Name = "Column18"
        Me.Column18.ReadOnly = True
        Me.Column18.Width = 130
        '
        'Column19
        '
        Me.Column19.HeaderText = "Email Address"
        Me.Column19.Name = "Column19"
        Me.Column19.ReadOnly = True
        Me.Column19.Width = 160
        '
        'Column20
        '
        Me.Column20.HeaderText = "Work Tel No"
        Me.Column20.Name = "Column20"
        Me.Column20.ReadOnly = True
        Me.Column20.Width = 120
        '
        'Column21
        '
        Me.Column21.HeaderText = "Gender"
        Me.Column21.Name = "Column21"
        Me.Column21.ReadOnly = True
        '
        'Column22
        '
        Me.Column22.HeaderText = "Title"
        Me.Column22.Name = "Column22"
        Me.Column22.ReadOnly = True
        '
        'Column23
        '
        Me.Column23.HeaderText = "Hometown"
        Me.Column23.Name = "Column23"
        Me.Column23.ReadOnly = True
        Me.Column23.Width = 110
        '
        'Column24
        '
        Me.Column24.HeaderText = "Religion"
        Me.Column24.Name = "Column24"
        Me.Column24.ReadOnly = True
        Me.Column24.Width = 110
        '
        'Column25
        '
        Me.Column25.HeaderText = "Registered Date"
        Me.Column25.Name = "Column25"
        Me.Column25.ReadOnly = True
        Me.Column25.Width = 120
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.cbo_Student_District)
        Me.GroupBox3.Controls.Add(Me.lbl_StaffEmail)
        Me.GroupBox3.Controls.Add(Me.cbo_Student_Region)
        Me.GroupBox3.Controls.Add(Me.lbl_StaffReligion)
        Me.GroupBox3.Controls.Add(Me.cbo_Student_Nationality)
        Me.GroupBox3.Controls.Add(Me.lbl_StaffNationality)
        Me.GroupBox3.Font = New System.Drawing.Font("Tahoma", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.Location = New System.Drawing.Point(836, 285)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(237, 125)
        Me.GroupBox3.TabIndex = 85
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Address Information"
        '
        'cbo_Student_District
        '
        Me.cbo_Student_District.BackColor = System.Drawing.Color.White
        Me.cbo_Student_District.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbo_Student_District.FormattingEnabled = True
        Me.cbo_Student_District.Location = New System.Drawing.Point(81, 87)
        Me.cbo_Student_District.Name = "cbo_Student_District"
        Me.cbo_Student_District.Size = New System.Drawing.Size(138, 23)
        Me.cbo_Student_District.TabIndex = 59
        '
        'lbl_StaffEmail
        '
        Me.lbl_StaffEmail.AutoSize = True
        Me.lbl_StaffEmail.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaffEmail.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_StaffEmail.Location = New System.Drawing.Point(15, 91)
        Me.lbl_StaffEmail.Name = "lbl_StaffEmail"
        Me.lbl_StaffEmail.Size = New System.Drawing.Size(61, 17)
        Me.lbl_StaffEmail.TabIndex = 58
        Me.lbl_StaffEmail.Text = "District :"
        '
        'cbo_Student_Region
        '
        Me.cbo_Student_Region.BackColor = System.Drawing.Color.White
        Me.cbo_Student_Region.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbo_Student_Region.FormattingEnabled = True
        Me.cbo_Student_Region.Items.AddRange(New Object() {"ASHANTI", "BRONG AHAFO", "CENTRAL", "EASTERN", "GREATER ACCRA", "NORTHERN", "UPPER EAST", "UPPER WEST", "VOLTA", "WESTERN"})
        Me.cbo_Student_Region.Location = New System.Drawing.Point(81, 55)
        Me.cbo_Student_Region.Name = "cbo_Student_Region"
        Me.cbo_Student_Region.Size = New System.Drawing.Size(138, 23)
        Me.cbo_Student_Region.Sorted = True
        Me.cbo_Student_Region.TabIndex = 57
        '
        'lbl_StaffReligion
        '
        Me.lbl_StaffReligion.AutoSize = True
        Me.lbl_StaffReligion.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaffReligion.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_StaffReligion.Location = New System.Drawing.Point(17, 58)
        Me.lbl_StaffReligion.Name = "lbl_StaffReligion"
        Me.lbl_StaffReligion.Size = New System.Drawing.Size(59, 17)
        Me.lbl_StaffReligion.TabIndex = 56
        Me.lbl_StaffReligion.Text = "Region :"
        '
        'cbo_Student_Nationality
        '
        Me.cbo_Student_Nationality.BackColor = System.Drawing.Color.White
        Me.cbo_Student_Nationality.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbo_Student_Nationality.FormattingEnabled = True
        Me.cbo_Student_Nationality.Items.AddRange(New Object() {"GHANAIAN", "NON-GHANAIAN"})
        Me.cbo_Student_Nationality.Location = New System.Drawing.Point(81, 24)
        Me.cbo_Student_Nationality.Name = "cbo_Student_Nationality"
        Me.cbo_Student_Nationality.Size = New System.Drawing.Size(138, 23)
        Me.cbo_Student_Nationality.TabIndex = 55
        '
        'lbl_StaffNationality
        '
        Me.lbl_StaffNationality.AutoSize = True
        Me.lbl_StaffNationality.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaffNationality.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_StaffNationality.Location = New System.Drawing.Point(5, 27)
        Me.lbl_StaffNationality.Name = "lbl_StaffNationality"
        Me.lbl_StaffNationality.Size = New System.Drawing.Size(85, 17)
        Me.lbl_StaffNationality.TabIndex = 54
        Me.lbl_StaffNationality.Text = "Nationality :"
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.txt_Student_Contact_Address)
        Me.GroupBox4.Controls.Add(Me.lbl_StaffAddress)
        Me.GroupBox4.Controls.Add(Me.txt_Student_Contact_Email)
        Me.GroupBox4.Controls.Add(Me.cbo_Student_Contact_Occupation)
        Me.GroupBox4.Controls.Add(Me.cbo_Student_Contact_Relation)
        Me.GroupBox4.Controls.Add(Me.lbl_Staffnextrel)
        Me.GroupBox4.Controls.Add(Me.lbl_StaffOccup)
        Me.GroupBox4.Controls.Add(Me.Label2)
        Me.GroupBox4.Controls.Add(Me.txt_Student_Contact_Name)
        Me.GroupBox4.Controls.Add(Me.lbl_StaffConName)
        Me.GroupBox4.Controls.Add(Me.txt_Student_Contact_Number)
        Me.GroupBox4.Controls.Add(Me.lbl_Staffconphone)
        Me.GroupBox4.Controls.Add(Me.txt_Student_Contact_WorkNo)
        Me.GroupBox4.Controls.Add(Me.lbl_Staffconwork)
        Me.GroupBox4.Font = New System.Drawing.Font("Tahoma", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox4.Location = New System.Drawing.Point(413, 285)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(417, 298)
        Me.GroupBox4.TabIndex = 85
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Contact Information"
        '
        'txt_Student_Contact_Address
        '
        Me.txt_Student_Contact_Address.BackColor = System.Drawing.Color.White
        Me.txt_Student_Contact_Address.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txt_Student_Contact_Address.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Student_Contact_Address.Location = New System.Drawing.Point(129, 203)
        Me.txt_Student_Contact_Address.MaxLength = 500
        Me.txt_Student_Contact_Address.Multiline = True
        Me.txt_Student_Contact_Address.Name = "txt_Student_Contact_Address"
        Me.txt_Student_Contact_Address.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txt_Student_Contact_Address.Size = New System.Drawing.Size(282, 48)
        Me.txt_Student_Contact_Address.TabIndex = 62
        '
        'lbl_StaffAddress
        '
        Me.lbl_StaffAddress.AutoSize = True
        Me.lbl_StaffAddress.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaffAddress.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_StaffAddress.Location = New System.Drawing.Point(14, 207)
        Me.lbl_StaffAddress.Name = "lbl_StaffAddress"
        Me.lbl_StaffAddress.Size = New System.Drawing.Size(107, 17)
        Me.lbl_StaffAddress.TabIndex = 61
        Me.lbl_StaffAddress.Text = "Postal Address :"
        '
        'txt_Student_Contact_Email
        '
        Me.txt_Student_Contact_Email.BackColor = System.Drawing.Color.White
        Me.txt_Student_Contact_Email.CharacterCasing = System.Windows.Forms.CharacterCasing.Lower
        Me.txt_Student_Contact_Email.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Student_Contact_Email.Location = New System.Drawing.Point(129, 106)
        Me.txt_Student_Contact_Email.Name = "txt_Student_Contact_Email"
        Me.txt_Student_Contact_Email.Size = New System.Drawing.Size(282, 21)
        Me.txt_Student_Contact_Email.TabIndex = 58
        '
        'cbo_Student_Contact_Occupation
        '
        Me.cbo_Student_Contact_Occupation.BackColor = System.Drawing.Color.White
        Me.cbo_Student_Contact_Occupation.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbo_Student_Contact_Occupation.FormattingEnabled = True
        Me.cbo_Student_Contact_Occupation.Items.AddRange(New Object() {"ACCOUNTANT", "APPRENTICE", "ARCHITECT", "ARMY OFFICER", "ARTISAN", "ASSEMBLYMAN", "AUDITOR", "BAKER", "BANKER", "BEAUTY PRACTITIONER", "BUSINESS ANALYST", "BUSINESSMAN", "CARPENTOR", "CATERER", "CHEF", "CIVIL SERVANT", "CLERGY", "COMPUTER SCIENTIST", "CONSTRUCTION ENGINEER", "DATABASE ADMINISTRATOR", "DESIGNER", "DISPENSING ASSISTANT", "DOCTOR", "DRIVER", "ELECTRICIAN", "FARMER", "FASHION DESIGNER", "FISH MONGER", "FISHERMAN", "FOOD VENDOR", "FOOTBALLER", "FOREIGN DIPLOMAT", "HAIR DRESSER", "HEALTH AID ", "HOUSE WIFE", "IMMIGRATION OFFICER", "LABOURER", "LAWYER", "LEGAL PRACTITIONER", "MASON", "MATRON", "MEDICAL PRACTITIONER", "MINER", "MINING ENGINEER", "MUSICIAN", "NETWORK ADMINISTRATOR", "NETWORK ENGINEER", "NURSE", "OTHER", "PAINTER", "PASTOR", "PENSIONER", "PHARMACIST", "PHARMACY TECHNICIAN", "POLICE OFFICER", "PROGRAMMER", "PUBLIC SERVANT", "RADIO PRESENTER", "REAL ESTATE AGENT", "RECEPTIONIST", "SALES PERSON", "SEAMSTRESS", "SECRETARY", "SECURITY", "STATE MINSTER", "STOCK BROKER", "STORE KEEPER", "SYSTEM ADMINISTRATOR", "TAILOR", "TEACHER", "TRADER", "TRAVEL AGENT", "TYPIST", "UNEMPLOYED"})
        Me.cbo_Student_Contact_Occupation.Location = New System.Drawing.Point(129, 136)
        Me.cbo_Student_Contact_Occupation.Name = "cbo_Student_Contact_Occupation"
        Me.cbo_Student_Contact_Occupation.Size = New System.Drawing.Size(282, 23)
        Me.cbo_Student_Contact_Occupation.TabIndex = 59
        '
        'cbo_Student_Contact_Relation
        '
        Me.cbo_Student_Contact_Relation.BackColor = System.Drawing.Color.White
        Me.cbo_Student_Contact_Relation.DropDownHeight = 75
        Me.cbo_Student_Contact_Relation.DropDownWidth = 75
        Me.cbo_Student_Contact_Relation.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbo_Student_Contact_Relation.FormattingEnabled = True
        Me.cbo_Student_Contact_Relation.IntegralHeight = False
        Me.cbo_Student_Contact_Relation.Items.AddRange(New Object() {"Brother", "Sister", "Father", "Mother", "StepMother", "StepFather", "Aunt", "Uncle", "GrandFather", "GrandMother", "Other", "GuardMother", "GuardFather"})
        Me.cbo_Student_Contact_Relation.Location = New System.Drawing.Point(129, 170)
        Me.cbo_Student_Contact_Relation.Name = "cbo_Student_Contact_Relation"
        Me.cbo_Student_Contact_Relation.Size = New System.Drawing.Size(282, 23)
        Me.cbo_Student_Contact_Relation.TabIndex = 60
        '
        'lbl_Staffnextrel
        '
        Me.lbl_Staffnextrel.AutoSize = True
        Me.lbl_Staffnextrel.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_Staffnextrel.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_Staffnextrel.Location = New System.Drawing.Point(14, 174)
        Me.lbl_Staffnextrel.Name = "lbl_Staffnextrel"
        Me.lbl_Staffnextrel.Size = New System.Drawing.Size(59, 17)
        Me.lbl_Staffnextrel.TabIndex = 56
        Me.lbl_Staffnextrel.Text = "Relation"
        '
        'lbl_StaffOccup
        '
        Me.lbl_StaffOccup.AutoSize = True
        Me.lbl_StaffOccup.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaffOccup.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_StaffOccup.Location = New System.Drawing.Point(14, 140)
        Me.lbl_StaffOccup.Name = "lbl_StaffOccup"
        Me.lbl_StaffOccup.Size = New System.Drawing.Size(86, 17)
        Me.lbl_StaffOccup.TabIndex = 55
        Me.lbl_StaffOccup.Text = "Occupation :"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.Label2.Location = New System.Drawing.Point(14, 110)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(103, 17)
        Me.Label2.TabIndex = 57
        Me.Label2.Text = "Email Address :"
        '
        'txt_Student_Contact_Name
        '
        Me.txt_Student_Contact_Name.BackColor = System.Drawing.Color.White
        Me.txt_Student_Contact_Name.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txt_Student_Contact_Name.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Student_Contact_Name.Location = New System.Drawing.Point(129, 17)
        Me.txt_Student_Contact_Name.MaxLength = 350
        Me.txt_Student_Contact_Name.Name = "txt_Student_Contact_Name"
        Me.txt_Student_Contact_Name.Size = New System.Drawing.Size(282, 21)
        Me.txt_Student_Contact_Name.TabIndex = 52
        '
        'lbl_StaffConName
        '
        Me.lbl_StaffConName.AutoSize = True
        Me.lbl_StaffConName.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StaffConName.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_StaffConName.Location = New System.Drawing.Point(14, 20)
        Me.lbl_StaffConName.Name = "lbl_StaffConName"
        Me.lbl_StaffConName.Size = New System.Drawing.Size(103, 17)
        Me.lbl_StaffConName.TabIndex = 49
        Me.lbl_StaffConName.Text = "Contact Name :"
        '
        'txt_Student_Contact_Number
        '
        Me.txt_Student_Contact_Number.BackColor = System.Drawing.Color.White
        Me.txt_Student_Contact_Number.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Student_Contact_Number.Location = New System.Drawing.Point(129, 48)
        Me.txt_Student_Contact_Number.MaxLength = 10
        Me.txt_Student_Contact_Number.Name = "txt_Student_Contact_Number"
        Me.txt_Student_Contact_Number.Size = New System.Drawing.Size(282, 21)
        Me.txt_Student_Contact_Number.TabIndex = 53
        '
        'lbl_Staffconphone
        '
        Me.lbl_Staffconphone.AutoSize = True
        Me.lbl_Staffconphone.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_Staffconphone.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_Staffconphone.Location = New System.Drawing.Point(14, 51)
        Me.lbl_Staffconphone.Name = "lbl_Staffconphone"
        Me.lbl_Staffconphone.Size = New System.Drawing.Size(77, 17)
        Me.lbl_Staffconphone.TabIndex = 50
        Me.lbl_Staffconphone.Text = "Phone No :"
        '
        'txt_Student_Contact_WorkNo
        '
        Me.txt_Student_Contact_WorkNo.BackColor = System.Drawing.Color.White
        Me.txt_Student_Contact_WorkNo.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Student_Contact_WorkNo.Location = New System.Drawing.Point(129, 79)
        Me.txt_Student_Contact_WorkNo.MaxLength = 10
        Me.txt_Student_Contact_WorkNo.Name = "txt_Student_Contact_WorkNo"
        Me.txt_Student_Contact_WorkNo.Size = New System.Drawing.Size(282, 21)
        Me.txt_Student_Contact_WorkNo.TabIndex = 54
        '
        'lbl_Staffconwork
        '
        Me.lbl_Staffconwork.AutoSize = True
        Me.lbl_Staffconwork.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_Staffconwork.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_Staffconwork.Location = New System.Drawing.Point(12, 81)
        Me.lbl_Staffconwork.Name = "lbl_Staffconwork"
        Me.lbl_Staffconwork.Size = New System.Drawing.Size(120, 17)
        Me.lbl_Staffconwork.TabIndex = 51
        Me.lbl_Staffconwork.Text = "Work No (if any) :"
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.dtpDate)
        Me.GroupBox5.Controls.Add(Me.Label3)
        Me.GroupBox5.Controls.Add(Me.lbl_StudClass)
        Me.GroupBox5.Controls.Add(Me.cboClass)
        Me.GroupBox5.Controls.Add(Me.cboDepartment)
        Me.GroupBox5.Controls.Add(Me.lbl_StudDept)
        Me.GroupBox5.Font = New System.Drawing.Font("Tahoma", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox5.Location = New System.Drawing.Point(836, 416)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(237, 167)
        Me.GroupBox5.TabIndex = 85
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Registration Information"
        '
        'dtpDate
        '
        Me.dtpDate.CustomFormat = "dd/MM/yyyy"
        Me.dtpDate.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtpDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpDate.Location = New System.Drawing.Point(14, 41)
        Me.dtpDate.Name = "dtpDate"
        Me.dtpDate.ShowCheckBox = True
        Me.dtpDate.Size = New System.Drawing.Size(205, 21)
        Me.dtpDate.TabIndex = 60
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.Label3.Location = New System.Drawing.Point(11, 24)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(106, 17)
        Me.Label3.TabIndex = 59
        Me.Label3.Text = "Date Registered"
        '
        'lbl_StudClass
        '
        Me.lbl_StudClass.AutoSize = True
        Me.lbl_StudClass.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StudClass.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_StudClass.Location = New System.Drawing.Point(29, 112)
        Me.lbl_StudClass.Name = "lbl_StudClass"
        Me.lbl_StudClass.Size = New System.Drawing.Size(85, 17)
        Me.lbl_StudClass.TabIndex = 56
        Me.lbl_StudClass.Text = "Class / Form"
        '
        'cboClass
        '
        Me.cboClass.BackColor = System.Drawing.Color.White
        Me.cboClass.Enabled = False
        Me.cboClass.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboClass.FormattingEnabled = True
        Me.cboClass.Location = New System.Drawing.Point(18, 130)
        Me.cboClass.Name = "cboClass"
        Me.cboClass.Size = New System.Drawing.Size(201, 23)
        Me.cboClass.Sorted = True
        Me.cboClass.TabIndex = 57
        '
        'cboDepartment
        '
        Me.cboDepartment.BackColor = System.Drawing.Color.White
        Me.cboDepartment.Enabled = False
        Me.cboDepartment.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboDepartment.FormattingEnabled = True
        Me.cboDepartment.Location = New System.Drawing.Point(18, 85)
        Me.cboDepartment.Name = "cboDepartment"
        Me.cboDepartment.Size = New System.Drawing.Size(201, 23)
        Me.cboDepartment.TabIndex = 55
        '
        'lbl_StudDept
        '
        Me.lbl_StudDept.AutoSize = True
        Me.lbl_StudDept.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_StudDept.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_StudDept.Location = New System.Drawing.Point(22, 68)
        Me.lbl_StudDept.Name = "lbl_StudDept"
        Me.lbl_StudDept.Size = New System.Drawing.Size(82, 17)
        Me.lbl_StudDept.TabIndex = 54
        Me.lbl_StudDept.Text = "Department"
        '
        'btnDelete
        '
        Me.btnDelete.BackColor = System.Drawing.SystemColors.Control
        Me.btnDelete.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnDelete.Enabled = False
        Me.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnDelete.Font = New System.Drawing.Font("Tahoma", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDelete.ForeColor = System.Drawing.Color.SteelBlue
        Me.btnDelete.Image = CType(resources.GetObject("btnDelete.Image"), System.Drawing.Image)
        Me.btnDelete.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnDelete.Location = New System.Drawing.Point(530, 13)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.Size = New System.Drawing.Size(133, 40)
        Me.btnDelete.TabIndex = 87
        Me.btnDelete.Text = "&Delete"
        Me.btnDelete.UseVisualStyleBackColor = False
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.btnSave)
        Me.GroupBox6.Controls.Add(Me.btnClear)
        Me.GroupBox6.Controls.Add(Me.btnCancel)
        Me.GroupBox6.Controls.Add(Me.btnDelete)
        Me.GroupBox6.Location = New System.Drawing.Point(15, 584)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(1058, 62)
        Me.GroupBox6.TabIndex = 91
        Me.GroupBox6.TabStop = False
        '
        'frmManageStudentProfile
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(1086, 651)
        Me.Controls.Add(Me.GroupBox6)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.MaximizeBox = False
        Me.Name = "frmManageStudentProfile"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "SIMS"
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        CType(Me.dgv, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.GroupBox6.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents lbl_Staffcontown As System.Windows.Forms.Label
    Friend WithEvents txtRegNo As System.Windows.Forms.TextBox
    Friend WithEvents txtFirstName As System.Windows.Forms.TextBox
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents btnSave As System.Windows.Forms.Button
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents dgv As System.Windows.Forms.DataGridView
    Friend WithEvents dtpicker_Student_DateOfBirth As System.Windows.Forms.DateTimePicker
    Friend WithEvents cboGender As System.Windows.Forms.ComboBox
    Friend WithEvents cboTitle As System.Windows.Forms.ComboBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents lbl_StaffDOB As System.Windows.Forms.Label
    Friend WithEvents lbl_StaffGender As System.Windows.Forms.Label
    Friend WithEvents lbl_StaffTitle As System.Windows.Forms.Label
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents cbo_Student_Religion As System.Windows.Forms.ComboBox
    Friend WithEvents txt_Student_House_Number As System.Windows.Forms.TextBox
    Friend WithEvents txt_Student_Hometown As System.Windows.Forms.TextBox
    Friend WithEvents lbl_StaffHometown As System.Windows.Forms.Label
    Friend WithEvents lblregion As System.Windows.Forms.Label
    Friend WithEvents lbl_StaffHouseno As System.Windows.Forms.Label
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents cbo_Student_Nationality As System.Windows.Forms.ComboBox
    Friend WithEvents lbl_StaffNationality As System.Windows.Forms.Label
    Friend WithEvents cbo_Student_Region As System.Windows.Forms.ComboBox
    Friend WithEvents lbl_StaffReligion As System.Windows.Forms.Label
    Friend WithEvents cbo_Student_District As System.Windows.Forms.ComboBox
    Friend WithEvents lbl_StaffEmail As System.Windows.Forms.Label
    Friend WithEvents txt_Student_Contact_Name As System.Windows.Forms.TextBox
    Friend WithEvents lbl_StaffConName As System.Windows.Forms.Label
    Friend WithEvents txt_Student_Contact_Number As System.Windows.Forms.TextBox
    Friend WithEvents lbl_Staffconphone As System.Windows.Forms.Label
    Friend WithEvents txt_Student_Contact_WorkNo As System.Windows.Forms.TextBox
    Friend WithEvents lbl_Staffconwork As System.Windows.Forms.Label
    Friend WithEvents txt_Student_Contact_Email As System.Windows.Forms.TextBox
    Friend WithEvents cbo_Student_Contact_Occupation As System.Windows.Forms.ComboBox
    Friend WithEvents cbo_Student_Contact_Relation As System.Windows.Forms.ComboBox
    Friend WithEvents lbl_Staffnextrel As System.Windows.Forms.Label
    Friend WithEvents lbl_StaffOccup As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txt_Student_Contact_Address As System.Windows.Forms.TextBox
    Friend WithEvents lbl_StaffAddress As System.Windows.Forms.Label
    Friend WithEvents cboDepartment As System.Windows.Forms.ComboBox
    Friend WithEvents lbl_StudDept As System.Windows.Forms.Label
    Friend WithEvents lbl_StudClass As System.Windows.Forms.Label
    Friend WithEvents cboClass As System.Windows.Forms.ComboBox
    Friend WithEvents dtpDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents btnDelete As System.Windows.Forms.Button
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtMDName As System.Windows.Forms.TextBox
    Friend WithEvents txt_student_age As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtLastname As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents Column1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column5 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column6 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column7 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column8 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column9 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column10 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column11 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column12 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column13 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column14 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column15 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column16 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column17 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column18 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column19 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column20 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column21 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column22 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column23 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column24 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column25 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents txtSID As System.Windows.Forms.TextBox
End Class
