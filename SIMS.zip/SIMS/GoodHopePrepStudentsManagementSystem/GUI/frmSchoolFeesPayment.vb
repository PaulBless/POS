﻿Imports System.Data.SqlClient

Public Class frmSchoolFeesPayment

    Private Sub txtRegNo_TextChanged(sender As Object, e As EventArgs) Handles txtRegNo.TextChanged, txtPayeeName.TextChanged
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()

            Dim cmd As SqlCommand = New SqlCommand("select * from Students where RegistrationNumber='" & Me.txtRegNo.Text & "'", ConnectionModule.con)
            Dim reader As SqlDataReader = cmd.ExecuteReader(CommandBehavior.CloseConnection)
            If (reader.Read()) Then
                txtSID.Text = reader.GetValue(0)
                txtName.Text = reader.GetValue(2) + " " + reader.GetValue(3) + " " + reader.GetValue(4)
                txtGender.Text = reader.GetValue(20)
                txtClass.Text = reader.GetValue(8)
                txtDept.Text = reader.GetValue(7)
            End If
            cmd.Dispose()

        Catch ex As Exception
            MsgBox(ex.Message)
            con.Close()
        End Try
    End Sub

    Sub Clearme()
        txtSID.Clear()
        txtRegNo.Clear()
        txtDept.Clear()
        txtClass.Clear()
        txtAmt.Clear()
        cboTerm.ResetText()
        txtName.Clear()
        txtGender.Clear()
        txtYear.Clear()
        txtPayeeNo.Clear()
        txtPayeeName.Clear()
        txtRegNo.Focus()
    End Sub


    Sub CurrentFeesPaid()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            com = New SqlCommand("select StudentID from FeesPaid where StudentID='" & txtSID.Text & "'", ConnectionModule.con)
            dr = com.ExecuteReader(CommandBehavior.CloseConnection)
            If dr.Read() = True Then
                dr.Close()
                con.Close()
                com1 = New SqlCommand("update FeesPaid set TotalPaid=TotalPaid + ('" & txtAmt.Text & "') where StudentID=@d1", ConnectionModule.con)
                com1.Parameters.AddWithValue("@d1", txtSID.Text)
                con.Open()
                com1.ExecuteNonQuery()
                con.Close()
            Else
                If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                ConnectionModule.con.Open()
                com = New SqlCommand("insert into FeesPaid (StudentID,TotalPaid) values (@d1,@d2)", ConnectionModule.con)
                com.Parameters.AddWithValue("@d1", txtSID.Text)
                com.Parameters.AddWithValue("@d2", txtAmt.Text)
             com.ExecuteNonQuery()
            End If

        Catch ex As Exception
            MsgBox(ex.ToString(), MsgBoxStyle.OkOnly + MsgBoxStyle.Critical, "error at currentfeepaid")
        End Try
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        If txtRegNo.Text = "" Then MsgBox("Enter student registration number", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "SIMS") : txtRegNo.Focus() : Exit Sub
        If cboAcademicYear.Text = "" Then MsgBox("Select academic year", MsgBoxStyle.OkOnly + MsgBoxStyle.Exclamation, "SIMS") : Exit Sub
        If cboTerm.Text = "" Then MsgBox("Select academic term", MsgBoxStyle.OkOnly + MsgBoxStyle.Exclamation, "SIMS") : Exit Sub
        If txtAmt.Text = "" Then MsgBox("Enter payment amount", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "SIMS") : txtAmt.Focus() : Exit Sub
        If txtPayeeName.Text = "" Then MsgBox("Enter payee name", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "SIMS") : txtPayeeName.Focus() : Exit Sub
        If txtPayeeNo.Text = "" Then MsgBox("Enter payee mobile number", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "SIMS") : txtPayeeNo.Focus() : Exit Sub
        If Not IsNumeric(txtPayeeNo.Text) Then MsgBox("Mobile number should be digits", MsgBoxStyle.OkOnly + MsgBoxStyle.Exclamation, "SIMS") : txtPayeeNo.Focus() : txtPayeeNo.SelectAll() : Exit Sub
        If Not IsNumeric(txtAmt.Text) Then MsgBox("Payment amount should be numeric/figures.", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "SIMS") : txtAmt.Focus() : txtAmt.SelectAll() : Exit Sub

        If MsgBox("Are you sure you want to save this payment record?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "SIMS") = MsgBoxResult.Yes Then
            Try
                If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                ConnectionModule.con.Open()
                com = New SqlCommand("insert into SchoolFees (StudentID,Year,Term,Amount,DatePaid,PayeeName,PayeeNo,ProcessedBy) values (@d1,@d2,@d3,@d4,@d5,@d6,@d7,@d8)", ConnectionModule.con)
                com.Parameters.AddWithValue("@d1", txtSID.Text)
                com.Parameters.AddWithValue("@d2", cboAcademicYear.Text)
                com.Parameters.AddWithValue("@d3", cboTerm.Text)
                com.Parameters.AddWithValue("@d4", txtAmt.Text)
                com.Parameters.AddWithValue("@d5", Date.Now)
                com.Parameters.AddWithValue("@d6", txtPayeeName.Text)
                com.Parameters.AddWithValue("@d7", txtPayeeNo.Text)
                com.Parameters.AddWithValue("@d8", LogName)
                com.ExecuteNonQuery()
                CurrentFeesPaid()
                MsgBox("Payment Successfully saved", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "SIMS - Success")
                Clearme()

            Catch ex As Exception
                MsgBox(ex.Message)
                con.Close()
            End Try
        End If

    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        Clearme()
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub

    Private Sub frmSchoolFeesPayment_FormClosed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed
        Clearme()
    End Sub

    Private Sub frmSchoolFeesPayment_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ActiveControl = txtRegNo
        'Me.Text = Me.Text + " - [Current User: " + frmLog.Logname + "]"

    End Sub

    Private Sub GroupBox4_Enter(sender As Object, e As EventArgs) Handles GroupBox4.Enter

    End Sub
    Public Sub AddAcademicYear()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            dset = New Data.DataSet()
            adapter = New SqlDataAdapter()
            adapter.SelectCommand = New SqlCommand("select ID,New from AcademicYear order by New", ConnectionModule.con)
            dset.Clear()
            adapter.Fill(dset, "AcademicYear")
            cboAcademicYear.DataSource = dset.Tables("AcademicYear")
            cboAcademicYear.DisplayMember = "New"
            cboAcademicYear.ValueMember = "ID"
            cboAcademicYear.Refresh()
            cboAcademicYear.SelectedIndex = -1
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at add academic info")
            con.Close()
        End Try
    End Sub

    Public Sub AddTerm()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            dset = New Data.DataSet()
            adapter = New SqlDataAdapter()
            adapter.SelectCommand = New SqlCommand("select ID,Term from Term order by Term", ConnectionModule.con)
            dset.Clear()
            adapter.Fill(dset, "Term")
            cboTerm.DataSource = dset.Tables("Term")
            cboTerm.DisplayMember = "Term"
            cboTerm.ValueMember = "ID"
            cboTerm.Refresh()
            cboTerm.SelectedIndex = -1
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at add term info")
            con.Close()
        End Try
    End Sub


    Private Sub cboAcademicYear_DropDown(sender As Object, e As EventArgs) Handles cboAcademicYear.DropDown
        AddAcademicYear()
    End Sub


    'com = New SqlCommand("insert into SchoolFees1 (StudentID,YearID,Term,Amount,DatePaid,PayeeName,PayeeNo,ProcessedBy) values (@d1,@d2,@d3,@d4,@d5,@d6,@d7,@d8)", ConnectionModule.con)
    'com.Parameters.AddWithValue("@d1", txtSID.Text)
    'com.Parameters.AddWithValue("@d2", cboAcademicYear.SelectedValue)
    'com.Parameters.AddWithValue("@d3", cboTerm.Text)
    'com.Parameters.AddWithValue("@d4", txtAmt.Text)
    'com.Parameters.AddWithValue("@d5", Date.Now)
    'com.Parameters.AddWithValue("@d6", txtPayeeName.Text)
    'com.Parameters.AddWithValue("@d7", txtPayeeNo.Text)
    'com.Parameters.AddWithValue("@d8", frmLog.Logname)
    'com.ExecuteNonQuery()

    Private Sub cboTerm_DropDown(sender As Object, e As EventArgs) Handles cboTerm.DropDown
        AddTerm()
    End Sub
End Class