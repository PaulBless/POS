﻿Imports System.Data.SqlClient

Public Class frmDesignation

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        '  If txtname.Text = "" Then MsgBox("Enter attendance status", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "SIMS Error") : Exit Sub
        Try
            'check record exists
            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            com1 = New SqlCommand("select * from designation where desgname='" & (txtname.Text) & "'", ConnectionModule.con)
            dr = com1.ExecuteReader(CommandBehavior.CloseConnection)
            If dr.Read() = True Then
                dr.Close()
                con.Close()
                MsgBox("Record Exists.. Cannot save duplicate record..." + vbCrLf + "NB:- Please update the record..", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "SIMS") : Exit Sub
            Else
                If con.State = ConnectionState.Open Then con.Close()
                com1 = New SqlCommand("insert into designation(desgname) values (@d1)", ConnectionModule.con)
                com1.Parameters.Add("@d1", SqlDbType.NVarChar).Value = txtname.Text
                con.Open()
                com1.ExecuteNonQuery()
                MessageBox.Show("Saved successfully.", "SIMS", MessageBoxButtons.OK, MessageBoxIcon.Information)
                com1.Dispose()  'dispose the command
                con.Close()     'close the db connection
                'clear controls
                btnSave.Enabled = False
                txtID.Clear()
                txtname.Clear()
                GetDesignation()
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Private Sub GetDesignation()
        Try
            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            com1 = New SqlCommand("select * from designation", ConnectionModule.con)
            dr = com1.ExecuteReader(CommandBehavior.CloseConnection)
            dgv.Rows.Clear()
            While dr.Read() = True
                dgv.Rows.Add(dr(0), dr(1))
            End While
            'dr.Close()
            con.Close()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Private Sub dgv_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv.CellContentClick
        Try
            txtID.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(0).Value
            txtname.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(1).Value.ToString()
            btnDelete.Enabled = True
            btnUpdate.Enabled = True
            btnSave.Enabled = False
        Catch ex As Exception

        End Try

    End Sub
    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        If txtID.Text = String.Empty Then MsgBox("Invalid record selection, check..", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "SIMS Error") : Exit Sub
        Try
            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            com1 = New SqlCommand("update designation set desgname=@d1 where ID='" & dgv.SelectedRows(0).Cells(0).Value & "'", con)
            com1.Parameters.Add("@d1", SqlDbType.NVarChar).Value = txtname.Text
            com1.ExecuteNonQuery()
            MessageBox.Show("Updated successfully.", "SIMS", MessageBoxButtons.OK, MessageBoxIcon.Information)
            com1.Dispose()
            con.Close()
            'clear controls
            txtID.Clear()
            txtname.Clear()
            btnUpdate.Enabled = False
            btnDelete.Enabled = False
            btnSave.Enabled = True
            GetDesignation()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        If txtID.Text = String.Empty Then MsgBox("Invalid record selection, check..", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "SIMS Error") : Exit Sub

        If MessageBox.Show("Deleted the selected designation. Continue?", "SIMS", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) = MsgBoxResult.Ok Then
            Try
                If con.State = ConnectionState.Open Then con.Close()
                con.Open()
                com1 = New SqlCommand("delete from designation where ID='" & dgv.SelectedRows(0).Cells(0).Value & "'", ConnectionModule.con)
                com1.ExecuteNonQuery()
                MessageBox.Show("Deleted successfully.", "SIMS", MessageBoxButtons.OK, MessageBoxIcon.Information)
                com1.Dispose()
                con.Close()
                'clear controls
                txtID.Clear()
                txtname.Clear()
                btnDelete.Enabled = False
                btnUpdate.Enabled = False
                btnSave.Enabled = True
                GetDesignation()

            Catch ex As Exception
                MessageBox.Show(ex.Message)
            End Try
        End If

    End Sub

    Private Sub txtYear_TextChanged(sender As Object, e As EventArgs) Handles txtname.TextChanged
        If (txtname.Text) = "" Then
            btnSave.Enabled = False
        Else
            btnSave.Enabled = True
        End If
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub frmDesignation_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        GetDesignation()

    End Sub
End Class