﻿Imports System.Data.SqlClient

Public Class BillSettings

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        If txtItem.Text = "" Then MsgBox("Specify the bill item", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "SIMS Error") : Exit Sub
        If txtAmount.Text = "" Then MsgBox("Specify the item amount", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "SIMS Error") : Exit Sub
        'confirm saving
        If MsgBox("Do you really want to save this record?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "Confirmation") = MsgBoxResult.Yes Then
            Try
                'check record exists
                If con.State = ConnectionState.Open Then con.Close()
                con.Open()
                com = New SqlCommand("select * from bill1 where itemname='" & txtItem.Text & "' and amount='" & Val(txtAmount.Text) & "'", con)
                dr = com.ExecuteReader(CommandBehavior.CloseConnection)
                If dr.Read() = True Then
                    dr.Close()
                    'show error message
                    MessageBox.Show("Record Exists. Cannot save duplicate data NB:- Please update the record.. ", "Duplicate", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Exit Sub
                Else
                    'insert bill item
                    If con.State = ConnectionState.Open Then con.Close()
                    con.Open()
                    com1 = New SqlCommand("insert into bill1(itemname,amount) values (@d1,@d2)", con)
                    com1.Parameters.Add("@d1", SqlDbType.NVarChar).Value = txtItem.Text
                    com1.Parameters.Add("@d2", SqlDbType.Real).Value = Val(txtAmount.Text)
                    com1.ExecuteNonQuery()
                    MessageBox.Show("Successfully saved.", "SIMS", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    com1.Dispose()
                    con.Close()
                    'clear controls
                    ClearMe()
                    btnUpdate.Enabled = False
                    btnDelete.Enabled = False
                    Exit Sub
                End If

            Catch ex As Exception
                MessageBox.Show(ex.Message)
            End Try
        End If
    End Sub
    Private Sub GetBillData()
        Try
            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            com1 = New SqlCommand("select * from bill1", ConnectionModule.con)
            dr = com1.ExecuteReader(CommandBehavior.CloseConnection)
            dgv.Rows.Clear()
            While dr.Read() = True
                dgv.Rows.Add(dr(0), dr(1), dr(2))
            End While
            'dr.Close()
            con.Close()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Sub ClearMe()
        txtID.Text = ""
        txtAmount.Text = ""
        txtItem.Text = ""
        GetBillData()
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub
    Private Sub txtAmount_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtAmount.KeyPress
        If Asc(e.KeyChar) <> 13 AndAlso Asc(e.KeyChar) <> 8 AndAlso Not IsNumeric(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        If MsgBox("Do you really want to delete this record?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "Confirmation") = MsgBoxResult.Yes Then
            Try
                'check record exists
                If con.State = ConnectionState.Open Then con.Close()
                con.Open()
                com = New SqlCommand("select * from bill1 where billid='" & Val(txtID.Text) & "'", con)
                dr = com.ExecuteReader(CommandBehavior.CloseConnection)
                If dr.HasRows() = True Then
                    'delete record
                    If con.State = ConnectionState.Open Then con.Close()
                    con.Open()
                    com1 = New SqlCommand("delete from bill1 where billid='" & dgv.SelectedRows(0).Cells(0).Value & "'", ConnectionModule.con)
                    com1.ExecuteNonQuery()
                    MessageBox.Show("Successfully deleted.", "SIMS", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    com1.Dispose()
                    con.Close()
                    'clear controls
                    ClearMe()
                    btnUpdate.Enabled = False
                    btnDelete.Enabled = False
                Else
                    'show error message
                    MessageBox.Show("Could not find specific record criteria to perform deletion.. ", "SIMS", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Exit Sub
                End If

            Catch ex As Exception
                MessageBox.Show(ex.Message)
            End Try
        End If
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        'If txtID.Text = String.Empty Then MsgBox("Invalid record selection, check..", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "SIMS Error") : Exit Sub
        If MsgBox("Do you really want to update this record?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "Confirmation") = MsgBoxResult.Yes Then
            Try
                'check record exists
                If con.State = ConnectionState.Open Then con.Close()
                con.Open()
                com = New SqlCommand("select * from bill1 where billid='" & Val(txtID.Text) & "'", con)
                dr = com.ExecuteReader(CommandBehavior.CloseConnection)
                If dr.HasRows() = True Then
                    'update the record
                    If con.State = ConnectionState.Open Then con.Close()
                    con.Open()
                    com1 = New SqlCommand("update bill1 set itemname=@d2, amount=@d3 where billid='" & dgv.SelectedRows(0).Cells(0).Value & "'", con)
                    com1.Parameters.Add("@d2", SqlDbType.NVarChar).Value = txtItem.Text
                    com1.Parameters.Add("@d3", SqlDbType.Real).Value = Val(txtAmount.Text)
                    com1.ExecuteNonQuery()
                    MessageBox.Show("Successfully updated.", "SIMS", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    com1.Dispose()
                    con.Close()
                    'clear controls
                    ClearMe()
                    btnSave.Enabled = True
                    btnUpdate.Enabled = False
                    btnDelete.Enabled = False
                Else
                    'show error message
                    MessageBox.Show("Could not find specific record criteria to perform update.. ", "SIMS", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Exit Sub
                End If

            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End If

    End Sub

    Private Sub BillSettings_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        GetBillData()
    End Sub

    Private Sub dgv_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv.CellContentClick

    End Sub

    Private Sub dgv_CellDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv.CellDoubleClick
        Try
            txtID.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(0).Value
            txtItem.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(1).Value.ToString()
            txtAmount.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(2).Value.ToString()
            btnUpdate.Enabled = True
            btnDelete.Enabled = True
            btnSave.Enabled = False
        Catch ex As Exception

        End Try
    End Sub
End Class