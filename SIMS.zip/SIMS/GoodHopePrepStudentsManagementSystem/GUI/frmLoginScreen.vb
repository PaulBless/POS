﻿Imports System.Data.SqlClient

Public Class frmLoginScreen

    Private Sub LoginUser()
        If txt_Username.Text = "" Then
            MessageBox.Show("Username is required.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Information)
            txt_Username.Focus()
            Exit Sub
        ElseIf txt_Password.Text = "" Then
            MsgBox("Password is required.", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Error")
            txt_Password.Focus()
            Exit Sub
        End If

        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()

            Dim Command As SqlCommand = New SqlCommand("SELECT Username,Password,Role FROM Users WHERE Username= '" & txt_Username.Text & "' and Password= '" & txt_Password.Text & "' ", ConnectionModule.con)
            Dim datareader As SqlDataReader = Command.ExecuteReader
            While datareader.Read
                If datareader.HasRows Then
                    If datareader.GetValue(2).ToString = "Admin" Then
                        MsgBox("Login Success")
                        Me.Hide()
                        txt_Username.Clear()
                        txt_Password.Clear()
                        AdminSection.Show()
                    Else
                        Exit Sub
                        MessageBox.Show("Wrong Username or Password!", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End If
                End If
                If datareader.HasRows Then
                    If datareader.GetValue(2).ToString = "User" Then
                        MsgBox("Login Success")
                        Me.Hide()
                        txt_Username.Clear()
                        txt_Password.Clear()
                        StaffSection.Show()
                    Else
                        Exit Sub
                        MessageBox.Show("Wrong Username or Password!", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End If
                End If
            End While
        Catch ex As Exception
            MsgBox(ex.Message)
            con.Close()
        End Try
    End Sub

    Private Sub btn_Login_Click(sender As Object, e As EventArgs) Handles btn_Login.Click
        LoginUser()
    End Sub

    Private Sub btn_Cancel_Login_Click(sender As Object, e As EventArgs) Handles btn_Cancel_Login.Click
        If MsgBox("Are you sure you want to exit?", MsgBoxStyle.YesNo + MsgBoxStyle.Question, "Close Window") = MsgBoxResult.Yes Then
            End
        End If
    End Sub
End Class