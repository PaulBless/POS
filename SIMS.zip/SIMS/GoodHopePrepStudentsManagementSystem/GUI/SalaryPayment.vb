﻿Imports System.Data.SqlClient

Public Class SalaryPayment

    Dim paid As String = "Yes"

    Private Sub btnHelp_Click(sender As Object, e As EventArgs) Handles btnHelp.Click
        'validate error
        If txtEmpID.Text = "" Then
            MsgBox("Please, employee id is required.", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "SMIS")
            txtEmpID.Focus()
            Exit Sub
        End If
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            com1 = New SqlCommand("SELECT * from vwStaffJobDetails1 where StaffCode='" & Me.txtEmpID.Text & "'", ConnectionModule.con)
            dr = com1.ExecuteReader(CommandBehavior.CloseConnection)
            If (dr.Read()) = True Then
                SearchId = dr.GetValue(0)
                txtSID.Text = dr.GetValue(0)
                txtEmployeeID.Text = dr.GetValue(1)
                txtTitle.Text = dr.GetValue(6)
                txtName.Text = dr.GetValue(2) + " " + dr.GetValue(3) + " " + dr.GetValue(4)
                txtGender.Text = dr.GetValue(5)
                txtPhone.Text = dr.GetValue(7)
                txtNation.Text = dr.GetValue(18)
                txtBackground.Text = dr.GetValue(8)
                txtQualification.Text = dr.GetValue(9)
                txtCategory.Text = dr.GetValue(10)
                txtDept.Text = dr.GetValue(11)
                txtJob.Text = dr.GetValue(12)
                txtStatus.Text = dr.GetValue(15)
                txtBasicSalary.Text = Format(dr.GetValue(19))
                btnSave.Enabled = True
                com1.Dispose()
            ElseIf dr.Read() = False Then
                MsgBox("Oooopps, the employee id you entered is incorrect or has no job specification!.." + vbCrLf + "Ensure that the employee has been designated to his/her specified job...This can be done using the 'Employee Designation' section.", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "Search Error")
                txtEmpID.SelectAll()
                txtEmpID.Focus()
                Exit Sub
            End If

        Catch ex As SqlException
            ErrorToString()
        Catch ex As Exception
            MsgBox(ex.Message)
            con.Close()
        End Try
    End Sub
    Sub Clearme()
        txtSID.Clear()
        txtName.Clear()
        txtGender.Clear()
        txtJob.Clear()
        txtPhone.Clear()
        txtQualification.Clear()
        txtBackground.Clear()
        txtCategory.Clear()
        txtEmpID.Clear()
        txtDept.Clear()
        txtTitle.Clear()
        txtStatus.Clear()
        txtBasicSalary.Clear()
        txtEmployeeID.Clear()
        txtNation.Clear()
        cboMonth.ResetText()
        cboYear.ResetText()
        cboTerm.ResetText()
        txtSalary.Clear()
        txtEmpID.Focus()
        btnSave.Enabled = False 'disable save button
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        'error validations
        If cboYear.Text = "" Then MsgBox("Specify the academic year", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Error") : cboYear.Focus() : Exit Sub
        If cboTerm.Text = "" Then MsgBox("Specify the school term", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Error") : Exit Sub
        If cboMonth.Text = "" Then MsgBox("Select the month of payment", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Error") : Exit Sub
        If txtSalary.Text = "" Then MsgBox("Payment amount is required", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Error") : txtSalary.Focus() : Exit Sub
        If (Val(txtSalary.Text) > Val(txtBasicSalary.Text)) Then
            MsgBox("Payment amount cannot be more than 'Basic Salary' of the employee", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "Error")
            txtSalary.Focus()
            txtSalary.SelectAll()
            Exit Sub
        End If
        If (Val(txtSalary.Text) < Val(txtBasicSalary.Text)) Then
            MsgBox("Payment amount cannot be less than 'Basic Salary' of the employee.", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "Error")
            txtSalary.Focus()
            txtSalary.SelectAll()
            Exit Sub
        End If
        'check the current status of employee
        If txtStatus.Text = "INACTIVE" Then MsgBox("The status of the employee is currently 'INACTIVE', Cannot continue payment..", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "Error") : Exit Sub

        'prompt for confirmation
        If MsgBox("Do you really want to save this salary payment record", MsgBoxStyle.YesNo + MsgBoxStyle.Question, "Confirmation") = MsgBoxResult.Yes Then
            Try
                If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                ConnectionModule.con.Open()
                'check if specific payment exists
                query = "select * from salarypayment1 where staffid=@d1 and year=@d2 and term=@d3 and month=@d4"
                com1 = New SqlCommand(query, con)
                com1.Parameters.AddWithValue("@d1", SearchId)
                com1.Parameters.AddWithValue("@d2", cboYear.Text)
                com1.Parameters.AddWithValue("@d3", cboTerm.Text)
                com1.Parameters.AddWithValue("@d4", cboMonth.Text)
                dr = com1.ExecuteReader(CommandBehavior.CloseConnection)
                If dr.Read() = True Then
                    Dim paidDate As String = dr.GetValue(7)
                    MsgBox("Duplicate Found.. The payment you are trying to add already exists.. " + vbNewLine + "Salary had been paid to the selected employee on '" + paidDate + "'", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "Payment Exists")
                    dr.Close()
                    Exit Sub
                Else
                    If con.State = ConnectionState.Open Then con.Close()
                    con.Open()
                    com = New SqlCommand("insert into SalaryPayment1(StaffID,Year,Term,Month,Salary,PaymentDate,IsPaid) values(@d1,@d2,@d3,@d4,@d5,@d6,@d7)", ConnectionModule.con)
                    com.Parameters.AddWithValue("@d1", SearchId)
                    com.Parameters.AddWithValue("@d2", cboYear.Text)
                    com.Parameters.AddWithValue("@d3", cboTerm.Text)
                    com.Parameters.AddWithValue("@d4", cboMonth.Text)
                    com.Parameters.AddWithValue("@d5", Val(txtSalary.Text))
                    com.Parameters.AddWithValue("@d6", Date.Now)
                    com.Parameters.AddWithValue("@d7", paid)
                    com.ExecuteNonQuery()
                    MessageBox.Show("Payment successfully saved!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Clearme()
                End If

            Catch ex As Exception
                MessageBox.Show(ex.Message)
            Finally
                con.Close()
            End Try

        End If
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        If MsgBox("Clear the form?", MsgBoxStyle.YesNo + MsgBoxStyle.Question) = DialogResult.Yes Then
            Clearme()
        End If
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub

    Private Sub txtSalary_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtSalary.KeyPress
        If Asc(e.KeyChar) <> 13 AndAlso Asc(e.KeyChar) <> 8 AndAlso Not IsNumeric(e.KeyChar) AndAlso Asc(e.KeyChar) <> 46 Then
            e.Handled = True
        Else
            e.Handled = False
        End If
    End Sub

    Private Sub txtSalary_TextChanged(sender As Object, e As EventArgs) Handles txtSalary.TextChanged

    End Sub
    Public Sub AcademicYear()
        Try
            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            dset = New Data.DataSet()
            adapter = New SqlDataAdapter()
            adapter.SelectCommand = New SqlCommand("select distinct year from session order by year desc", ConnectionModule.con)
            dset.Clear()
            adapter.Fill(dset, "session")
            cboYear.DataSource = dset.Tables("session")
            cboYear.DisplayMember = "year"
            cboYear.Refresh()
            cboYear.SelectedIndex = -1
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at get academicyear")
            con.Close()
        End Try
    End Sub
    Public Sub AcademicTerm()
        Try
            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            dset = New Data.DataSet()
            adapter = New SqlDataAdapter()
            adapter.SelectCommand = New SqlCommand("select distinct term from session order by term asc", ConnectionModule.con)
            dset.Clear()
            adapter.Fill(dset, "session")
            cboTerm.DataSource = dset.Tables("session")
            cboTerm.DisplayMember = "term"
            cboTerm.Refresh()
            cboTerm.SelectedIndex = -1
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at get academicterm")
            con.Close()
        End Try
    End Sub

    Private Sub cboTerm_DropDown(sender As Object, e As EventArgs) Handles cboTerm.DropDown
        AcademicTerm()
    End Sub

    Private Sub cboYear_DropDown(sender As Object, e As EventArgs) Handles cboYear.DropDown
        AcademicYear()
    End Sub

    Private Sub SalaryPayment_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ActiveControl = txtEmpID
    End Sub
End Class