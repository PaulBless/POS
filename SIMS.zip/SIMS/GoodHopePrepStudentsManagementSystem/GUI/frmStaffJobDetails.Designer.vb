﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmStaffJobDetails
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmStaffJobDetails))
        Me.gbojobdetails = New System.Windows.Forms.GroupBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.DateEmployed = New System.Windows.Forms.DateTimePicker()
        Me.lbl_StaffDateEmployed = New System.Windows.Forms.Label()
        Me.cboSaffdepartment = New System.Windows.Forms.ComboBox()
        Me.cboPortfolio = New System.Windows.Forms.ComboBox()
        Me.cboStatus = New System.Windows.Forms.ComboBox()
        Me.lbl_Staffdepartment = New System.Windows.Forms.Label()
        Me.cboDesignation = New System.Windows.Forms.ComboBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.cboStaffcategory = New System.Windows.Forms.ComboBox()
        Me.lbl_Staffcategory = New System.Windows.Forms.Label()
        Me.cboStaffqualification = New System.Windows.Forms.ComboBox()
        Me.lbl_Staffqualification = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.lblFile = New System.Windows.Forms.Label()
        Me.cboType = New System.Windows.Forms.ComboBox()
        Me.cboBackground = New System.Windows.Forms.ComboBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.cboCode = New System.Windows.Forms.ComboBox()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtEmpID = New System.Windows.Forms.TextBox()
        Me.btnAddFile = New System.Windows.Forms.Button()
        Me.btnHelp = New System.Windows.Forms.Button()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.lbl_Staffssnit = New System.Windows.Forms.Label()
        Me.lbl_6 = New System.Windows.Forms.Label()
        Me.lbl_5 = New System.Windows.Forms.Label()
        Me.lbl_4 = New System.Windows.Forms.Label()
        Me.lbl_3 = New System.Windows.Forms.Label()
        Me.lbl_2 = New System.Windows.Forms.Label()
        Me.lbl_1 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.gbojobdetails.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.Panel2.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'gbojobdetails
        '
        Me.gbojobdetails.Controls.Add(Me.Label15)
        Me.gbojobdetails.Controls.Add(Me.Label14)
        Me.gbojobdetails.Controls.Add(Me.Label13)
        Me.gbojobdetails.Controls.Add(Me.DateEmployed)
        Me.gbojobdetails.Controls.Add(Me.lbl_StaffDateEmployed)
        Me.gbojobdetails.Controls.Add(Me.cboSaffdepartment)
        Me.gbojobdetails.Controls.Add(Me.cboPortfolio)
        Me.gbojobdetails.Controls.Add(Me.cboStatus)
        Me.gbojobdetails.Controls.Add(Me.lbl_Staffdepartment)
        Me.gbojobdetails.Controls.Add(Me.cboDesignation)
        Me.gbojobdetails.Controls.Add(Me.Label6)
        Me.gbojobdetails.Controls.Add(Me.Label5)
        Me.gbojobdetails.Controls.Add(Me.Label2)
        Me.gbojobdetails.Controls.Add(Me.cboStaffcategory)
        Me.gbojobdetails.Controls.Add(Me.lbl_Staffcategory)
        Me.gbojobdetails.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbojobdetails.Location = New System.Drawing.Point(124, 317)
        Me.gbojobdetails.Name = "gbojobdetails"
        Me.gbojobdetails.Size = New System.Drawing.Size(636, 137)
        Me.gbojobdetails.TabIndex = 4
        Me.gbojobdetails.TabStop = False
        Me.gbojobdetails.Text = "Job Details/Description"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.Color.Red
        Me.Label15.Location = New System.Drawing.Point(105, 59)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(15, 19)
        Me.Label15.TabIndex = 75
        Me.Label15.Text = "*"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.Color.Red
        Me.Label14.Location = New System.Drawing.Point(105, 97)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(15, 19)
        Me.Label14.TabIndex = 75
        Me.Label14.Text = "*"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.Color.Red
        Me.Label13.Location = New System.Drawing.Point(105, 25)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(15, 19)
        Me.Label13.TabIndex = 75
        Me.Label13.Text = "*"
        '
        'DateEmployed
        '
        Me.DateEmployed.CalendarFont = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DateEmployed.CalendarMonthBackground = System.Drawing.Color.White
        Me.DateEmployed.Checked = False
        Me.DateEmployed.CustomFormat = "dd/MM/yyyy"
        Me.DateEmployed.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DateEmployed.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.DateEmployed.Location = New System.Drawing.Point(431, 91)
        Me.DateEmployed.Name = "DateEmployed"
        Me.DateEmployed.ShowCheckBox = True
        Me.DateEmployed.Size = New System.Drawing.Size(181, 23)
        Me.DateEmployed.TabIndex = 74
        '
        'lbl_StaffDateEmployed
        '
        Me.lbl_StaffDateEmployed.AutoSize = True
        Me.lbl_StaffDateEmployed.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold)
        Me.lbl_StaffDateEmployed.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_StaffDateEmployed.Location = New System.Drawing.Point(344, 93)
        Me.lbl_StaffDateEmployed.Name = "lbl_StaffDateEmployed"
        Me.lbl_StaffDateEmployed.Size = New System.Drawing.Size(74, 17)
        Me.lbl_StaffDateEmployed.TabIndex = 73
        Me.lbl_StaffDateEmployed.Text = "Start Date "
        '
        'cboSaffdepartment
        '
        Me.cboSaffdepartment.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.cboSaffdepartment.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.cboSaffdepartment.BackColor = System.Drawing.Color.White
        Me.cboSaffdepartment.DropDownHeight = 75
        Me.cboSaffdepartment.DropDownWidth = 75
        Me.cboSaffdepartment.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.cboSaffdepartment.FormattingEnabled = True
        Me.cboSaffdepartment.IntegralHeight = False
        Me.cboSaffdepartment.Location = New System.Drawing.Point(431, 23)
        Me.cboSaffdepartment.Name = "cboSaffdepartment"
        Me.cboSaffdepartment.Size = New System.Drawing.Size(181, 23)
        Me.cboSaffdepartment.TabIndex = 49
        '
        'cboPortfolio
        '
        Me.cboPortfolio.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cboPortfolio.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.cboPortfolio.BackColor = System.Drawing.Color.White
        Me.cboPortfolio.DropDownHeight = 120
        Me.cboPortfolio.DropDownWidth = 105
        Me.cboPortfolio.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.cboPortfolio.FormattingEnabled = True
        Me.cboPortfolio.IntegralHeight = False
        Me.cboPortfolio.Location = New System.Drawing.Point(431, 57)
        Me.cboPortfolio.Name = "cboPortfolio"
        Me.cboPortfolio.Size = New System.Drawing.Size(181, 23)
        Me.cboPortfolio.Sorted = True
        Me.cboPortfolio.TabIndex = 36
        '
        'cboStatus
        '
        Me.cboStatus.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.cboStatus.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.cboStatus.BackColor = System.Drawing.Color.White
        Me.cboStatus.DropDownHeight = 107
        Me.cboStatus.DropDownWidth = 105
        Me.cboStatus.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.cboStatus.FormattingEnabled = True
        Me.cboStatus.IntegralHeight = False
        Me.cboStatus.Items.AddRange(New Object() {"ACTIVE"})
        Me.cboStatus.Location = New System.Drawing.Point(126, 93)
        Me.cboStatus.Name = "cboStatus"
        Me.cboStatus.Size = New System.Drawing.Size(185, 23)
        Me.cboStatus.TabIndex = 36
        '
        'lbl_Staffdepartment
        '
        Me.lbl_Staffdepartment.AutoSize = True
        Me.lbl_Staffdepartment.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold)
        Me.lbl_Staffdepartment.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_Staffdepartment.Location = New System.Drawing.Point(344, 25)
        Me.lbl_Staffdepartment.Name = "lbl_Staffdepartment"
        Me.lbl_Staffdepartment.Size = New System.Drawing.Size(86, 17)
        Me.lbl_Staffdepartment.TabIndex = 48
        Me.lbl_Staffdepartment.Text = "Department "
        '
        'cboDesignation
        '
        Me.cboDesignation.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.cboDesignation.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.cboDesignation.BackColor = System.Drawing.Color.White
        Me.cboDesignation.DropDownHeight = 77
        Me.cboDesignation.DropDownWidth = 77
        Me.cboDesignation.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.cboDesignation.FormattingEnabled = True
        Me.cboDesignation.IntegralHeight = False
        Me.cboDesignation.Location = New System.Drawing.Point(126, 57)
        Me.cboDesignation.Name = "cboDesignation"
        Me.cboDesignation.Size = New System.Drawing.Size(185, 23)
        Me.cboDesignation.Sorted = True
        Me.cboDesignation.TabIndex = 47
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label6.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.Label6.Location = New System.Drawing.Point(22, 59)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(87, 17)
        Me.Label6.TabIndex = 40
        Me.Label6.Text = "Designation "
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label5.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.Label5.Location = New System.Drawing.Point(58, 95)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(50, 17)
        Me.Label5.TabIndex = 12
        Me.Label5.Text = "Status "
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label2.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.Label2.Location = New System.Drawing.Point(344, 59)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(67, 17)
        Me.Label2.TabIndex = 12
        Me.Label2.Text = "Portfolio "
        '
        'cboStaffcategory
        '
        Me.cboStaffcategory.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.cboStaffcategory.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.cboStaffcategory.BackColor = System.Drawing.Color.White
        Me.cboStaffcategory.DropDownHeight = 75
        Me.cboStaffcategory.DropDownWidth = 75
        Me.cboStaffcategory.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.cboStaffcategory.FormattingEnabled = True
        Me.cboStaffcategory.IntegralHeight = False
        Me.cboStaffcategory.Items.AddRange(New Object() {"Teaching", "Non-Teaching"})
        Me.cboStaffcategory.Location = New System.Drawing.Point(126, 23)
        Me.cboStaffcategory.Name = "cboStaffcategory"
        Me.cboStaffcategory.Size = New System.Drawing.Size(185, 23)
        Me.cboStaffcategory.TabIndex = 37
        '
        'lbl_Staffcategory
        '
        Me.lbl_Staffcategory.AutoSize = True
        Me.lbl_Staffcategory.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold)
        Me.lbl_Staffcategory.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_Staffcategory.Location = New System.Drawing.Point(38, 25)
        Me.lbl_Staffcategory.Name = "lbl_Staffcategory"
        Me.lbl_Staffcategory.Size = New System.Drawing.Size(68, 17)
        Me.lbl_Staffcategory.TabIndex = 12
        Me.lbl_Staffcategory.Text = "Category "
        '
        'cboStaffqualification
        '
        Me.cboStaffqualification.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.cboStaffqualification.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.cboStaffqualification.BackColor = System.Drawing.Color.White
        Me.cboStaffqualification.DropDownHeight = 107
        Me.cboStaffqualification.DropDownWidth = 105
        Me.cboStaffqualification.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.cboStaffqualification.FormattingEnabled = True
        Me.cboStaffqualification.IntegralHeight = False
        Me.cboStaffqualification.Location = New System.Drawing.Point(126, 58)
        Me.cboStaffqualification.Name = "cboStaffqualification"
        Me.cboStaffqualification.Size = New System.Drawing.Size(486, 23)
        Me.cboStaffqualification.Sorted = True
        Me.cboStaffqualification.TabIndex = 36
        '
        'lbl_Staffqualification
        '
        Me.lbl_Staffqualification.AutoSize = True
        Me.lbl_Staffqualification.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold)
        Me.lbl_Staffqualification.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_Staffqualification.Location = New System.Drawing.Point(24, 60)
        Me.lbl_Staffqualification.Name = "lbl_Staffqualification"
        Me.lbl_Staffqualification.Size = New System.Drawing.Size(88, 17)
        Me.lbl_Staffqualification.TabIndex = 10
        Me.lbl_Staffqualification.Text = "Qualification"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label18)
        Me.GroupBox1.Controls.Add(Me.Label17)
        Me.GroupBox1.Controls.Add(Me.Label16)
        Me.GroupBox1.Controls.Add(Me.lblFile)
        Me.GroupBox1.Controls.Add(Me.cboType)
        Me.GroupBox1.Controls.Add(Me.cboBackground)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.cboStaffqualification)
        Me.GroupBox1.Controls.Add(Me.lbl_Staffqualification)
        Me.GroupBox1.Controls.Add(Me.Label20)
        Me.GroupBox1.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(124, 204)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(636, 107)
        Me.GroupBox1.TabIndex = 6
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Educational Information"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.ForeColor = System.Drawing.Color.Red
        Me.Label18.Location = New System.Drawing.Point(439, 27)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(15, 19)
        Me.Label18.TabIndex = 75
        Me.Label18.Text = "*"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.ForeColor = System.Drawing.Color.Red
        Me.Label17.Location = New System.Drawing.Point(110, 27)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(15, 19)
        Me.Label17.TabIndex = 75
        Me.Label17.Text = "*"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.ForeColor = System.Drawing.Color.Red
        Me.Label16.Location = New System.Drawing.Point(110, 60)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(15, 19)
        Me.Label16.TabIndex = 75
        Me.Label16.Text = "*"
        '
        'lblFile
        '
        Me.lblFile.AutoSize = True
        Me.lblFile.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold)
        Me.lblFile.ForeColor = System.Drawing.Color.Black
        Me.lblFile.Location = New System.Drawing.Point(123, 84)
        Me.lblFile.Name = "lblFile"
        Me.lblFile.Size = New System.Drawing.Size(15, 17)
        Me.lblFile.TabIndex = 12
        Me.lblFile.Text = "F"
        '
        'cboType
        '
        Me.cboType.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.cboType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.cboType.BackColor = System.Drawing.Color.White
        Me.cboType.DropDownHeight = 107
        Me.cboType.DropDownWidth = 105
        Me.cboType.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.cboType.FormattingEnabled = True
        Me.cboType.IntegralHeight = False
        Me.cboType.Items.AddRange(New Object() {"CASUAL", "CONTRACT", "OTHER", "PERMANENT", "TEMPORAL", "INTERNSHIP"})
        Me.cboType.Location = New System.Drawing.Point(455, 25)
        Me.cboType.Name = "cboType"
        Me.cboType.Size = New System.Drawing.Size(157, 23)
        Me.cboType.TabIndex = 36
        '
        'cboBackground
        '
        Me.cboBackground.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.cboBackground.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.cboBackground.BackColor = System.Drawing.Color.White
        Me.cboBackground.DropDownHeight = 107
        Me.cboBackground.DropDownWidth = 105
        Me.cboBackground.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.cboBackground.FormattingEnabled = True
        Me.cboBackground.IntegralHeight = False
        Me.cboBackground.Items.AddRange(New Object() {"BASIC", "SECONDARY", "TERTIARY", "OTHER"})
        Me.cboBackground.Location = New System.Drawing.Point(126, 25)
        Me.cboBackground.Name = "cboBackground"
        Me.cboBackground.Size = New System.Drawing.Size(185, 23)
        Me.cboBackground.TabIndex = 36
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label4.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.Label4.Location = New System.Drawing.Point(318, 27)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(123, 17)
        Me.Label4.TabIndex = 10
        Me.Label4.Text = "Appointment Type"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label3.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.Label3.Location = New System.Drawing.Point(31, 27)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(81, 17)
        Me.Label3.TabIndex = 10
        Me.Label3.Text = "Background"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label20.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.Label20.Location = New System.Drawing.Point(40, 82)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(78, 17)
        Me.Label20.TabIndex = 12
        Me.Label20.Text = "File Name :"
        '
        'cboCode
        '
        Me.cboCode.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.cboCode.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.cboCode.BackColor = System.Drawing.Color.White
        Me.cboCode.DropDownHeight = 75
        Me.cboCode.DropDownWidth = 75
        Me.cboCode.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.cboCode.FormattingEnabled = True
        Me.cboCode.IntegralHeight = False
        Me.cboCode.Location = New System.Drawing.Point(548, 11)
        Me.cboCode.Name = "cboCode"
        Me.cboCode.Size = New System.Drawing.Size(81, 23)
        Me.cboCode.TabIndex = 37
        Me.cboCode.Visible = False
        '
        'btnCancel
        '
        Me.btnCancel.BackColor = System.Drawing.SystemColors.Control
        Me.btnCancel.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnCancel.Font = New System.Drawing.Font("Tahoma", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCancel.ForeColor = System.Drawing.Color.SteelBlue
        Me.btnCancel.Image = CType(resources.GetObject("btnCancel.Image"), System.Drawing.Image)
        Me.btnCancel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnCancel.Location = New System.Drawing.Point(419, 19)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(135, 40)
        Me.btnCancel.TabIndex = 63
        Me.btnCancel.Text = "&Close"
        Me.btnCancel.UseVisualStyleBackColor = False
        '
        'btnClear
        '
        Me.btnClear.BackColor = System.Drawing.SystemColors.Control
        Me.btnClear.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnClear.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnClear.Font = New System.Drawing.Font("Tahoma", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClear.ForeColor = System.Drawing.Color.SteelBlue
        Me.btnClear.Image = CType(resources.GetObject("btnClear.Image"), System.Drawing.Image)
        Me.btnClear.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnClear.Location = New System.Drawing.Point(251, 19)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(135, 40)
        Me.btnClear.TabIndex = 65
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = False
        '
        'btnSave
        '
        Me.btnSave.BackColor = System.Drawing.SystemColors.Control
        Me.btnSave.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnSave.Font = New System.Drawing.Font("Tahoma", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSave.ForeColor = System.Drawing.Color.SteelBlue
        Me.btnSave.Image = CType(resources.GetObject("btnSave.Image"), System.Drawing.Image)
        Me.btnSave.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnSave.Location = New System.Drawing.Point(83, 19)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(135, 40)
        Me.btnSave.TabIndex = 66
        Me.btnSave.Text = "Save"
        Me.btnSave.UseVisualStyleBackColor = False
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.SteelBlue
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(780, 35)
        Me.Panel1.TabIndex = 71
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Trebuchet MS", 18.0!, System.Drawing.FontStyle.Bold)
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(230, 5)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(312, 29)
        Me.Label1.TabIndex = 12
        Me.Label1.Text = "Employee Job Assignment "
        '
        'txtEmpID
        '
        Me.txtEmpID.BackColor = System.Drawing.Color.White
        Me.txtEmpID.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtEmpID.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.txtEmpID.Location = New System.Drawing.Point(338, 42)
        Me.txtEmpID.MaxLength = 10
        Me.txtEmpID.Name = "txtEmpID"
        Me.txtEmpID.Size = New System.Drawing.Size(230, 21)
        Me.txtEmpID.TabIndex = 74
        '
        'btnAddFile
        '
        Me.btnAddFile.BackColor = System.Drawing.Color.Firebrick
        Me.btnAddFile.Cursor = System.Windows.Forms.Cursors.Default
        Me.btnAddFile.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnAddFile.FlatAppearance.BorderColor = System.Drawing.Color.DarkGray
        Me.btnAddFile.FlatAppearance.BorderSize = 0
        Me.btnAddFile.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnAddFile.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold)
        Me.btnAddFile.ForeColor = System.Drawing.Color.Gainsboro
        Me.btnAddFile.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnAddFile.Location = New System.Drawing.Point(673, 40)
        Me.btnAddFile.Name = "btnAddFile"
        Me.btnAddFile.Size = New System.Drawing.Size(88, 23)
        Me.btnAddFile.TabIndex = 76
        Me.btnAddFile.Text = "ADD FILE"
        Me.btnAddFile.UseVisualStyleBackColor = False
        '
        'btnHelp
        '
        Me.btnHelp.BackColor = System.Drawing.Color.LightSkyBlue
        Me.btnHelp.BackgroundImage = CType(resources.GetObject("btnHelp.BackgroundImage"), System.Drawing.Image)
        Me.btnHelp.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnHelp.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnHelp.FlatAppearance.BorderColor = System.Drawing.Color.DarkGray
        Me.btnHelp.FlatAppearance.BorderSize = 0
        Me.btnHelp.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnHelp.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold)
        Me.btnHelp.ForeColor = System.Drawing.Color.White
        Me.btnHelp.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnHelp.Location = New System.Drawing.Point(573, 42)
        Me.btnHelp.Name = "btnHelp"
        Me.btnHelp.Size = New System.Drawing.Size(24, 21)
        Me.btnHelp.TabIndex = 75
        Me.btnHelp.UseVisualStyleBackColor = False
        Me.btnHelp.Visible = False
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label11.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.Label11.Location = New System.Drawing.Point(47, 94)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(93, 17)
        Me.Label11.TabIndex = 12
        Me.Label11.Text = "Nationality   :"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label10.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.Label10.Location = New System.Drawing.Point(50, 67)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(91, 17)
        Me.Label10.TabIndex = 12
        Me.Label10.Text = "Phone          :"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label12.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.Label12.Location = New System.Drawing.Point(317, 38)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(92, 17)
        Me.Label12.TabIndex = 12
        Me.Label12.Text = "Age              :"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label9.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.Label9.Location = New System.Drawing.Point(50, 38)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(92, 17)
        Me.Label9.TabIndex = 12
        Me.Label9.Text = "Gender         :"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label8.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.Label8.Location = New System.Drawing.Point(50, 9)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(92, 17)
        Me.Label8.TabIndex = 12
        Me.Label8.Text = "Name           :"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.Label7.ForeColor = System.Drawing.Color.Indigo
        Me.Label7.Location = New System.Drawing.Point(226, 42)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(97, 19)
        Me.Label7.TabIndex = 12
        Me.Label7.Text = "EMPLOYEE ID"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.btnCancel)
        Me.GroupBox3.Controls.Add(Me.btnSave)
        Me.GroupBox3.Controls.Add(Me.btnClear)
        Me.GroupBox3.Location = New System.Drawing.Point(124, 469)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(636, 72)
        Me.GroupBox3.TabIndex = 76
        Me.GroupBox3.TabStop = False
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.ForeColor = System.Drawing.Color.Red
        Me.Label19.Location = New System.Drawing.Point(321, 42)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(15, 19)
        Me.Label19.TabIndex = 75
        Me.Label19.Text = "*"
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.SystemColors.Control
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel2.Controls.Add(Me.lbl_Staffssnit)
        Me.Panel2.Controls.Add(Me.Label11)
        Me.Panel2.Controls.Add(Me.cboCode)
        Me.Panel2.Controls.Add(Me.Label10)
        Me.Panel2.Controls.Add(Me.lbl_6)
        Me.Panel2.Controls.Add(Me.lbl_5)
        Me.Panel2.Controls.Add(Me.lbl_4)
        Me.Panel2.Controls.Add(Me.lbl_3)
        Me.Panel2.Controls.Add(Me.lbl_2)
        Me.Panel2.Controls.Add(Me.lbl_1)
        Me.Panel2.Controls.Add(Me.Label12)
        Me.Panel2.Controls.Add(Me.Label9)
        Me.Panel2.Controls.Add(Me.Label8)
        Me.Panel2.Location = New System.Drawing.Point(124, 66)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(636, 132)
        Me.Panel2.TabIndex = 77
        '
        'lbl_Staffssnit
        '
        Me.lbl_Staffssnit.AutoSize = True
        Me.lbl_Staffssnit.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_Staffssnit.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_Staffssnit.Location = New System.Drawing.Point(317, 67)
        Me.lbl_Staffssnit.Name = "lbl_Staffssnit"
        Me.lbl_Staffssnit.Size = New System.Drawing.Size(90, 17)
        Me.lbl_Staffssnit.TabIndex = 78
        Me.lbl_Staffssnit.Text = "SSNIT No     :"
        '
        'lbl_6
        '
        Me.lbl_6.AutoSize = True
        Me.lbl_6.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold)
        Me.lbl_6.ForeColor = System.Drawing.Color.Black
        Me.lbl_6.Location = New System.Drawing.Point(427, 67)
        Me.lbl_6.Name = "lbl_6"
        Me.lbl_6.Size = New System.Drawing.Size(15, 17)
        Me.lbl_6.TabIndex = 12
        Me.lbl_6.Text = "6"
        Me.lbl_6.Visible = False
        '
        'lbl_5
        '
        Me.lbl_5.AutoSize = True
        Me.lbl_5.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold)
        Me.lbl_5.ForeColor = System.Drawing.Color.Black
        Me.lbl_5.Location = New System.Drawing.Point(427, 38)
        Me.lbl_5.Name = "lbl_5"
        Me.lbl_5.Size = New System.Drawing.Size(15, 17)
        Me.lbl_5.TabIndex = 12
        Me.lbl_5.Text = "5"
        Me.lbl_5.Visible = False
        '
        'lbl_4
        '
        Me.lbl_4.AutoSize = True
        Me.lbl_4.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold)
        Me.lbl_4.ForeColor = System.Drawing.Color.Black
        Me.lbl_4.Location = New System.Drawing.Point(146, 94)
        Me.lbl_4.Name = "lbl_4"
        Me.lbl_4.Size = New System.Drawing.Size(15, 17)
        Me.lbl_4.TabIndex = 12
        Me.lbl_4.Text = "4"
        Me.lbl_4.Visible = False
        '
        'lbl_3
        '
        Me.lbl_3.AutoSize = True
        Me.lbl_3.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold)
        Me.lbl_3.ForeColor = System.Drawing.Color.Black
        Me.lbl_3.Location = New System.Drawing.Point(148, 67)
        Me.lbl_3.Name = "lbl_3"
        Me.lbl_3.Size = New System.Drawing.Size(15, 17)
        Me.lbl_3.TabIndex = 12
        Me.lbl_3.Text = "3"
        Me.lbl_3.Visible = False
        '
        'lbl_2
        '
        Me.lbl_2.AutoSize = True
        Me.lbl_2.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold)
        Me.lbl_2.ForeColor = System.Drawing.Color.Black
        Me.lbl_2.Location = New System.Drawing.Point(148, 38)
        Me.lbl_2.Name = "lbl_2"
        Me.lbl_2.Size = New System.Drawing.Size(15, 17)
        Me.lbl_2.TabIndex = 12
        Me.lbl_2.Text = "2"
        Me.lbl_2.Visible = False
        '
        'lbl_1
        '
        Me.lbl_1.AutoSize = True
        Me.lbl_1.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold)
        Me.lbl_1.ForeColor = System.Drawing.Color.Black
        Me.lbl_1.Location = New System.Drawing.Point(148, 9)
        Me.lbl_1.Name = "lbl_1"
        Me.lbl_1.Size = New System.Drawing.Size(15, 17)
        Me.lbl_1.TabIndex = 12
        Me.lbl_1.Text = "1"
        Me.lbl_1.Visible = False
        '
        'PictureBox1
        '
        Me.PictureBox1.BackgroundImage = CType(resources.GetObject("PictureBox1.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox1.Dock = System.Windows.Forms.DockStyle.Left
        Me.PictureBox1.Location = New System.Drawing.Point(0, 35)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(118, 510)
        Me.PictureBox1.TabIndex = 78
        Me.PictureBox1.TabStop = False
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'frmStaffJobDetails
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(780, 545)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.txtEmpID)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.btnAddFile)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.gbojobdetails)
        Me.Controls.Add(Me.btnHelp)
        Me.Controls.Add(Me.Label7)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.MaximizeBox = False
        Me.Name = "frmStaffJobDetails"
        Me.Text = "SMIS"
        Me.gbojobdetails.ResumeLayout(False)
        Me.gbojobdetails.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents gbojobdetails As System.Windows.Forms.GroupBox
    Friend WithEvents cboStaffcategory As System.Windows.Forms.ComboBox
    Friend WithEvents cboStaffqualification As System.Windows.Forms.ComboBox
    Friend WithEvents lbl_Staffcategory As System.Windows.Forms.Label
    Friend WithEvents lbl_Staffqualification As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents cboBackground As System.Windows.Forms.ComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents cboCode As System.Windows.Forms.ComboBox
    Friend WithEvents cboSaffdepartment As System.Windows.Forms.ComboBox
    Friend WithEvents lbl_Staffdepartment As System.Windows.Forms.Label
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents btnSave As System.Windows.Forms.Button
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cboType As System.Windows.Forms.ComboBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtEmpID As System.Windows.Forms.TextBox
    Friend WithEvents cboStatus As System.Windows.Forms.ComboBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents cboPortfolio As System.Windows.Forms.ComboBox
    Friend WithEvents cboDesignation As System.Windows.Forms.ComboBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents DateEmployed As System.Windows.Forms.DateTimePicker
    Friend WithEvents lbl_StaffDateEmployed As System.Windows.Forms.Label
    Friend WithEvents btnAddFile As System.Windows.Forms.Button
    Friend WithEvents btnHelp As System.Windows.Forms.Button
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Private WithEvents Label15 As System.Windows.Forms.Label
    Private WithEvents Label14 As System.Windows.Forms.Label
    Private WithEvents Label13 As System.Windows.Forms.Label
    Private WithEvents Label18 As System.Windows.Forms.Label
    Private WithEvents Label17 As System.Windows.Forms.Label
    Private WithEvents Label16 As System.Windows.Forms.Label
    Private WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents lbl_Staffssnit As System.Windows.Forms.Label
    Friend WithEvents lbl_6 As System.Windows.Forms.Label
    Friend WithEvents lbl_5 As System.Windows.Forms.Label
    Friend WithEvents lbl_4 As System.Windows.Forms.Label
    Friend WithEvents lbl_3 As System.Windows.Forms.Label
    Friend WithEvents lbl_2 As System.Windows.Forms.Label
    Friend WithEvents lbl_1 As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents lblFile As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
End Class
