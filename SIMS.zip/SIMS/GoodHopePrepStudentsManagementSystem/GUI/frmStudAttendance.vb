﻿Imports System.Data.SqlClient
Imports System.Net
Imports System.Web
Imports System.Data.SqlTypes
Imports System.Net.Sockets

Public Class frmStudAttendance

    Dim current As Integer = 1

    Private Sub frmStudAttendance_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
    Public Sub MyClassRooms()
        Try
            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            dset = New Data.DataSet()
            adapter = New SqlDataAdapter()
            adapter.SelectCommand = New SqlCommand("select distinct room from classroom order by room asc", ConnectionModule.con)
            dset.Clear()
            adapter.Fill(dset, "classroom")
            cboRoom.DataSource = dset.Tables("classroom")
            cboRoom.DisplayMember = "room"
            ''cboYear.ValueMember = "ID"
            cboRoom.Refresh()
            cboRoom.SelectedIndex = -1
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at get rooms")
            con.Close()
        End Try
    End Sub

    Public Sub AcademicYear()
        Try
            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            dset = New Data.DataSet()
            adapter = New SqlDataAdapter()
            adapter.SelectCommand = New SqlCommand("select distinct year from session order by year desc", ConnectionModule.con)
            dset.Clear()
            adapter.Fill(dset, "session")
            cboYear.DataSource = dset.Tables("session")
            cboYear.DisplayMember = "year"
            ''cboYear.ValueMember = "ID"
            cboYear.Refresh()
            cboYear.SelectedIndex = -1
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at get academicyear")
            con.Close()
        End Try
    End Sub
    Public Sub AcademicTerm()
        Try
            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            dset = New Data.DataSet()
            adapter = New SqlDataAdapter()
            adapter.SelectCommand = New SqlCommand("select distinct term from session order by term asc", ConnectionModule.con)
            dset.Clear()
            adapter.Fill(dset, "session")
            cboTerm.DataSource = dset.Tables("session")
            cboTerm.DisplayMember = "term"
            ''cboYear.ValueMember = "ID"
            cboTerm.Refresh()
            cboTerm.SelectedIndex = -1
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at get academicterm")
            con.Close()
        End Try
    End Sub

    Private Sub GetClassList_1()
        Try
            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            query = "select id, firstname + space(1) + middlename + space(1) + lastname as studname from students where class='CRECHE'"
            adapter = New SqlDataAdapter(query, con)
            table = New DataTable()
            adapter.Fill(table)
            dgv.Rows.Clear()
            For Each item As DataRow In table.Rows
                Dim i As Integer = dgv.Rows.Add()
                dgv.Rows(i).Cells(0).Value = "true"
                dgv.Rows(i).Cells(1).Value = item("studname").ToString()
                dgv.Rows(i).Cells(2).Value = item("id").ToString()
            Next

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Private Sub GetClassList_2()
        Try
            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            query = "select id, firstname + space(1) + middlename + space(1) + lastname as studname from students where class='NURSERY 1'"
            adapter = New SqlDataAdapter(query, con)
            table = New DataTable()
            adapter.Fill(table)
            dgv.Rows.Clear()
            For Each item As DataRow In table.Rows
                Dim i As Integer = dgv.Rows.Add()
                dgv.Rows(i).Cells(0).Value = "true"
                dgv.Rows(i).Cells(1).Value = item("studname").ToString()
                dgv.Rows(i).Cells(2).Value = item("id").ToString()
            Next

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Private Sub GetClassList_3()
        Try
            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            query = "select id, firstname + space(1) + middlename + space(1) + lastname as studname from students where class='NURSERY 2'"
            adapter = New SqlDataAdapter(query, con)
            table = New DataTable()
            adapter.Fill(table)
            dgv.Rows.Clear()
            For Each item As DataRow In table.Rows
                Dim i As Integer = dgv.Rows.Add()
                dgv.Rows(i).Cells(0).Value = "true"
                dgv.Rows(i).Cells(1).Value = item("studname").ToString()
                dgv.Rows(i).Cells(2).Value = item("id").ToString()
            Next

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Private Sub GetClassList_4()
        Try
            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            query = "select id, firstname + space(1) + middlename + space(1) + lastname as studname from students where class='KG 1'"
            adapter = New SqlDataAdapter(query, con)
            table = New DataTable()
            adapter.Fill(table)
            dgv.Rows.Clear()
            For Each item As DataRow In table.Rows
                Dim i As Integer = dgv.Rows.Add()
                dgv.Rows(i).Cells(0).Value = "true"
                dgv.Rows(i).Cells(1).Value = item("studname").ToString()
                dgv.Rows(i).Cells(2).Value = item("id").ToString()
            Next

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Private Sub GetClassList_5()
        Try
            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            query = "select id, firstname + space(1) + middlename + space(1) + lastname as studname from students where class='KG 2'"
            adapter = New SqlDataAdapter(query, con)
            table = New DataTable()
            adapter.Fill(table)
            dgv.Rows.Clear()
            For Each item As DataRow In table.Rows
                Dim i As Integer = dgv.Rows.Add()
                dgv.Rows(i).Cells(0).Value = "true"
                dgv.Rows(i).Cells(1).Value = item("studname").ToString()
                dgv.Rows(i).Cells(2).Value = item("id").ToString()
            Next

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Private Sub GetClassList_6()
        Try
            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            query = "select id, firstname + space(1) + middlename + space(1) + lastname as studname from students where class='PRIMARY 1'"
            adapter = New SqlDataAdapter(query, con)
            table = New DataTable()
            adapter.Fill(table)
            dgv.Rows.Clear()
            For Each item As DataRow In table.Rows
                Dim i As Integer = dgv.Rows.Add()
                dgv.Rows(i).Cells(0).Value = "true"
                dgv.Rows(i).Cells(1).Value = item("studname").ToString()
                dgv.Rows(i).Cells(2).Value = item("id").ToString()
            Next

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Private Sub GetClassList_7()
        Try
            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            query = "select id, firstname + space(1) + middlename + space(1) + lastname as studname from students where class='PRIMARY 2'"
            adapter = New SqlDataAdapter(query, con)
            table = New DataTable()
            adapter.Fill(table)
            dgv.Rows.Clear()
            For Each item As DataRow In table.Rows
                Dim i As Integer = dgv.Rows.Add()
                dgv.Rows(i).Cells(0).Value = "true"
                dgv.Rows(i).Cells(1).Value = item("studname").ToString()
                dgv.Rows(i).Cells(2).Value = item("id").ToString()
            Next

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Private Sub GetClassList_8()
        Try
            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            query = "select id, firstname + space(1) + middlename + space(1) + lastname as studname from students where class='PRIMARY 3'"
            adapter = New SqlDataAdapter(query, con)
            table = New DataTable()
            adapter.Fill(table)
            dgv.Rows.Clear()
            For Each item As DataRow In table.Rows
                Dim i As Integer = dgv.Rows.Add()
                dgv.Rows(i).Cells(0).Value = "true"
                dgv.Rows(i).Cells(1).Value = item("studname").ToString()
                dgv.Rows(i).Cells(2).Value = item("id").ToString()
            Next

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Private Sub GetClassList_9()
        Try
            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            query = "select id, firstname + space(1) + middlename + space(1) + lastname as studname from students where class='PRIMARY 4'"
            adapter = New SqlDataAdapter(query, con)
            table = New DataTable()
            adapter.Fill(table)
            dgv.Rows.Clear()
            For Each item As DataRow In table.Rows
                Dim i As Integer = dgv.Rows.Add()
                dgv.Rows(i).Cells(0).Value = "true"
                dgv.Rows(i).Cells(1).Value = item("studname").ToString()
                dgv.Rows(i).Cells(2).Value = item("id").ToString()
            Next

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Private Sub GetClassList_10()
        Try
            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            query = "select id, firstname + space(1) + middlename + space(1) + lastname as studname from students where class='PRIMARY 5'"
            adapter = New SqlDataAdapter(query, con)
            table = New DataTable()
            adapter.Fill(table)
            dgv.Rows.Clear()
            For Each item As DataRow In table.Rows
                Dim i As Integer = dgv.Rows.Add()
                dgv.Rows(i).Cells(0).Value = "true"
                dgv.Rows(i).Cells(1).Value = item("studname").ToString()
                dgv.Rows(i).Cells(2).Value = item("id").ToString()
            Next

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Private Sub GetClassList_11()
        Try
            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            query = "select id, firstname + space(1) + middlename + space(1) + lastname as studname from students where class='PRIMARY 6'"
            adapter = New SqlDataAdapter(query, con)
            table = New DataTable()
            adapter.Fill(table)
            dgv.Rows.Clear()
            For Each item As DataRow In table.Rows
                Dim i As Integer = dgv.Rows.Add()
                dgv.Rows(i).Cells(0).Value = "true"
                dgv.Rows(i).Cells(1).Value = item("studname").ToString()
                dgv.Rows(i).Cells(2).Value = item("id").ToString()
            Next

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Private Sub GetClassList_12()
        Try
            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            query = "select id, firstname + space(1) + middlename + space(1) + lastname as studname from students where class='JHS 1'"
            adapter = New SqlDataAdapter(query, con)
            table = New DataTable()
            adapter.Fill(table)
            dgv.Rows.Clear()
            For Each item As DataRow In table.Rows
                Dim i As Integer = dgv.Rows.Add()
                dgv.Rows(i).Cells(0).Value = "true"
                dgv.Rows(i).Cells(1).Value = item("studname").ToString()
                dgv.Rows(i).Cells(2).Value = item("id").ToString()
            Next

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Private Sub GetClassList_13()
        Try
            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            query = "select id, firstname + space(1) + middlename + space(1) + lastname as studname from students where class='JHS 2'"
            adapter = New SqlDataAdapter(query, con)
            table = New DataTable()
            adapter.Fill(table)
            dgv.Rows.Clear()
            For Each item As DataRow In table.Rows
                Dim i As Integer = dgv.Rows.Add()
                dgv.Rows(i).Cells(0).Value = "true"
                dgv.Rows(i).Cells(1).Value = item("studname").ToString()
                dgv.Rows(i).Cells(2).Value = item("id").ToString()
            Next

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Private Sub GetClassList_14()
        Try
            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            query = "select id, firstname + space(1) + middlename + space(1) + lastname as studname from students where class='JHS 3'"
            adapter = New SqlDataAdapter(query, con)
            table = New DataTable()
            adapter.Fill(table)
            dgv.Rows.Clear()
            For Each item As DataRow In table.Rows
                Dim i As Integer = dgv.Rows.Add()
                dgv.Rows(i).Cells(0).Value = "true"
                dgv.Rows(i).Cells(1).Value = item("studname").ToString()
                dgv.Rows(i).Cells(2).Value = item("id").ToString()
            Next

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub


    Private Sub cboTerm_DropDown(sender As Object, e As EventArgs) Handles cboTerm.DropDown
        AcademicTerm()
    End Sub

    Private Sub cboTerm_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboTerm.SelectedIndexChanged

    End Sub

    Private Sub cboRoom_Click(sender As Object, e As EventArgs) Handles cboRoom.Click
        Try
            dgv.Rows.Clear()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub cboRoom_DropDown(sender As Object, e As EventArgs) Handles cboRoom.DropDown
        MyClassRooms()
    End Sub

    Private Sub cboYear_DropDown(sender As Object, e As EventArgs) Handles cboYear.DropDown
        AcademicYear()
    End Sub

    Private Sub cboRoom_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboRoom.SelectedIndexChanged
        Try
            If cboRoom.Text = "CRECHE" Then
                dgv.Rows.Clear()
                GetClassList_1()
                Exit Sub
            ElseIf cboRoom.Text = "NURSERY 1" Then
                dgv.Rows.Clear()
                GetClassList_2()
                Exit Sub
            ElseIf cboRoom.Text = "NURSERY 2" Then
                dgv.Rows.Clear()
                GetClassList_3()
                Exit Sub
            ElseIf cboRoom.Text = "KG 1" Then
                dgv.Rows.Clear()
                GetClassList_4()
                Exit Sub
            ElseIf cboRoom.Text = "KG 2" Then
                dgv.Rows.Clear()
                GetClassList_5()
                Exit Sub
            ElseIf cboRoom.Text = "PRIMARY 1" Then
                dgv.Rows.Clear()
                GetClassList_6()
                Exit Sub
            ElseIf cboRoom.Text = "PRIMARY 2" Then
                dgv.Rows.Clear()
                GetClassList_7()
                Exit Sub
            ElseIf cboRoom.Text = "PRIMARY 3" Then
                dgv.Rows.Clear()
                GetClassList_8()
                Exit Sub
            ElseIf cboRoom.Text = "PRIMARY 4" Then
                dgv.Rows.Clear()
                GetClassList_9()
                Exit Sub
            ElseIf cboRoom.Text = "PRIMARY 5" Then
                dgv.Rows.Clear()
                GetClassList_10()
                Exit Sub
            ElseIf cboRoom.Text = "PRIMARY 6" Then
                dgv.Rows.Clear()
                GetClassList_11()
                Exit Sub
            ElseIf cboRoom.Text = "JHS 1" Then
                dgv.Rows.Clear()
                GetClassList_12()
                Exit Sub
            ElseIf cboRoom.Text = "JHS 2" Then
                dgv.Rows.Clear()
                GetClassList_13()
                Exit Sub
            ElseIf cboRoom.Text = "JHS 3" Then
                dgv.Rows.Clear()
                GetClassList_14()
                Exit Sub

            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        If cboRoom.Text = "" Then MsgBox("Input Error, please specify class", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "SIMS") : Exit Sub
        If cboYear.Text = "" Then MsgBox("Input Error, please specify academic year", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "SIMS") : Exit Sub
        If cboTerm.Text = "" Then MsgBox("Input Error, please specify term", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "SIMS") : Exit Sub
        ''If cboRoom.Text = "" Then MsgBox("Input Error, please specify class", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "SIMS") : Exit Sub

        If MsgBox("Are you sure you want to save this register?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "Confirmation") = DialogResult.Yes Then
            For Each item As DataGridViewRow In dgv.Rows
                'If (Convert.ToBoolean(item.Cells(0).Value)) Then
                'If (Boolean.Parse(item.Cells(0).Value.ToString())) Then
                'MsgBox("selected rows : " + item.Cells(0).RowIndex.ToString())
                Try
                    If con.State = ConnectionState.Open Then con.Close()
                    con.Open()
                    'sql statement with search criteria: academic year, studentid and term
                    query = "select * from studattendance where studid='" & item.Cells(2).Value.ToString() & "' and acayear='" & cboYear.Text.ToString() & "' and term='" & cboTerm.Text.ToString() & "'"
                    com = New SqlCommand(query, con)
                    dr = com.ExecuteReader()
                    If dr.Read() = True Then
                        'close reader and dbconnection
                        dr.Close()
                        con.Close()
                        query = "update studattendance set totalmade=totalmade + (" & current & "), outof=outof + (" & current & ") where studid='" & item.Cells(2).Value.ToString() & "'"
                        com1 = New SqlCommand(query, con)
                        con.Open()
                        com1.ExecuteNonQuery()
                        con.Close()
                        MsgBox("register updated")
                        'item.Cells(0).Value = False
                        Exit Sub
                    Else
                        If con.State = ConnectionState.Open Then con.Close()
                        query = "insert into studattendance(studid,totalmade,acayear,term,outof) values(@d1,@d2,@d3,@d4,@d5)"
                        com = New SqlCommand(query, con)
                        com.Parameters.Add("@d1", SqlDbType.Int).Value = item.Cells(2).Value.ToString()
                        com.Parameters.Add("@d2", SqlDbType.Int).Value = current
                        com.Parameters.Add("@d3", SqlDbType.NVarChar).Value = cboYear.Text.ToString()
                        com.Parameters.Add("@d4", SqlDbType.NVarChar).Value = cboTerm.Text.ToString()
                        com.Parameters.Add("@d5", SqlDbType.Int).Value = current
                        con.Open()
                        com.ExecuteNonQuery()
                        con.Close()
                        MsgBox("register saved")
                        Exit Sub
                    End If

                Catch ex As Exception
                    MsgBox(ex.Message)
                End Try

                'End If
                'End If
            Next


        End If


    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        ''encyption testing
        'Dim enterd As String = text1.Text
        'Dim value As String = EncryptNew(enterd)
        'text2.Text = value

        MsgBox(DateTime.Now)
       

    End Sub
End Class