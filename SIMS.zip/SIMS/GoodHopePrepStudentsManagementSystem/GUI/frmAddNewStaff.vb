﻿Imports System.Data.SqlClient
Imports CrystalDecisions.Shared.Json
Imports Microsoft.VisualBasic
Imports System.Windows.Forms
Imports System.IO
Imports System.Drawing.Imaging



Public Class frmAddNewStaff

    Dim a As New OpenFileDialog
    Dim pic As String
    Dim cmd As SqlCommand
    Dim rno As Integer = 0
    Dim ms As MemoryStream
    Dim photo_array As Byte()


    Dim _code As String 'variable to hold staffcode

    'Private Sub btnClearStaffpic_Click(sender As Object, e As EventArgs) Handles btnClearStaffpic.Click
    '    Picture.Image = Nothing
    'End Sub


    Function CheckName(ByVal Name As String) As Boolean
        If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
        ConnectionModule.con.Open()
        Dim value As Boolean = False

        Dim selectCustomerInfo As SqlCommand = New SqlCommand("select 'FirstName','LastName','MiddleName' from Staff where FirstName='" & Me.txtStafffirstname.Text & "' AND LastName='" & txtStaffsurname.Text & "' AND MiddleName='" & Me.txtStaffmiddlename.Text & "' ", ConnectionModule.con)
        Dim readInfo As SqlDataReader = selectCustomerInfo.ExecuteReader(CommandBehavior.CloseConnection)
        While readInfo.Read
            If readInfo(0) > 0 Then
                value = True
            End If
        End While
        con.Close()

        Return value
    End Function

    Sub ReturnCode()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            Dim command As SqlCommand = New SqlCommand("select * from Staff where FirstName='" & Me.txtStafffirstname.Text & "' and LastName='" & Me.txtStaffsurname.Text & "' and MiddleName='" & Me.txtStaffmiddlename.Text & "'", ConnectionModule.con)
            Dim reader As SqlDataReader = command.ExecuteReader(CommandBehavior.CloseConnection)
            If reader.HasRows Then
                While reader.Read()
                    _code = reader.GetValue(1)
                End While
            End If
            command.Dispose()

        Catch ex As Exception
            con.Close()

        End Try
    End Sub

    Sub AddRecord()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            cmd = New SqlCommand("insert into Staff(FirstName,MiddleName,LastName,Gender,Title,DOB,Age,MaritalStatus,PhoneNumber,Email,Hometown,HouseNo,Nationality,Region,Religion,SSNIT,Salary,ContactName,ContactNumber,Town,ContactHouseNo,Occupation,ContactRelation,NameofKin,NumberofKin,Relation,Date,IsBenefitAllowed) values (@d2,@d3,@d4,@d5,@d6,@d7,@d8,@d9,@d10,@d11,@d12,@d13,@d14,@d15,@d16,@d17,@d18,@d19,@d20,@d21,@d22,@d23,@d24,@d25,@d26,@d27,@d28,@d29)", ConnectionModule.con)
            cmd.Parameters.AddWithValue("@d2", txtStafffirstname.Text)
            cmd.Parameters.AddWithValue("@d3", txtStaffmiddlename.Text)
            cmd.Parameters.AddWithValue("@d4", txtStaffsurname.Text)
            cmd.Parameters.AddWithValue("@d5", cboGender.Text)
            cmd.Parameters.AddWithValue("@d6", cboTitle.Text)
            cmd.Parameters.AddWithValue("@d7", dtpDOB.Text.ToString())
            cmd.Parameters.AddWithValue("@d8", txtstaffage.Text)
            cmd.Parameters.AddWithValue("@d9", cbomaritalstatus.Text)
            cmd.Parameters.AddWithValue("@d10", txtStaffphone.Text)
            cmd.Parameters.AddWithValue("@d11", txtStaffemail.Text.Trim())
            cmd.Parameters.AddWithValue("@d12", txtStaffhometown.Text)
            cmd.Parameters.AddWithValue("@d13", txthouseno.Text)
            cmd.Parameters.AddWithValue("@d14", cboNationality.Text)
            cmd.Parameters.AddWithValue("@d15", cboStaffregion.Text)
            cmd.Parameters.AddWithValue("@d16", cboreligion.Text)
            cmd.Parameters.AddWithValue("@d17", txtStaffSsnit.Text)
            cmd.Parameters.AddWithValue("@d18", Format(Val(txtSalary.Text), "#,##0.00"))
            cmd.Parameters.AddWithValue("@d19", txtContactname.Text)
            cmd.Parameters.AddWithValue("@d20", txtContactphone.Text)
            cmd.Parameters.AddWithValue("@d21", txlocality.Text)
            cmd.Parameters.AddWithValue("@d22", txtContacthouse.Text)
            cmd.Parameters.AddWithValue("@d23", cboOccupation.Text)
            cmd.Parameters.AddWithValue("@d24", cboContactRelation.Text)
            cmd.Parameters.AddWithValue("@d25", txtNextofkin.Text)
            cmd.Parameters.AddWithValue("@d26", txtNextkinno.Text)
            cmd.Parameters.AddWithValue("@d27", cboKinRelation.Text)
            cmd.Parameters.AddWithValue("@d28", Date.Now.ToString())
            cmd.Parameters.AddWithValue("@d29", cboAllowance.Text)
            cmd.ExecuteNonQuery()
            ReturnCode()
            MsgBox("Record added successfully; EMPLOYEE ID : '" + _code.ToString + "'" + vbCrLf + "To complete the registration, specify job details/description using 'Employee Designation Master'..", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Successful")
            'clear form after saving
            ClearForm()

        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "Error.")
        Finally
            con.Close()
        End Try
        ' End If
        'End If


        'Dim ms As New MemoryStream()
        ''Dim bmpImage As New Bitmap(Picture.Image)
        'bmpImage.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg)
        'Dim data As Byte() = ms.GetBuffer()
        'Dim p As New SqlParameter("@d18", SqlDbType.Image)
        'p.Value = data
        'cmd.Parameters.Add(p)

    End Sub

    'Sub Find()
    '    adapt.MissingSchemaAction = MissingSchemaAction.AddWithKey
    'End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        'check empty fields
        If txtStafffirstname.Text = "" Then MsgBox("Enter firstname", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Error") : txtStafffirstname.Focus() : Exit Sub
        If txtStaffsurname.Text = "" Then MsgBox("Enter surname", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Error") : txtStaffsurname.Focus() : Exit Sub
        If cboGender.Text = "" Then MsgBox("Select gender", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Error") : Exit Sub
        If cbomaritalstatus.Text = "" Then MsgBox("Select marital Status", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Error") : Exit Sub
        If txtStaffphone.Text = "" Then MsgBox("Invalid employee phone number", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Error") : txtStaffphone.Focus() : Exit Sub
        If txthouseno.Text = "" Then MsgBox("Enter house number", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Error") : txthouseno.Focus() : Exit Sub
        If txtStaffhometown.Text = "" Then MsgBox("Enter hometown", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Error") : txtStaffhometown.Focus() : Exit Sub
        If txtContactname.Text = "" Then MsgBox("Enter contact name", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Error") : txtContactname.Focus() : Exit Sub
        If txtContactphone.Text = "" Then MsgBox("Enter contact phone number", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Error") : txtContactphone.Focus() : Exit Sub
        If cboreligion.Text = "" Then MsgBox("Select religion", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Error") : Exit Sub
        If dtpDOB.Value = Today Then MsgBox("Enter date of birth", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Error") : Exit Sub
        If txtSalary.Text = "" Then MsgBox("Enter basic salary of employee", MsgBoxStyle.OkOnly + MsgBoxStyle.Information, "Error") : Exit Sub
        If Not txtStaffphone.Text.StartsWith("0") Then
            MsgBox("Invalid employee phone number, must start with zero(0)", MsgBoxStyle.Exclamation, "Error") : txtStaffphone.SelectAll() : Exit Sub
        ElseIf txtStaffphone.TextLength < 10 Then
            MsgBox("Incomplete employee phone number, must be 10 digits", MsgBoxStyle.Exclamation, "Error") : txtStaffphone.SelectAll() : Exit Sub
        ElseIf Not txtContactphone.Text.StartsWith("0") Then
            MsgBox("Invalid contact phone number, must start with zero(0)", MsgBoxStyle.Exclamation, "Error") : txtContactphone.SelectAll() : Exit Sub
        ElseIf txtContactphone.TextLength < 10 Then
            MsgBox("Incomplete contact phone number, must be 10 digits", MsgBoxStyle.Exclamation, "Error") : txtContactphone.SelectAll() : Exit Sub
        ElseIf Not txtNextkinno.Text.StartsWith("0") Then
            MsgBox("Invalid next of kin phone number, must start with zero(0)", MsgBoxStyle.Exclamation, "Error") : txtNextkinno.SelectAll() : Exit Sub
        ElseIf txtStaffphone.TextLength < 10 Then
            MsgBox("Incomplete next of kin phone number, must be 10 digits", MsgBoxStyle.Exclamation, "Error") : txtNextkinno.SelectAll() : Exit Sub
        End If

        'If Picture.Image Is Nothing Or Not Picture.Image Is Nothing Then 'continue to save record whether image is uploaded or not
        Dim ans As DialogResult = MessageBox.Show("Are you sure you want to save this record?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If ans = Windows.Forms.DialogResult.Yes Then
            Try
                If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                ConnectionModule.con.Open()
                com = New SqlCommand("select 'FirstName','LastName','MiddleName' from Staff where FirstName='" & Me.txtStafffirstname.Text & "' AND LastName='" & txtStaffsurname.Text & "' AND MiddleName='" & Me.txtStaffmiddlename.Text & "' ", ConnectionModule.con)
                dr = com.ExecuteReader(CommandBehavior.CloseConnection)
                dr.Read()
                If Not dr.HasRows Then
                    AddRecord()
                    StaffSearch.Getdata()
                Else
                    MsgBox("Duplicate Record Found." & vbNewLine & "The name " + Me.txtStafffirstname.Text + " " + Me.txtStaffmiddlename.Text + " " + Me.txtStaffsurname.Text & " is already registered into the system.", MsgBoxStyle.Critical, "Duplicate")
                End If
                com.Dispose()
                dr.Close()
                con.Close()

            Catch ex As Exception
                MsgBox(ex.ToString())
            End Try
        End If
        'End If

    End Sub

    Sub ClearForm()
        txtContacthouse.Clear()
        txtContactname.Clear()
        txtContactphone.Clear()
        txtNextkinno.Clear()
        txtNextofkin.Clear()
        txtStaffSsnit.Clear()
        txlocality.Clear()
        txtSalary.Text = ""
        txtStaffemail.Clear()
        txtStafffirstname.Clear()
        txtStaffsurname.Clear()
        txtStaffmiddlename.Clear()
        txtStaffhometown.Clear()
        txtStaffphone.Clear()
        txtstaffage.Text = ""
        txthouseno.Clear()
        cboNationality.Text = ""
        cboStaffregion.Text = ""
        cboOccupation.ResetText()
        cboKinRelation.ResetText()
        cboTitle.ResetText()
        cbomaritalstatus.ResetText()
        cboContactRelation.ResetText()
        cboreligion.ResetText()
        cboGender.ResetText()
        dtpDOB.Text = Now
        cboAllowance.Text = ""
        'Picture.Image = Nothing
        txtStaffsurname.Focus()
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        Dim clear As MsgBoxResult = MsgBox("Clear the form?", MsgBoxStyle.YesNo + MsgBoxStyle.Question, "SMIS")
        If clear = MsgBoxResult.Yes Then
            ClearForm()
        End If
    End Sub

    'Sub convert_Photo()
    '    ' converting photo/image to binary format/data
    '    If Not Picture.Image Is Nothing Then
    '        'using filestream
    '        ''Dim fs As FileStream = New FileStream(a.FileName, FileMode.Open, FileAccess.Read)
    '        ''photo_array = New Byte() {fs.Length}
    '        ''fs.Read(photo_array, 0, photo_array.Length)

    '        'using memeorystream
    '        ms = New MemoryStream()
    '        Picture.Image.Save(ms, ImageFormat.Jpeg)
    '        photo_array = New Byte() {ms.Length}
    '        ms.Position = 0
    '        ms.Read(photo_array, 0, photo_array.Length)

    '        'cmd.Parameters.AddWithValue("@d18", photo_array)

    '    End If
    'End Sub


    'Private Sub btnUploadStaffpic_Click(sender As Object, e As EventArgs) Handles btnUploadStaffpic.Click
    '    'code to upload an image of staff
    '    'With OpenFileDialog1
    '    '.Title = "Select Staff Picture"
    '    '.Filter = ("Images |*.png; *.bmp; *.jpg;*.jpeg; *.gif;")
    '    '.Multiselect = False
    '    '.InitialDirectory = "@C:\"
    '    '.FileName = ""
    '    '.ShowDialog()
    '    'If .FileName <> "" Then
    '    '    pboStaffimage.Load(.FileName.ToString())
    '    'End If
    '    'End With

    '    'Dim pic As String
    '    'a.Title = "Select Staff Picture"
    '    'a.Filter = "jpeg|*jpg|All Files|*.*"
    '    'a.FilterIndex = 4
    '    'a.Multiselect = False
    '    'pic = a.FileName
    '    'a.ShowDialog()
    '    'Picture.Image = Image.FromFile(a.FileName)

    '    'code to browse for staff picture
    '    'Try
    '    '    With OpenFileDialog1
    '    '        .Filter = ("Images |*.png; *.bmp; *.jpg;*.jpeg; *.gif;")
    '    '        .FilterIndex = 4
    '    '        .Multiselect = False
    '    '    End With
    '    '    'Clear the file name
    '    '    OpenFileDialog1.FileName = ""
    '    '    If OpenFileDialog1.ShowDialog() = DialogResult.OK Then
    '    '        Picture.Image = Image.FromFile(OpenFileDialog1.FileName)
    '    '    End If
    '    'Catch ex As Exception
    '    '    MsgBox(ex.ToString())
    '    'End Try


    'End Sub

    Private Sub GetEmployeeData()
        Dim enteredID As String
        enteredID = InputBox("Provide the Employee ID in the box below and click the OK button")
        If con.State = ConnectionState.Open Then con.Close()
        con.Open()
        query = "select * from staff where staffcode=@d1"
        com = New SqlCommand(query, con)
        com.Parameters.AddWithValue("@d1", enteredID.ToString())
        table = New DataTable()
        adapter = New SqlDataAdapter(com)
        adapter.Fill(table)
        If table.Rows.Count < 1 Then
            'display search error
            MsgBox("The Employee ID you entered does not match any record..", MsgBoxStyle.OkOnly + MsgBoxStyle.Critical, "Search Error") : Exit Sub
        Else
            Try
                'read db values to textboxes
                SearchId = table.Rows(0)(0).ToString()
                txtStafffirstname.Text = table.Rows(0)(2).ToString()
                txtStaffmiddlename.Text = table.Rows(0)(3).ToString()
                txtStaffsurname.Text = table.Rows(0)(4).ToString()
                cboGender.Text = table.Rows(0)(5).ToString()
                cboTitle.Text = table.Rows(0)(6).ToString()
                dtpDOB.Text = table.Rows(0)(7).ToString()
                txtstaffage.Text = table.Rows(0)(8).ToString()
                cbomaritalstatus.Text = table.Rows(0)(9).ToString()
                txtStaffphone.Text = table.Rows(0)(10).ToString()
                txtStaffemail.Text = table.Rows(0)(11).ToString()
                txtStaffhometown.Text = table.Rows(0)(12).ToString()
                txthouseno.Text = table.Rows(0)(13).ToString()
                cboNationality.Text = table.Rows(0)(14).ToString()
                cboStaffregion.Text = table.Rows(0)(15).ToString()
                cboreligion.Text = table.Rows(0)(16).ToString()
                txtStaffSsnit.Text = table.Rows(0)(17).ToString()
                txtSalary.Text = table.Rows(0)(18).ToString()
                txtContactname.Text = table.Rows(0)(19).ToString()
                txtContactphone.Text = table.Rows(0)(20).ToString()
                txlocality.Text = table.Rows(0)(21).ToString()
                txtContacthouse.Text = table.Rows(0)(22).ToString()
                cboOccupation.Text = table.Rows(0)(23).ToString()
                cboContactRelation.Text = table.Rows(0)(24).ToString()
                txtNextofkin.Text = table.Rows(0)(25).ToString()
                txtNextkinno.Text = table.Rows(0)(26).ToString()
                cboKinRelation.Text = table.Rows(0)(27).ToString()
                cboAllowance.Text = table.Rows(0)(29).ToString()
                'btnSave.Enabled = False
            Catch ex As Exception
                ErrorToString()
            End Try

        End If
    End Sub

    Sub SearchEmployee_ByInputBoxValue()
        Try
            Dim msg As String
            msg = InputBox("Please enter all characters of the Employee ID in the box below and click OK")
            'open and close db_connection
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            com1 = New SqlCommand("select * from Staff where StaffCode='" & msg.ToString() & "'", ConnectionModule.con)
            dr = com1.ExecuteReader(CommandBehavior.CloseConnection)
            If dr.HasRows() = True Then
                While dr.Read()
                    txtStafffirstname.Text = dr.GetValue(2)
                    txtStaffmiddlename.Text = dr.GetValue(3)
                    txtStaffsurname.Text = dr.GetValue(4)
                    cboGender.Text = dr.GetValue(5)
                    cboTitle.Text = dr.GetValue(6)
                    dtpDOB.Text = dr.GetValue(7)
                    txtstaffage.Text = dr.GetValue(8)
                    cbomaritalstatus.Text = dr.GetValue(9)
                    txtStaffphone.Text = dr.GetValue(10)
                    txtStaffemail.Text = dr.GetValue(11)
                    txtStaffhometown.Text = dr.GetValue(12)
                    txthouseno.Text = dr.GetValue(13)
                    cboNationality.Text = dr.GetValue(14)
                    cboStaffregion.Text = dr.GetValue(15)
                    cboreligion.Text = dr.GetValue(16)
                    txtStaffSsnit.Text = dr.GetValue(17)
                    txtSalary.Text = dr.GetByte(18)
                    txtContactname.Text = dr.GetValue(19)
                    txtContactphone.Text = dr.GetValue(20)
                    txlocality.Text = dr.GetValue(21)
                    txtContacthouse.Text = dr.GetValue(22)
                    cboOccupation.Text = dr.GetValue(23)
                    cboContactRelation.Text = dr.GetValue(24)
                    txtNextofkin.Text = dr.GetValue(25)
                    txtNextkinno.Text = dr.GetValue(26)
                    cboKinRelation.Text = dr.GetValue(27)
                    cboAllowance.Text = dr.GetValue(29)
                End While
                com1.Dispose()
                'Exit Sub
            Else
                MsgBox("Invalid employee ID, no record found; please check...", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "Search Error")
                Exit Sub
            End If

        Catch ex As Exception
            ErrorToString()
        Finally
            con.Close()
        End Try

    End Sub
    Private Sub btnFind_Click(sender As Object, e As EventArgs)
        'invoke the method
        SearchEmployee_ByInputBoxValue()

    End Sub

    Private Sub cboStafftitle_Enter(sender As Object, e As EventArgs) Handles cboTitle.Enter
        If cboGender.Text = "" Then
            MsgBox("You must select gender", MsgBoxStyle.Information, "SIMS")
            cboGender.Focus()
        End If
    End Sub

  Private Sub txtstaffage_Click(sender As Object, e As EventArgs) Handles txtstaffage.Click
        MessageBox.Show("You must enter date of birth first!", "SMIS", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub

    Private Sub cboStaffgender_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboGender.SelectedIndexChanged
        cboTitle.Items.Clear()
      If cboGender.SelectedItem = "FEMALE" Then
            cboTitle.Items.Clear()
            cboTitle.Items.Add("Hajia")
            cboTitle.Items.Add("Miss")
            cboTitle.Items.Add("Mrs")
            Exit Sub
        ElseIf cboGender.SelectedItem = "MALE" Then
            cboTitle.Items.Clear()
            cboTitle.Items.Add("Mr")
            Exit Sub
        End If

    End Sub

    Private Sub frmAddNewStaff_Load(sender As Object, e As EventArgs) Handles MyBase.Load
      

      
    End Sub

    Sub addingnew()

        'Dim comdSave As SqlCommand = New SqlCommand("insert into tblStaff(FirstName,MiddleName,LastName,Gender,Title,DOB,Age,MaritalStatus,PhoneNumber,Email,Hometown,HouseNo,Nationality,Region,Religion,SSNIT,Salary,ContactName,ContactNumber,Town,ContactHouseNo,Occupation,ContactRelation,NameofKin,NumberofKin,Relation) values (@FirstName,@MiddleName,@LastName,@Gender,@Title,@DOB,@Age,@MaritalStatus,@PhoneNumber,@Email,@Hometown,@HouseNo,@Nationality,@Region,@Religion,@SSNIT,@Salary,@ContactName,@ContactNumber,@Town,@ContactHouseNo,@Occupation,@ContactRelation,@NameofKin,@NumberofKin,@Relation)", ConnectionModule.con)
        'comdSave.Parameters.AddWithValue("@FirstName", txtStafffirstname.Text)
        'comdSave.Parameters.AddWithValue("@MiddleName", txtStaffmiddlename.Text)
        'comdSave.Parameters.AddWithValue("@LastName", txtStaffsurname.Text)
        'comdSave.Parameters.AddWithValue("@Gender", cboStaffgender.Text)
        'comdSave.Parameters.AddWithValue("@Title", cboStafftitle.Text)
        '' comdSave.Parameters.AddWithValue("@DOB", Val(dtpStaff))
        'comdSave.Parameters.AddWithValue("@DOB", DateTimePicker1.Text)
        'comdSave.Parameters.AddWithValue("@Age", txtstaffage.Text)
        'comdSave.Parameters.AddWithValue("@MaritalStatus", cboStaffmaritalstatus.Text)
        'comdSave.Parameters.AddWithValue("@PhoneNumber", txtStaffphone.Text)
        'comdSave.Parameters.AddWithValue("@Email", txtStaffemail.Text)
        'comdSave.Parameters.AddWithValue("@Hometown", txtStaffhometown.Text)
        'comdSave.Parameters.AddWithValue("@HouseNo", txthouseno.Text)
        'comdSave.Parameters.AddWithValue("@Nationality", cboStaffnationality.Text)
        'comdSave.Parameters.AddWithValue("@Region", cboStaffregion.Text)
        'comdSave.Parameters.AddWithValue("@Religion", cbostaffreligion.Text)
        'comdSave.Parameters.AddWithValue("@SSNIT", txtStaffSsnit.Text)
        'comdSave.Parameters.Add("@Salary", SqlDbType.Image).Value = IO.File.ReadAllBytes(a.FileName)
        'comdSave.Parameters.AddWithValue("@ContactName", txtContactname.Text)
        'comdSave.Parameters.AddWithValue("@ContactNumber", txtContactphone.Text)
        'comdSave.Parameters.AddWithValue("@Town", txlocality.Text)
        'comdSave.Parameters.AddWithValue("@ContactHouseNo", txtContacthouse.Text)
        'comdSave.Parameters.AddWithValue("@Occupation", cboContactoccupation.Text)
        'comdSave.Parameters.AddWithValue("@ContactRelation", cboContactRelation.Text)
        'comdSave.Parameters.AddWithValue("@NameofKin", txtNextofkin.Text)
        'comdSave.Parameters.AddWithValue("@NumberofKin", txtNextkinno.Text)
        'comdSave.Parameters.AddWithValue("@Relation", cboKinRelation.Text)

    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs)
        ''If SearchId = 0 Then MsgBox("Invalid employee id, please check", MsgBoxStyle.OkOnly + MsgBoxStyle.Critical, "SIMS") : Exit Sub
        ''If MsgBox("The selected employee record will be 'permanently' Deleted from the system." + vbCrLf + "Are you sure you want to continue?", MsgBoxStyle.Critical + MsgBoxStyle.YesNo) = DialogResult.Yes Then
        ''    Try
        ''        If con.State = ConnectionState.Open Then con.Close()
        ''        con.Open()
        ''        com = New SqlCommand("delete from Staff where StaffID='" & SearchId & "'", ConnectionModule.con)
        ''        com.ExecuteNonQuery()
        ''        MessageBox.Show("Record Successfully Deleted.", "SIMS", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1)
        ''        com.Parameters.Clear()
        ''        ClearForm()

        ''    Catch ex As Exception
        ''        MessageBox.Show(ex.ToString(), "at delete")
        ''    End Try
        ''End If

        'Try
        '    MsgBox("This function can only be accessed from the Employee Profile Mastery", MsgBoxStyle.Exclamation, "SIMS") : Exit Sub
        'Catch ex As Exception

        'End Try
    End Sub

       Private Sub cboAllowance_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboAllowance.SelectedIndexChanged

    End Sub

    Private Sub txtStaffphone_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtStaffphone.KeyPress
        'accepts only numbers/digits
        If Asc(e.KeyChar) <> 13 AndAlso Asc(e.KeyChar) <> 8 AndAlso Not IsNumeric(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub

    Private Sub txtSalary_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtSalary.KeyPress
        'accepts only numbers/digits
        If Asc(e.KeyChar) <> 13 AndAlso Asc(e.KeyChar) <> 8 AndAlso Not IsNumeric(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub

    Private Sub txtContactphone_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtContactphone.KeyPress
        'accepts only numbers/digits
        If Asc(e.KeyChar) <> 13 AndAlso Asc(e.KeyChar) <> 8 AndAlso Not IsNumeric(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub

   Private Sub txtNextkinno_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtNextkinno.KeyPress
        'accepts only numbers/digits
        If Asc(e.KeyChar) <> 13 AndAlso Asc(e.KeyChar) <> 8 AndAlso Not IsNumeric(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub

    Private Sub txlocality_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txlocality.KeyPress
        Select Case Asc(e.KeyChar)
            Case 8, 32, 65 To 90, 97 To 122
                e.Handled = False
            Case Else
                e.Handled = True
        End Select
    End Sub

    Private Sub txtContactname_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtContactname.KeyPress
        Select Case Asc(e.KeyChar)
            Case 8, 32, 65 To 90, 97 To 122
                e.Handled = False
            Case Else
                e.Handled = True
        End Select
    End Sub

    Private Sub txtContactname_TextChanged(sender As Object, e As EventArgs) Handles txtContactname.TextChanged

    End Sub

    Private Sub txtStaffsurname_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtStaffsurname.KeyPress
        Select Case Asc(e.KeyChar)
            Case 8, 32, 65 To 90, 97 To 122
                e.Handled = False
            Case Else
                e.Handled = True
        End Select
    End Sub

    Private Sub txtStaffsurname_TextChanged(sender As Object, e As EventArgs) Handles txtStaffsurname.TextChanged

    End Sub

    Private Sub txtStafffirstname_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtStafffirstname.KeyPress
        Select Case Asc(e.KeyChar)
            Case 8, 32, 65 To 90, 97 To 122
                e.Handled = False
            Case Else
                e.Handled = True
        End Select
    End Sub

    Private Sub txtStafffirstname_TextChanged(sender As Object, e As EventArgs) Handles txtStafffirstname.TextChanged
       
    End Sub

    Private Sub txtStaffmiddlename_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtStaffmiddlename.KeyPress
        'reject special characters
        Select Case Asc(e.KeyChar)
            Case 33 To 44, 46, 58 To 64, 91 To 96, 123 To 126
                e.Handled = True
            Case Else
                e.Handled = False
        End Select
    End Sub

    Private Sub txtStaffemail_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtStaffemail.KeyPress
        'reject special characters
        Select Case Asc(e.KeyChar)
            Case 33 To 44, 46, 58 To 64, 91 To 96, 123 To 126
                e.Handled = True
            Case Else
                e.Handled = False
        End Select
    End Sub

    Private Sub txtStaffhometown_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtStaffhometown.KeyPress
        Select Case Asc(e.KeyChar)
            Case 8, 32, 65 To 90, 97 To 122
                e.Handled = False
            Case Else
                e.Handled = True
        End Select
    End Sub

    Private Sub txthouseno_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txthouseno.KeyPress
        Select Case Asc(e.KeyChar)
            Case 8, 32, 65 To 90, 97 To 122
                e.Handled = False
            Case Else
                e.Handled = True
        End Select
    End Sub

    Private Sub txtNextofkin_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtNextofkin.KeyPress
        Select Case Asc(e.KeyChar)
            Case 8, 32, 65 To 90, 97 To 122
                e.Handled = False
            Case Else
                e.Handled = True
        End Select
    End Sub

    Private Sub txtstaffage_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtstaffage.KeyPress
        'accepts only numbers/digits
        If Asc(e.KeyChar) <> 13 AndAlso Asc(e.KeyChar) <> 8 AndAlso Not IsNumeric(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub

    Private Sub txtstaffage_TextChanged(sender As Object, e As EventArgs) Handles txtstaffage.TextChanged

    End Sub

    Private Sub btnHelp_Click(sender As Object, e As EventArgs)
        'enable txtempid to entry
    End Sub

    Sub SearchEmployee_ByTextBoxValue()
        Try
          'open and close db_connection
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            com1 = New SqlCommand("select * from Staff where StaffCode=@d1'", ConnectionModule.con)
            'com1.Parameters.AddWithValue("@d1", txtEmpID.Text)
            dr = com1.ExecuteReader(CommandBehavior.CloseConnection)
            If dr.HasRows() = True Then
                While dr.Read()
                    txtStafffirstname.Text = dr.GetValue(2)
                    txtStaffmiddlename.Text = dr.GetValue(3)
                    txtStaffsurname.Text = dr.GetValue(4)
                    cboGender.Text = dr.GetValue(5)
                    cboTitle.Text = dr.GetValue(6)
                    dtpDOB.Text = dr.GetValue(7)
                    txtstaffage.Text = dr.GetValue(8)
                    cbomaritalstatus.Text = dr.GetValue(9)
                    txtStaffphone.Text = dr.GetValue(10)
                    txtStaffemail.Text = dr.GetValue(11)
                    txtStaffhometown.Text = dr.GetValue(12)
                    txthouseno.Text = dr.GetValue(13)
                    cboNationality.Text = dr.GetValue(14)
                    cboStaffregion.Text = dr.GetValue(15)
                    cboreligion.Text = dr.GetValue(16)
                    txtStaffSsnit.Text = dr.GetValue(17)
                    txtSalary.Text = dr.GetByte(18)
                    txtContactname.Text = dr.GetValue(19)
                    txtContactphone.Text = dr.GetValue(20)
                    txlocality.Text = dr.GetValue(21)
                    txtContacthouse.Text = dr.GetValue(22)
                    cboOccupation.Text = dr.GetValue(23)
                    cboContactRelation.Text = dr.GetValue(24)
                    txtNextofkin.Text = dr.GetValue(25)
                    txtNextkinno.Text = dr.GetValue(26)
                    cboKinRelation.Text = dr.GetValue(27)
                    cboAllowance.Text = dr.GetValue(29)
                End While
                com1.Dispose()
                Exit Sub
            Else
                'do nothing

            End If

        Catch ex As Exception
            ' MsgBox(ex.Message.ToString())
        Finally
            con.Close()
        End Try

    End Sub

    Private Sub txtEmpID_TextChanged(sender As Object, e As EventArgs)
        Try
          

        Catch ex As SqlException
            ErrorToString()
        Catch ex As Exception
            ErrorToString()
        End Try

    End Sub

    Private Sub dtp_KeyPress(sender As Object, e As KeyPressEventArgs) Handles dtpDOB.KeyPress
        If Asc(e.KeyChar) <> 13 AndAlso Asc(e.KeyChar) <> 8 AndAlso Not IsNumeric(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub

    Private Sub dtp_TextChanged(sender As Object, e As EventArgs) Handles dtpDOB.TextChanged
        'If Asc(e.KeyChar) <> 13 AndAlso Asc(e.KeyChar) <> 8 AndAlso Not IsNumeric(e.KeyChar) Then
        '    e.Handled = True
        'End If
    End Sub

    Private Sub dtp_ValueChanged(sender As Object, e As EventArgs) Handles dtpDOB.ValueChanged
        Dim age As Integer
        age = DateTime.Today.Year - dtpDOB.Value.Year
        txtstaffage.Text = age.ToString
    End Sub

    Private Sub txtStaffphone_KeyDown(sender As Object, e As KeyEventArgs) Handles txtStaffphone.KeyDown
    
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub
End Class