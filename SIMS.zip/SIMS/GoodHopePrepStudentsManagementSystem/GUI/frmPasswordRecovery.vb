﻿Imports System.Data.SqlClient

Public Class frmPasswordRecovery

    Private Sub frmPasswordRecovery_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ActiveControl = SName
        ' Me.Text = Me.Text + " - [Current User: " + frmLog.Logname + "]"
    End Sub

    Sub FillCombo()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            dset = New DataSet()
            adapter = New SqlDataAdapter()
            dset.Clear()
            adapter.SelectCommand = New SqlCommand("select StaffID, (FirstName + ' ' + MiddleName + ' ' + LastName) as StaffName from Staff order by FirstName Asc", ConnectionModule.con)
            adapter.Fill(dset, "Staff")
            SName.DataSource = dset.Tables("Staff")
            SName.DisplayMember = "StaffName"
            SName.ValueMember = "StaffID"
            SName.SelectedIndex = -1
        Catch ex As Exception
            MsgBox(ex.ToString(), MsgBoxStyle.OkOnly, "at fill staffname")
            con.Close()
        End Try

    End Sub

    Private Sub SName_DropDown(sender As Object, e As EventArgs) Handles SName.DropDown
        FillCombo()
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        Role.ResetText()
        SName.ResetText()
        txtUsername.Clear()
        txt_pass.Clear()
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub

    Private Sub SName_SelectedIndexChanged(sender As Object, e As EventArgs) Handles SName.SelectedIndexChanged
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            ' Dim str As String = "SELECT * from users  where staffID='" & SName.SelectedValue & "'"
            com = New SqlCommand("SELECT Staff.StaffID, (Staff.FirstName + ' '+ Staff.MiddleName + ' ' + Staff.LastName) as Name, Users.Username, Users.Password, Users.Role FROM Staff INNER JOIN Users ON Staff.StaffID = Users.staffID  where Staff.StaffID='" & SName.SelectedValue & "'", ConnectionModule.con)
            dr = com.ExecuteReader(CommandBehavior.CloseConnection)
            If dr.Read() = True Then
                txtUsername.Text = dr(2).ToString()
                txt_pass.Text = dr(3).ToString()
                Role.Text = dr(4).ToString()
            End If
            dr.Close()
        Catch ex As Exception
            MsgBox(ex.ToString())
            con.Close()
        End Try

    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        If txt_pass.Text <> String.Empty Then
            If CheckBox1.CheckState = CheckState.Checked Then
                txt_pass.UseSystemPasswordChar = False
                CheckBox1.Text = "Hide"
                Exit Sub
            End If
            If CheckBox1.CheckState = CheckState.Unchecked Then
                txt_pass.UseSystemPasswordChar = True
                CheckBox1.Text = "Show"
                Exit Sub
            End If

        End If
    End Sub
End Class