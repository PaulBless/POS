﻿Imports System.Data.SqlClient

Public Class frmAttendance


    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        Try
            If txtAttendanceStatus.Text = "" Then MsgBox("Enter attendance status", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "SIMS Error") : Exit Sub
            'check record exists
            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            com1 = New SqlCommand("select * from attendance where Status='" & (txtAttendanceStatus.Text) & "'", ConnectionModule.con)
            dr = com1.ExecuteReader(CommandBehavior.CloseConnection)
            If dr.Read() = True Then
                dr.Close()
                con.Close()
                MsgBox("Record Exists.. Cannot save duplicate record..." + vbCrLf + "NB:- Please update the record..", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "SIMS") : Exit Sub
            Else
                If con.State = ConnectionState.Open Then con.Close()
                com1 = New SqlCommand("insert into Attendance(Status) values (@d1)", ConnectionModule.con)
                com1.Parameters.Add("@d1", SqlDbType.NVarChar).Value = txtAttendanceStatus.Text
                con.Open()
                com1.ExecuteNonQuery()
                MessageBox.Show("Attendance saved.", "SIMS", MessageBoxButtons.OK, MessageBoxIcon.Information)
                com1.Dispose()  'dispose the command
                con.Close()     'close the db connection
                'clear controls
                txtID.Clear()
                txtAttendanceStatus.Clear()
                GetAttendance()
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        If txtID.Text = String.Empty Then MsgBox("Invalid record selection, check..", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "SIMS Error") : Exit Sub
        Try
            'check record exists
            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            com = New SqlCommand("select * from attendance where id='" & Val(txtID.Text) & "'", con)
            dr = com.ExecuteReader(CommandBehavior.CloseConnection)
            If dr.HasRows() = True Then
                'update the record
                If con.State = ConnectionState.Open Then con.Close()
                con.Open()
                com1 = New SqlCommand("update Attendance set Status=@d1 where ID='" & dgv.SelectedRows(0).Cells(0).Value & "'", con)
                com1.Parameters.Add("@d1", SqlDbType.NVarChar).Value = txtAttendanceStatus.Text
                com1.ExecuteNonQuery()
                MessageBox.Show("Attendance updated.", "SIMS", MessageBoxButtons.OK, MessageBoxIcon.Information)
                com1.Dispose()
                con.Close()
                'clear controls
                txtID.Clear()
                txtAttendanceStatus.Clear()
                GetAttendance()
            Else
                'show error message
                MessageBox.Show("Could not find specific record criteria to perform update.. ", "SIMS", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Exit Sub
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Private Sub GetAttendance()
        Try
            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            com1 = New SqlCommand("select * from attendance", ConnectionModule.con)
            dr = com1.ExecuteReader(CommandBehavior.CloseConnection)
            dgv.Rows.Clear()
            While dr.Read() = True
                dgv.Rows.Add(dr(0), dr(1))
            End While
            'dr.Close()
            con.Close()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Private Sub dgv_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv.CellContentClick
        Try
            txtID.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(0).Value
            txtAttendanceStatus.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(1).Value.ToString()
        Catch ex As Exception

        End Try

    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        If txtID.Text = String.Empty Then MsgBox("Invalid record selection, check..", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "SIMS Error") : Exit Sub

        Try
            'check record exists
            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            com = New SqlCommand("select * from attendance where id='" & Val(txtID.Text) & "'", con)
            dr = com.ExecuteReader(CommandBehavior.CloseConnection)
            If dr.HasRows() = True Then
                'delete record
                If con.State = ConnectionState.Open Then con.Close()
                con.Open()
                com1 = New SqlCommand("delete from attendance where ID='" & dgv.SelectedRows(0).Cells(0).Value & "'", ConnectionModule.con)
                com1.ExecuteNonQuery()
                MessageBox.Show("Record deleted.", "SIMS", MessageBoxButtons.OK, MessageBoxIcon.Information)
                com1.Dispose()
                con.Close()
                'clear controls
                txtID.Clear()
                txtAttendanceStatus.Clear()
                GetAttendance()
            Else
                'show error message
                MessageBox.Show("Could not find specific record criteria to perform deletion.. ", "SIMS", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Exit Sub
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub frmAttendance_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        GetAttendance()

    End Sub

    Private Sub txtAttendanceStatus_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtAttendanceStatus.KeyPress
        Select Case Asc(e.KeyChar)
            Case 8, 32, 65 To 90, 97 To 122
                e.Handled = False
            Case Else
                e.Handled = True
        End Select
    End Sub
End Class