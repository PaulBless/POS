﻿Public Class Report

    Private Sub TabPage3_Click(sender As Object, e As EventArgs)

    End Sub
End Class