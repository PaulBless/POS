﻿Imports System.IO
Imports System.Data.SqlClient
Public Class StaffSearch


    Private Sub StaffSearch_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ActiveControl = txtStaffName

        Getdata()

    End Sub

    Public Sub Getdata()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()

            com = New SqlCommand("select RTRIM(StaffID), RTRIM(StaffCode), RTRIM(FirstName), RTRIM(MiddleName), RTRIM(LastName), RTRIM(Gender), RTRIM(Title), RTRIM(DOB), RTRIM(Age), RTRIM(MaritalStatus), RTRIM(PhoneNumber), RTRIM(Email), RTRIM(Hometown), RTRIM(HouseNo), RTRIM(Nationality), RTRIM(Region), RTRIM(Religion), RTRIM(SSNIT), RTRIM(Salary), RTRIM(ContactName), RTRIM(ContactNumber), RTRIM(Town), RTRIM(ContactHouseNo), RTRIM(Occupation), RTRIM(ContactRelation), RTRIM(NameofKin),RTRIM(NumberofKin),RTRIM(Relation),RTRIM([Date]) from Staff order by FirstName ASC", ConnectionModule.con)
            dr = com.ExecuteReader(CommandBehavior.CloseConnection)
            dgv.Rows.Clear()
            While (dr.Read() = True)
                dgv.Rows.Add(dr(0), dr(1), dr(2), dr(3), dr(4), dr(5), dr(6), dr(7), dr(8), dr(9), dr(10), dr(11), dr(12), dr(13), dr(14), dr(15), dr(16), dr(17), dr(18), dr(19), dr(20), dr(21), dr(22), dr(23), dr(24), dr(25), dr(26), dr(27), dr(28))
                'set the image column of the gridview to stretch layout
                'For i As Integer = 0 To dgv.ColumnCount - 1
                '    If TypeOf dgv.Columns(i) Is DataGridViewImageColumn Then
                '        DirectCast(dgv.Columns(i), DataGridViewImageColumn).ImageLayout = DataGridViewImageCellLayout.Stretch
                '    End If
                'Next
            End While
            con.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error at getdata", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Sub Reset()
        txtStaffName.Clear()
        txtCode.Clear()
        txtDept.Clear()
        Getdata()

    End Sub

    Sub Reset1()
        txtEID.Clear()
        txtSalary.Clear()
        txtStafffirstname.Clear()
        txtStaffsurname.Clear()
        txtStaffmiddlename.Clear()
        txtstaffage.Clear()
        txtEmpID.Clear()
        txtContactphone.Clear()
        txtContacthouse.Clear()
        txtContactname.Clear()
        locality.Clear()
        gender.ResetText()
        cboStafftitle.ResetText()
        cboKinRelation.ResetText()
        cboContactRelation.ResetText()
        cboContactoccupation.ResetText()
        phoneno.Clear()
        hometown.Clear()
        houseno.Clear()
        dtpDOB.Text = Now
        nationality.ResetText()
        region.ResetText()
        religion.ResetText()
        email.Clear()
        nextofkin.Clear()
        Nextkinno.Clear()
        ssnit.Clear()
        status.ResetText()
        Reset()
    End Sub

    'Sub Showme()
    '    Try
    '        If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
    '        ConnectionModule.con.Open()

    '        Dim dtable As New DataTable
    '        '  Dim cmd As SqlCommand = New SqlCommand("select * from Staff where StaffCode='" & Me.txtsearchvalue.Text & "'", ConnectionModule.con)
    '        ' Dim adap As SqlDataAdapter = New SqlDataAdapter(cmd)
    '        dtable.Clear()
    '        ' adap.Fill(dtable)
    '        dgview.DataSource = dtable

    '        dgview.AutoGenerateColumns = False
    '        dgview.ColumnCount = 20

    '        'For i As Integer = 0 To dgview.Columns.Count
    '        dgview.Columns(0).HeaderText = "Staff Code"
    '        dgview.Columns(1).HeaderText = "Title"
    '        dgview.Columns(2).HeaderText = "First Name"
    '        dgview.Columns(3).HeaderText = "Other Names"
    '        dgview.Columns(4).HeaderText = "Gender"
    '        dgview.Columns(5).HeaderText = "Date of Birth."
    '        dgview.Columns(6).HeaderText = "Marital Status"
    '        dgview.Columns(7).HeaderText = "Phone No"
    '        dgview.Columns(8).HeaderText = "Hometown"
    '        dgview.Columns(9).HeaderText = "House No."
    '        dgview.Columns(10).HeaderText = "Email Address"
    '        dgview.Columns(11).HeaderText = "Nationality"
    '        dgview.Columns(12).HeaderText = "Region"
    '        dgview.Columns(13).HeaderText = "Religion"
    '        dgview.Columns(14).HeaderText = "Contact Person"
    '        dgview.Columns(15).HeaderText = "Contact Number"
    '        dgview.Columns(16).HeaderText = "Occupation"
    '        dgview.Columns(17).HeaderText = "Town"
    '        dgview.Columns(18).HeaderText = "Relationship"
    '        dgview.Columns(19).HeaderText = "Next of Kin"
    '        dgview.Columns(20).HeaderText = "Kin's Number"

    '        'set datapropertyname of each column
    '        dgview.Columns(0).DataPropertyName = "StaffCode"
    '        dgview.Columns(1).DataPropertyName = "Title"
    '        dgview.Columns(2).DataPropertyName = "FirstName"
    '        dgview.Columns(3).DataPropertyName = "MiddleName" + " " + "LastName"
    '        dgview.Columns(4).DataPropertyName = "Gender"
    '        dgview.Columns(5).DataPropertyName = "DOB"
    '        dgview.Columns(6).DataPropertyName = "MaritalStatus"
    '        dgview.Columns(7).DataPropertyName = "PhoneNumber"
    '        dgview.Columns(8).DataPropertyName = "Hometown"
    '        dgview.Columns(9).DataPropertyName = "HouseNo"
    '        dgview.Columns(10).DataPropertyName = "Email"
    '        dgview.Columns(11).DataPropertyName = "Nationality"
    '        dgview.Columns(12).DataPropertyName = "Region"
    '        dgview.Columns(14).DataPropertyName = "ContactName"
    '        dgview.Columns(15).DataPropertyName = "ContactNumber"
    '        dgview.Columns(17).DataPropertyName = "Town"
    '        dgview.Columns(18).DataPropertyName = "ContactRelation"
    '        dgview.Columns(16).DataPropertyName = "Occupation"
    '        dgview.Columns(19).DataPropertyName = "NameofKin"
    '        dgview.Columns(20).DataPropertyName = "NumberofKin"


    '        'setting the width of the column
    '        dgview.Columns(0).Width = 80
    '        dgview.Columns(1).Width = 120
    '        dgview.Columns(2).Width = 180
    '        dgview.Columns(3).Width = 160
    '        dgview.Columns(4).Width = 100
    '        dgview.Columns(5).Width = 120
    '        dgview.Columns(6).Width = 150
    '        dgview.Columns(7).Width = 160
    '        dgview.Columns(8).Width = 140
    '        dgview.Columns(9).Width = 120
    '        dgview.Columns(10).Width = 200
    '        dgview.Columns(11).Width = 120
    '        dgview.Columns(12).Width = 160
    '        dgview.Columns(13).Width = 140
    '        dgview.Columns(14).Width = 140
    '        dgview.Columns(15).Width = 160
    '        dgview.Columns(16).Width = 140
    '        dgview.Columns(17).Width = 140
    '        dgview.Columns(18).Width = 160
    '        dgview.Columns(19).Width = 160
    '        dgview.Columns(20).Width = 160

    '        'Next

    '        dgview.Refresh()

    '    Catch ex As Exception

    '        con.Close()

    '    End Try
    'End Sub


    Private Sub btnsearch_Click(sender As Object, e As EventArgs)
        'If cboSearch.Text = "" And cbogender.Text = "" And txtsearchvalue.Text = "" Then
        '    MsgBox("Please select search criteria and gender", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "SIMS - Error")
        '    Exit Sub
        'End If

        'If cboSearch.Text <> "" And cbogender.Text = "" Then
        '    MsgBox("Please select gender.", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "SIMS - Error")
        '    txtsearchvalue.Focus()
        '    Exit Sub
        'End If

        'If cboSearch.Text = "" And cbogender.Text <> "" Then
        '    MsgBox("Please select criteria.", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "SIMS - Error")
        '    cboSearch.Focus()
        '    Exit Sub
        'End If

        'If cboSearch.Text = "StaffCode" And txtsearchvalue.Text <> "" And cbogender.SelectedItem = "Male" Then
        '    Try
        '        If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
        '        ConnectionModule.con.Open()

        '        Dim dst As Data.DataSet = New Data.DataSet
        '        Dim adpt As SqlDataAdapter = New SqlDataAdapter
        '        dst.Clear()
        '        adpt.SelectCommand = New SqlCommand("select * from Staff where StaffCode='" & Me.txtsearchvalue.Text & "' and Gender='" & Me.cbogender.SelectedItem & "'", ConnectionModule.con)
        '        adpt.Fill(dst, "Staff")
        '        dgview.DataSource = dst.Tables("Staff")
        '        dgview.Refresh()


        '        dgview.AutoGenerateColumns = False
        '        dgview.ColumnCount = 20

        '        For i As Integer = 0 To dgview.Columns.Count
        '            dgview.Columns(0).HeaderText = "Staff Code"
        '            dgview.Columns(1).HeaderText = "Title"
        '            dgview.Columns(2).HeaderText = "First Name"
        '            dgview.Columns(3).HeaderText = "Other Names"
        '            dgview.Columns(4).HeaderText = "Gender"
        '            dgview.Columns(5).HeaderText = "Date of Birth."
        '            dgview.Columns(6).HeaderText = "Marital Status"
        '            dgview.Columns(7).HeaderText = "Phone No"
        '            dgview.Columns(8).HeaderText = "Hometown"
        '            dgview.Columns(9).HeaderText = "House No."
        '            dgview.Columns(10).HeaderText = "Email Address"
        '            dgview.Columns(11).HeaderText = "Nationality"
        '            dgview.Columns(12).HeaderText = "Region"
        '            dgview.Columns(13).HeaderText = "Religion"
        '            dgview.Columns(14).HeaderText = "Contact Person"
        '            dgview.Columns(15).HeaderText = "Contact Number"
        '            dgview.Columns(16).HeaderText = "Occupation"
        '            dgview.Columns(17).HeaderText = "Town"
        '            dgview.Columns(18).HeaderText = "Relationship"
        '            dgview.Columns(19).HeaderText = "Next of Kin"
        '            dgview.Columns(20).HeaderText = "Kin's Number"

        '            'set datapropertyname of each column
        '            dgview.Columns(0).DataPropertyName = "StaffCode"
        '            dgview.Columns(1).DataPropertyName = "Title"
        '            dgview.Columns(2).DataPropertyName = "FirstName"
        '            dgview.Columns(3).DataPropertyName = "MiddleName" + " " + "LastName"
        '            dgview.Columns(4).DataPropertyName = "Gender"
        '            dgview.Columns(5).DataPropertyName = "DOB"
        '            dgview.Columns(6).DataPropertyName = "MaritalStatus"
        '            dgview.Columns(7).DataPropertyName = "PhoneNumber"
        '            dgview.Columns(8).DataPropertyName = "Hometown"
        '            dgview.Columns(9).DataPropertyName = "HouseNo"
        '            dgview.Columns(10).DataPropertyName = "Email"
        '            dgview.Columns(11).DataPropertyName = "Nationality"
        '            dgview.Columns(12).DataPropertyName = "Region"
        '            dgview.Columns(14).DataPropertyName = "ContactName"
        '            dgview.Columns(15).DataPropertyName = "ContactNumber"
        '            dgview.Columns(17).DataPropertyName = "Town"
        '            dgview.Columns(18).DataPropertyName = "ContactRelation"
        '            dgview.Columns(16).DataPropertyName = "Occupation"
        '            dgview.Columns(19).DataPropertyName = "NameofKin"
        '            dgview.Columns(20).DataPropertyName = "NumberofKin"


        '            'setting the width of the column
        '            dgview.Columns(0).Width = 80
        '            dgview.Columns(1).Width = 120
        '            dgview.Columns(2).Width = 180
        '            dgview.Columns(3).Width = 160
        '            dgview.Columns(4).Width = 100
        '            dgview.Columns(5).Width = 120
        '            dgview.Columns(6).Width = 150
        '            dgview.Columns(7).Width = 160
        '            dgview.Columns(8).Width = 140
        '            dgview.Columns(9).Width = 120
        '            dgview.Columns(10).Width = 200
        '            dgview.Columns(11).Width = 120
        '            dgview.Columns(12).Width = 160
        '            dgview.Columns(13).Width = 140
        '            dgview.Columns(14).Width = 140
        '            dgview.Columns(15).Width = 160
        '            dgview.Columns(16).Width = 140
        '            dgview.Columns(17).Width = 140
        '            dgview.Columns(18).Width = 160
        '            dgview.Columns(19).Width = 160
        '            dgview.Columns(20).Width = 160

        '        Next

        '        dgview.Refresh()

        '    Catch ex As Exception
        '        'MsgBox(ex.Message)
        '    Finally

        '        con.Close()

        '    End Try
        '    Exit Sub
        'End If



        'Try

        'Catch ex As Exception

        'End Try
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs)
        'Try
        '    If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
        '    ConnectionModule.con.Open()

        '    Dim dtable As New DataTable
        '   ' Dim cmd As SqlCommand = New SqlCommand("select * from Staff where StaffCode='" & Me.txtsearchvalue.Text & "' and Gender='" & Me.cbogender.SelectedItem & "'", ConnectionModule.con)
        '    Dim read As SqlDataReader = cmd.ExecuteReader(CommandBehavior.CloseConnection)
        '    If read.HasRows Then
        '        While read.Read()
        '            dgview.Rows.Add(read("StaffCode"), read("FirstName"), read("Gender"), read("PhoneNo"), read("Town"), read("Occupation"), read("Email"), read("ContactName"))
        '        End While
        '    End If
        '    dgview.Refresh()

        'Catch ex As Exception
        '    'MsgBox(ex.Message)
        'Finally
        '    con.Close()
        'End Try


    End Sub

    Private Sub txtStaffName_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtStaffName.KeyPress
        Select Case Asc(e.KeyChar)
            Case 8, 32, 65 To 90, 97 To 122
                e.Handled = False
            Case Else
                e.Handled = True
        End Select
    End Sub

    Private Sub txtStaffName_TextChanged(sender As Object, e As EventArgs) Handles txtStaffName.TextChanged
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()

            com = New SqlCommand("select RTRIM(StaffID), RTRIM(StaffCode), RTRIM(FirstName), RTRIM(MiddleName), RTRIM(LastName), RTRIM(Gender), RTRIM(Title), RTRIM(DOB), RTRIM(Age), RTRIM(MaritalStatus), RTRIM(PhoneNumber), RTRIM(Email), RTRIM(Hometown), RTRIM(HouseNo), RTRIM(Nationality), RTRIM(Region), RTRIM(Religion), RTRIM(SSNIT), RTRIM(Salary), RTRIM(ContactName), RTRIM(ContactNumber), RTRIM(Town), RTRIM(ContactHouseNo), RTRIM(Occupation), RTRIM(ContactRelation), RTRIM(NameofKin),RTRIM(NumberofKin),RTRIM(Relation),RTRIM([Date]) from Staff where FirstName like '%" & txtStaffName.Text & "%' order by FirstName ASC", ConnectionModule.con)
            dr = com.ExecuteReader(CommandBehavior.CloseConnection)
            dgv.Rows.Clear()
            While (dr.Read() = True)
                dgv.Rows.Add(dr(0), dr(1), dr(2), dr(3), dr(4), dr(5), dr(6), dr(7), dr(8), dr(9), dr(10), dr(11), dr(12), dr(13), dr(14), dr(15), dr(16), dr(17), dr(18), dr(19), dr(20), dr(21), dr(22), dr(23), dr(24), dr(25), dr(26), dr(27), dr(28))
            End While
            con.Close()
        Catch ex As Exception
            '   MessageBox.Show(ex.Message, "Error at name", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub txtDept_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtDept.KeyPress
        Select Case Asc(e.KeyChar)
            Case 8, 32, 65 To 90, 97 To 122
                e.Handled = False
            Case Else
                e.Handled = True
        End Select
    End Sub

    Private Sub txtDept_TextChanged(sender As Object, e As EventArgs) Handles txtDept.TextChanged
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()

            com = New SqlCommand("select RTRIM(StaffID), RTRIM(StaffCode), RTRIM(FirstName), RTRIM(MiddleName), RTRIM(LastName), RTRIM(Gender), RTRIM(Title), RTRIM(DOB), RTRIM(Age), RTRIM(MaritalStatus), RTRIM(PhoneNumber), RTRIM(Email), RTRIM(Hometown), RTRIM(HouseNo), RTRIM(Nationality), RTRIM(Region), RTRIM(Religion), RTRIM(SSNIT), RTRIM(Salary), RTRIM(ContactName), RTRIM(ContactNumber), RTRIM(Town), RTRIM(ContactHouseNo), RTRIM(Occupation), RTRIM(ContactRelation), RTRIM(NameofKin),RTRIM(NumberofKin),RTRIM(Relation),RTRIM([Date]) from Staff where Gender like '%" & txtDept.Text & "%' order by FirstName ASC", ConnectionModule.con)
            dr = com.ExecuteReader(CommandBehavior.CloseConnection)
            dgv.Rows.Clear()
            While (dr.Read() = True)
                dgv.Rows.Add(dr(0), dr(1), dr(2), dr(3), dr(4), dr(5), dr(6), dr(7), dr(8), dr(9), dr(10), dr(11), dr(12), dr(13), dr(14), dr(15), dr(16), dr(17), dr(18), dr(19), dr(20), dr(21), dr(22), dr(23), dr(24), dr(25), dr(26), dr(27), dr(28))
            End While
            con.Close()
        Catch ex As Exception
            ''MessageBox.Show(ex.Message, "Error at dept", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub txtcode_TextChanged(sender As Object, e As EventArgs) Handles txtCode.TextChanged
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()

            com = New SqlCommand("select RTRIM(StaffID), RTRIM(StaffCode), RTRIM(FirstName), RTRIM(MiddleName), RTRIM(LastName), RTRIM(Gender), RTRIM(Title), RTRIM(DOB), RTRIM(Age), RTRIM(MaritalStatus), RTRIM(PhoneNumber), RTRIM(Email), RTRIM(Hometown), RTRIM(HouseNo), RTRIM(Nationality), RTRIM(Region), RTRIM(Religion), RTRIM(SSNIT), RTRIM(Salary), RTRIM(ContactName), RTRIM(ContactNumber), RTRIM(Town), RTRIM(ContactHouseNo), RTRIM(Occupation), RTRIM(ContactRelation), RTRIM(NameofKin),RTRIM(NumberofKin),RTRIM(Relation),RTRIM([Date]) from Staff where StaffCode like '%" & txtCode.Text & "%' order by FirstName ASC", ConnectionModule.con)
            dr = com.ExecuteReader(CommandBehavior.CloseConnection)
            dgv.Rows.Clear()
            While (dr.Read() = True)
                dgv.Rows.Add(dr(0), dr(1), dr(2), dr(3), dr(4), dr(5), dr(6), dr(7), dr(8), dr(9), dr(10), dr(11), dr(12), dr(13), dr(14), dr(15), dr(16), dr(17), dr(18), dr(19), dr(20), dr(21), dr(22), dr(23), dr(24), dr(25), dr(26), dr(27), dr(28))
            End While
            con.Close()
        Catch ex As Exception
            '   ' MessageBox.Show(ex.Message, "Error at name", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub


    Private Sub btncancel_Click(sender As Object, e As EventArgs) Handles btncancel.Click
        Me.Close()
    End Sub

    Private Sub btnrefresh_Click(sender As Object, e As EventArgs) Handles btnrefresh.Click
        Reset1()
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        'If txtEID.Text = "" Then MsgBox("Invalid employee information. Select valid employee record to be deleted from the gridview", MsgBoxStyle.OkOnly + MsgBoxStyle.Exclamation, "SMIS") : Exit Sub

        If MsgBox("The selected employee record will be 'permanently' Deleted from the system." + vbCrLf + "Are you sure you want to continue?", MsgBoxStyle.Critical + MsgBoxStyle.YesNo, "Confirmation") = DialogResult.Yes Then
            Try
                If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                ConnectionModule.con.Open()
                com = New SqlCommand("delete from Staff where StaffID='" & dgv.SelectedRows(0).Cells(0).Value & "'", ConnectionModule.con)
                com.ExecuteNonQuery()
                MessageBox.Show("Employee record successfully deleted.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1)
                com.Parameters.Clear()
                Reset1()
            Catch ex As Exception
                MessageBox.Show(ex.ToString(), "at delete")
            End Try
        End If

    End Sub

    Private Sub dgv_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv.CellClick
        dgv.SelectAll()
    End Sub

    Private Sub dgvinfo_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv.CellContentClick
        'dgv.SelectAll()
    End Sub

    Private Sub dgvinfo_CellContentDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv.CellContentDoubleClick
        Try
            txtStafffirstname.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(2).Value
            txtStaffmiddlename.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(3).Value
            txtStaffsurname.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(4).Value
            gender.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(5).Value
            cboStafftitle.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(6).Value
            dtpDOB.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(7).Value
            txtstaffage.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(8).Value
            status.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(9).Value
            phoneno.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(10).Value
            email.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(11).Value
            hometown.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(12).Value
            houseno.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(13).Value
            nationality.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(14).Value
            region.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(15).Value
            religion.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(16).Value
            ssnit.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(17).Value
            txtSalary.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(18).Value
            txtContactname.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(19).Value
            txtContactphone.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(20).Value
            locality.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(21).Value
            txtContacthouse.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(22).Value
            cboContactoccupation.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(23).Value
            cboContactRelation.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(24).Value
            nextofkin.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(25).Value
            Nextkinno.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(26).Value
            cboKinRelation.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(27).Value
            txtEmpID.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(1).Value
            txtEID.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(0).Value
            SearchId = dgv.Rows(dgv.CurrentRow.Index).Cells(0).Value
            btnUpdate.Enabled = True
            btnDelete.Enabled = True
        Catch ex As Exception

        End Try
    End Sub

   Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        'If txtEID.Text = "" Then MsgBox("Invalid information. Select employee record from the gridview", MsgBoxStyle.OkOnly + MsgBoxStyle.Exclamation, "SMIS") : Exit Sub

        If MsgBox("Save changes made to the selected employee record." + vbCrLf + "Are you sure you want to continue?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "Confirmation") = DialogResult.Yes Then
            Try
                If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                ConnectionModule.con.Open()
                query = "update Staff set FirstName=@FirstName, MiddleName=@MiddleName, LastName=@LastName, Gender=@Gender, Title=@Title, DOB=@DOB, Age=@Age, MaritalStatus=@MaritalStatus, PhoneNumber=@PhoneNumber, Email=@Email, Hometown=@Hometown, HouseNo=@HouseNo, Nationality=@Nationality, Region=@Region, Religion=@Religion, SSNIT=@SSNIT, Salary=@Salary, ContactName=@ContactName, ContactNumber=@ContactNumber, Town=@Town, ContactHouseNo=@ContactHouseNo, Occupation=@Occupation, ContactRelation=@ContactRelation, NameofKin=@NameofKin, NumberofKin=@NumberofKin, Relation=@Relation where StaffID='" & dgv.SelectedRows(0).Cells(0).Value & "'"
                com = New SqlCommand(query, ConnectionModule.con)
                com.Parameters.AddWithValue("@FirstName", txtStafffirstname.Text)
                com.Parameters.AddWithValue("@MiddleName", txtStaffmiddlename.Text)
                com.Parameters.AddWithValue("@LastName", txtStaffsurname.Text)
                com.Parameters.AddWithValue("@Gender", gender.Text)
                com.Parameters.AddWithValue("@Title", cboStafftitle.Text)
                com.Parameters.AddWithValue("@DOB", dtpDOB.Text.ToString())
                com.Parameters.AddWithValue("@Age", txtstaffage.Text)
                com.Parameters.AddWithValue("@MaritalStatus", status.Text)
                com.Parameters.AddWithValue("@PhoneNumber", phoneno.Text)
                com.Parameters.AddWithValue("@Email", email.Text)
                com.Parameters.AddWithValue("@Hometown", hometown.Text)
                com.Parameters.AddWithValue("@HouseNo", houseno.Text)
                com.Parameters.AddWithValue("@Nationality", nationality.Text)
                com.Parameters.AddWithValue("@Region", region.Text)
                com.Parameters.AddWithValue("@Religion", religion.Text)
                com.Parameters.AddWithValue("@SSNIT", ssnit.Text)
                com.Parameters.AddWithValue("@Salary", txtSalary.Text)
                com.Parameters.AddWithValue("@ContactName", txtContactname.Text)
                com.Parameters.AddWithValue("@ContactNumber", txtContactphone.Text)
                com.Parameters.AddWithValue("@Town", locality.Text)
                com.Parameters.AddWithValue("@ContactHouseNo", txtContacthouse.Text)
                com.Parameters.AddWithValue("@Occupation", cboContactoccupation.Text)
                com.Parameters.AddWithValue("@ContactRelation", cboContactRelation.Text)
                com.Parameters.AddWithValue("@NameofKin", nextofkin.Text)
                com.Parameters.AddWithValue("@NumberofKin", Nextkinno.Text)
                com.Parameters.AddWithValue("@Relation", cboKinRelation.Text)
                com.ExecuteNonQuery()
                MessageBox.Show("Successfully Updated Record", "SIMS", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1)
                com.Parameters.Clear()
                Reset1()
            Catch ex As Exception
                MessageBox.Show(ex.ToString(), "at update")
                con.Close()
            End Try
        End If

    End Sub

    Private Sub dtpDOB_ValueChanged(sender As Object, e As EventArgs) Handles dtpDOB.ValueChanged
        Dim Age As New Integer
        Age = DateTime.Today.Year - dtpDOB.Value.Year
        txtstaffage.Text = Age.ToString
    End Sub

    Private Sub gbostfresult_Enter(sender As Object, e As EventArgs) Handles gbostfresult.Enter

    End Sub

    Private Sub txtContactphone_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtContactphone.KeyPress
        If Asc(e.KeyChar) <> 13 AndAlso Asc(e.KeyChar) <> 8 AndAlso Not IsNumeric(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub

    Private Sub txtSalary_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtSalary.KeyPress
        If Asc(e.KeyChar) <> 13 AndAlso Asc(e.KeyChar) <> 8 AndAlso Not IsNumeric(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub

    Private Sub phoneno_KeyPress(sender As Object, e As KeyPressEventArgs) Handles phoneno.KeyPress
        If Asc(e.KeyChar) <> 13 AndAlso Asc(e.KeyChar) <> 8 AndAlso Not IsNumeric(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub

    Private Sub txtStaffsurname_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtStaffsurname.KeyPress
        Select Case Asc(e.KeyChar)
            Case 8, 32, 65 To 90, 97 To 122
                e.Handled = False
            Case Else
                e.Handled = True
        End Select
    End Sub

    Private Sub txtStafffirstname_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtStafffirstname.KeyPress
        Select Case Asc(e.KeyChar)
            Case 8, 32, 65 To 90, 97 To 122
                e.Handled = False
            Case Else
                e.Handled = True
        End Select
    End Sub

    Private Sub txtStaffmiddlename_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtStaffmiddlename.KeyPress
        Select Case Asc(e.KeyChar)
            Case 8, 32, 65 To 90, 97 To 122
                e.Handled = False
            Case Else
                e.Handled = True
        End Select
    End Sub

    Private Sub email_KeyPress(sender As Object, e As KeyPressEventArgs) Handles email.KeyPress
        'reject special characters
        Select Case Asc(e.KeyChar)
            Case 33 To 44, 46, 58 To 64, 91 To 96, 123 To 126
                e.Handled = True
            Case Else
                e.Handled = False
        End Select
    End Sub

    Private Sub txtContacthouse_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtContacthouse.KeyPress
        Select Case Asc(e.KeyChar)
            Case 8, 32, 65 To 90, 97 To 122
                e.Handled = False
            Case Else
                e.Handled = True
        End Select
    End Sub

    Private Sub txtContacthouse_TextChanged(sender As Object, e As EventArgs) Handles txtContacthouse.TextChanged

    End Sub

    Private Sub locality_KeyPress(sender As Object, e As KeyPressEventArgs) Handles locality.KeyPress
        Select Case Asc(e.KeyChar)
            Case 8, 32, 65 To 90, 97 To 122
                e.Handled = False
            Case Else
                e.Handled = True
        End Select
    End Sub

    Private Sub phoneno_TextChanged(sender As Object, e As EventArgs) Handles phoneno.TextChanged

    End Sub
End Class