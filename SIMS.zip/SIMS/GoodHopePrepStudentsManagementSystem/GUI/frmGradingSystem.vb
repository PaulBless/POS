﻿Imports System.Data.SqlClient

Public Class frmGradingSystem

    Private Sub GroupBox9_Enter(sender As Object, e As EventArgs)

    End Sub

    Private Sub dgvinfo_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv.CellContentClick

    End Sub

    Public Sub GetData()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            com = New SqlCommand("select no,grade,boundary,description from gradehistory order by grade asc", ConnectionModule.con)
            dr = com.ExecuteReader(CommandBehavior.CloseConnection)
            dgv.Rows.Clear()
            While dr.Read() = True
                dgv.Rows.Add(dr(0), dr(1), dr(2), dr(3))
            End While
            dr.Close()
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at getdata")
            con.Close()
        End Try
    End Sub
    Private Sub frmGradingSystem_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        GetData()
    End Sub

    Private Sub GroupBox4_Enter(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub btn_Cancel_Student_Form_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        If MsgBox("Do you really want to delete this record?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "SIMS") = MsgBoxResult.Yes Then
            Try
                'check record exists
                If con.State = ConnectionState.Open Then con.Close()
                con.Open()
                com = New SqlCommand("select * from gradehistory where grade='" & (txtGL.Text) & "'", con)
                dr = com.ExecuteReader(CommandBehavior.CloseConnection)
                If Not dr.Read() = True Then
                    dr.Close()
                    'show error message
                    MessageBox.Show("Sorry.. No valid data or record to perform deletion" + vbCrLf + "Please provide correct criteria.. ", "SIMS", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Exit Sub
                Else
                    'insert record
                    If con.State = ConnectionState.Open Then con.Close()
                    con.Open()
                    com1 = New SqlCommand("delete from gradehistory where no='" & dgv.SelectedRows(0).Cells(0).Value & "'", ConnectionModule.con)
                    com1.ExecuteNonQuery()
                    MessageBox.Show("Successfully deleted", "SIMS", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    com1.Dispose()
                    con.Close()
                    'clear controls
                    ClearMe()
                    btnSave.Enabled = True
                    btnUpdate.Enabled = False
                    btnDelete.Enabled = False
                    Exit Sub
                End If

            Catch ex As Exception
                MessageBox.Show(ex.Message)
            End Try
        End If
    End Sub

    Private Sub btn_SaveStudentRecord_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        If txtGL.Text = "" Then MsgBox("Specify the grade letter", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "SIMS Error") : Exit Sub
        If txtGB.Text = "" Then MsgBox("Please specify grade boundary", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "SIMS Error") : Exit Sub
        If txtGD.Text = "" Then MsgBox("Provide short description", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "SIMS Error") : Exit Sub
        'confirm saving
        If MsgBox("Do you really want to save this record?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "SIMS") = MsgBoxResult.Yes Then
            Try
                'check record exists
                If con.State = ConnectionState.Open Then con.Close()
                con.Open()
                com = New SqlCommand("select * from gradehistory where grade='" & (txtGL.Text) & "'", con)
                dr = com.ExecuteReader(CommandBehavior.CloseConnection)
                If dr.Read() = True Then
                    dr.Close()
                    'show error message
                    MessageBox.Show("Record Exists.. Cannot save duplicate entry." + vbCrLf + "Please try updating the record.. ", "SIMS", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Exit Sub
                Else
                    'insert record
                    If con.State = ConnectionState.Open Then con.Close()
                    con.Open()
                    com1 = New SqlCommand("insert into gradehistory(grade,boundary,description) values (@d1,@d2,@d3)", ConnectionModule.con)
                    com1.Parameters.Add("@d1", SqlDbType.NVarChar).Value = txtGL.Text
                    com1.Parameters.Add("@d2", SqlDbType.VarChar).Value = txtGB.Text
                    com1.Parameters.Add("@d3", SqlDbType.Real).Value = (txtGD.Text)
                    com1.ExecuteNonQuery()
                    MessageBox.Show("Successfully saved.", "SIMS", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    com1.Dispose()
                    con.Close()
                    'clear controls
                    ClearMe()
                    btnSave.Enabled = True
                    btnUpdate.Enabled = False
                    btnDelete.Enabled = False
                    Exit Sub
                End If

            Catch ex As Exception
                MessageBox.Show(ex.Message)
            End Try
        End If
    End Sub

    Private Sub btn_Refresh_form_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        'confirm saving
        If MsgBox("Do you really want to save this record?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "SIMS") = MsgBoxResult.Yes Then
            Try
                'check record exists
                If con.State = ConnectionState.Open Then con.Close()
                con.Open()
                com = New SqlCommand("select * from gradehistory where grade='" & (txtGL.Text) & "'", con)
                dr = com.ExecuteReader(CommandBehavior.CloseConnection)
                If Not dr.Read() = True Then
                    dr.Close()
                    'show error message
                    MessageBox.Show("Sorry.. No valid data or record to perform update on" + vbCrLf + "Please provide correct criteria.. ", "SIMS", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Exit Sub
                Else
                    'insert record
                    If con.State = ConnectionState.Open Then con.Close()
                    con.Open()
                    com1 = New SqlCommand("update gradehistory set grade=@d1, boundary=@d2, description=@d3 where no='" & dgv.SelectedRows(0).Cells(0).Value & "'", ConnectionModule.con)
                    com1.Parameters.Add("@d1", SqlDbType.NVarChar).Value = txtGL.Text
                    com1.Parameters.Add("@d2", SqlDbType.VarChar).Value = txtGB.Text
                    com1.Parameters.Add("@d3", SqlDbType.Real).Value = (txtGD.Text)
                    com1.ExecuteNonQuery()
                    MessageBox.Show("Successfully updated.", "SIMS", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    com1.Dispose()
                    con.Close()
                    'clear controls
                    ClearMe()
                    btnSave.Enabled = True
                    btnUpdate.Enabled = False
                    btnDelete.Enabled = False
                    Exit Sub
                End If

            Catch ex As Exception
                MessageBox.Show(ex.Message)
            End Try
        End If
    End Sub

    Private Sub ClearMe()
        txtGB.Clear()
        txtGD.Clear()
        txtGL.Clear()
        GetData()
      
    End Sub

End Class