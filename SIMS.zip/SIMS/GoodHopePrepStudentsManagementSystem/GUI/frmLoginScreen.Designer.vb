﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmLoginScreen
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmLoginScreen))
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.link_Change_Password = New System.Windows.Forms.LinkLabel()
        Me.Panel_Login_Picture = New System.Windows.Forms.Panel()
        Me.LabelPassword = New System.Windows.Forms.Label()
        Me.LabelUsername = New System.Windows.Forms.Label()
        Me.txt_Username = New System.Windows.Forms.TextBox()
        Me.txt_Password = New System.Windows.Forms.TextBox()
        Me.btn_Login = New System.Windows.Forms.Button()
        Me.btn_Cancel_Login = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Panel2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.LightBlue
        Me.Panel2.Controls.Add(Me.Label1)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel2.Location = New System.Drawing.Point(0, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(483, 62)
        Me.Panel2.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 27.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(3, 6)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(475, 45)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "LOGIN SCREEN"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'link_Change_Password
        '
        Me.link_Change_Password.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.link_Change_Password.LinkColor = System.Drawing.Color.Black
        Me.link_Change_Password.Location = New System.Drawing.Point(221, 131)
        Me.link_Change_Password.Name = "link_Change_Password"
        Me.link_Change_Password.Size = New System.Drawing.Size(151, 24)
        Me.link_Change_Password.TabIndex = 0
        Me.link_Change_Password.TabStop = True
        Me.link_Change_Password.Text = "Change Password?"
        Me.link_Change_Password.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.link_Change_Password.VisitedLinkColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        '
        'Panel_Login_Picture
        '
        Me.Panel_Login_Picture.BackColor = System.Drawing.Color.Transparent
        Me.Panel_Login_Picture.BackgroundImage = CType(resources.GetObject("Panel_Login_Picture.BackgroundImage"), System.Drawing.Image)
        Me.Panel_Login_Picture.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel_Login_Picture.Location = New System.Drawing.Point(6, 25)
        Me.Panel_Login_Picture.Name = "Panel_Login_Picture"
        Me.Panel_Login_Picture.Size = New System.Drawing.Size(142, 130)
        Me.Panel_Login_Picture.TabIndex = 9
        '
        'LabelPassword
        '
        Me.LabelPassword.AutoSize = True
        Me.LabelPassword.BackColor = System.Drawing.Color.White
        Me.LabelPassword.Font = New System.Drawing.Font("Times New Roman", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelPassword.ForeColor = System.Drawing.Color.Black
        Me.LabelPassword.Location = New System.Drawing.Point(161, 85)
        Me.LabelPassword.Name = "LabelPassword"
        Me.LabelPassword.Size = New System.Drawing.Size(93, 21)
        Me.LabelPassword.TabIndex = 11
        Me.LabelPassword.Text = "Password :"
        '
        'LabelUsername
        '
        Me.LabelUsername.AutoSize = True
        Me.LabelUsername.BackColor = System.Drawing.Color.White
        Me.LabelUsername.Font = New System.Drawing.Font("Times New Roman", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelUsername.ForeColor = System.Drawing.Color.Black
        Me.LabelUsername.Location = New System.Drawing.Point(161, 37)
        Me.LabelUsername.Name = "LabelUsername"
        Me.LabelUsername.Size = New System.Drawing.Size(93, 21)
        Me.LabelUsername.TabIndex = 10
        Me.LabelUsername.Text = "Username :"
        '
        'txt_Username
        '
        Me.txt_Username.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txt_Username.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Username.Location = New System.Drawing.Point(260, 36)
        Me.txt_Username.MaxLength = 50
        Me.txt_Username.Name = "txt_Username"
        Me.txt_Username.Size = New System.Drawing.Size(202, 22)
        Me.txt_Username.TabIndex = 12
        '
        'txt_Password
        '
        Me.txt_Password.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Password.Location = New System.Drawing.Point(260, 84)
        Me.txt_Password.MaxLength = 50
        Me.txt_Password.Name = "txt_Password"
        Me.txt_Password.Size = New System.Drawing.Size(202, 22)
        Me.txt_Password.TabIndex = 13
        Me.txt_Password.UseSystemPasswordChar = True
        '
        'btn_Login
        '
        Me.btn_Login.BackColor = System.Drawing.Color.LightBlue
        Me.btn_Login.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_Login.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.btn_Login.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_Login.Font = New System.Drawing.Font("Trebuchet MS", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Login.Location = New System.Drawing.Point(77, 260)
        Me.btn_Login.Name = "btn_Login"
        Me.btn_Login.Size = New System.Drawing.Size(170, 50)
        Me.btn_Login.TabIndex = 14
        Me.btn_Login.Text = "&Login"
        Me.btn_Login.UseVisualStyleBackColor = False
        '
        'btn_Cancel_Login
        '
        Me.btn_Cancel_Login.BackColor = System.Drawing.Color.LightBlue
        Me.btn_Cancel_Login.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_Cancel_Login.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btn_Cancel_Login.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.btn_Cancel_Login.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_Cancel_Login.Font = New System.Drawing.Font("Trebuchet MS", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Cancel_Login.Location = New System.Drawing.Point(287, 260)
        Me.btn_Cancel_Login.Name = "btn_Cancel_Login"
        Me.btn_Cancel_Login.Size = New System.Drawing.Size(170, 50)
        Me.btn_Cancel_Login.TabIndex = 15
        Me.btn_Cancel_Login.Text = "&Exit"
        Me.btn_Cancel_Login.UseVisualStyleBackColor = False
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.LabelPassword)
        Me.GroupBox1.Controls.Add(Me.link_Change_Password)
        Me.GroupBox1.Controls.Add(Me.Panel_Login_Picture)
        Me.GroupBox1.Controls.Add(Me.LabelUsername)
        Me.GroupBox1.Controls.Add(Me.txt_Username)
        Me.GroupBox1.Controls.Add(Me.txt_Password)
        Me.GroupBox1.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(9, 81)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(469, 164)
        Me.GroupBox1.TabIndex = 16
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Login Information"
        '
        'frmLoginScreen
        '
        Me.AcceptButton = Me.btn_Login
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.CancelButton = Me.btn_Cancel_Login
        Me.ClientSize = New System.Drawing.Size(483, 322)
        Me.Controls.Add(Me.btn_Cancel_Login)
        Me.Controls.Add(Me.btn_Login)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.GroupBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmLoginScreen"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "frmLoginScreen"
        Me.Panel2.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Panel_Login_Picture As System.Windows.Forms.Panel
    Friend WithEvents LabelPassword As System.Windows.Forms.Label
    Friend WithEvents LabelUsername As System.Windows.Forms.Label
    Friend WithEvents txt_Username As System.Windows.Forms.TextBox
    Friend WithEvents txt_Password As System.Windows.Forms.TextBox
    Friend WithEvents link_Change_Password As System.Windows.Forms.LinkLabel
    Friend WithEvents btn_Login As System.Windows.Forms.Button
    Friend WithEvents btn_Cancel_Login As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
End Class
