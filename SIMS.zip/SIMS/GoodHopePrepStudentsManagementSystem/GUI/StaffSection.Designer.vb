﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class StaffSection
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub


    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(StaffSection))
        Me.MenuStrip = New System.Windows.Forms.MenuStrip()
        Me.SetupToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItemLogOff = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItemExit = New System.Windows.Forms.ToolStripMenuItem()
        Me.AssessmentToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FillSBAToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FillTerminalReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ClassToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ClassListToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SchoolBasedAssessmentSBAToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ManageUserAccountToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ChangePasswordToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ForgottenPasswordToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.changAccountSettingsStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutSIMDToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.JecmasSolutionsHomepageToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolTip = New System.Windows.Forms.ToolTip(Me.components)
        Me.StatusStrip = New System.Windows.Forms.StatusStrip()
        Me.ToolStripLogUser = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusUserShow = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusDesignationShow = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripLabelDesignation = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lbl_datetimeshow = New System.Windows.Forms.Label()
        Me.DateTimeLabel = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.DialyAttendanceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NewStudentToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SearchStudentToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ViewStudentProfileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StudentsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip.SuspendLayout()
        Me.StatusStrip.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip
        '
        Me.MenuStrip.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.MenuStrip.Font = New System.Drawing.Font("Segoe UI Semibold", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MenuStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SetupToolStripMenuItem, Me.StudentsToolStripMenuItem, Me.AssessmentToolStripMenuItem, Me.ClassToolStripMenuItem, Me.ManageUserAccountToolStripMenuItem, Me.HelpToolStripMenuItem})
        Me.MenuStrip.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip.Name = "MenuStrip"
        Me.MenuStrip.Size = New System.Drawing.Size(1092, 28)
        Me.MenuStrip.TabIndex = 5
        Me.MenuStrip.Text = "MenuStrip"
        '
        'SetupToolStripMenuItem
        '
        Me.SetupToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItemLogOff, Me.ToolStripMenuItemExit})
        Me.SetupToolStripMenuItem.Name = "SetupToolStripMenuItem"
        Me.SetupToolStripMenuItem.Size = New System.Drawing.Size(112, 24)
        Me.SetupToolStripMenuItem.Text = "&System Setup"
        '
        'ToolStripMenuItemLogOff
        '
        Me.ToolStripMenuItemLogOff.Image = CType(resources.GetObject("ToolStripMenuItemLogOff.Image"), System.Drawing.Image)
        Me.ToolStripMenuItemLogOff.Name = "ToolStripMenuItemLogOff"
        Me.ToolStripMenuItemLogOff.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.F9), System.Windows.Forms.Keys)
        Me.ToolStripMenuItemLogOff.Size = New System.Drawing.Size(240, 24)
        Me.ToolStripMenuItemLogOff.Text = "Lof Out"
        '
        'ToolStripMenuItemExit
        '
        Me.ToolStripMenuItemExit.Image = CType(resources.GetObject("ToolStripMenuItemExit.Image"), System.Drawing.Image)
        Me.ToolStripMenuItemExit.Name = "ToolStripMenuItemExit"
        Me.ToolStripMenuItemExit.ShortcutKeys = CType((System.Windows.Forms.Keys.Alt Or System.Windows.Forms.Keys.F4), System.Windows.Forms.Keys)
        Me.ToolStripMenuItemExit.Size = New System.Drawing.Size(240, 24)
        Me.ToolStripMenuItemExit.Text = "Exit Application"
        '
        'AssessmentToolStripMenuItem
        '
        Me.AssessmentToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FillSBAToolStripMenuItem, Me.FillTerminalReportToolStripMenuItem})
        Me.AssessmentToolStripMenuItem.Name = "AssessmentToolStripMenuItem"
        Me.AssessmentToolStripMenuItem.Size = New System.Drawing.Size(104, 24)
        Me.AssessmentToolStripMenuItem.Text = "Assessments"
        '
        'FillSBAToolStripMenuItem
        '
        Me.FillSBAToolStripMenuItem.Image = CType(resources.GetObject("FillSBAToolStripMenuItem.Image"), System.Drawing.Image)
        Me.FillSBAToolStripMenuItem.Name = "FillSBAToolStripMenuItem"
        Me.FillSBAToolStripMenuItem.Size = New System.Drawing.Size(211, 24)
        Me.FillSBAToolStripMenuItem.Text = "Fill SBA"
        '
        'FillTerminalReportToolStripMenuItem
        '
        Me.FillTerminalReportToolStripMenuItem.Image = CType(resources.GetObject("FillTerminalReportToolStripMenuItem.Image"), System.Drawing.Image)
        Me.FillTerminalReportToolStripMenuItem.Name = "FillTerminalReportToolStripMenuItem"
        Me.FillTerminalReportToolStripMenuItem.Size = New System.Drawing.Size(211, 24)
        Me.FillTerminalReportToolStripMenuItem.Text = "Fill Terminal Report"
        '
        'ClassToolStripMenuItem
        '
        Me.ClassToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ClassListToolStripMenuItem, Me.SchoolBasedAssessmentSBAToolStripMenuItem})
        Me.ClassToolStripMenuItem.Name = "ClassToolStripMenuItem"
        Me.ClassToolStripMenuItem.Size = New System.Drawing.Size(73, 24)
        Me.ClassToolStripMenuItem.Text = "Reports"
        '
        'ClassListToolStripMenuItem
        '
        Me.ClassListToolStripMenuItem.Image = CType(resources.GetObject("ClassListToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ClassListToolStripMenuItem.Name = "ClassListToolStripMenuItem"
        Me.ClassListToolStripMenuItem.Size = New System.Drawing.Size(323, 24)
        Me.ClassListToolStripMenuItem.Text = "View Class List"
        '
        'SchoolBasedAssessmentSBAToolStripMenuItem
        '
        Me.SchoolBasedAssessmentSBAToolStripMenuItem.Image = CType(resources.GetObject("SchoolBasedAssessmentSBAToolStripMenuItem.Image"), System.Drawing.Image)
        Me.SchoolBasedAssessmentSBAToolStripMenuItem.Name = "SchoolBasedAssessmentSBAToolStripMenuItem"
        Me.SchoolBasedAssessmentSBAToolStripMenuItem.Size = New System.Drawing.Size(323, 24)
        Me.SchoolBasedAssessmentSBAToolStripMenuItem.Text = "View School Based Assessment(SBA)"
        '
        'ManageUserAccountToolStripMenuItem
        '
        Me.ManageUserAccountToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ChangePasswordToolStripMenuItem, Me.ForgottenPasswordToolStripMenuItem, Me.changAccountSettingsStripMenuItem})
        Me.ManageUserAccountToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI Semibold", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ManageUserAccountToolStripMenuItem.Name = "ManageUserAccountToolStripMenuItem"
        Me.ManageUserAccountToolStripMenuItem.Size = New System.Drawing.Size(103, 24)
        Me.ManageUserAccountToolStripMenuItem.Text = "My Account"
        '
        'ChangePasswordToolStripMenuItem
        '
        Me.ChangePasswordToolStripMenuItem.Image = CType(resources.GetObject("ChangePasswordToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ChangePasswordToolStripMenuItem.Name = "ChangePasswordToolStripMenuItem"
        Me.ChangePasswordToolStripMenuItem.Size = New System.Drawing.Size(248, 24)
        Me.ChangePasswordToolStripMenuItem.Text = "Change Password"
        '
        'ForgottenPasswordToolStripMenuItem
        '
        Me.ForgottenPasswordToolStripMenuItem.Enabled = False
        Me.ForgottenPasswordToolStripMenuItem.Image = CType(resources.GetObject("ForgottenPasswordToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ForgottenPasswordToolStripMenuItem.Name = "ForgottenPasswordToolStripMenuItem"
        Me.ForgottenPasswordToolStripMenuItem.Size = New System.Drawing.Size(248, 24)
        Me.ForgottenPasswordToolStripMenuItem.Text = "Forgotten Password?"
        '
        'changAccountSettingsStripMenuItem
        '
        Me.changAccountSettingsStripMenuItem.Image = CType(resources.GetObject("changAccountSettingsStripMenuItem.Image"), System.Drawing.Image)
        Me.changAccountSettingsStripMenuItem.Name = "changAccountSettingsStripMenuItem"
        Me.changAccountSettingsStripMenuItem.Size = New System.Drawing.Size(248, 24)
        Me.changAccountSettingsStripMenuItem.Text = "Change Account Settings"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AboutSIMDToolStripMenuItem, Me.JecmasSolutionsHomepageToolStripMenuItem})
        Me.HelpToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI Semibold", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(53, 24)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'AboutSIMDToolStripMenuItem
        '
        Me.AboutSIMDToolStripMenuItem.Image = CType(resources.GetObject("AboutSIMDToolStripMenuItem.Image"), System.Drawing.Image)
        Me.AboutSIMDToolStripMenuItem.Name = "AboutSIMDToolStripMenuItem"
        Me.AboutSIMDToolStripMenuItem.Size = New System.Drawing.Size(272, 24)
        Me.AboutSIMDToolStripMenuItem.Text = "About SIMS"
        '
        'JecmasSolutionsHomepageToolStripMenuItem
        '
        Me.JecmasSolutionsHomepageToolStripMenuItem.Image = CType(resources.GetObject("JecmasSolutionsHomepageToolStripMenuItem.Image"), System.Drawing.Image)
        Me.JecmasSolutionsHomepageToolStripMenuItem.Name = "JecmasSolutionsHomepageToolStripMenuItem"
        Me.JecmasSolutionsHomepageToolStripMenuItem.Size = New System.Drawing.Size(272, 24)
        Me.JecmasSolutionsHomepageToolStripMenuItem.Text = "Jecmas Solutions Homepage"
        '
        'StatusStrip
        '
        Me.StatusStrip.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.StatusStrip.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StatusStrip.GripStyle = System.Windows.Forms.ToolStripGripStyle.Visible
        Me.StatusStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripLogUser, Me.ToolStripStatusUserShow, Me.ToolStripStatusDesignationShow, Me.ToolStripLabelDesignation})
        Me.StatusStrip.Location = New System.Drawing.Point(0, 421)
        Me.StatusStrip.Name = "StatusStrip"
        Me.StatusStrip.Size = New System.Drawing.Size(1092, 25)
        Me.StatusStrip.TabIndex = 15
        Me.StatusStrip.Text = "StatusStrip"
        '
        'ToolStripLogUser
        '
        Me.ToolStripLogUser.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripLogUser.ForeColor = System.Drawing.Color.White
        Me.ToolStripLogUser.Name = "ToolStripLogUser"
        Me.ToolStripLogUser.Size = New System.Drawing.Size(76, 20)
        Me.ToolStripLogUser.Text = "Log User:"
        '
        'ToolStripStatusUserShow
        '
        Me.ToolStripStatusUserShow.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripStatusUserShow.ForeColor = System.Drawing.Color.Blue
        Me.ToolStripStatusUserShow.Name = "ToolStripStatusUserShow"
        Me.ToolStripStatusUserShow.Size = New System.Drawing.Size(106, 20)
        Me.ToolStripStatusUserShow.Text = "CurrentUser   "
        '
        'ToolStripStatusDesignationShow
        '
        Me.ToolStripStatusDesignationShow.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripStatusDesignationShow.ForeColor = System.Drawing.Color.White
        Me.ToolStripStatusDesignationShow.Name = "ToolStripStatusDesignationShow"
        Me.ToolStripStatusDesignationShow.Size = New System.Drawing.Size(48, 20)
        Me.ToolStripStatusDesignationShow.Text = "Role :"
        '
        'ToolStripLabelDesignation
        '
        Me.ToolStripLabelDesignation.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripLabelDesignation.ForeColor = System.Drawing.Color.Blue
        Me.ToolStripLabelDesignation.Name = "ToolStripLabelDesignation"
        Me.ToolStripLabelDesignation.Size = New System.Drawing.Size(72, 20)
        Me.ToolStripLabelDesignation.Text = "UserRole"
        '
        'lbl_datetimeshow
        '
        Me.lbl_datetimeshow.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lbl_datetimeshow.AutoSize = True
        Me.lbl_datetimeshow.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lbl_datetimeshow.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_datetimeshow.ForeColor = System.Drawing.Color.White
        Me.lbl_datetimeshow.Location = New System.Drawing.Point(793, 6)
        Me.lbl_datetimeshow.Name = "lbl_datetimeshow"
        Me.lbl_datetimeshow.Size = New System.Drawing.Size(97, 19)
        Me.lbl_datetimeshow.TabIndex = 22
        Me.lbl_datetimeshow.Text = "DATE TIME"
        '
        'DateTimeLabel
        '
        Me.DateTimeLabel.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DateTimeLabel.AutoSize = True
        Me.DateTimeLabel.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.DateTimeLabel.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DateTimeLabel.ForeColor = System.Drawing.Color.White
        Me.DateTimeLabel.Location = New System.Drawing.Point(693, 6)
        Me.DateTimeLabel.Name = "DateTimeLabel"
        Me.DateTimeLabel.Size = New System.Drawing.Size(102, 19)
        Me.DateTimeLabel.TabIndex = 23
        Me.DateTimeLabel.Text = "DATE/TIME:"
        '
        'Label3
        '
        Me.Label3.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Monotype Corsiva", 15.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Blue
        Me.Label3.Location = New System.Drawing.Point(28, 394)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(292, 25)
        Me.Label3.TabIndex = 27
        Me.Label3.Text = "Powered By: Jecmas Solutions,Ghana"
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.Color.White
        Me.Label4.Dock = System.Windows.Forms.DockStyle.Top
        Me.Label4.Font = New System.Drawing.Font("Arial Rounded MT Bold", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.Blue
        Me.Label4.Location = New System.Drawing.Point(0, 28)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(1092, 37)
        Me.Label4.TabIndex = 29
        Me.Label4.Text = "STUDENTS  INFORMATION  MANAGEMENT  SYSTEM"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'DialyAttendanceToolStripMenuItem
        '
        Me.DialyAttendanceToolStripMenuItem.Image = CType(resources.GetObject("DialyAttendanceToolStripMenuItem.Image"), System.Drawing.Image)
        Me.DialyAttendanceToolStripMenuItem.Name = "DialyAttendanceToolStripMenuItem"
        Me.DialyAttendanceToolStripMenuItem.Size = New System.Drawing.Size(310, 24)
        Me.DialyAttendanceToolStripMenuItem.Text = "Dialy Attendance"
        '
        'NewStudentToolStripMenuItem
        '
        Me.NewStudentToolStripMenuItem.BackColor = System.Drawing.SystemColors.Control
        Me.NewStudentToolStripMenuItem.Enabled = False
        Me.NewStudentToolStripMenuItem.Image = CType(resources.GetObject("NewStudentToolStripMenuItem.Image"), System.Drawing.Image)
        Me.NewStudentToolStripMenuItem.Name = "NewStudentToolStripMenuItem"
        Me.NewStudentToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.N), System.Windows.Forms.Keys)
        Me.NewStudentToolStripMenuItem.Size = New System.Drawing.Size(310, 24)
        Me.NewStudentToolStripMenuItem.Text = "New Student Registration"
        '
        'SearchStudentToolStripMenuItem
        '
        Me.SearchStudentToolStripMenuItem.Image = CType(resources.GetObject("SearchStudentToolStripMenuItem.Image"), System.Drawing.Image)
        Me.SearchStudentToolStripMenuItem.Name = "SearchStudentToolStripMenuItem"
        Me.SearchStudentToolStripMenuItem.ShortcutKeys = CType(((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Shift) _
            Or System.Windows.Forms.Keys.S), System.Windows.Forms.Keys)
        Me.SearchStudentToolStripMenuItem.Size = New System.Drawing.Size(310, 24)
        Me.SearchStudentToolStripMenuItem.Text = "Search Student  "
        '
        'ViewStudentProfileToolStripMenuItem
        '
        Me.ViewStudentProfileToolStripMenuItem.Image = CType(resources.GetObject("ViewStudentProfileToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ViewStudentProfileToolStripMenuItem.Name = "ViewStudentProfileToolStripMenuItem"
        Me.ViewStudentProfileToolStripMenuItem.ShortcutKeys = CType(((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Shift) _
            Or System.Windows.Forms.Keys.P), System.Windows.Forms.Keys)
        Me.ViewStudentProfileToolStripMenuItem.Size = New System.Drawing.Size(310, 24)
        Me.ViewStudentProfileToolStripMenuItem.Text = "View Student Profile"
        '
        'StudentsToolStripMenuItem
        '
        Me.StudentsToolStripMenuItem.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.StudentsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DialyAttendanceToolStripMenuItem, Me.NewStudentToolStripMenuItem, Me.SearchStudentToolStripMenuItem, Me.ViewStudentProfileToolStripMenuItem})
        Me.StudentsToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI Semibold", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StudentsToolStripMenuItem.ImageTransparentColor = System.Drawing.SystemColors.ActiveBorder
        Me.StudentsToolStripMenuItem.Name = "StudentsToolStripMenuItem"
        Me.StudentsToolStripMenuItem.Size = New System.Drawing.Size(80, 24)
        Me.StudentsToolStripMenuItem.Text = "&Students"
        '
        'StaffSection
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1092, 446)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.DateTimeLabel)
        Me.Controls.Add(Me.lbl_datetimeshow)
        Me.Controls.Add(Me.StatusStrip)
        Me.Controls.Add(Me.MenuStrip)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.IsMdiContainer = True
        Me.MainMenuStrip = Me.MenuStrip
        Me.Name = "StaffSection"
        Me.Text = "SIMS"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.MenuStrip.ResumeLayout(False)
        Me.MenuStrip.PerformLayout()
        Me.StatusStrip.ResumeLayout(False)
        Me.StatusStrip.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ToolTip As System.Windows.Forms.ToolTip
    Friend WithEvents MenuStrip As System.Windows.Forms.MenuStrip
    Friend WithEvents HelpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AboutSIMDToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents JecmasSolutionsHomepageToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ManageUserAccountToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ChangePasswordToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ForgottenPasswordToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents changAccountSettingsStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StatusStrip As System.Windows.Forms.StatusStrip
    Friend WithEvents ToolStripLogUser As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripStatusUserShow As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripLabelDesignation As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripStatusDesignationShow As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents lbl_datetimeshow As System.Windows.Forms.Label
    Friend WithEvents SetupToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItemLogOff As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItemExit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ClassToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ClassListToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SchoolBasedAssessmentSBAToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AssessmentToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FillSBAToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FillTerminalReportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DateTimeLabel As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents StudentsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DialyAttendanceToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NewStudentToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SearchStudentToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ViewStudentProfileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem

End Class
