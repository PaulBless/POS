﻿Imports System.Text
Imports System.Data.SqlClient

Public Class AdvancedSearch

    Dim studentAdmisionform As New frmConfirm_Student_Admission

    Private Sub AdvancedSearch_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ActiveControl = cbooption1

        'cbooption1.SelectedIndex = 0
    End Sub

    Sub Records()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()

            Dim cmd = New SqlCommand("SELECT RTRIM(ID),RTRIM(RegistrationNumber),RTRIM(FirstName), RTRIM(MiddleName), RTRIM(LastName), RTRIM(DOB),RTRIM(Age),RTRIM(Department),RTRIM(Class),RTRIM(Region),RTRIM(District),RTRIM(Nationality),RTRIM(HouseAddress),RTRIM(ContactName),RTRIM(ContactNumber),RTRIM(ContactAddress),RTRIM(ContactOccupation),RTRIM(ContactRelation),RTRIM(ContactEmail),RTRIM(ContactWorkNo),RTRIM(Gender),RTRIM(Title),RTRIM(Hometown),RTRIM(RegistrationDate),RTRIM(Religion) from Students where FirstName like '%" & txtvalue.Text & "%' order by ID ASC", ConnectionModule.con)
            Dim rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection)
            dgv.Rows.Clear()
            While (rdr.Read() = True)
                dgv.Rows.Add(rdr(0), rdr(1), rdr(2), rdr(3) + "  " + rdr(4), rdr(5), rdr(6), rdr(7), rdr(8), rdr(9), rdr(10), rdr(11), rdr(12), rdr(13), rdr(14), rdr(15), rdr(16), rdr(17), rdr(18), rdr(19), rdr(20), rdr(21), rdr(22), rdr(23), rdr(24))
            End While
            con.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub
    Public Sub ClassListJhs()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            dset = New Data.DataSet()
            adapter = New SqlDataAdapter()
            adapter.SelectCommand = New SqlCommand("select distinct room from classroom order by room asc", ConnectionModule.con)
            dset.Clear()
            adapter.Fill(dset, "classroom")
            cboClass.DataSource = dset.Tables("classroom")
            cboClass.DisplayMember = "room"
            cboClass.Refresh()
            cboClass.SelectedIndex = -1
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at get academic year")
            con.Close()
        End Try
    End Sub

    Public Sub GetDeptList()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            dset = New Data.DataSet()
            adapter = New SqlDataAdapter()
            adapter.SelectCommand = New SqlCommand("select name from tbldepartment order by deptid asc", ConnectionModule.con)
            dset.Clear()
            adapter.Fill(dset, "tbldepartment")
            cboDepartment.DataSource = dset.Tables("tbldepartment")
            cboDepartment.DisplayMember = "name"
            cboDepartment.Refresh()
            cboDepartment.SelectedIndex = -1
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at get school dept")
            con.Close()
        End Try
    End Sub

    Private Sub btnasearch_Click(sender As Object, e As EventArgs) Handles btnasearch.Click
        If cbooption1.Text = "" And cbooption2.Text = "" And txtvalue.Text = "" And cbogender.Text = "" And cboReligion.Text = "" And cbodepartment.Text = "" And cboclass.Text = "" Then MsgBox("Provide search criteria and click the search button.", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "Error") : Exit Sub
        'If dgv.Rows.Count > 0 Then btnclearsearch_Click(sender, e) : Exit Sub

        'search by class of student
        If cboclass.Text <> "" And cbooption1.Text = "" And cbooption2.Text = "" And txtvalue.Text = "" And cbogender.Text = "" And cboReligion.Text = "" And cbodepartment.Text = "" Then
            Try
                If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                ConnectionModule.con.Open()
                com1 = New SqlCommand("SELECT RTRIM(ID),RTRIM(RegistrationNumber),RTRIM(FirstName), RTRIM(MiddleName), RTRIM(LastName), RTRIM(DOB),RTRIM(Age),RTRIM(Department),RTRIM(Class),RTRIM(Region),RTRIM(District),RTRIM(Nationality),RTRIM(HouseAddress),RTRIM(ContactName),RTRIM(ContactNumber),RTRIM(ContactAddress),RTRIM(ContactOccupation),RTRIM(ContactRelation),RTRIM(ContactEmail),RTRIM(ContactWorkNo),RTRIM(Gender),RTRIM(Title),RTRIM(Hometown),RTRIM(RegistrationDate),RTRIM(Religion) from Students where Class=" & cboclass.Text & " order by firstname ASC", ConnectionModule.con)
                dr = com1.ExecuteReader(CommandBehavior.CloseConnection)
                dgv.Rows.Clear()
                If dr.HasRows() = True Then
                    While (dr.Read() = True)
                        dgv.Rows.Add(dr(0), dr(1), dr(2), dr(3) + "  " + dr(4), dr(5), dr(6), dr(7), dr(8), dr(9), dr(10), dr(11), dr(12), dr(13), dr(14), dr(15), dr(16), dr(17), dr(18), dr(19), dr(20), dr(21), dr(22), dr(23), dr(24))
                    End While
                    dr.Close()
                Else
                    MsgBox("Output exceeds records..Please specify more criteria", MsgBoxStyle.OkOnly + MsgBoxStyle.Information, "Error")
                    Exit Sub
                End If
                con.Close()
            Catch ex As Exception
                MessageBox.Show(ex.ToString(), "error at regno_contains_letters")
            End Try
        End If

        '1: search by reg no contains a value of letters/digits
        If cbooption1.Text = "Registration No" And cbooption2.Text = "Contains" And txtvalue.Text <> "" Then
            Try
                If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                ConnectionModule.con.Open()
                com1 = New SqlCommand("SELECT RTRIM(ID),RTRIM(RegistrationNumber),RTRIM(FirstName), RTRIM(MiddleName), RTRIM(LastName), RTRIM(DOB),RTRIM(Age),RTRIM(Department),RTRIM(Class),RTRIM(Region),RTRIM(District),RTRIM(Nationality),RTRIM(HouseAddress),RTRIM(ContactName),RTRIM(ContactNumber),RTRIM(ContactAddress),RTRIM(ContactOccupation),RTRIM(ContactRelation),RTRIM(ContactEmail),RTRIM(ContactWorkNo),RTRIM(Gender),RTRIM(Title),RTRIM(Hometown),RTRIM(RegistrationDate),RTRIM(Religion) from Students where RegistrationNumber like'%" & txtvalue.Text & "%' order by RegistrationNumber ASC", ConnectionModule.con)
                dr = com1.ExecuteReader(CommandBehavior.CloseConnection)
                dgv.Rows.Clear()
                If dr.HasRows() = True Then
                    While (dr.Read() = True)
                        dgv.Rows.Add(dr(0), dr(1), dr(2), dr(3) + "  " + dr(4), dr(5), dr(6), dr(7), dr(8), dr(9), dr(10), dr(11), dr(12), dr(13), dr(14), dr(15), dr(16), dr(17), dr(18), dr(19), dr(20), dr(21), dr(22), dr(23), dr(24))
                    End While
                    dr.Close()
                Else
                    MsgBox("Output exceeds records..", MsgBoxStyle.OkOnly + MsgBoxStyle.Information, "Error")
                    Exit Sub
                End If
                con.Close()
            Catch ex As Exception
                MessageBox.Show(ex.ToString(), "error at regno_contains_letters")
            End Try
        End If
        '2: search by reg no end with value
        If cbooption1.Text = "Registration No" And cbooption2.Text = "End With" And txtvalue.Text <> "" Then
            Try
                If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                ConnectionModule.con.Open()
                com1 = New SqlCommand("SELECT RTRIM(ID),RTRIM(RegistrationNumber),RTRIM(FirstName), RTRIM(MiddleName), RTRIM(LastName), RTRIM(DOB),RTRIM(Age),RTRIM(Department),RTRIM(Class),RTRIM(Region),RTRIM(District),RTRIM(Nationality),RTRIM(HouseAddress),RTRIM(ContactName),RTRIM(ContactNumber),RTRIM(ContactAddress),RTRIM(ContactOccupation),RTRIM(ContactRelation),RTRIM(ContactEmail),RTRIM(ContactWorkNo),RTRIM(Gender),RTRIM(Title),RTRIM(Hometown),RTRIM(RegistrationDate),RTRIM(Religion) from Students where RegistrationNumber like 'm______" & txtvalue.Text & "' order by RegistrationNumber ASC", ConnectionModule.con)
                Dim dr = com1.ExecuteReader(CommandBehavior.CloseConnection)
                dgv.Rows.Clear()
                If dr.HasRows = True Then
                    While (dr.Read() = True)
                        dgv.Rows.Add(dr(0), dr(1), dr(2), dr(3) + "  " + dr(4), dr(5), dr(6), dr(7), dr(8), dr(9), dr(10), dr(11), dr(12), dr(13), dr(14), dr(15), dr(16), dr(17), dr(18), dr(19), dr(20), dr(21), dr(22), dr(23), dr(24))
                    End While
                    dr.Close()
                Else
                    MsgBox("No specific record match your search criteria..", MsgBoxStyle.Information + +MsgBoxStyle.OkOnly, "Error")
                End If
                con.Close()
            Catch ex As Exception
                MessageBox.Show(ex.ToString(), "error at regno_end with_letter")
            End Try
        End If
        '3: search by reg no start with value
        If cbooption1.Text = "Registration No" And cbooption2.Text = "Start With" And txtvalue.Text <> "" Then
            Try
                If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                ConnectionModule.con.Open()
                com1 = New SqlCommand("SELECT RTRIM(ID),RTRIM(RegistrationNumber),RTRIM(FirstName), RTRIM(MiddleName), RTRIM(LastName), RTRIM(DOB),RTRIM(Age),RTRIM(Department),RTRIM(Class),RTRIM(Region),RTRIM(District),RTRIM(Nationality),RTRIM(HouseAddress),RTRIM(ContactName),RTRIM(ContactNumber),RTRIM(ContactAddress),RTRIM(ContactOccupation),RTRIM(ContactRelation),RTRIM(ContactEmail),RTRIM(ContactWorkNo),RTRIM(Gender),RTRIM(Title),RTRIM(Hometown),RTRIM(RegistrationDate),RTRIM(Religion) from Students where RegistrationNumber like '[" & txtvalue.Text & "]%' order by RegistrationNumber ASC", ConnectionModule.con)
                dr = com1.ExecuteReader(CommandBehavior.CloseConnection)
                dgv.Rows.Clear()
                If dr.HasRows = True Then
                    While (dr.Read() = True)
                        dgv.Rows.Add(dr(0), dr(1), dr(2), dr(3) + "  " + dr(4), dr(5), dr(6), dr(7), dr(8), dr(9), dr(10), dr(11), dr(12), dr(13), dr(14), dr(15), dr(16), dr(17), dr(18), dr(19), dr(20), dr(21), dr(22), dr(23), dr(24))
                    End While
                    dr.Close()
                Else
                    MsgBox("No specific record match your search criteria..", MsgBoxStyle.Information + +MsgBoxStyle.OkOnly, "Error")
                End If
                con.Close()
            Catch ex As Exception
                MessageBox.Show(ex.ToString(), "error at regno_start with_letter")
            End Try
        End If
        '4:search by reg no equals parameter value
        If cbooption1.Text = "Registration No" And cbooption2.Text = "Equals" And txtvalue.Text <> "" Then
            Try
                If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                ConnectionModule.con.Open()
                com1 = New SqlCommand("SELECT RTRIM(ID),RTRIM(RegistrationNumber),RTRIM(FirstName), RTRIM(MiddleName), RTRIM(LastName), RTRIM(DOB),RTRIM(Age),RTRIM(Department),RTRIM(Class),RTRIM(Region),RTRIM(District),RTRIM(Nationality),RTRIM(HouseAddress),RTRIM(ContactName),RTRIM(ContactNumber),RTRIM(ContactAddress),RTRIM(ContactOccupation),RTRIM(ContactRelation),RTRIM(ContactEmail),RTRIM(ContactWorkNo),RTRIM(Gender),RTRIM(Title),RTRIM(Hometown),RTRIM(RegistrationDate),RTRIM(Religion) from Students where RegistrationNumber=" & txtvalue.Text & " order by RegistrationNumber ASC", ConnectionModule.con)
                dr = com1.ExecuteReader(CommandBehavior.CloseConnection)
                dgv.Rows.Clear()
                If dr.HasRows = True Then
                    While (dr.Read() = True)
                        dgv.Rows.Add(dr(0), dr(1), dr(2), dr(3) + "  " + dr(4), dr(5), dr(6), dr(7), dr(8), dr(9), dr(10), dr(11), dr(12), dr(13), dr(14), dr(15), dr(16), dr(17), dr(18), dr(19), dr(20), dr(21), dr(22), dr(23), dr(24))
                    End While
                    dr.Close()
                Else
                    MsgBox("No specific record match your search criteria..", MsgBoxStyle.Information + +MsgBoxStyle.OkOnly, "Error")
                End If
                con.Close()
            Catch ex As Exception
                MessageBox.Show(ex.ToString(), "error at regno_start with_letter")
            End Try
        End If
        '5: search by reg no start with and gender is female
        If cbooption1.Text = "Registration No" And cbooption2.Text = "Start With" And txtvalue.Text <> "" And cbogender.Text = "FEMALE" Then
            Try
                If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                ConnectionModule.con.Open()
                com1 = New SqlCommand("SELECT RTRIM(ID),RTRIM(RegistrationNumber),RTRIM(FirstName), RTRIM(MiddleName), RTRIM(LastName), RTRIM(DOB),RTRIM(Age),RTRIM(Department),RTRIM(Class),RTRIM(Region),RTRIM(District),RTRIM(Nationality),RTRIM(HouseAddress),RTRIM(ContactName),RTRIM(ContactNumber),RTRIM(ContactAddress),RTRIM(ContactOccupation),RTRIM(ContactRelation),RTRIM(ContactEmail),RTRIM(ContactWorkNo),RTRIM(Gender),RTRIM(Title),RTRIM(Hometown),RTRIM(RegistrationDate),RTRIM(Religion) from Students where RegistrationNumber like '[" & txtvalue.Text & "]%' and Gender='FEMALE' order by FirstName ASC", ConnectionModule.con)
                dr = com1.ExecuteReader(CommandBehavior.CloseConnection)
                dgv.Rows.Clear()
                If dr.HasRows = True Then
                    While (dr.Read() = True)
                        dgv.Rows.Add(dr(0), dr(1), dr(2), dr(3) + "  " + dr(4), dr(5), dr(6), dr(7), dr(8), dr(9), dr(10), dr(11), dr(12), dr(13), dr(14), dr(15), dr(16), dr(17), dr(18), dr(19), dr(20), dr(21), dr(22), dr(23), dr(24))
                    End While
                    dr.Close()
                Else
                    MsgBox("No specific record match your search criteria..", MsgBoxStyle.Information + +MsgBoxStyle.OkOnly, "Error")
                End If
                con.Close()
            Catch ex As Exception
                MessageBox.Show(ex.ToString(), "error at regno_start with_letter")
            End Try
        End If
        '6: search by reg no start with  and male gender
        If cbooption1.Text = "Registration No" And cbooption2.Text = "Start With" And txtvalue.Text <> "" And cbogender.Text = "MALE" Then
            Try
                If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                ConnectionModule.con.Open()
                com1 = New SqlCommand("SELECT RTRIM(ID),RTRIM(RegistrationNumber),RTRIM(FirstName), RTRIM(MiddleName), RTRIM(LastName), RTRIM(DOB),RTRIM(Age),RTRIM(Department),RTRIM(Class),RTRIM(Region),RTRIM(District),RTRIM(Nationality),RTRIM(HouseAddress),RTRIM(ContactName),RTRIM(ContactNumber),RTRIM(ContactAddress),RTRIM(ContactOccupation),RTRIM(ContactRelation),RTRIM(ContactEmail),RTRIM(ContactWorkNo),RTRIM(Gender),RTRIM(Title),RTRIM(Hometown),RTRIM(RegistrationDate),RTRIM(Religion) from Students where RegistrationNumber like '[" & txtvalue.Text & "]%' and Gender='MALE' order by FirstName ASC", ConnectionModule.con)
                dr = com1.ExecuteReader(CommandBehavior.CloseConnection)
                dgv.Rows.Clear()
                If dr.HasRows = True Then
                    While (dr.Read() = True)
                        dgv.Rows.Add(dr(0), dr(1), dr(2), dr(3) + "  " + dr(4), dr(5), dr(6), dr(7), dr(8), dr(9), dr(10), dr(11), dr(12), dr(13), dr(14), dr(15), dr(16), dr(17), dr(18), dr(19), dr(20), dr(21), dr(22), dr(23), dr(24))
                    End While
                    dr.Close()
                Else
                    MsgBox("No specific record match your search criteria..", MsgBoxStyle.Information + +MsgBoxStyle.OkOnly, "Error")
                End If
                con.Close()
            Catch ex As Exception
                MessageBox.Show(ex.ToString(), "error at regno_start with_letter")
            End Try
        End If
        '7: search by reg no start with  and female gender with specific department
        If cbooption1.Text = "Registration No" And cbooption2.Text = "Start With" And txtvalue.Text <> "" And cbogender.Text = "FEMALE" And cbodepartment.Text = "KINDERGARTEN" Then
            Try
                If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                ConnectionModule.con.Open()
                com1 = New SqlCommand("SELECT RTRIM(ID),RTRIM(RegistrationNumber),RTRIM(FirstName), RTRIM(MiddleName), RTRIM(LastName), RTRIM(DOB),RTRIM(Age),RTRIM(Department),RTRIM(Class),RTRIM(Region),RTRIM(District),RTRIM(Nationality),RTRIM(HouseAddress),RTRIM(ContactName),RTRIM(ContactNumber),RTRIM(ContactAddress),RTRIM(ContactOccupation),RTRIM(ContactRelation),RTRIM(ContactEmail),RTRIM(ContactWorkNo),RTRIM(Gender),RTRIM(Title),RTRIM(Hometown),RTRIM(RegistrationDate),RTRIM(Religion) from Students where RegistrationNumber like '[" & txtvalue.Text & "]%' and Gender='FEMALE' and Department='KINDERGARTEN' order by FirstName ASC", ConnectionModule.con)
                dr = com1.ExecuteReader(CommandBehavior.CloseConnection)
                dgv.Rows.Clear()
                If dr.HasRows = True Then
                    While (dr.Read() = True)
                        dgv.Rows.Add(dr(0), dr(1), dr(2), dr(3) + "  " + dr(4), dr(5), dr(6), dr(7), dr(8), dr(9), dr(10), dr(11), dr(12), dr(13), dr(14), dr(15), dr(16), dr(17), dr(18), dr(19), dr(20), dr(21), dr(22), dr(23), dr(24))
                    End While
                    dr.Close()
                Else
                    MsgBox("no data fit ur search")
                End If
                con.Close()
            Catch ex As Exception
                MessageBox.Show(ex.ToString(), "error at regno_start with_letter")
            End Try
        End If
        '7: search by reg no start with  and female gender with specific department
        If cbooption1.Text = "Registration No" And cbooption2.Text = "Start With" And txtvalue.Text <> "" And cbogender.Text = "FEMALE" And cbodepartment.Text = "LOWER PRIMARY" Then
            Try
                If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                ConnectionModule.con.Open()
                com1 = New SqlCommand("SELECT RTRIM(ID),RTRIM(RegistrationNumber),RTRIM(FirstName), RTRIM(MiddleName), RTRIM(LastName), RTRIM(DOB),RTRIM(Age),RTRIM(Department),RTRIM(Class),RTRIM(Region),RTRIM(District),RTRIM(Nationality),RTRIM(HouseAddress),RTRIM(ContactName),RTRIM(ContactNumber),RTRIM(ContactAddress),RTRIM(ContactOccupation),RTRIM(ContactRelation),RTRIM(ContactEmail),RTRIM(ContactWorkNo),RTRIM(Gender),RTRIM(Title),RTRIM(Hometown),RTRIM(RegistrationDate),RTRIM(Religion) from Students where RegistrationNumber like '[" & txtvalue.Text & "]%' and Gender='FEMALE' and Department='LOWER PRIMARY' order by FirstName ASC", ConnectionModule.con)
                dr = com1.ExecuteReader(CommandBehavior.CloseConnection)
                dgv.Rows.Clear()
                If dr.HasRows = True Then
                    While (dr.Read() = True)
                        dgv.Rows.Add(dr(0), dr(1), dr(2), dr(3) + "  " + dr(4), dr(5), dr(6), dr(7), dr(8), dr(9), dr(10), dr(11), dr(12), dr(13), dr(14), dr(15), dr(16), dr(17), dr(18), dr(19), dr(20), dr(21), dr(22), dr(23), dr(24))
                    End While
                    dr.Close()
                Else
                    MsgBox("no data fit ur search")
                End If
                con.Close()
            Catch ex As Exception
                MessageBox.Show(ex.ToString(), "error at regno_start with_letter")
            End Try
        End If
        '7: search by reg no start with  and female gender with specific department
        If cbooption1.Text = "Registration No" And cbooption2.Text = "Start With" And txtvalue.Text <> "" And cbogender.Text = "FEMALE" And cbodepartment.Text = "UPPER PRIMARY" Then
            Try
                If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                ConnectionModule.con.Open()
                com1 = New SqlCommand("SELECT RTRIM(ID),RTRIM(RegistrationNumber),RTRIM(FirstName), RTRIM(MiddleName), RTRIM(LastName), RTRIM(DOB),RTRIM(Age),RTRIM(Department),RTRIM(Class),RTRIM(Region),RTRIM(District),RTRIM(Nationality),RTRIM(HouseAddress),RTRIM(ContactName),RTRIM(ContactNumber),RTRIM(ContactAddress),RTRIM(ContactOccupation),RTRIM(ContactRelation),RTRIM(ContactEmail),RTRIM(ContactWorkNo),RTRIM(Gender),RTRIM(Title),RTRIM(Hometown),RTRIM(RegistrationDate),RTRIM(Religion) from Students where RegistrationNumber like '[" & txtvalue.Text & "]%' and Gender='FEMALE' and Department='UPPER PRIMARY' order by FirstName ASC", ConnectionModule.con)
                dr = com1.ExecuteReader(CommandBehavior.CloseConnection)
                dgv.Rows.Clear()
                If dr.HasRows = True Then
                    While (dr.Read() = True)
                        dgv.Rows.Add(dr(0), dr(1), dr(2), dr(3) + "  " + dr(4), dr(5), dr(6), dr(7), dr(8), dr(9), dr(10), dr(11), dr(12), dr(13), dr(14), dr(15), dr(16), dr(17), dr(18), dr(19), dr(20), dr(21), dr(22), dr(23), dr(24))
                    End While
                    dr.Close()
                Else
                    MsgBox("no data fit ur search")
                End If
                con.Close()
            Catch ex As Exception
                MessageBox.Show(ex.ToString(), "error at regno_start with_letter")
            End Try
        End If
        '7: search by reg no start with  and female gender with specific department
        If cbooption1.Text = "Registration No" And cbooption2.Text = "Start With" And txtvalue.Text <> "" And cbogender.Text = "FEMALE" And cbodepartment.Text = "JUNIOR HIGH SCHOOL" Then
            Try
                If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                ConnectionModule.con.Open()
                com1 = New SqlCommand("SELECT RTRIM(ID),RTRIM(RegistrationNumber),RTRIM(FirstName), RTRIM(MiddleName), RTRIM(LastName), RTRIM(DOB),RTRIM(Age),RTRIM(Department),RTRIM(Class),RTRIM(Region),RTRIM(District),RTRIM(Nationality),RTRIM(HouseAddress),RTRIM(ContactName),RTRIM(ContactNumber),RTRIM(ContactAddress),RTRIM(ContactOccupation),RTRIM(ContactRelation),RTRIM(ContactEmail),RTRIM(ContactWorkNo),RTRIM(Gender),RTRIM(Title),RTRIM(Hometown),RTRIM(RegistrationDate),RTRIM(Religion) from Students where RegistrationNumber like '[" & txtvalue.Text & "]%' and Gender='FEMALE' and Department='JUNIOR HIGH SCHOOL' order by FirstName ASC", ConnectionModule.con)
                dr = com1.ExecuteReader(CommandBehavior.CloseConnection)
                dgv.Rows.Clear()
                If dr.HasRows = True Then
                    While (dr.Read() = True)
                        dgv.Rows.Add(dr(0), dr(1), dr(2), dr(3) + "  " + dr(4), dr(5), dr(6), dr(7), dr(8), dr(9), dr(10), dr(11), dr(12), dr(13), dr(14), dr(15), dr(16), dr(17), dr(18), dr(19), dr(20), dr(21), dr(22), dr(23), dr(24))
                    End While
                    dr.Close()
                Else
                    MsgBox("Output exceeds records..", MsgBoxStyle.OkOnly + MsgBoxStyle.Information, "Error")
                End If
                con.Close()
            Catch ex As Exception
                MessageBox.Show(ex.ToString(), "error at regno_start with_letter")
            End Try
        End If

        '8: search by reg no start with  and male gender
        If cbooption1.Text = "Registration No" And cbooption2.Text = "Start With" And txtvalue.Text <> "" And cbogender.Text = "MALE" And cbodepartment.Text = "KINDERGARTEN" Then
            Try
                If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                ConnectionModule.con.Open()
                com1 = New SqlCommand("SELECT RTRIM(ID),RTRIM(RegistrationNumber),RTRIM(FirstName), RTRIM(MiddleName), RTRIM(LastName), RTRIM(DOB),RTRIM(Age),RTRIM(Department),RTRIM(Class),RTRIM(Region),RTRIM(District),RTRIM(Nationality),RTRIM(HouseAddress),RTRIM(ContactName),RTRIM(ContactNumber),RTRIM(ContactAddress),RTRIM(ContactOccupation),RTRIM(ContactRelation),RTRIM(ContactEmail),RTRIM(ContactWorkNo),RTRIM(Gender),RTRIM(Title),RTRIM(Hometown),RTRIM(RegistrationDate),RTRIM(Religion) from Students where RegistrationNumber like '[" & txtvalue.Text & "]%' and Gender='MALE' and Department='KINDERGARTEN' order by FirstName ASC", ConnectionModule.con)
                dr = com1.ExecuteReader(CommandBehavior.CloseConnection)
                dgv.Rows.Clear()
                If dr.HasRows = True Then
                    While (dr.Read() = True)
                        dgv.Rows.Add(dr(0), dr(1), dr(2), dr(3) + "  " + dr(4), dr(5), dr(6), dr(7), dr(8), dr(9), dr(10), dr(11), dr(12), dr(13), dr(14), dr(15), dr(16), dr(17), dr(18), dr(19), dr(20), dr(21), dr(22), dr(23), dr(24))
                    End While
                    dr.Close()
                Else
                    MsgBox("no data fit ur search")
                End If
                con.Close()
            Catch ex As Exception
                MessageBox.Show(ex.ToString(), "error at regno_start with_letter")
            End Try
        End If
        '8: search by reg no start with  and male gender
        If cbooption1.Text = "Registration No" And cbooption2.Text = "Start With" And txtvalue.Text <> "" And cbogender.Text = "MALE" And cbodepartment.Text = "LOWER PRIMARY" Then
            Try
                If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                ConnectionModule.con.Open()
                com1 = New SqlCommand("SELECT RTRIM(ID),RTRIM(RegistrationNumber),RTRIM(FirstName), RTRIM(MiddleName), RTRIM(LastName), RTRIM(DOB),RTRIM(Age),RTRIM(Department),RTRIM(Class),RTRIM(Region),RTRIM(District),RTRIM(Nationality),RTRIM(HouseAddress),RTRIM(ContactName),RTRIM(ContactNumber),RTRIM(ContactAddress),RTRIM(ContactOccupation),RTRIM(ContactRelation),RTRIM(ContactEmail),RTRIM(ContactWorkNo),RTRIM(Gender),RTRIM(Title),RTRIM(Hometown),RTRIM(RegistrationDate),RTRIM(Religion) from Students where RegistrationNumber like '[" & txtvalue.Text & "]%' and Gender='MALE' and Department='LOWER PRIMARY' order by FirstName ASC", ConnectionModule.con)
                dr = com1.ExecuteReader(CommandBehavior.CloseConnection)
                dgv.Rows.Clear()
                If dr.HasRows = True Then
                    While (dr.Read() = True)
                        dgv.Rows.Add(dr(0), dr(1), dr(2), dr(3) + "  " + dr(4), dr(5), dr(6), dr(7), dr(8), dr(9), dr(10), dr(11), dr(12), dr(13), dr(14), dr(15), dr(16), dr(17), dr(18), dr(19), dr(20), dr(21), dr(22), dr(23), dr(24))
                    End While
                    dr.Close()
                Else
                    MsgBox("Output exceeds records..", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Erorr")
                End If
                con.Close()
            Catch ex As Exception
                MessageBox.Show(ex.ToString(), "error at regno_start with_letter")
            End Try
        End If
        '8: search by reg no start with  and male gender
        If cbooption1.Text = "Registration No" And cbooption2.Text = "Start With" And txtvalue.Text <> "" And cbogender.Text = "MALE" And cbodepartment.Text = "UPPER PRIMARY" Then
            Try
                If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                ConnectionModule.con.Open()
                com1 = New SqlCommand("SELECT RTRIM(ID),RTRIM(RegistrationNumber),RTRIM(FirstName), RTRIM(MiddleName), RTRIM(LastName), RTRIM(DOB),RTRIM(Age),RTRIM(Department),RTRIM(Class),RTRIM(Region),RTRIM(District),RTRIM(Nationality),RTRIM(HouseAddress),RTRIM(ContactName),RTRIM(ContactNumber),RTRIM(ContactAddress),RTRIM(ContactOccupation),RTRIM(ContactRelation),RTRIM(ContactEmail),RTRIM(ContactWorkNo),RTRIM(Gender),RTRIM(Title),RTRIM(Hometown),RTRIM(RegistrationDate),RTRIM(Religion) from Students where RegistrationNumber like '[" & txtvalue.Text & "]%' and Gender='MALE' and Department='UPPER PRIMARY' order by FirstName ASC", ConnectionModule.con)
                dr = com1.ExecuteReader(CommandBehavior.CloseConnection)
                dgv.Rows.Clear()
                If dr.HasRows = True Then
                    While (dr.Read() = True)
                        dgv.Rows.Add(dr(0), dr(1), dr(2), dr(3) + "  " + dr(4), dr(5), dr(6), dr(7), dr(8), dr(9), dr(10), dr(11), dr(12), dr(13), dr(14), dr(15), dr(16), dr(17), dr(18), dr(19), dr(20), dr(21), dr(22), dr(23), dr(24))
                    End While
                    dr.Close()
                Else
                    MsgBox("Output exceeds records..", MsgBoxStyle.OkOnly + MsgBoxStyle.Information, "Error")
                End If
                con.Close()
            Catch ex As Exception
                MessageBox.Show(ex.ToString(), "error at regno_start with_letter")
            End Try
        End If
        '8: search by reg no start with  and male gender
        If cbooption1.Text = "Registration No" And cbooption2.Text = "Start With" And txtvalue.Text <> "" And cbogender.Text = "MALE" And cbodepartment.Text = "JUNIOR HIGH SCHOOL" Then
            Try
                If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                ConnectionModule.con.Open()
                com1 = New SqlCommand("SELECT RTRIM(ID),RTRIM(RegistrationNumber),RTRIM(FirstName), RTRIM(MiddleName), RTRIM(LastName), RTRIM(DOB),RTRIM(Age),RTRIM(Department),RTRIM(Class),RTRIM(Region),RTRIM(District),RTRIM(Nationality),RTRIM(HouseAddress),RTRIM(ContactName),RTRIM(ContactNumber),RTRIM(ContactAddress),RTRIM(ContactOccupation),RTRIM(ContactRelation),RTRIM(ContactEmail),RTRIM(ContactWorkNo),RTRIM(Gender),RTRIM(Title),RTRIM(Hometown),RTRIM(RegistrationDate),RTRIM(Religion) from Students where RegistrationNumber like '[" & txtvalue.Text & "]%' and Gender='MALE' and Department='JUNIOR HIGH SCHOOL' order by FirstName ASC", ConnectionModule.con)
                dr = com1.ExecuteReader(CommandBehavior.CloseConnection)
                dgv.Rows.Clear()
                If dr.HasRows = True Then
                    While (dr.Read() = True)
                        dgv.Rows.Add(dr(0), dr(1), dr(2), dr(3) + "  " + dr(4), dr(5), dr(6), dr(7), dr(8), dr(9), dr(10), dr(11), dr(12), dr(13), dr(14), dr(15), dr(16), dr(17), dr(18), dr(19), dr(20), dr(21), dr(22), dr(23), dr(24))
                    End While
                    dr.Close()
                Else
                    MsgBox("Output exceeds records..", MsgBoxStyle.OkOnly + MsgBoxStyle.Information, "Error")
                End If
                con.Close()
            Catch ex As Exception
                MessageBox.Show(ex.ToString(), "error at regno_start with_letter")
            End Try
        End If
        '9: search by rreligion
        If cboReligion.Text = "CHRISTIANITY" Then
            Try
                If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                ConnectionModule.con.Open()
                com1 = New SqlCommand("SELECT RTRIM(ID),RTRIM(RegistrationNumber),RTRIM(FirstName), RTRIM(MiddleName), RTRIM(LastName), RTRIM(DOB),RTRIM(Age),RTRIM(Department),RTRIM(Class),RTRIM(Region),RTRIM(District),RTRIM(Nationality),RTRIM(HouseAddress),RTRIM(ContactName),RTRIM(ContactNumber),RTRIM(ContactAddress),RTRIM(ContactOccupation),RTRIM(ContactRelation),RTRIM(ContactEmail),RTRIM(ContactWorkNo),RTRIM(Gender),RTRIM(Title),RTRIM(Hometown),RTRIM(RegistrationDate),RTRIM(Religion) from Students where Religion='CHRISTIANITY' order by FirstName ASC", ConnectionModule.con)
                dr = com1.ExecuteReader(CommandBehavior.CloseConnection)
                dgv.Rows.Clear()
                If dr.HasRows = True Then
                    While (dr.Read() = True)
                        dgv.Rows.Add(dr(0), dr(1), dr(2), dr(3) + "  " + dr(4), dr(5), dr(6), dr(7), dr(8), dr(9), dr(10), dr(11), dr(12), dr(13), dr(14), dr(15), dr(16), dr(17), dr(18), dr(19), dr(20), dr(21), dr(22), dr(23), dr(24))
                    End While
                    dr.Close()
                    'Else
                    '    MsgBox("Specify more search parameters that fit your search criteria..", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Error")
                End If
                con.Close()
            Catch ex As Exception
                MessageBox.Show(ex.ToString(), "error at christianity")
            End Try
        End If
        '9: search by rreligion
        If cboReligion.Text = "ISLAM" Then
            Try
                If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                ConnectionModule.con.Open()
                com1 = New SqlCommand("SELECT RTRIM(ID),RTRIM(RegistrationNumber),RTRIM(FirstName), RTRIM(MiddleName), RTRIM(LastName), RTRIM(DOB),RTRIM(Age),RTRIM(Department),RTRIM(Class),RTRIM(Region),RTRIM(District),RTRIM(Nationality),RTRIM(HouseAddress),RTRIM(ContactName),RTRIM(ContactNumber),RTRIM(ContactAddress),RTRIM(ContactOccupation),RTRIM(ContactRelation),RTRIM(ContactEmail),RTRIM(ContactWorkNo),RTRIM(Gender),RTRIM(Title),RTRIM(Hometown),RTRIM(RegistrationDate),RTRIM(Religion) from Students where Religion='ISLAM' order by FirstName ASC", ConnectionModule.con)
                dr = com1.ExecuteReader(CommandBehavior.CloseConnection)
                dgv.Rows.Clear()
                If dr.HasRows = True Then
                    While (dr.Read() = True)
                        dgv.Rows.Add(dr(0), dr(1), dr(2), dr(3) + "  " + dr(4), dr(5), dr(6), dr(7), dr(8), dr(9), dr(10), dr(11), dr(12), dr(13), dr(14), dr(15), dr(16), dr(17), dr(18), dr(19), dr(20), dr(21), dr(22), dr(23), dr(24))
                    End While
                    dr.Close()
                    'Else
                    '    MsgBox("Output exceeds records.", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "ERROR")
                End If
                con.Close()
            Catch ex As Exception
                MessageBox.Show(ex.ToString(), "error at islam")
            End Try
        End If
        '9: search by rreligion
        If cboReligion.Text = "TRADITIONALIST" Then
            Try
                If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                ConnectionModule.con.Open()
                com1 = New SqlCommand("SELECT RTRIM(ID),RTRIM(RegistrationNumber),RTRIM(FirstName), RTRIM(MiddleName), RTRIM(LastName), RTRIM(DOB),RTRIM(Age),RTRIM(Department),RTRIM(Class),RTRIM(Region),RTRIM(District),RTRIM(Nationality),RTRIM(HouseAddress),RTRIM(ContactName),RTRIM(ContactNumber),RTRIM(ContactAddress),RTRIM(ContactOccupation),RTRIM(ContactRelation),RTRIM(ContactEmail),RTRIM(ContactWorkNo),RTRIM(Gender),RTRIM(Title),RTRIM(Hometown),RTRIM(RegistrationDate),RTRIM(Religion) from Students where Religion='TRADITIONALIST' order by RegistrationNumber ASC", ConnectionModule.con)
                dr = com1.ExecuteReader(CommandBehavior.CloseConnection)
                dgv.Rows.Clear()
                If dr.HasRows = True Then
                    While (dr.Read() = True)
                        dgv.Rows.Add(dr(0), dr(1), dr(2), dr(3) + "  " + dr(4), dr(5), dr(6), dr(7), dr(8), dr(9), dr(10), dr(11), dr(12), dr(13), dr(14), dr(15), dr(16), dr(17), dr(18), dr(19), dr(20), dr(21), dr(22), dr(23), dr(24))
                    End While
                    dr.Close()
                    'Else
                    '    MsgBox("No record found for your search criteria", MsgBoxStyle.OkOnly + MsgBoxStyle.Information, "SMIS")
                End If
                con.Close()
            Catch ex As Exception
                MessageBox.Show(ex.ToString(), "error at traditionlist")
            End Try
        End If
        'end of first search section

        'beginning of section two
        If cbodepartment.Text = "KINDERGARTEN" Then
            Try
                If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                ConnectionModule.con.Open()
                Dim cmd = New SqlCommand("SELECT RTRIM(ID),RTRIM(RegistrationNumber),RTRIM(FirstName), RTRIM(MiddleName), RTRIM(LastName), RTRIM(DOB),RTRIM(Age),RTRIM(Department),RTRIM(Class),RTRIM(Region),RTRIM(District),RTRIM(Nationality),RTRIM(HouseAddress),RTRIM(ContactName),RTRIM(ContactNumber),RTRIM(ContactAddress),RTRIM(ContactOccupation),RTRIM(ContactRelation),RTRIM(ContactEmail),RTRIM(ContactWorkNo),RTRIM(Gender),RTRIM(Title),RTRIM(Hometown),RTRIM(RegistrationDate),RTRIM(Religion) from Students where Department='KINDERGARTEN' order by class ASC", ConnectionModule.con)
                Dim rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection)
                dgv.Rows.Clear()
                While (rdr.Read() = True)
                    dgv.Rows.Add(rdr(0), rdr(1), rdr(2), rdr(3) + "  " + rdr(4), rdr(5), rdr(6), rdr(7), rdr(8), rdr(9), rdr(10), rdr(11), rdr(12), rdr(13), rdr(14), rdr(15), rdr(16), rdr(17), rdr(18), rdr(19), rdr(20), rdr(21), rdr(22), rdr(23), rdr(24))
                End While
                con.Close()
            Catch ex As Exception
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
            Exit Sub
        End If
        If cbodepartment.Text = "LOWER PRIMARY" Then
            Try
                If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                ConnectionModule.con.Open()
                Dim cmd = New SqlCommand("SELECT RTRIM(ID),RTRIM(RegistrationNumber),RTRIM(FirstName), RTRIM(MiddleName), RTRIM(LastName), RTRIM(DOB),RTRIM(Age),RTRIM(Department),RTRIM(Class),RTRIM(Region),RTRIM(District),RTRIM(Nationality),RTRIM(HouseAddress),RTRIM(ContactName),RTRIM(ContactNumber),RTRIM(ContactAddress),RTRIM(ContactOccupation),RTRIM(ContactRelation),RTRIM(ContactEmail),RTRIM(ContactWorkNo),RTRIM(Gender),RTRIM(Title),RTRIM(Hometown),RTRIM(RegistrationDate),RTRIM(Religion) from Students where Department='LOWER PRIMARY' order by Class ASC", ConnectionModule.con)
                Dim rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection)
                dgv.Rows.Clear()
                While (rdr.Read() = True)
                    dgv.Rows.Add(rdr(0), rdr(1), rdr(2), rdr(3) + "  " + rdr(4), rdr(5), rdr(6), rdr(7), rdr(8), rdr(9), rdr(10), rdr(11), rdr(12), rdr(13), rdr(14), rdr(15), rdr(16), rdr(17), rdr(18), rdr(19), rdr(20), rdr(21), rdr(22), rdr(23), rdr(24))
                End While
                con.Close()
            Catch ex As Exception
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
            Exit Sub
        End If
        If cbodepartment.Text = "UPPER PRIMARY" Then
            Try
                If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                ConnectionModule.con.Open()
                Dim cmd = New SqlCommand("SELECT RTRIM(ID),RTRIM(RegistrationNumber),RTRIM(FirstName), RTRIM(MiddleName), RTRIM(LastName), RTRIM(DOB),RTRIM(Age),RTRIM(Department),RTRIM(Class),RTRIM(Region),RTRIM(District),RTRIM(Nationality),RTRIM(HouseAddress),RTRIM(ContactName),RTRIM(ContactNumber),RTRIM(ContactAddress),RTRIM(ContactOccupation),RTRIM(ContactRelation),RTRIM(ContactEmail),RTRIM(ContactWorkNo),RTRIM(Gender),RTRIM(Title),RTRIM(Hometown),RTRIM(RegistrationDate),RTRIM(Religion) from Students where Department='UPPER PRIMARY' order by Class ASC", ConnectionModule.con)
                Dim rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection)
                dgv.Rows.Clear()
                While (rdr.Read() = True)
                    dgv.Rows.Add(rdr(0), rdr(1), rdr(2), rdr(3) + "  " + rdr(4), rdr(5), rdr(6), rdr(7), rdr(8), rdr(9), rdr(10), rdr(11), rdr(12), rdr(13), rdr(14), rdr(15), rdr(16), rdr(17), rdr(18), rdr(19), rdr(20), rdr(21), rdr(22), rdr(23), rdr(24))
                End While
                con.Close()
            Catch ex As Exception
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
            Exit Sub
        End If
        If cbodepartment.Text = "JUNIOR HIGH SCHOOL" Then
            Try
                If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                ConnectionModule.con.Open()
                Dim cmd = New SqlCommand("SELECT RTRIM(ID),RTRIM(RegistrationNumber),RTRIM(FirstName), RTRIM(MiddleName), RTRIM(LastName), RTRIM(DOB),RTRIM(Age),RTRIM(Department),RTRIM(Class),RTRIM(Region),RTRIM(District),RTRIM(Nationality),RTRIM(HouseAddress),RTRIM(ContactName),RTRIM(ContactNumber),RTRIM(ContactAddress),RTRIM(ContactOccupation),RTRIM(ContactRelation),RTRIM(ContactEmail),RTRIM(ContactWorkNo),RTRIM(Gender),RTRIM(Title),RTRIM(Hometown),RTRIM(RegistrationDate),RTRIM(Religion) from Students where Department='JUNIOR HIGH SCHOOL' order by Class ASC", ConnectionModule.con)
                Dim rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection)
                dgv.Rows.Clear()
                While (rdr.Read() = True)
                    dgv.Rows.Add(rdr(0), rdr(1), rdr(2), rdr(3) + "  " + rdr(4), rdr(5), rdr(6), rdr(7), rdr(8), rdr(9), rdr(10), rdr(11), rdr(12), rdr(13), rdr(14), rdr(15), rdr(16), rdr(17), rdr(18), rdr(19), rdr(20), rdr(21), rdr(22), rdr(23), rdr(24))
                End While
                con.Close()
            Catch ex As Exception
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If

        'search student info according to detailed criteria provided
        If cbooption1.Text = "Registration No" And cbooption2.Text = "Start With" And txtvalue.Text <> "" And cbogender.Text = "FEMALE" And cbodepartment.Text = "KINDERGARTEN" Then
            Try
                If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                ConnectionModule.con.Open()
                Dim cmd = New SqlCommand("SELECT RTRIM(ID),RTRIM(RegistrationNumber),RTRIM(FirstName), RTRIM(MiddleName), RTRIM(LastName), RTRIM(DOB),RTRIM(Age),RTRIM(Department),RTRIM(Class),RTRIM(Region),RTRIM(District),RTRIM(Nationality),RTRIM(HouseAddress),RTRIM(ContactName),RTRIM(ContactNumber),RTRIM(ContactAddress),RTRIM(ContactOccupation),RTRIM(ContactRelation),RTRIM(ContactEmail),RTRIM(ContactWorkNo),RTRIM(Gender),RTRIM(Title),RTRIM(Hometown),RTRIM(RegistrationDate),RTRIM(Religion) from Students where RegistrationNumber like '[" & txtvalue.Text & "]%' and Gender='FEMALE' and Department='KINDERGARTEN' order by RegistrationNumber ASC", ConnectionModule.con)
                Dim rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection)
                dgv.Rows.Clear()
                While (rdr.Read() = True)
                    dgv.Rows.Add(rdr(0), rdr(1), rdr(2), rdr(3) + "  " + rdr(4), rdr(5), rdr(6), rdr(7), rdr(8), rdr(9), rdr(10), rdr(11), rdr(12), rdr(13), rdr(14), rdr(15), rdr(16), rdr(17), rdr(18), rdr(19), rdr(20), rdr(21), rdr(22), rdr(23), rdr(24))
                End While
                con.Close()
            Catch ex As Exception
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
            Exit Sub
        End If
        If cbooption1.Text = "Registration No" And cbooption2.Text = "Start With" And txtvalue.Text <> "" And cbogender.Text = "FEMALE" And cbodepartment.Text = "LOWER PRIMARY" Then
            Try
                If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                ConnectionModule.con.Open()
                Dim cmd = New SqlCommand("SELECT RTRIM(ID),RTRIM(RegistrationNumber),RTRIM(FirstName), RTRIM(MiddleName), RTRIM(LastName), RTRIM(DOB),RTRIM(Age),RTRIM(Department),RTRIM(Class),RTRIM(Region),RTRIM(District),RTRIM(Nationality),RTRIM(HouseAddress),RTRIM(ContactName),RTRIM(ContactNumber),RTRIM(ContactAddress),RTRIM(ContactOccupation),RTRIM(ContactRelation),RTRIM(ContactEmail),RTRIM(ContactWorkNo),RTRIM(Gender),RTRIM(Title),RTRIM(Hometown),RTRIM(RegistrationDate),RTRIM(Religion) from Students where RegistrationNumber like '[" & txtvalue.Text & "]%' and Gender='FEMALE' and Department='LOWER PRIMARY' order by RegistrationNumber ASC", ConnectionModule.con)
                Dim rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection)
                dgv.Rows.Clear()
                While (rdr.Read() = True)
                    dgv.Rows.Add(rdr(0), rdr(1), rdr(2), rdr(3) + "  " + rdr(4), rdr(5), rdr(6), rdr(7), rdr(8), rdr(9), rdr(10), rdr(11), rdr(12), rdr(13), rdr(14), rdr(15), rdr(16), rdr(17), rdr(18), rdr(19), rdr(20), rdr(21), rdr(22), rdr(23), rdr(24))
                End While
                con.Close()
            Catch ex As Exception
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
            Exit Sub
        End If
        If cbooption1.Text = "Registration No" And cbooption2.Text = "Start With" And txtvalue.Text <> "" And cbogender.Text = "FEMALE" And cbodepartment.Text = "UPPER PRIMARY" Then
            Try
                If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                ConnectionModule.con.Open()
                Dim cmd = New SqlCommand("SELECT RTRIM(ID),RTRIM(RegistrationNumber),RTRIM(FirstName), RTRIM(MiddleName), RTRIM(LastName), RTRIM(DOB),RTRIM(Age),RTRIM(Department),RTRIM(Class),RTRIM(Region),RTRIM(District),RTRIM(Nationality),RTRIM(HouseAddress),RTRIM(ContactName),RTRIM(ContactNumber),RTRIM(ContactAddress),RTRIM(ContactOccupation),RTRIM(ContactRelation),RTRIM(ContactEmail),RTRIM(ContactWorkNo),RTRIM(Gender),RTRIM(Title),RTRIM(Hometown),RTRIM(RegistrationDate),RTRIM(Religion) from Students where RegistrationNumber like '[" & txtvalue.Text & "]%' and Gender='FEMALE' and Department='UPPER PRIMARY' order by RegistrationNumber ASC", ConnectionModule.con)
                Dim rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection)
                dgv.Rows.Clear()
                While (rdr.Read() = True)
                    dgv.Rows.Add(rdr(0), rdr(1), rdr(2), rdr(3) + "  " + rdr(4), rdr(5), rdr(6), rdr(7), rdr(8), rdr(9), rdr(10), rdr(11), rdr(12), rdr(13), rdr(14), rdr(15), rdr(16), rdr(17), rdr(18), rdr(19), rdr(20), rdr(21), rdr(22), rdr(23), rdr(24))
                End While
                con.Close()
            Catch ex As Exception
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
            Exit Sub
        End If
        If cbooption1.Text = "Registration No" And cbooption2.Text = "Start With" And txtvalue.Text <> "" And cbogender.Text = "FEMALE" And cbodepartment.Text = "JUNIOR HIGH SCHOOL" Then
            Try
                If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                ConnectionModule.con.Open()
                Dim cmd = New SqlCommand("SELECT RTRIM(ID),RTRIM(RegistrationNumber),RTRIM(FirstName), RTRIM(MiddleName), RTRIM(LastName), RTRIM(DOB),RTRIM(Age),RTRIM(Department),RTRIM(Class),RTRIM(Region),RTRIM(District),RTRIM(Nationality),RTRIM(HouseAddress),RTRIM(ContactName),RTRIM(ContactNumber),RTRIM(ContactAddress),RTRIM(ContactOccupation),RTRIM(ContactRelation),RTRIM(ContactEmail),RTRIM(ContactWorkNo),RTRIM(Gender),RTRIM(Title),RTRIM(Hometown),RTRIM(RegistrationDate),RTRIM(Religion) from Students where RegistrationNumber like '[" & txtvalue.Text & "]%' and Gender='FEMALE' and Department='JUNIOR HIGH SCHOOL' order by RegistrationNumber ASC", ConnectionModule.con)
                Dim rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection)
                dgv.Rows.Clear()
                While (rdr.Read() = True)
                    dgv.Rows.Add(rdr(0), rdr(1), rdr(2), rdr(3) + "  " + rdr(4), rdr(5), rdr(6), rdr(7), rdr(8), rdr(9), rdr(10), rdr(11), rdr(12), rdr(13), rdr(14), rdr(15), rdr(16), rdr(17), rdr(18), rdr(19), rdr(20), rdr(21), rdr(22), rdr(23), rdr(24))
                End While
                con.Close()
            Catch ex As Exception
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
            Exit Sub
        End If
        If cbooption1.Text = "Registration No" And cbooption2.Text = "Start With" And txtvalue.Text <> "" And cbogender.Text = "MALE" And cbodepartment.Text = "KINDERGARTEN" Then
            Try
                If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                ConnectionModule.con.Open()
                Dim cmd = New SqlCommand("SELECT RTRIM(ID),RTRIM(RegistrationNumber),RTRIM(FirstName), RTRIM(MiddleName), RTRIM(LastName), RTRIM(DOB),RTRIM(Age),RTRIM(Department),RTRIM(Class),RTRIM(Region),RTRIM(District),RTRIM(Nationality),RTRIM(HouseAddress),RTRIM(ContactName),RTRIM(ContactNumber),RTRIM(ContactAddress),RTRIM(ContactOccupation),RTRIM(ContactRelation),RTRIM(ContactEmail),RTRIM(ContactWorkNo),RTRIM(Gender),RTRIM(Title),RTRIM(Hometown),RTRIM(RegistrationDate),RTRIM(Religion) from Students where RegistrationNumber like '[" & txtvalue.Text & "]%' and Gender='MALE' and Department='KINDERGARTEN' order by RegistrationNumber ASC", ConnectionModule.con)
                Dim rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection)
                dgv.Rows.Clear()
                While (rdr.Read() = True)
                    dgv.Rows.Add(rdr(0), rdr(1), rdr(2), rdr(3) + "  " + rdr(4), rdr(5), rdr(6), rdr(7), rdr(8), rdr(9), rdr(10), rdr(11), rdr(12), rdr(13), rdr(14), rdr(15), rdr(16), rdr(17), rdr(18), rdr(19), rdr(20), rdr(21), rdr(22), rdr(23), rdr(24))
                End While
                con.Close()
            Catch ex As Exception
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
            Exit Sub
        End If
        If cbooption1.Text = "Registration No" And cbooption2.Text = "Start With" And txtvalue.Text <> "" And cbogender.Text = "MALE" And cbodepartment.Text = "LOWER PRIMARY" Then
            Try
                If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                ConnectionModule.con.Open()
                Dim cmd = New SqlCommand("SELECT RTRIM(ID),RTRIM(RegistrationNumber),RTRIM(FirstName), RTRIM(MiddleName), RTRIM(LastName), RTRIM(DOB),RTRIM(Age),RTRIM(Department),RTRIM(Class),RTRIM(Region),RTRIM(District),RTRIM(Nationality),RTRIM(HouseAddress),RTRIM(ContactName),RTRIM(ContactNumber),RTRIM(ContactAddress),RTRIM(ContactOccupation),RTRIM(ContactRelation),RTRIM(ContactEmail),RTRIM(ContactWorkNo),RTRIM(Gender),RTRIM(Title),RTRIM(Hometown),RTRIM(RegistrationDate),RTRIM(Religion) from Students where RegistrationNumber like '[" & txtvalue.Text & "]%' and Gender='MALE' and Department='LOWER PRIMARY' order by RegistrationNumber ASC", ConnectionModule.con)
                Dim rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection)
                dgv.Rows.Clear()
                While (rdr.Read() = True)
                    dgv.Rows.Add(rdr(0), rdr(1), rdr(2), rdr(3) + "  " + rdr(4), rdr(5), rdr(6), rdr(7), rdr(8), rdr(9), rdr(10), rdr(11), rdr(12), rdr(13), rdr(14), rdr(15), rdr(16), rdr(17), rdr(18), rdr(19), rdr(20), rdr(21), rdr(22), rdr(23), rdr(24))
                End While
                con.Close()
            Catch ex As Exception
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
            Exit Sub
        End If
        If cbooption1.Text = "Registration No" And cbooption2.Text = "Start With" And txtvalue.Text <> "" And cbogender.Text = "MALE" And cbodepartment.Text = "UPPER PRIMARY" Then
            Try
                If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                ConnectionModule.con.Open()
                Dim cmd = New SqlCommand("SELECT RTRIM(ID),RTRIM(RegistrationNumber),RTRIM(FirstName), RTRIM(MiddleName), RTRIM(LastName), RTRIM(DOB),RTRIM(Age),RTRIM(Department),RTRIM(Class),RTRIM(Region),RTRIM(District),RTRIM(Nationality),RTRIM(HouseAddress),RTRIM(ContactName),RTRIM(ContactNumber),RTRIM(ContactAddress),RTRIM(ContactOccupation),RTRIM(ContactRelation),RTRIM(ContactEmail),RTRIM(ContactWorkNo),RTRIM(Gender),RTRIM(Title),RTRIM(Hometown),RTRIM(RegistrationDate),RTRIM(Religion) from Students where RegistrationNumber like '[" & txtvalue.Text & "]%' and Gender='MALE' and Department='UPPER PRIMARY' order by RegistrationNumber ASC", ConnectionModule.con)
                Dim rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection)
                dgv.Rows.Clear()
                While (rdr.Read() = True)
                    dgv.Rows.Add(rdr(0), rdr(1), rdr(2), rdr(3) + "  " + rdr(4), rdr(5), rdr(6), rdr(7), rdr(8), rdr(9), rdr(10), rdr(11), rdr(12), rdr(13), rdr(14), rdr(15), rdr(16), rdr(17), rdr(18), rdr(19), rdr(20), rdr(21), rdr(22), rdr(23), rdr(24))
                End While
                con.Close()
            Catch ex As Exception
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
            Exit Sub
        End If
        If cbooption1.Text = "Registration No" And cbooption2.Text = "Start With" And txtvalue.Text <> "" And cbogender.Text = "MALE" And cbodepartment.Text = "JUNIOR HIGH SCHOOL" Then
            Try
                If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                ConnectionModule.con.Open()
                Dim cmd = New SqlCommand("SELECT RTRIM(ID),RTRIM(RegistrationNumber),RTRIM(FirstName), RTRIM(MiddleName), RTRIM(LastName), RTRIM(DOB),RTRIM(Age),RTRIM(Department),RTRIM(Class),RTRIM(Region),RTRIM(District),RTRIM(Nationality),RTRIM(HouseAddress),RTRIM(ContactName),RTRIM(ContactNumber),RTRIM(ContactAddress),RTRIM(ContactOccupation),RTRIM(ContactRelation),RTRIM(ContactEmail),RTRIM(ContactWorkNo),RTRIM(Gender),RTRIM(Title),RTRIM(Hometown),RTRIM(RegistrationDate),RTRIM(Religion) from Students where RegistrationNumber like '[" & txtvalue.Text & "]%' and Gender='MALE' and Department='JUNIOR HIGH SCHOOL' order by RegistrationNumber ASC", ConnectionModule.con)
                Dim rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection)
                dgv.Rows.Clear()
                While (rdr.Read() = True)
                    dgv.Rows.Add(rdr(0), rdr(1), rdr(2), rdr(3) + "  " + rdr(4), rdr(5), rdr(6), rdr(7), rdr(8), rdr(9), rdr(10), rdr(11), rdr(12), rdr(13), rdr(14), rdr(15), rdr(16), rdr(17), rdr(18), rdr(19), rdr(20), rdr(21), rdr(22), rdr(23), rdr(24))
                End While
                con.Close()
            Catch ex As Exception
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If

        'another search criteria by endwith
        If cbooption1.Text = "Registration No" And cbooption2.Text = "End With" And txtvalue.Text <> "" And cbogender.Text = "FEMALE" Then
            Try
                If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                ConnectionModule.con.Open()
                Dim cmd = New SqlCommand("SELECT RTRIM(ID),RTRIM(RegistrationNumber),RTRIM(FirstName), RTRIM(MiddleName), RTRIM(LastName), RTRIM(DOB),RTRIM(Age),RTRIM(Department),RTRIM(Class),RTRIM(Region),RTRIM(District),RTRIM(Nationality),RTRIM(HouseAddress),RTRIM(ContactName),RTRIM(ContactNumber),RTRIM(ContactAddress),RTRIM(ContactOccupation),RTRIM(ContactRelation),RTRIM(ContactEmail),RTRIM(ContactWorkNo),RTRIM(Gender),RTRIM(Title),RTRIM(Hometown),RTRIM(RegistrationDate),RTRIM(Religion) from Students where RegistrationNumber like 'm______" & txtvalue.Text & "' and Gender='FEMALE' order by RegistrationNumber ASC", ConnectionModule.con)
                Dim rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection)
                dgv.Rows.Clear()
                While (rdr.Read() = True)
                    dgv.Rows.Add(rdr(0), rdr(1), rdr(2), rdr(3) + "  " + rdr(4), rdr(5), rdr(6), rdr(7), rdr(8), rdr(9), rdr(10), rdr(11), rdr(12), rdr(13), rdr(14), rdr(15), rdr(16), rdr(17), rdr(18), rdr(19), rdr(20), rdr(21), rdr(22), rdr(23), rdr(24))
                End While
                con.Close()
            Catch ex As Exception
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
            Exit Sub
        ElseIf cbooption1.Text = "Registration No" And cbooption2.Text = "End With" And txtvalue.Text <> "" And cbogender.Text = "MALE" Then
            Try
                If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                ConnectionModule.con.Open()
                Dim cmd = New SqlCommand("SELECT RTRIM(ID),RTRIM(RegistrationNumber),RTRIM(FirstName), RTRIM(MiddleName), RTRIM(LastName), RTRIM(DOB),RTRIM(Age),RTRIM(Department),RTRIM(Class),RTRIM(Region),RTRIM(District),RTRIM(Nationality),RTRIM(HouseAddress),RTRIM(ContactName),RTRIM(ContactNumber),RTRIM(ContactAddress),RTRIM(ContactOccupation),RTRIM(ContactRelation),RTRIM(ContactEmail),RTRIM(ContactWorkNo),RTRIM(Gender),RTRIM(Title),RTRIM(Hometown),RTRIM(RegistrationDate),RTRIM(Religion) from Students where RegistrationNumber like 'm______" & txtvalue.Text & "' and Gender='MALE' order by RegistrationNumber ASC", ConnectionModule.con)
                Dim rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection)
                dgv.Rows.Clear()
                While (rdr.Read() = True)
                    dgv.Rows.Add(rdr(0), rdr(1), rdr(2), rdr(3) + "  " + rdr(4), rdr(5), rdr(6), rdr(7), rdr(8), rdr(9), rdr(10), rdr(11), rdr(12), rdr(13), rdr(14), rdr(15), rdr(16), rdr(17), rdr(18), rdr(19), rdr(20), rdr(21), rdr(22), rdr(23), rdr(24))
                End While
                con.Close()
            Catch ex As Exception
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
            Exit Sub
        End If
        'another search method - firstname
        If cbooption1.Text = "First Name" And cbooption2.Text = "Contains" And txtvalue.Text <> "" Then
            Try
                If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                ConnectionModule.con.Open()
                Dim cmd = New SqlCommand("SELECT RTRIM(ID),RTRIM(RegistrationNumber),RTRIM(FirstName), RTRIM(MiddleName), RTRIM(LastName), RTRIM(DOB),RTRIM(Age),RTRIM(Department),RTRIM(Class),RTRIM(Region),RTRIM(District),RTRIM(Nationality),RTRIM(HouseAddress),RTRIM(ContactName),RTRIM(ContactNumber),RTRIM(ContactAddress),RTRIM(ContactOccupation),RTRIM(ContactRelation),RTRIM(ContactEmail),RTRIM(ContactWorkNo),RTRIM(Gender),RTRIM(Title),RTRIM(Hometown),RTRIM(RegistrationDate),RTRIM(Religion) from Students where FirstName like '%" & txtvalue.Text & "%' order by ID ASC", ConnectionModule.con)
                Dim rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection)
                dgv.Rows.Clear()
                While (rdr.Read() = True)
                    dgv.Rows.Add(rdr(0), rdr(1), rdr(2), rdr(3) + "  " + rdr(4), rdr(5), rdr(6), rdr(7), rdr(8), rdr(9), rdr(10), rdr(11), rdr(12), rdr(13), rdr(14), rdr(15), rdr(16), rdr(17), rdr(18), rdr(19), rdr(20), rdr(21), rdr(22), rdr(23), rdr(24))
                End While
                con.Close()
            Catch ex As Exception
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
            Exit Sub
        ElseIf cbooption1.Text = "First Name" And cbooption2.Text = "Equals" And txtvalue.Text <> "" Then
            Try
                If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                ConnectionModule.con.Open()
                Dim cmd = New SqlCommand("SELECT RTRIM(ID),RTRIM(RegistrationNumber),RTRIM(FirstName), RTRIM(MiddleName), RTRIM(LastName), RTRIM(DOB),RTRIM(Age),RTRIM(Department),RTRIM(Class),RTRIM(Region),RTRIM(District),RTRIM(Nationality),RTRIM(HouseAddress),RTRIM(ContactName),RTRIM(ContactNumber),RTRIM(ContactAddress),RTRIM(ContactOccupation),RTRIM(ContactRelation),RTRIM(ContactEmail),RTRIM(ContactWorkNo),RTRIM(Gender),RTRIM(Title),RTRIM(Hometown),RTRIM(RegistrationDate),RTRIM(Religion) from Students where FirstName='" & txtvalue.Text & "' order by ID ASC", ConnectionModule.con)
                Dim rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection)
                dgv.Rows.Clear()
                While (rdr.Read() = True)
                    dgv.Rows.Add(rdr(0), rdr(1), rdr(2), rdr(3) + "  " + rdr(4), rdr(5), rdr(6), rdr(7), rdr(8), rdr(9), rdr(10), rdr(11), rdr(12), rdr(13), rdr(14), rdr(15), rdr(16), rdr(17), rdr(18), rdr(19), rdr(20), rdr(21), rdr(22), rdr(23), rdr(24))
                End While
                con.Close()
            Catch ex As Exception
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
            Exit Sub
        ElseIf cbooption1.Text = "First Name" And cbooption2.Text = "Start With" And txtvalue.Text <> "" Then
            Try
                If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                ConnectionModule.con.Open()
                com1 = New SqlCommand("SELECT RTRIM(ID),RTRIM(RegistrationNumber),RTRIM(FirstName), RTRIM(MiddleName), RTRIM(LastName), RTRIM(DOB),RTRIM(Age),RTRIM(Department),RTRIM(Class),RTRIM(Region),RTRIM(District),RTRIM(Nationality),RTRIM(HouseAddress),RTRIM(ContactName),RTRIM(ContactNumber),RTRIM(ContactAddress),RTRIM(ContactOccupation),RTRIM(ContactRelation),RTRIM(ContactEmail),RTRIM(ContactWorkNo),RTRIM(Gender),RTRIM(Title),RTRIM(Hometown),RTRIM(RegistrationDate),RTRIM(Religion) from Students where FirstName like '[" & txtvalue.Text & "]%' order by FirstName ASC", ConnectionModule.con)
                dr = com1.ExecuteReader(CommandBehavior.CloseConnection)
                dgv.Rows.Clear()
                If dr.HasRows = True Then
                    While (dr.Read() = True)
                        dgv.Rows.Add(dr(0), dr(1), dr(2), dr(3) + "  " + dr(4), dr(5), dr(6), dr(7), dr(8), dr(9), dr(10), dr(11), dr(12), dr(13), dr(14), dr(15), dr(16), dr(17), dr(18), dr(19), dr(20), dr(21), dr(22), dr(23), dr(24))
                    End While
                    dr.Close()
                Else
                    MsgBox("No record or data was found for your search criteria..", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Error")
                End If
                con.Close()
            Catch ex As Exception
                MessageBox.Show(ex.ToString(), "error at regno_start with_letter")
            End Try
            Exit Sub
        ElseIf cbooption1.Text = "Surname" And cbooption2.Text = "Start With" And txtvalue.Text <> "" Then
            Try
                If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                ConnectionModule.con.Open()
                com1 = New SqlCommand("SELECT RTRIM(ID),RTRIM(RegistrationNumber),RTRIM(FirstName), RTRIM(MiddleName), RTRIM(LastName), RTRIM(DOB),RTRIM(Age),RTRIM(Department),RTRIM(Class),RTRIM(Region),RTRIM(District),RTRIM(Nationality),RTRIM(HouseAddress),RTRIM(ContactName),RTRIM(ContactNumber),RTRIM(ContactAddress),RTRIM(ContactOccupation),RTRIM(ContactRelation),RTRIM(ContactEmail),RTRIM(ContactWorkNo),RTRIM(Gender),RTRIM(Title),RTRIM(Hometown),RTRIM(RegistrationDate),RTRIM(Religion) from Students where LastName like '[" & txtvalue.Text & "]%' order by FirstName ASC", ConnectionModule.con)
                dr = com1.ExecuteReader(CommandBehavior.CloseConnection)
                dgv.Rows.Clear()
                If dr.HasRows = True Then
                    While (dr.Read() = True)
                        dgv.Rows.Add(dr(0), dr(1), dr(2), dr(3) + "  " + dr(4), dr(5), dr(6), dr(7), dr(8), dr(9), dr(10), dr(11), dr(12), dr(13), dr(14), dr(15), dr(16), dr(17), dr(18), dr(19), dr(20), dr(21), dr(22), dr(23), dr(24))
                    End While
                    dr.Close()
                Else
                    MsgBox("No record or data was found for your search criteria..", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Error")
                End If
                con.Close()
            Catch ex As Exception
                MessageBox.Show(ex.ToString(), "error at regno_start with_letter")
            End Try
            Exit Sub
        ElseIf cbooption1.Text = "Surname" And cbooption2.Text = "Contains" And txtvalue.Text <> "" Then
            Try
                If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                ConnectionModule.con.Open()
                Dim cmd = New SqlCommand("SELECT RTRIM(ID),RTRIM(RegistrationNumber),RTRIM(FirstName), RTRIM(MiddleName), RTRIM(LastName), RTRIM(DOB),RTRIM(Age),RTRIM(Department),RTRIM(Class),RTRIM(Region),RTRIM(District),RTRIM(Nationality),RTRIM(HouseAddress),RTRIM(ContactName),RTRIM(ContactNumber),RTRIM(ContactAddress),RTRIM(ContactOccupation),RTRIM(ContactRelation),RTRIM(ContactEmail),RTRIM(ContactWorkNo),RTRIM(Gender),RTRIM(Title),RTRIM(Hometown),RTRIM(RegistrationDate),RTRIM(Religion) from Students where LastName like '%" & txtvalue.Text & "%' order by ID ASC", ConnectionModule.con)
                Dim rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection)
                dgv.Rows.Clear()
                While (rdr.Read() = True)
                    dgv.Rows.Add(rdr(0), rdr(1), rdr(2), rdr(3) + "  " + rdr(4), rdr(5), rdr(6), rdr(7), rdr(8), rdr(9), rdr(10), rdr(11), rdr(12), rdr(13), rdr(14), rdr(15), rdr(16), rdr(17), rdr(18), rdr(19), rdr(20), rdr(21), rdr(22), rdr(23), rdr(24))
                End While
                con.Close()
            Catch ex As Exception
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
            Exit Sub
        ElseIf cbooption1.Text = "Surname" And cbooption2.Text = "Equals" And txtvalue.Text <> "" Then
            Try
                If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                ConnectionModule.con.Open()
                Dim cmd = New SqlCommand("SELECT RTRIM(ID),RTRIM(RegistrationNumber),RTRIM(FirstName), RTRIM(MiddleName), RTRIM(LastName), RTRIM(DOB),RTRIM(Age),RTRIM(Department),RTRIM(Class),RTRIM(Region),RTRIM(District),RTRIM(Nationality),RTRIM(HouseAddress),RTRIM(ContactName),RTRIM(ContactNumber),RTRIM(ContactAddress),RTRIM(ContactOccupation),RTRIM(ContactRelation),RTRIM(ContactEmail),RTRIM(ContactWorkNo),RTRIM(Gender),RTRIM(Title),RTRIM(Hometown),RTRIM(RegistrationDate),RTRIM(Religion) from Students where LastName='" & txtvalue.Text & "' order by ID ASC", ConnectionModule.con)
                Dim rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection)
                dgv.Rows.Clear()
                While (rdr.Read() = True)
                    dgv.Rows.Add(rdr(0), rdr(1), rdr(2), rdr(3) + "  " + rdr(4), rdr(5), rdr(6), rdr(7), rdr(8), rdr(9), rdr(10), rdr(11), rdr(12), rdr(13), rdr(14), rdr(15), rdr(16), rdr(17), rdr(18), rdr(19), rdr(20), rdr(21), rdr(22), rdr(23), rdr(24))
                End While
                con.Close()
            Catch ex As Exception
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
            Exit Sub
        End If
        'search only by gender
        If cbogender.Text = "FEMALE" Then
            Try
                If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                ConnectionModule.con.Open()
                Dim cmd = New SqlCommand("SELECT RTRIM(ID),RTRIM(RegistrationNumber),RTRIM(FirstName), RTRIM(MiddleName), RTRIM(LastName), RTRIM(DOB),RTRIM(Age),RTRIM(Department),RTRIM(Class),RTRIM(Region),RTRIM(District),RTRIM(Nationality),RTRIM(HouseAddress),RTRIM(ContactName),RTRIM(ContactNumber),RTRIM(ContactAddress),RTRIM(ContactOccupation),RTRIM(ContactRelation),RTRIM(ContactEmail),RTRIM(ContactWorkNo),RTRIM(Gender),RTRIM(Title),RTRIM(Hometown),RTRIM(RegistrationDate),RTRIM(Religion) from Students where Gender='FEMALE' order by ID ASC", ConnectionModule.con)
                Dim rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection)
                dgv.Rows.Clear()
                While (rdr.Read() = True)
                    dgv.Rows.Add(rdr(0), rdr(1), rdr(2), rdr(3) + "  " + rdr(4), rdr(5), rdr(6), rdr(7), rdr(8), rdr(9), rdr(10), rdr(11), rdr(12), rdr(13), rdr(14), rdr(15), rdr(16), rdr(17), rdr(18), rdr(19), rdr(20), rdr(21), rdr(22), rdr(23), rdr(24))
                End While
                con.Close()
            Catch ex As Exception
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
            Exit Sub
        ElseIf cbogender.Text = "MALE" Then
            Try
                If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                ConnectionModule.con.Open()
                Dim cmd = New SqlCommand("SELECT RTRIM(ID),RTRIM(RegistrationNumber),RTRIM(FirstName), RTRIM(MiddleName), RTRIM(LastName), RTRIM(DOB),RTRIM(Age),RTRIM(Department),RTRIM(Class),RTRIM(Region),RTRIM(District),RTRIM(Nationality),RTRIM(HouseAddress),RTRIM(ContactName),RTRIM(ContactNumber),RTRIM(ContactAddress),RTRIM(ContactOccupation),RTRIM(ContactRelation),RTRIM(ContactEmail),RTRIM(ContactWorkNo),RTRIM(Gender),RTRIM(Title),RTRIM(Hometown),RTRIM(RegistrationDate),RTRIM(Religion) from Students where Gender='MALE' order by ID ASC", ConnectionModule.con)
                Dim rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection)
                dgv.Rows.Clear()
                While (rdr.Read() = True)
                    dgv.Rows.Add(rdr(0), rdr(1), rdr(2), rdr(3) + "  " + rdr(4), rdr(5), rdr(6), rdr(7), rdr(8), rdr(9), rdr(10), rdr(11), rdr(12), rdr(13), rdr(14), rdr(15), rdr(16), rdr(17), rdr(18), rdr(19), rdr(20), rdr(21), rdr(22), rdr(23), rdr(24))
                End While
                con.Close()
            Catch ex As Exception
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
            Exit Sub
            'Else
            'MsgBox("The search details provided does not match any student record", MsgBoxStyle.OkOnly + MsgBoxStyle.Information, "SIMS - Error")
        End If

    End Sub

    Sub ClearAll()
        cbooption1.ResetText()
        cbooption2.ResetText()
        cbogender.ResetText()
        cbodepartment.ResetText()
        cboclass.ResetText()
        txtvalue.Clear()
        cboReligion.ResetText()
        dgv.Rows.Clear()
    End Sub
    Private Sub AdvancedSearch_FormClosed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed
        ClearAll()
    End Sub

    Private Sub btnclearsearch_Click(sender As Object, e As EventArgs) Handles btnclearsearch.Click
        ClearAll()
    End Sub

    Private Sub cbogender_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbogender.SelectedIndexChanged, cboReligion.SelectedIndexChanged
        ''btnclearsearch_Click(sender, e)
    End Sub

    Private Sub cbodepartment_DropDown(sender As Object, e As EventArgs) Handles cbodepartment.DropDown
        GetDeptList()
    End Sub

    Private Sub cbodepartment_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbodepartment.SelectedIndexChanged
        '' btnclearsearch_Click(sender, e)

    End Sub

    Private Sub cboclass_DropDown(sender As Object, e As EventArgs) Handles cboclass.DropDown
        ClassListJhs()
    End Sub

    Private Sub cboclass_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboclass.SelectedIndexChanged
        '' btnclearsearch_Click(sender, e)
    End Sub


   
    Private Sub GroupBox1_Enter(sender As Object, e As EventArgs) Handles GroupBox1.Enter

    End Sub
End Class