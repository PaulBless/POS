﻿Public Class Receipt

    Private Sub Label13_Click(sender As Object, e As EventArgs) Handles lblFeeType.Click

    End Sub

    Private Sub Label8_Click(sender As Object, e As EventArgs) Handles lblTerm.Click, Label18.Click

    End Sub
End Class