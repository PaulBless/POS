﻿Public Class EmployeeInfoSheet

    Private Sub GroupBox2_Enter(sender As Object, e As EventArgs)

    End Sub

    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs) Handles Panel1.Paint, Panel2.Paint, Panel4.Paint, Panel3.Paint, Panel5.Paint, Panel6.Paint

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click, Label3.Click, Label4.Click

    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click, Button1.Click, Button5.Click, Button4.Click, Button3.Click, Button2.Click, Button6.Click

    End Sub

    Private Sub MemberInfoSheet_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class