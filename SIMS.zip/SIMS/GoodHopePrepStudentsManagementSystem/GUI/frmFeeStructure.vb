﻿Imports System.Data.SqlClient

Public Class frmFeeStructure

    Private Sub Reset()
        txtAmt.Clear()
        cboClass.ResetText()
        cboTerm.ResetText()
        cboYear.ResetText()
        GetFees1()
    End Sub
    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        Reset()
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub

    Sub AddFees()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            com = New SqlCommand("insert into Fees1 (Year,Term,Class,Amount) values (@d1,@d2,@d3,@d4)", ConnectionModule.con)
            com.Parameters.AddWithValue("@d1", cboYear.Text)
            com.Parameters.AddWithValue("@d2", cboTerm.Text)
            com.Parameters.AddWithValue("@d3", cboClass.Text)
            com.Parameters.AddWithValue("@d4", txtAmt.Text)
            com.ExecuteNonQuery()
            MsgBox("Fees Saved Successfully", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "SIMS - Success")
            GetFees1()
            Reset()
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "at add fees")
            con.Close()
        End Try
    End Sub
    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        If Len(Trim(cboYear.Text)) = 0 Then
            MessageBox.Show("Please select academic year", "SIMS", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            cboClass.Focus()
            Exit Sub
        End If
        If Len(Trim(cboTerm.Text)) = 0 Then
            MessageBox.Show("Please select term", "SIMS", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            cboTerm.Focus()
            Exit Sub
        End If
        If Len(Trim(cboClass.Text)) = 0 Then
            MessageBox.Show("Please select specific class", "SIMS", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            cboClass.Focus()
            Exit Sub
        End If
        If Len(Trim(txtAmt.Text)) = 0 Then
            MessageBox.Show("Please enter fee amount", "", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtAmt.Focus()
            Exit Sub
        End If

        If MsgBox("Add fees to School Fees List Structure, Are you sure?", MsgBoxStyle.YesNo + MsgBoxStyle.Question, "SIMS") = DialogResult.Yes Then
            Try
                If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                ConnectionModule.con.Open()
                com = New SqlCommand("select * from Fees1 where Year='" & cboYear.Text & "' and Term='" & cboTerm.Text & "' and Class='" & cboClass.Text & "'", con)
                dr = com.ExecuteReader(CommandBehavior.CloseConnection)
                If Not dr.Read() Then
                    AddFees()
                Else
                    MsgBox("Sorry!, The Fees you want to add already Exists in the Fees List Structure. You can change or edit the fees amount by clicking on the 'Update' button. Thank you", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "SIMS")
                    dr.Close()

                End If

            Catch ex As Exception
                MessageBox.Show(ex.Message)
                con.Close()
            End Try
        End If

    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        'If Len(Trim(cboClass.Text)) = 0 Then
        '    MessageBox.Show("Please select class", "SIMS", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        '    cboClass.Focus()
        '    Exit Sub
        'End If
        'If Len(Trim(cboTerm.Text)) = 0 Then
        '    MessageBox.Show("Please select Fee type/name", "SIMS", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        '    cboTerm.Focus()
        '    Exit Sub
        'End If
        'If Len(Trim(txtAmt.Text)) = 0 Then
        '    MessageBox.Show("Please enter fee amount", "", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        '    txtAmt.Focus()
        '    Exit Sub
        'End If

        If txtAmt.Text = "" Or cboClass.Text = "" Then MsgBox("Please select the fees that you want to update from the gridview", MsgBoxStyle.OkOnly + MsgBoxStyle.Exclamation, "SIMS") : Exit Sub
        If MsgBox("Add fees to School Fees List Structure, Are you sure?", MsgBoxStyle.YesNo + MsgBoxStyle.Question, "SIMS") = DialogResult.Yes Then
            Try
                If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                ConnectionModule.con.Open()
                com = New SqlCommand("update Fees1 set Year=@d1, Term=@d2, Class=@d3, Amount=@d4 where ID='" & dgv.SelectedRows(0).Cells(0).Value & "'", ConnectionModule.con)
                com.Parameters.AddWithValue("@d1", cboYear.Text)
                com.Parameters.AddWithValue("@d2", cboTerm.Text)
                com.Parameters.AddWithValue("@d3", cboClass.Text)
                com.Parameters.AddWithValue("@d4", Val(txtAmt.Text))
                com.ExecuteNonQuery()
                MsgBox("Fees Updated Successfully", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "SIMS - Success")
                GetFees1()
                btnClear_Click(sender, e)

            Catch ex As Exception
                MessageBox.Show(ex.Message)
                con.Close()
            End Try
        End If

    End Sub

    Private Sub GetFees()
        'If Len(Trim(cboClass.Text)) = 0 Then
        '    MessageBox.Show("Please select class", "SIMS", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        '    cboClass.Focus()
        '    Exit Sub
        'End If
        'If Len(Trim(cboTerm.Text)) = 0 Then
        '    MessageBox.Show("Please select feename", "SIMS", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        '    cboTerm.Focus()
        '    Exit Sub
        'End If

        'Try
        '    If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
        '    ConnectionModule.con.Open()
        '    com = New SqlCommand("select * from Fees where Class='" & Me.cboClass.Text & "' and FeeName='" & Me.cboTerm.Text & "'", ConnectionModule.con)
        '    dr = com.ExecuteReader(CommandBehavior.CloseConnection)
        '    'While (dr.Read() = True)
        '    '    txtAmt.Text = dr.GetValue(3)
        '    'End While
        '    If dr.Read() Then
        '        txtAmt.Text = dr.GetValue(3)
        '        dr.Close()
        '    Else
        '        MsgBox("No specified  fee amount for Class: '" + cboClass.Text + "' And Fee Type: '" + cboTerm.Text + "' was found in the List of Fees Structure", MsgBoxStyle.OkOnly + MsgBoxStyle.Critical, "SIMS-Error")
        '        cboClass.SelectAll()
        '        cboTerm.SelectAll()
        '        Exit Sub

        '    End If
        'Catch ex As Exception
        '    MessageBox.Show(ex.Message)
        '    con.Close()
        'End Try

    End Sub

    Sub GetFees1()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            com = New SqlCommand("select ID,Year,Term,Class,Amount from Fees1 order by ID", ConnectionModule.con)
            dr = com.ExecuteReader(CommandBehavior.CloseConnection)
            dgv.Rows.Clear()
            If dr.HasRows() Then
                While dr.Read()
                    dgv.Rows.Add(dr(0), dr(1), dr(2), dr(3), dr(4))
                End While
                dr.Close()
            Else
                MsgBox("No specified record or information was found in the List of Fees Structure" + vbCrLf + "You are required to add fees for specific academic year, term and classes", MsgBoxStyle.OkOnly + MsgBoxStyle.Critical, "SIMS-Error")
                Exit Sub

            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message)
            con.Close()
        End Try
    End Sub

    Private Sub btnGetFee_Click(sender As Object, e As EventArgs) Handles btnGetFee.Click
       'new get fees code
        '  If dgv.Rows.Count > 0 Then MsgBox("Fees information already populated into grid", MsgBoxStyle.OkOnly + MsgBoxStyle.Information, "SIMS") : Exit Sub
        If txtAmt.Text <> "" And cboYear.Text <> "" And cboTerm.Text <> "" Then
            Reset()
            Exit Sub
        End If

        GetFees1()
     
    End Sub

    Private Sub frmFeeStructure_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub GroupBox2_Enter(sender As Object, e As EventArgs) Handles GroupBox2.Enter

    End Sub

    Public Sub AddAcademicYear()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            dset = New Data.DataSet()
            adapter = New SqlDataAdapter()
            adapter.SelectCommand = New SqlCommand("select ID,New from AcademicYear order by New", ConnectionModule.con)
            dset.Clear()
            adapter.Fill(dset, "AcademicYear")
            cboYear.DataSource = dset.Tables("AcademicYear")
            cboYear.DisplayMember = "New"
            cboYear.ValueMember = "ID"
            cboYear.Refresh()
            cboYear.SelectedIndex = -1
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at add academic info")
            con.Close()
        End Try
    End Sub

    Public Sub AddTerm()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            dset = New Data.DataSet()
            adapter = New SqlDataAdapter()
            adapter.SelectCommand = New SqlCommand("select ID,Term from Term order by Term", ConnectionModule.con)
            dset.Clear()
            adapter.Fill(dset, "Term")
            cboTerm.DataSource = dset.Tables("Term")
            cboTerm.DisplayMember = "Term"
            cboTerm.ValueMember = "ID"
            cboTerm.Refresh()
            cboTerm.SelectedIndex = -1
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at add term info")
            con.Close()
        End Try
    End Sub


    Private Sub dgv_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv.CellContentClick
        Try
            cboYear.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(1).Value
            cboTerm.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(2).Value
            cboClass.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(3).Value
            txtAmt.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(4).Value

        Catch ex As Exception

        End Try

    End Sub

    Private Sub cboYear_DragDrop(sender As Object, e As DragEventArgs) Handles cboYear.DragDrop
    End Sub

    Private Sub cboTerm_DropDown(sender As Object, e As EventArgs) Handles cboTerm.DropDown
        AddTerm()
    End Sub

    Private Sub cboYear_DropDown(sender As Object, e As EventArgs) Handles cboYear.DropDown
        AddAcademicYear()
    End Sub

    Private Sub cboYear_DropDownClosed(sender As Object, e As EventArgs) Handles cboYear.DropDownClosed

    End Sub
End Class