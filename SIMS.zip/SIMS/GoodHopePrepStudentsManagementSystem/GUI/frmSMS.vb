﻿Public Class frmSMS

    Private Sub frmSMS_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
    Private Sub NewSMS()
          'Dim client As New WebClient
            'Dim number As String = text1.Text
            'Dim message As String = text2.Text
        'Dim baseUrl As String = "http://api.clickatell.com/http/sendmsg?user=zisan94268&password=OYeNLVUHTNIHbD&api_id=3528011&to='" & number & "'&text='" & message & ""
            'client.OpenRead(baseUrl)
            'MsgBox("message sent..")

        'Try
        '    'sms testing
        '    Const apiurl As String = "http://api.clickatell.com/http/sendmsg?user=zisan94268&password=OYeNLVUHTNIHbD&api_id=3528011&to='"
        '    Dim number As String = text1.Text
        '    Dim mesage As String = text2.Text
        '    SmsFunc(number, mesage, apiurl)

        'Catch ex As Exception
        '    MsgBox(ex.ToString())
        'End Try
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click

    End Sub
End Class