﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AdminSection
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub


    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(AdminSection))
        Me.MenuStrip = New System.Windows.Forms.MenuStrip()
        Me.SystemToolStrip = New System.Windows.Forms.ToolStripMenuItem()
        Me.IDCardGeneratorToolStrip = New System.Windows.Forms.ToolStripMenuItem()
        Me.StudentsIDToolStrip = New System.Windows.Forms.ToolStripMenuItem()
        Me.EmployeeIDToolStrip = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator5 = New System.Windows.Forms.ToolStripSeparator()
        Me.LockToolStrip = New System.Windows.Forms.ToolStripMenuItem()
        Me.LogOffToolStrip = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator9 = New System.Windows.Forms.ToolStripSeparator()
        Me.ExitToolStrip = New System.Windows.Forms.ToolStripMenuItem()
        Me.StudentsToolStrip = New System.Windows.Forms.ToolStripMenuItem()
        Me.NewStudentRegistrationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.StudentAttendanceToolStrip = New System.Windows.Forms.ToolStripMenuItem()
        Me.ManageStudentsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ViewStudentProfileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.SearchStudentToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator7 = New System.Windows.Forms.ToolStripSeparator()
        Me.ManageStudentProfileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AcademicToolStrip = New System.Windows.Forms.ToolStripMenuItem()
        Me.SBAToolStrip = New System.Windows.Forms.ToolStripMenuItem()
        Me.TSAToolStrip = New System.Windows.Forms.ToolStripMenuItem()
        Me.TerminalReportToolStrip = New System.Windows.Forms.ToolStripMenuItem()
        Me.TermlyAssessmentToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GradingSystemToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EmployeeToolStrip = New System.Windows.Forms.ToolStripMenuItem()
        Me.EmployeeRegistration = New System.Windows.Forms.ToolStripMenuItem()
        Me.EmployeeInfoSheet = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.EmployeeDesignation = New System.Windows.Forms.ToolStripMenuItem()
        Me.EmployeeAttendanceRegister = New System.Windows.Forms.ToolStripMenuItem()
        Me.JobProfileMastery = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator11 = New System.Windows.Forms.ToolStripSeparator()
        Me.EmployeeProfileMastery = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator12 = New System.Windows.Forms.ToolStripSeparator()
        Me.EmployeeLeaveApplicationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ApplyForLeaveToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ApproveLeaveToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FinanceToolStrip = New System.Windows.Forms.ToolStripMenuItem()
        Me.PaymentsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SalaryPaymentToolStrip = New System.Windows.Forms.ToolStripMenuItem()
        Me.OtherFeesPaymentsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator6 = New System.Windows.Forms.ToolStripSeparator()
        Me.CheckPaymentsToolStrip = New System.Windows.Forms.ToolStripMenuItem()
        Me.CheckSchFeesPaidToolStrip = New System.Windows.Forms.ToolStripMenuItem()
        Me.CheckOtherFeesPaidToolStrip = New System.Windows.Forms.ToolStripMenuItem()
        Me.BillingToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TerminalBillToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GenerateTerminalBillToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RecordsToolStrip = New System.Windows.Forms.ToolStripMenuItem()
        Me.FeesPaymentRecordTooStrip = New System.Windows.Forms.ToolStripMenuItem()
        Me.SchoolFeesHistoryToolStrip = New System.Windows.Forms.ToolStripMenuItem()
        Me.OtherFeesHistoryToolStrip = New System.Windows.Forms.ToolStripMenuItem()
        Me.SalaryPaymentRecordTooStrip = New System.Windows.Forms.ToolStripMenuItem()
        Me.ReportToolStrip = New System.Windows.Forms.ToolStripMenuItem()
        Me.AcademicRecordsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AccountReportToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.StaffReToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TermlySchoolFeesPaidToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TermlyBusFeesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MonthlyExpenditureOnStaffToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TermlyExpenditureOnStaffToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.YearlyExpenditureOnStaffToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StuudentsArrearsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StudentsReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AllRegisteredStudentsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RegisteredStudentByDepartmentToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ListsOfActiveStudentsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ListsOfInactiveStudentsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ActiveRegisteredStudentsByClassToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator10 = New System.Windows.Forms.ToolStripSeparator()
        Me.StaffReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RegisteredStaffDeptToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RegisteredStaffToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ListOfActiveStaffToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ListOfInactiveStaffToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UtilitiesToolStrip = New System.Windows.Forms.ToolStripMenuItem()
        Me.ChangePasswordToolStrip = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator13 = New System.Windows.Forms.ToolStripSeparator()
        Me.CreateNewUserToolStrip = New System.Windows.Forms.ToolStripMenuItem()
        Me.PasswordRecoveryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UseMaintenanceToolstrip = New System.Windows.Forms.ToolStripMenuItem()
        Me.AccountSettingsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OptionToolStrip = New System.Windows.Forms.ToolStripMenuItem()
        Me.SchoolInfoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SettingsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AcademicYearToolStrip = New System.Windows.Forms.ToolStripMenuItem()
        Me.AttendanceToolStrip = New System.Windows.Forms.ToolStripMenuItem()
        Me.BillSettingsToolStrip = New System.Windows.Forms.ToolStripMenuItem()
        Me.ClassRoomToolStrip = New System.Windows.Forms.ToolStripMenuItem()
        Me.DesignationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FeesToolStrip = New System.Windows.Forms.ToolStripMenuItem()
        Me.GradingSystemToolStrip = New System.Windows.Forms.ToolStripMenuItem()
        Me.SubjectsToolStrip = New System.Windows.Forms.ToolStripMenuItem()
        Me.PaymentModeToolStrip = New System.Windows.Forms.ToolStripMenuItem()
        Me.OtherFeesSettingsToolStrip = New System.Windows.Forms.ToolStripMenuItem()
        Me.AppointmentTypeToolStrip = New System.Windows.Forms.ToolStripMenuItem()
        Me.PortfolioToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ClassTeacherAssignmentToolStrip = New System.Windows.Forms.ToolStripMenuItem()
        Me.SystemSettingsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolsToolStrip = New System.Windows.Forms.ToolStripMenuItem()
        Me.CalculatorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MicrosoftWordToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStrip = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.JecmasSolutionsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolTip = New System.Windows.Forms.ToolTip(Me.components)
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.lblAnimation = New System.Windows.Forms.Label()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.ToolStripStatusLabel2 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lblUserType = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel3 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lblUser = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel4 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lblDateTime = New System.Windows.Forms.ToolStripStatusLabel()
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.MenuStrip.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.StatusStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip
        '
        Me.MenuStrip.BackColor = System.Drawing.SystemColors.Control
        Me.MenuStrip.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MenuStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SystemToolStrip, Me.StudentsToolStrip, Me.AcademicToolStrip, Me.EmployeeToolStrip, Me.FinanceToolStrip, Me.RecordsToolStrip, Me.ReportToolStrip, Me.UtilitiesToolStrip, Me.OptionToolStrip, Me.ToolsToolStrip, Me.HelpToolStrip})
        Me.MenuStrip.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip.Name = "MenuStrip"
        Me.MenuStrip.ShowItemToolTips = True
        Me.MenuStrip.Size = New System.Drawing.Size(1276, 28)
        Me.MenuStrip.TabIndex = 5
        Me.MenuStrip.Text = "MenuStrip"
        '
        'SystemToolStrip
        '
        Me.SystemToolStrip.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.IDCardGeneratorToolStrip, Me.ToolStripSeparator5, Me.LockToolStrip, Me.LogOffToolStrip, Me.ToolStripSeparator9, Me.ExitToolStrip})
        Me.SystemToolStrip.Font = New System.Drawing.Font("Segoe UI Semibold", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SystemToolStrip.Name = "SystemToolStrip"
        Me.SystemToolStrip.Size = New System.Drawing.Size(48, 24)
        Me.SystemToolStrip.Text = "&FILE"
        '
        'IDCardGeneratorToolStrip
        '
        Me.IDCardGeneratorToolStrip.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.StudentsIDToolStrip, Me.EmployeeIDToolStrip})
        Me.IDCardGeneratorToolStrip.Name = "IDCardGeneratorToolStrip"
        Me.IDCardGeneratorToolStrip.Size = New System.Drawing.Size(202, 24)
        Me.IDCardGeneratorToolStrip.Text = "ID Card Generator"
        '
        'StudentsIDToolStrip
        '
        Me.StudentsIDToolStrip.Name = "StudentsIDToolStrip"
        Me.StudentsIDToolStrip.Size = New System.Drawing.Size(209, 24)
        Me.StudentsIDToolStrip.Text = "Students ID"
        '
        'EmployeeIDToolStrip
        '
        Me.EmployeeIDToolStrip.Name = "EmployeeIDToolStrip"
        Me.EmployeeIDToolStrip.Size = New System.Drawing.Size(209, 24)
        Me.EmployeeIDToolStrip.Text = "Employee / Staff ID"
        '
        'ToolStripSeparator5
        '
        Me.ToolStripSeparator5.Name = "ToolStripSeparator5"
        Me.ToolStripSeparator5.Size = New System.Drawing.Size(199, 6)
        '
        'LockToolStrip
        '
        Me.LockToolStrip.Image = CType(resources.GetObject("LockToolStrip.Image"), System.Drawing.Image)
        Me.LockToolStrip.Name = "LockToolStrip"
        Me.LockToolStrip.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.F7), System.Windows.Forms.Keys)
        Me.LockToolStrip.Size = New System.Drawing.Size(202, 24)
        Me.LockToolStrip.Text = "Lock"
        '
        'LogOffToolStrip
        '
        Me.LogOffToolStrip.Image = CType(resources.GetObject("LogOffToolStrip.Image"), System.Drawing.Image)
        Me.LogOffToolStrip.Name = "LogOffToolStrip"
        Me.LogOffToolStrip.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.F9), System.Windows.Forms.Keys)
        Me.LogOffToolStrip.Size = New System.Drawing.Size(202, 24)
        Me.LogOffToolStrip.Text = "Log Out"
        '
        'ToolStripSeparator9
        '
        Me.ToolStripSeparator9.Name = "ToolStripSeparator9"
        Me.ToolStripSeparator9.Size = New System.Drawing.Size(199, 6)
        '
        'ExitToolStrip
        '
        Me.ExitToolStrip.Image = CType(resources.GetObject("ExitToolStrip.Image"), System.Drawing.Image)
        Me.ExitToolStrip.Name = "ExitToolStrip"
        Me.ExitToolStrip.ShortcutKeys = CType((System.Windows.Forms.Keys.Alt Or System.Windows.Forms.Keys.F4), System.Windows.Forms.Keys)
        Me.ExitToolStrip.Size = New System.Drawing.Size(202, 24)
        Me.ExitToolStrip.Text = "Exit"
        '
        'StudentsToolStrip
        '
        Me.StudentsToolStrip.BackColor = System.Drawing.SystemColors.Control
        Me.StudentsToolStrip.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NewStudentRegistrationToolStripMenuItem, Me.ToolStripSeparator3, Me.StudentAttendanceToolStrip, Me.ManageStudentsToolStripMenuItem})
        Me.StudentsToolStrip.Font = New System.Drawing.Font("Segoe UI Semibold", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StudentsToolStrip.ForeColor = System.Drawing.Color.Black
        Me.StudentsToolStrip.Name = "StudentsToolStrip"
        Me.StudentsToolStrip.Size = New System.Drawing.Size(95, 24)
        Me.StudentsToolStrip.Text = "&STUDENTS"
        '
        'NewStudentRegistrationToolStripMenuItem
        '
        Me.NewStudentRegistrationToolStripMenuItem.BackColor = System.Drawing.Color.Transparent
        Me.NewStudentRegistrationToolStripMenuItem.Image = CType(resources.GetObject("NewStudentRegistrationToolStripMenuItem.Image"), System.Drawing.Image)
        Me.NewStudentRegistrationToolStripMenuItem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.NewStudentRegistrationToolStripMenuItem.Name = "NewStudentRegistrationToolStripMenuItem"
        Me.NewStudentRegistrationToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.N), System.Windows.Forms.Keys)
        Me.NewStudentRegistrationToolStripMenuItem.Size = New System.Drawing.Size(272, 24)
        Me.NewStudentRegistrationToolStripMenuItem.Text = "Student Registration"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(269, 6)
        '
        'StudentAttendanceToolStrip
        '
        Me.StudentAttendanceToolStrip.Name = "StudentAttendanceToolStrip"
        Me.StudentAttendanceToolStrip.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.A), System.Windows.Forms.Keys)
        Me.StudentAttendanceToolStrip.Size = New System.Drawing.Size(272, 24)
        Me.StudentAttendanceToolStrip.Text = "Student Attendance"
        '
        'ManageStudentsToolStripMenuItem
        '
        Me.ManageStudentsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ViewStudentProfileToolStripMenuItem, Me.ToolStripSeparator2, Me.SearchStudentToolStripMenuItem, Me.ToolStripSeparator7, Me.ManageStudentProfileToolStripMenuItem})
        Me.ManageStudentsToolStripMenuItem.Image = CType(resources.GetObject("ManageStudentsToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ManageStudentsToolStripMenuItem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.ManageStudentsToolStripMenuItem.Name = "ManageStudentsToolStripMenuItem"
        Me.ManageStudentsToolStripMenuItem.Size = New System.Drawing.Size(272, 24)
        Me.ManageStudentsToolStripMenuItem.Text = "Students Records"
        '
        'ViewStudentProfileToolStripMenuItem
        '
        Me.ViewStudentProfileToolStripMenuItem.Image = CType(resources.GetObject("ViewStudentProfileToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ViewStudentProfileToolStripMenuItem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.ViewStudentProfileToolStripMenuItem.Name = "ViewStudentProfileToolStripMenuItem"
        Me.ViewStudentProfileToolStripMenuItem.Size = New System.Drawing.Size(231, 24)
        Me.ViewStudentProfileToolStripMenuItem.Text = "Search Student"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(228, 6)
        '
        'SearchStudentToolStripMenuItem
        '
        Me.SearchStudentToolStripMenuItem.Image = CType(resources.GetObject("SearchStudentToolStripMenuItem.Image"), System.Drawing.Image)
        Me.SearchStudentToolStripMenuItem.Name = "SearchStudentToolStripMenuItem"
        Me.SearchStudentToolStripMenuItem.Size = New System.Drawing.Size(231, 24)
        Me.SearchStudentToolStripMenuItem.Text = "View Student Profile"
        '
        'ToolStripSeparator7
        '
        Me.ToolStripSeparator7.Name = "ToolStripSeparator7"
        Me.ToolStripSeparator7.Size = New System.Drawing.Size(228, 6)
        '
        'ManageStudentProfileToolStripMenuItem
        '
        Me.ManageStudentProfileToolStripMenuItem.Image = CType(resources.GetObject("ManageStudentProfileToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ManageStudentProfileToolStripMenuItem.Name = "ManageStudentProfileToolStripMenuItem"
        Me.ManageStudentProfileToolStripMenuItem.Size = New System.Drawing.Size(231, 24)
        Me.ManageStudentProfileToolStripMenuItem.Text = "Student Profile Master"
        '
        'AcademicToolStrip
        '
        Me.AcademicToolStrip.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SBAToolStrip, Me.TSAToolStrip, Me.TerminalReportToolStrip, Me.TermlyAssessmentToolStripMenuItem, Me.GradingSystemToolStripMenuItem})
        Me.AcademicToolStrip.Font = New System.Drawing.Font("Segoe UI Semibold", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AcademicToolStrip.Name = "AcademicToolStrip"
        Me.AcademicToolStrip.Size = New System.Drawing.Size(104, 24)
        Me.AcademicToolStrip.Text = "ACADEMICS"
        '
        'SBAToolStrip
        '
        Me.SBAToolStrip.Image = CType(resources.GetObject("SBAToolStrip.Image"), System.Drawing.Image)
        Me.SBAToolStrip.Name = "SBAToolStrip"
        Me.SBAToolStrip.Size = New System.Drawing.Size(350, 24)
        Me.SBAToolStrip.Text = "School Based Assessment (SBA)"
        '
        'TSAToolStrip
        '
        Me.TSAToolStrip.Name = "TSAToolStrip"
        Me.TSAToolStrip.Size = New System.Drawing.Size(350, 24)
        Me.TSAToolStrip.Text = "Termly Assessment - Student Behaviour "
        '
        'TerminalReportToolStrip
        '
        Me.TerminalReportToolStrip.Image = CType(resources.GetObject("TerminalReportToolStrip.Image"), System.Drawing.Image)
        Me.TerminalReportToolStrip.Name = "TerminalReportToolStrip"
        Me.TerminalReportToolStrip.Size = New System.Drawing.Size(350, 24)
        Me.TerminalReportToolStrip.Text = "Terminal Report"
        '
        'TermlyAssessmentToolStripMenuItem
        '
        Me.TermlyAssessmentToolStripMenuItem.Name = "TermlyAssessmentToolStripMenuItem"
        Me.TermlyAssessmentToolStripMenuItem.Size = New System.Drawing.Size(350, 24)
        Me.TermlyAssessmentToolStripMenuItem.Text = "A&ssessments"
        '
        'GradingSystemToolStripMenuItem
        '
        Me.GradingSystemToolStripMenuItem.Name = "GradingSystemToolStripMenuItem"
        Me.GradingSystemToolStripMenuItem.Size = New System.Drawing.Size(350, 24)
        Me.GradingSystemToolStripMenuItem.Text = "Grading System"
        '
        'EmployeeToolStrip
        '
        Me.EmployeeToolStrip.BackColor = System.Drawing.SystemColors.Control
        Me.EmployeeToolStrip.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.EmployeeRegistration, Me.EmployeeInfoSheet, Me.ToolStripSeparator1, Me.EmployeeDesignation, Me.EmployeeAttendanceRegister, Me.JobProfileMastery, Me.ToolStripSeparator11, Me.EmployeeProfileMastery, Me.ToolStripSeparator12, Me.EmployeeLeaveApplicationToolStripMenuItem})
        Me.EmployeeToolStrip.Font = New System.Drawing.Font("Segoe UI Semibold", 11.25!, System.Drawing.FontStyle.Bold)
        Me.EmployeeToolStrip.ForeColor = System.Drawing.Color.Black
        Me.EmployeeToolStrip.Name = "EmployeeToolStrip"
        Me.EmployeeToolStrip.Size = New System.Drawing.Size(95, 24)
        Me.EmployeeToolStrip.Text = "&EMPLOYEE"
        '
        'EmployeeRegistration
        '
        Me.EmployeeRegistration.Image = CType(resources.GetObject("EmployeeRegistration.Image"), System.Drawing.Image)
        Me.EmployeeRegistration.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.EmployeeRegistration.Name = "EmployeeRegistration"
        Me.EmployeeRegistration.ShortcutKeys = CType(((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Shift) _
            Or System.Windows.Forms.Keys.N), System.Windows.Forms.Keys)
        Me.EmployeeRegistration.Size = New System.Drawing.Size(379, 24)
        Me.EmployeeRegistration.Text = "Employee Registration"
        '
        'EmployeeInfoSheet
        '
        Me.EmployeeInfoSheet.Image = CType(resources.GetObject("EmployeeInfoSheet.Image"), System.Drawing.Image)
        Me.EmployeeInfoSheet.Name = "EmployeeInfoSheet"
        Me.EmployeeInfoSheet.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.I), System.Windows.Forms.Keys)
        Me.EmployeeInfoSheet.Size = New System.Drawing.Size(379, 24)
        Me.EmployeeInfoSheet.Text = "Employee Info Sheet"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(376, 6)
        '
        'EmployeeDesignation
        '
        Me.EmployeeDesignation.Image = CType(resources.GetObject("EmployeeDesignation.Image"), System.Drawing.Image)
        Me.EmployeeDesignation.Name = "EmployeeDesignation"
        Me.EmployeeDesignation.Size = New System.Drawing.Size(379, 24)
        Me.EmployeeDesignation.Text = "Employee Job Designation "
        '
        'EmployeeAttendanceRegister
        '
        Me.EmployeeAttendanceRegister.Name = "EmployeeAttendanceRegister"
        Me.EmployeeAttendanceRegister.ShortcutKeys = CType(((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Shift) _
            Or System.Windows.Forms.Keys.R), System.Windows.Forms.Keys)
        Me.EmployeeAttendanceRegister.Size = New System.Drawing.Size(379, 24)
        Me.EmployeeAttendanceRegister.Text = "Employee Attendance Register"
        '
        'JobProfileMastery
        '
        Me.JobProfileMastery.Image = CType(resources.GetObject("JobProfileMastery.Image"), System.Drawing.Image)
        Me.JobProfileMastery.Name = "JobProfileMastery"
        Me.JobProfileMastery.Size = New System.Drawing.Size(379, 24)
        Me.JobProfileMastery.Text = "Job Profile Mastery"
        '
        'ToolStripSeparator11
        '
        Me.ToolStripSeparator11.Name = "ToolStripSeparator11"
        Me.ToolStripSeparator11.Size = New System.Drawing.Size(376, 6)
        '
        'EmployeeProfileMastery
        '
        Me.EmployeeProfileMastery.Image = CType(resources.GetObject("EmployeeProfileMastery.Image"), System.Drawing.Image)
        Me.EmployeeProfileMastery.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.EmployeeProfileMastery.Name = "EmployeeProfileMastery"
        Me.EmployeeProfileMastery.ShortcutKeys = CType(((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Shift) _
            Or System.Windows.Forms.Keys.M), System.Windows.Forms.Keys)
        Me.EmployeeProfileMastery.Size = New System.Drawing.Size(379, 24)
        Me.EmployeeProfileMastery.Text = "Employee Profile Master"
        '
        'ToolStripSeparator12
        '
        Me.ToolStripSeparator12.Name = "ToolStripSeparator12"
        Me.ToolStripSeparator12.Size = New System.Drawing.Size(376, 6)
        '
        'EmployeeLeaveApplicationToolStripMenuItem
        '
        Me.EmployeeLeaveApplicationToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ApplyForLeaveToolStripMenuItem, Me.ApproveLeaveToolStripMenuItem})
        Me.EmployeeLeaveApplicationToolStripMenuItem.Name = "EmployeeLeaveApplicationToolStripMenuItem"
        Me.EmployeeLeaveApplicationToolStripMenuItem.Size = New System.Drawing.Size(379, 24)
        Me.EmployeeLeaveApplicationToolStripMenuItem.Text = "Employee Leave Mastery"
        Me.EmployeeLeaveApplicationToolStripMenuItem.Visible = False
        '
        'ApplyForLeaveToolStripMenuItem
        '
        Me.ApplyForLeaveToolStripMenuItem.Name = "ApplyForLeaveToolStripMenuItem"
        Me.ApplyForLeaveToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.A), System.Windows.Forms.Keys)
        Me.ApplyForLeaveToolStripMenuItem.Size = New System.Drawing.Size(238, 24)
        Me.ApplyForLeaveToolStripMenuItem.Text = "Apply for Leave"
        '
        'ApproveLeaveToolStripMenuItem
        '
        Me.ApproveLeaveToolStripMenuItem.Name = "ApproveLeaveToolStripMenuItem"
        Me.ApproveLeaveToolStripMenuItem.Size = New System.Drawing.Size(238, 24)
        Me.ApproveLeaveToolStripMenuItem.Text = "Leave Management"
        '
        'FinanceToolStrip
        '
        Me.FinanceToolStrip.BackColor = System.Drawing.SystemColors.Control
        Me.FinanceToolStrip.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PaymentsToolStripMenuItem, Me.SalaryPaymentToolStrip, Me.OtherFeesPaymentsToolStripMenuItem, Me.ToolStripSeparator6, Me.CheckPaymentsToolStrip, Me.BillingToolStripMenuItem})
        Me.FinanceToolStrip.Font = New System.Drawing.Font("Segoe UI Semibold", 11.25!, System.Drawing.FontStyle.Bold)
        Me.FinanceToolStrip.ForeColor = System.Drawing.Color.Black
        Me.FinanceToolStrip.Name = "FinanceToolStrip"
        Me.FinanceToolStrip.Size = New System.Drawing.Size(210, 24)
        Me.FinanceToolStrip.Text = "&FINANCIAL TRANSACTIONS"
        '
        'PaymentsToolStripMenuItem
        '
        Me.PaymentsToolStripMenuItem.Image = CType(resources.GetObject("PaymentsToolStripMenuItem.Image"), System.Drawing.Image)
        Me.PaymentsToolStripMenuItem.Name = "PaymentsToolStripMenuItem"
        Me.PaymentsToolStripMenuItem.Size = New System.Drawing.Size(290, 24)
        Me.PaymentsToolStripMenuItem.Text = "School Fees Collection or Entry"
        '
        'SalaryPaymentToolStrip
        '
        Me.SalaryPaymentToolStrip.Image = CType(resources.GetObject("SalaryPaymentToolStrip.Image"), System.Drawing.Image)
        Me.SalaryPaymentToolStrip.Name = "SalaryPaymentToolStrip"
        Me.SalaryPaymentToolStrip.Size = New System.Drawing.Size(290, 24)
        Me.SalaryPaymentToolStrip.Text = "Employee Salary Payment"
        '
        'OtherFeesPaymentsToolStripMenuItem
        '
        Me.OtherFeesPaymentsToolStripMenuItem.Image = CType(resources.GetObject("OtherFeesPaymentsToolStripMenuItem.Image"), System.Drawing.Image)
        Me.OtherFeesPaymentsToolStripMenuItem.Name = "OtherFeesPaymentsToolStripMenuItem"
        Me.OtherFeesPaymentsToolStripMenuItem.Size = New System.Drawing.Size(290, 24)
        Me.OtherFeesPaymentsToolStripMenuItem.Text = "Other Fees Payments"
        '
        'ToolStripSeparator6
        '
        Me.ToolStripSeparator6.Name = "ToolStripSeparator6"
        Me.ToolStripSeparator6.Size = New System.Drawing.Size(287, 6)
        '
        'CheckPaymentsToolStrip
        '
        Me.CheckPaymentsToolStrip.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CheckSchFeesPaidToolStrip, Me.CheckOtherFeesPaidToolStrip})
        Me.CheckPaymentsToolStrip.Image = CType(resources.GetObject("CheckPaymentsToolStrip.Image"), System.Drawing.Image)
        Me.CheckPaymentsToolStrip.Name = "CheckPaymentsToolStrip"
        Me.CheckPaymentsToolStrip.Size = New System.Drawing.Size(290, 24)
        Me.CheckPaymentsToolStrip.Text = "Check Payments"
        '
        'CheckSchFeesPaidToolStrip
        '
        Me.CheckSchFeesPaidToolStrip.Image = CType(resources.GetObject("CheckSchFeesPaidToolStrip.Image"), System.Drawing.Image)
        Me.CheckSchFeesPaidToolStrip.Name = "CheckSchFeesPaidToolStrip"
        Me.CheckSchFeesPaidToolStrip.Size = New System.Drawing.Size(307, 24)
        Me.CheckSchFeesPaidToolStrip.Text = "Total School Fees Paid by Student"
        '
        'CheckOtherFeesPaidToolStrip
        '
        Me.CheckOtherFeesPaidToolStrip.Image = CType(resources.GetObject("CheckOtherFeesPaidToolStrip.Image"), System.Drawing.Image)
        Me.CheckOtherFeesPaidToolStrip.Name = "CheckOtherFeesPaidToolStrip"
        Me.CheckOtherFeesPaidToolStrip.Size = New System.Drawing.Size(307, 24)
        Me.CheckOtherFeesPaidToolStrip.Text = "Other Fees Paid by Student"
        '
        'BillingToolStripMenuItem
        '
        Me.BillingToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TerminalBillToolStripMenuItem, Me.GenerateTerminalBillToolStripMenuItem})
        Me.BillingToolStripMenuItem.Image = CType(resources.GetObject("BillingToolStripMenuItem.Image"), System.Drawing.Image)
        Me.BillingToolStripMenuItem.Name = "BillingToolStripMenuItem"
        Me.BillingToolStripMenuItem.Size = New System.Drawing.Size(290, 24)
        Me.BillingToolStripMenuItem.Text = "Billing"
        '
        'TerminalBillToolStripMenuItem
        '
        Me.TerminalBillToolStripMenuItem.Image = CType(resources.GetObject("TerminalBillToolStripMenuItem.Image"), System.Drawing.Image)
        Me.TerminalBillToolStripMenuItem.Name = "TerminalBillToolStripMenuItem"
        Me.TerminalBillToolStripMenuItem.Size = New System.Drawing.Size(243, 24)
        Me.TerminalBillToolStripMenuItem.Text = "Fill Student Terminal Bill"
        '
        'GenerateTerminalBillToolStripMenuItem
        '
        Me.GenerateTerminalBillToolStripMenuItem.Image = CType(resources.GetObject("GenerateTerminalBillToolStripMenuItem.Image"), System.Drawing.Image)
        Me.GenerateTerminalBillToolStripMenuItem.Name = "GenerateTerminalBillToolStripMenuItem"
        Me.GenerateTerminalBillToolStripMenuItem.Size = New System.Drawing.Size(243, 24)
        Me.GenerateTerminalBillToolStripMenuItem.Text = "Generate Terminal Bill"
        '
        'RecordsToolStrip
        '
        Me.RecordsToolStrip.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FeesPaymentRecordTooStrip, Me.SalaryPaymentRecordTooStrip})
        Me.RecordsToolStrip.Font = New System.Drawing.Font("Segoe UI Semibold", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RecordsToolStrip.Name = "RecordsToolStrip"
        Me.RecordsToolStrip.Size = New System.Drawing.Size(86, 24)
        Me.RecordsToolStrip.Text = "&RECORDS"
        '
        'FeesPaymentRecordTooStrip
        '
        Me.FeesPaymentRecordTooStrip.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SchoolFeesHistoryToolStrip, Me.OtherFeesHistoryToolStrip})
        Me.FeesPaymentRecordTooStrip.Name = "FeesPaymentRecordTooStrip"
        Me.FeesPaymentRecordTooStrip.Size = New System.Drawing.Size(243, 24)
        Me.FeesPaymentRecordTooStrip.Text = "Fees Payments Record"
        '
        'SchoolFeesHistoryToolStrip
        '
        Me.SchoolFeesHistoryToolStrip.Name = "SchoolFeesHistoryToolStrip"
        Me.SchoolFeesHistoryToolStrip.Size = New System.Drawing.Size(276, 24)
        Me.SchoolFeesHistoryToolStrip.Text = "School Fees Payment History"
        '
        'OtherFeesHistoryToolStrip
        '
        Me.OtherFeesHistoryToolStrip.Name = "OtherFeesHistoryToolStrip"
        Me.OtherFeesHistoryToolStrip.Size = New System.Drawing.Size(276, 24)
        Me.OtherFeesHistoryToolStrip.Text = "Other Fees Payment History"
        '
        'SalaryPaymentRecordTooStrip
        '
        Me.SalaryPaymentRecordTooStrip.Name = "SalaryPaymentRecordTooStrip"
        Me.SalaryPaymentRecordTooStrip.Size = New System.Drawing.Size(243, 24)
        Me.SalaryPaymentRecordTooStrip.Text = "Salary Payments Record"
        '
        'ReportToolStrip
        '
        Me.ReportToolStrip.BackColor = System.Drawing.SystemColors.Control
        Me.ReportToolStrip.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AcademicRecordsToolStripMenuItem, Me.AccountReportToolStripMenuItem1, Me.StudentsReportToolStripMenuItem, Me.ToolStripSeparator10, Me.StaffReportToolStripMenuItem})
        Me.ReportToolStrip.Font = New System.Drawing.Font("Segoe UI Semibold", 11.25!, System.Drawing.FontStyle.Bold)
        Me.ReportToolStrip.ForeColor = System.Drawing.Color.Black
        Me.ReportToolStrip.Name = "ReportToolStrip"
        Me.ReportToolStrip.Size = New System.Drawing.Size(83, 24)
        Me.ReportToolStrip.Text = "&REPORTS"
        '
        'AcademicRecordsToolStripMenuItem
        '
        Me.AcademicRecordsToolStripMenuItem.Name = "AcademicRecordsToolStripMenuItem"
        Me.AcademicRecordsToolStripMenuItem.Size = New System.Drawing.Size(202, 24)
        Me.AcademicRecordsToolStripMenuItem.Text = "Academic Records"
        '
        'AccountReportToolStripMenuItem1
        '
        Me.AccountReportToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.StaffReToolStripMenuItem, Me.TermlySchoolFeesPaidToolStripMenuItem, Me.TermlyBusFeesToolStripMenuItem, Me.MonthlyExpenditureOnStaffToolStripMenuItem, Me.TermlyExpenditureOnStaffToolStripMenuItem, Me.YearlyExpenditureOnStaffToolStripMenuItem, Me.StuudentsArrearsToolStripMenuItem})
        Me.AccountReportToolStripMenuItem1.Image = CType(resources.GetObject("AccountReportToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.AccountReportToolStripMenuItem1.Name = "AccountReportToolStripMenuItem1"
        Me.AccountReportToolStripMenuItem1.Size = New System.Drawing.Size(202, 24)
        Me.AccountReportToolStripMenuItem1.Text = "Accounts Report"
        '
        'StaffReToolStripMenuItem
        '
        Me.StaffReToolStripMenuItem.Image = CType(resources.GetObject("StaffReToolStripMenuItem.Image"), System.Drawing.Image)
        Me.StaffReToolStripMenuItem.Name = "StaffReToolStripMenuItem"
        Me.StaffReToolStripMenuItem.Size = New System.Drawing.Size(284, 24)
        Me.StaffReToolStripMenuItem.Text = "Staff Remuneration"
        '
        'TermlySchoolFeesPaidToolStripMenuItem
        '
        Me.TermlySchoolFeesPaidToolStripMenuItem.Image = CType(resources.GetObject("TermlySchoolFeesPaidToolStripMenuItem.Image"), System.Drawing.Image)
        Me.TermlySchoolFeesPaidToolStripMenuItem.Name = "TermlySchoolFeesPaidToolStripMenuItem"
        Me.TermlySchoolFeesPaidToolStripMenuItem.Size = New System.Drawing.Size(284, 24)
        Me.TermlySchoolFeesPaidToolStripMenuItem.Text = "Total School Fees Paid in Term"
        '
        'TermlyBusFeesToolStripMenuItem
        '
        Me.TermlyBusFeesToolStripMenuItem.Image = CType(resources.GetObject("TermlyBusFeesToolStripMenuItem.Image"), System.Drawing.Image)
        Me.TermlyBusFeesToolStripMenuItem.Name = "TermlyBusFeesToolStripMenuItem"
        Me.TermlyBusFeesToolStripMenuItem.Size = New System.Drawing.Size(284, 24)
        Me.TermlyBusFeesToolStripMenuItem.Text = "Total Bus Fees Paid in Term"
        '
        'MonthlyExpenditureOnStaffToolStripMenuItem
        '
        Me.MonthlyExpenditureOnStaffToolStripMenuItem.Image = CType(resources.GetObject("MonthlyExpenditureOnStaffToolStripMenuItem.Image"), System.Drawing.Image)
        Me.MonthlyExpenditureOnStaffToolStripMenuItem.Name = "MonthlyExpenditureOnStaffToolStripMenuItem"
        Me.MonthlyExpenditureOnStaffToolStripMenuItem.Size = New System.Drawing.Size(284, 24)
        Me.MonthlyExpenditureOnStaffToolStripMenuItem.Text = "Monthly Expenditure on Staff"
        '
        'TermlyExpenditureOnStaffToolStripMenuItem
        '
        Me.TermlyExpenditureOnStaffToolStripMenuItem.Image = CType(resources.GetObject("TermlyExpenditureOnStaffToolStripMenuItem.Image"), System.Drawing.Image)
        Me.TermlyExpenditureOnStaffToolStripMenuItem.Name = "TermlyExpenditureOnStaffToolStripMenuItem"
        Me.TermlyExpenditureOnStaffToolStripMenuItem.Size = New System.Drawing.Size(284, 24)
        Me.TermlyExpenditureOnStaffToolStripMenuItem.Text = "Termly Expenditure on Staff"
        '
        'YearlyExpenditureOnStaffToolStripMenuItem
        '
        Me.YearlyExpenditureOnStaffToolStripMenuItem.Image = CType(resources.GetObject("YearlyExpenditureOnStaffToolStripMenuItem.Image"), System.Drawing.Image)
        Me.YearlyExpenditureOnStaffToolStripMenuItem.Name = "YearlyExpenditureOnStaffToolStripMenuItem"
        Me.YearlyExpenditureOnStaffToolStripMenuItem.Size = New System.Drawing.Size(284, 24)
        Me.YearlyExpenditureOnStaffToolStripMenuItem.Text = "Yearly Expenditure on Staff"
        '
        'StuudentsArrearsToolStripMenuItem
        '
        Me.StuudentsArrearsToolStripMenuItem.Image = CType(resources.GetObject("StuudentsArrearsToolStripMenuItem.Image"), System.Drawing.Image)
        Me.StuudentsArrearsToolStripMenuItem.Name = "StuudentsArrearsToolStripMenuItem"
        Me.StuudentsArrearsToolStripMenuItem.Size = New System.Drawing.Size(284, 24)
        Me.StuudentsArrearsToolStripMenuItem.Text = "Students School Fees Arrears"
        '
        'StudentsReportToolStripMenuItem
        '
        Me.StudentsReportToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AllRegisteredStudentsToolStripMenuItem, Me.RegisteredStudentByDepartmentToolStripMenuItem, Me.ListsOfActiveStudentsToolStripMenuItem, Me.ListsOfInactiveStudentsToolStripMenuItem, Me.ActiveRegisteredStudentsByClassToolStripMenuItem})
        Me.StudentsReportToolStripMenuItem.Name = "StudentsReportToolStripMenuItem"
        Me.StudentsReportToolStripMenuItem.Size = New System.Drawing.Size(202, 24)
        Me.StudentsReportToolStripMenuItem.Text = "Students Reports"
        '
        'AllRegisteredStudentsToolStripMenuItem
        '
        Me.AllRegisteredStudentsToolStripMenuItem.Name = "AllRegisteredStudentsToolStripMenuItem"
        Me.AllRegisteredStudentsToolStripMenuItem.Size = New System.Drawing.Size(317, 24)
        Me.AllRegisteredStudentsToolStripMenuItem.Text = "All Registered Students"
        '
        'RegisteredStudentByDepartmentToolStripMenuItem
        '
        Me.RegisteredStudentByDepartmentToolStripMenuItem.Name = "RegisteredStudentByDepartmentToolStripMenuItem"
        Me.RegisteredStudentByDepartmentToolStripMenuItem.Size = New System.Drawing.Size(317, 24)
        Me.RegisteredStudentByDepartmentToolStripMenuItem.Text = "Registered Student by Department"
        '
        'ListsOfActiveStudentsToolStripMenuItem
        '
        Me.ListsOfActiveStudentsToolStripMenuItem.Name = "ListsOfActiveStudentsToolStripMenuItem"
        Me.ListsOfActiveStudentsToolStripMenuItem.Size = New System.Drawing.Size(317, 24)
        Me.ListsOfActiveStudentsToolStripMenuItem.Text = "Lists of Active Students"
        '
        'ListsOfInactiveStudentsToolStripMenuItem
        '
        Me.ListsOfInactiveStudentsToolStripMenuItem.Name = "ListsOfInactiveStudentsToolStripMenuItem"
        Me.ListsOfInactiveStudentsToolStripMenuItem.Size = New System.Drawing.Size(317, 24)
        Me.ListsOfInactiveStudentsToolStripMenuItem.Text = "Lists of Inactive Students"
        '
        'ActiveRegisteredStudentsByClassToolStripMenuItem
        '
        Me.ActiveRegisteredStudentsByClassToolStripMenuItem.Name = "ActiveRegisteredStudentsByClassToolStripMenuItem"
        Me.ActiveRegisteredStudentsByClassToolStripMenuItem.Size = New System.Drawing.Size(317, 24)
        Me.ActiveRegisteredStudentsByClassToolStripMenuItem.Text = "Active Registered Students by Class"
        '
        'ToolStripSeparator10
        '
        Me.ToolStripSeparator10.Name = "ToolStripSeparator10"
        Me.ToolStripSeparator10.Size = New System.Drawing.Size(199, 6)
        '
        'StaffReportToolStripMenuItem
        '
        Me.StaffReportToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.RegisteredStaffDeptToolStripMenuItem, Me.RegisteredStaffToolStripMenuItem, Me.ListOfActiveStaffToolStripMenuItem, Me.ListOfInactiveStaffToolStripMenuItem})
        Me.StaffReportToolStripMenuItem.Image = CType(resources.GetObject("StaffReportToolStripMenuItem.Image"), System.Drawing.Image)
        Me.StaffReportToolStripMenuItem.Name = "StaffReportToolStripMenuItem"
        Me.StaffReportToolStripMenuItem.Size = New System.Drawing.Size(202, 24)
        Me.StaffReportToolStripMenuItem.Text = "Employee Reports"
        '
        'RegisteredStaffDeptToolStripMenuItem
        '
        Me.RegisteredStaffDeptToolStripMenuItem.Image = CType(resources.GetObject("RegisteredStaffDeptToolStripMenuItem.Image"), System.Drawing.Image)
        Me.RegisteredStaffDeptToolStripMenuItem.Name = "RegisteredStaffDeptToolStripMenuItem"
        Me.RegisteredStaffDeptToolStripMenuItem.Size = New System.Drawing.Size(252, 24)
        Me.RegisteredStaffDeptToolStripMenuItem.Text = "Employee By Department"
        '
        'RegisteredStaffToolStripMenuItem
        '
        Me.RegisteredStaffToolStripMenuItem.Image = CType(resources.GetObject("RegisteredStaffToolStripMenuItem.Image"), System.Drawing.Image)
        Me.RegisteredStaffToolStripMenuItem.Name = "RegisteredStaffToolStripMenuItem"
        Me.RegisteredStaffToolStripMenuItem.Size = New System.Drawing.Size(252, 24)
        Me.RegisteredStaffToolStripMenuItem.Text = "All Registered Employee"
        '
        'ListOfActiveStaffToolStripMenuItem
        '
        Me.ListOfActiveStaffToolStripMenuItem.Name = "ListOfActiveStaffToolStripMenuItem"
        Me.ListOfActiveStaffToolStripMenuItem.Size = New System.Drawing.Size(252, 24)
        Me.ListOfActiveStaffToolStripMenuItem.Text = "List of Active Staff"
        '
        'ListOfInactiveStaffToolStripMenuItem
        '
        Me.ListOfInactiveStaffToolStripMenuItem.Name = "ListOfInactiveStaffToolStripMenuItem"
        Me.ListOfInactiveStaffToolStripMenuItem.Size = New System.Drawing.Size(252, 24)
        Me.ListOfInactiveStaffToolStripMenuItem.Text = "List of Inactive Staff"
        '
        'UtilitiesToolStrip
        '
        Me.UtilitiesToolStrip.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ChangePasswordToolStrip, Me.ToolStripSeparator13, Me.CreateNewUserToolStrip, Me.PasswordRecoveryToolStripMenuItem, Me.UseMaintenanceToolstrip, Me.AccountSettingsToolStripMenuItem})
        Me.UtilitiesToolStrip.Font = New System.Drawing.Font("Segoe UI Semibold", 11.25!, System.Drawing.FontStyle.Bold)
        Me.UtilitiesToolStrip.Name = "UtilitiesToolStrip"
        Me.UtilitiesToolStrip.Size = New System.Drawing.Size(83, 24)
        Me.UtilitiesToolStrip.Text = "&UTILITIES"
        '
        'ChangePasswordToolStrip
        '
        Me.ChangePasswordToolStrip.Image = CType(resources.GetObject("ChangePasswordToolStrip.Image"), System.Drawing.Image)
        Me.ChangePasswordToolStrip.Name = "ChangePasswordToolStrip"
        Me.ChangePasswordToolStrip.Size = New System.Drawing.Size(284, 24)
        Me.ChangePasswordToolStrip.Text = "Change Password"
        '
        'ToolStripSeparator13
        '
        Me.ToolStripSeparator13.Name = "ToolStripSeparator13"
        Me.ToolStripSeparator13.Size = New System.Drawing.Size(281, 6)
        '
        'CreateNewUserToolStrip
        '
        Me.CreateNewUserToolStrip.Image = CType(resources.GetObject("CreateNewUserToolStrip.Image"), System.Drawing.Image)
        Me.CreateNewUserToolStrip.Name = "CreateNewUserToolStrip"
        Me.CreateNewUserToolStrip.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.U), System.Windows.Forms.Keys)
        Me.CreateNewUserToolStrip.Size = New System.Drawing.Size(284, 24)
        Me.CreateNewUserToolStrip.Text = "New User Registration"
        '
        'PasswordRecoveryToolStripMenuItem
        '
        Me.PasswordRecoveryToolStripMenuItem.Image = CType(resources.GetObject("PasswordRecoveryToolStripMenuItem.Image"), System.Drawing.Image)
        Me.PasswordRecoveryToolStripMenuItem.Name = "PasswordRecoveryToolStripMenuItem"
        Me.PasswordRecoveryToolStripMenuItem.Size = New System.Drawing.Size(284, 24)
        Me.PasswordRecoveryToolStripMenuItem.Text = "Password Recovery Module"
        '
        'UseMaintenanceToolstrip
        '
        Me.UseMaintenanceToolstrip.Image = CType(resources.GetObject("UseMaintenanceToolstrip.Image"), System.Drawing.Image)
        Me.UseMaintenanceToolstrip.Name = "UseMaintenanceToolstrip"
        Me.UseMaintenanceToolstrip.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.M), System.Windows.Forms.Keys)
        Me.UseMaintenanceToolstrip.Size = New System.Drawing.Size(284, 24)
        Me.UseMaintenanceToolstrip.Text = "User Maintenance"
        '
        'AccountSettingsToolStripMenuItem
        '
        Me.AccountSettingsToolStripMenuItem.Image = CType(resources.GetObject("AccountSettingsToolStripMenuItem.Image"), System.Drawing.Image)
        Me.AccountSettingsToolStripMenuItem.Name = "AccountSettingsToolStripMenuItem"
        Me.AccountSettingsToolStripMenuItem.Size = New System.Drawing.Size(284, 24)
        Me.AccountSettingsToolStripMenuItem.Text = "User Account Settings"
        Me.AccountSettingsToolStripMenuItem.Visible = False
        '
        'OptionToolStrip
        '
        Me.OptionToolStrip.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SchoolInfoToolStripMenuItem, Me.SettingsToolStripMenuItem, Me.ClassTeacherAssignmentToolStrip, Me.SystemSettingsToolStripMenuItem})
        Me.OptionToolStrip.Font = New System.Drawing.Font("Segoe UI Semibold", 11.25!, System.Drawing.FontStyle.Bold)
        Me.OptionToolStrip.Name = "OptionToolStrip"
        Me.OptionToolStrip.Size = New System.Drawing.Size(84, 24)
        Me.OptionToolStrip.Text = "&OPTIONS"
        '
        'SchoolInfoToolStripMenuItem
        '
        Me.SchoolInfoToolStripMenuItem.Name = "SchoolInfoToolStripMenuItem"
        Me.SchoolInfoToolStripMenuItem.Size = New System.Drawing.Size(251, 24)
        Me.SchoolInfoToolStripMenuItem.Text = "School Profile"
        '
        'SettingsToolStripMenuItem
        '
        Me.SettingsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AcademicYearToolStrip, Me.AttendanceToolStrip, Me.BillSettingsToolStrip, Me.ClassRoomToolStrip, Me.DesignationToolStripMenuItem, Me.FeesToolStrip, Me.GradingSystemToolStrip, Me.SubjectsToolStrip, Me.PaymentModeToolStrip, Me.OtherFeesSettingsToolStrip, Me.AppointmentTypeToolStrip, Me.PortfolioToolStripMenuItem})
        Me.SettingsToolStripMenuItem.Name = "SettingsToolStripMenuItem"
        Me.SettingsToolStripMenuItem.Size = New System.Drawing.Size(251, 24)
        Me.SettingsToolStripMenuItem.Text = "Data Settings"
        '
        'AcademicYearToolStrip
        '
        Me.AcademicYearToolStrip.Name = "AcademicYearToolStrip"
        Me.AcademicYearToolStrip.Size = New System.Drawing.Size(242, 24)
        Me.AcademicYearToolStrip.Text = "Academic Session / Year"
        '
        'AttendanceToolStrip
        '
        Me.AttendanceToolStrip.Name = "AttendanceToolStrip"
        Me.AttendanceToolStrip.Size = New System.Drawing.Size(242, 24)
        Me.AttendanceToolStrip.Text = "Attendance"
        '
        'BillSettingsToolStrip
        '
        Me.BillSettingsToolStrip.Name = "BillSettingsToolStrip"
        Me.BillSettingsToolStrip.Size = New System.Drawing.Size(242, 24)
        Me.BillSettingsToolStrip.Text = "Bill Settings"
        '
        'ClassRoomToolStrip
        '
        Me.ClassRoomToolStrip.Name = "ClassRoomToolStrip"
        Me.ClassRoomToolStrip.Size = New System.Drawing.Size(242, 24)
        Me.ClassRoomToolStrip.Text = "Class Type / Room"
        '
        'DesignationToolStripMenuItem
        '
        Me.DesignationToolStripMenuItem.Name = "DesignationToolStripMenuItem"
        Me.DesignationToolStripMenuItem.Size = New System.Drawing.Size(242, 24)
        Me.DesignationToolStripMenuItem.Text = "User Designation"
        '
        'FeesToolStrip
        '
        Me.FeesToolStrip.Name = "FeesToolStrip"
        Me.FeesToolStrip.Size = New System.Drawing.Size(242, 24)
        Me.FeesToolStrip.Text = "School Fees Settings"
        '
        'GradingSystemToolStrip
        '
        Me.GradingSystemToolStrip.Name = "GradingSystemToolStrip"
        Me.GradingSystemToolStrip.Size = New System.Drawing.Size(242, 24)
        Me.GradingSystemToolStrip.Text = "Grading System"
        '
        'SubjectsToolStrip
        '
        Me.SubjectsToolStrip.Name = "SubjectsToolStrip"
        Me.SubjectsToolStrip.Size = New System.Drawing.Size(242, 24)
        Me.SubjectsToolStrip.Text = "Subjects"
        '
        'PaymentModeToolStrip
        '
        Me.PaymentModeToolStrip.Name = "PaymentModeToolStrip"
        Me.PaymentModeToolStrip.Size = New System.Drawing.Size(242, 24)
        Me.PaymentModeToolStrip.Text = "Payment Mode"
        '
        'OtherFeesSettingsToolStrip
        '
        Me.OtherFeesSettingsToolStrip.Name = "OtherFeesSettingsToolStrip"
        Me.OtherFeesSettingsToolStrip.Size = New System.Drawing.Size(242, 24)
        Me.OtherFeesSettingsToolStrip.Text = "Other Fees Settings"
        '
        'AppointmentTypeToolStrip
        '
        Me.AppointmentTypeToolStrip.Name = "AppointmentTypeToolStrip"
        Me.AppointmentTypeToolStrip.Size = New System.Drawing.Size(242, 24)
        Me.AppointmentTypeToolStrip.Text = "Appointment Type"
        '
        'PortfolioToolStripMenuItem
        '
        Me.PortfolioToolStripMenuItem.Name = "PortfolioToolStripMenuItem"
        Me.PortfolioToolStripMenuItem.Size = New System.Drawing.Size(242, 24)
        Me.PortfolioToolStripMenuItem.Text = "Portfolio"
        '
        'ClassTeacherAssignmentToolStrip
        '
        Me.ClassTeacherAssignmentToolStrip.Name = "ClassTeacherAssignmentToolStrip"
        Me.ClassTeacherAssignmentToolStrip.Size = New System.Drawing.Size(251, 24)
        Me.ClassTeacherAssignmentToolStrip.Text = "Class Teacher Assignment"
        '
        'SystemSettingsToolStripMenuItem
        '
        Me.SystemSettingsToolStripMenuItem.Name = "SystemSettingsToolStripMenuItem"
        Me.SystemSettingsToolStripMenuItem.Size = New System.Drawing.Size(251, 24)
        Me.SystemSettingsToolStripMenuItem.Text = "System Settings"
        '
        'ToolsToolStrip
        '
        Me.ToolsToolStrip.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CalculatorToolStripMenuItem, Me.MicrosoftWordToolStripMenuItem})
        Me.ToolsToolStrip.Font = New System.Drawing.Font("Segoe UI Semibold", 11.25!, System.Drawing.FontStyle.Bold)
        Me.ToolsToolStrip.Name = "ToolsToolStrip"
        Me.ToolsToolStrip.Size = New System.Drawing.Size(65, 24)
        Me.ToolsToolStrip.Text = "&TOOLS"
        '
        'CalculatorToolStripMenuItem
        '
        Me.CalculatorToolStripMenuItem.Name = "CalculatorToolStripMenuItem"
        Me.CalculatorToolStripMenuItem.Size = New System.Drawing.Size(185, 24)
        Me.CalculatorToolStripMenuItem.Text = "Calculator"
        '
        'MicrosoftWordToolStripMenuItem
        '
        Me.MicrosoftWordToolStripMenuItem.Name = "MicrosoftWordToolStripMenuItem"
        Me.MicrosoftWordToolStripMenuItem.Size = New System.Drawing.Size(185, 24)
        Me.MicrosoftWordToolStripMenuItem.Text = "Microsoft Word"
        '
        'HelpToolStrip
        '
        Me.HelpToolStrip.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.HelpToolStripMenuItem, Me.JecmasSolutionsToolStripMenuItem, Me.AboutToolStripMenuItem})
        Me.HelpToolStrip.Font = New System.Drawing.Font("Segoe UI Semibold", 11.25!, System.Drawing.FontStyle.Bold)
        Me.HelpToolStrip.Name = "HelpToolStrip"
        Me.HelpToolStrip.Size = New System.Drawing.Size(56, 24)
        Me.HelpToolStrip.Text = "&HELP"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(272, 24)
        Me.HelpToolStripMenuItem.Text = "Help "
        '
        'JecmasSolutionsToolStripMenuItem
        '
        Me.JecmasSolutionsToolStripMenuItem.Image = CType(resources.GetObject("JecmasSolutionsToolStripMenuItem.Image"), System.Drawing.Image)
        Me.JecmasSolutionsToolStripMenuItem.Name = "JecmasSolutionsToolStripMenuItem"
        Me.JecmasSolutionsToolStripMenuItem.Size = New System.Drawing.Size(272, 24)
        Me.JecmasSolutionsToolStripMenuItem.Text = "Jecmas Solutions Homepage"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Image = CType(resources.GetObject("AboutToolStripMenuItem.Image"), System.Drawing.Image)
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(272, 24)
        Me.AboutToolStripMenuItem.Text = "About SIMS"
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.White
        Me.Panel1.Controls.Add(Me.lblAnimation)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 28)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1276, 35)
        Me.Panel1.TabIndex = 13
        '
        'lblAnimation
        '
        Me.lblAnimation.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblAnimation.BackColor = System.Drawing.Color.Transparent
        Me.lblAnimation.Font = New System.Drawing.Font("Segoe UI", 28.0!, System.Drawing.FontStyle.Bold)
        Me.lblAnimation.ForeColor = System.Drawing.Color.Blue
        Me.lblAnimation.Location = New System.Drawing.Point(2, -10)
        Me.lblAnimation.Name = "lblAnimation"
        Me.lblAnimation.Size = New System.Drawing.Size(1274, 41)
        Me.lblAnimation.TabIndex = 14
        Me.lblAnimation.Text = "STUDENT MANAGEMENT INFORMATION SYSTEM"
        Me.lblAnimation.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'StatusStrip1
        '
        Me.StatusStrip1.BackColor = System.Drawing.SystemColors.Control
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel2, Me.lblUserType, Me.ToolStripStatusLabel3, Me.lblUser, Me.ToolStripStatusLabel4, Me.ToolStripStatusLabel1, Me.lblDateTime})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 478)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(1276, 24)
        Me.StatusStrip1.TabIndex = 27
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'ToolStripStatusLabel2
        '
        Me.ToolStripStatusLabel2.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.ToolStripStatusLabel2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ToolStripStatusLabel2.Name = "ToolStripStatusLabel2"
        Me.ToolStripStatusLabel2.Size = New System.Drawing.Size(104, 19)
        Me.ToolStripStatusLabel2.Text = "Logged in As :"
        '
        'lblUserType
        '
        Me.lblUserType.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.lblUserType.ForeColor = System.Drawing.Color.Blue
        Me.lblUserType.Image = CType(resources.GetObject("lblUserType.Image"), System.Drawing.Image)
        Me.lblUserType.Name = "lblUserType"
        Me.lblUserType.Size = New System.Drawing.Size(91, 19)
        Me.lblUserType.Text = "User Type"
        '
        'ToolStripStatusLabel3
        '
        Me.ToolStripStatusLabel3.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.ToolStripStatusLabel3.ForeColor = System.Drawing.Color.Maroon
        Me.ToolStripStatusLabel3.Name = "ToolStripStatusLabel3"
        Me.ToolStripStatusLabel3.Size = New System.Drawing.Size(13, 19)
        Me.ToolStripStatusLabel3.Text = ":"
        '
        'lblUser
        '
        Me.lblUser.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.lblUser.ForeColor = System.Drawing.Color.Blue
        Me.lblUser.Name = "lblUser"
        Me.lblUser.Size = New System.Drawing.Size(83, 19)
        Me.lblUser.Text = "User Name"
        '
        'ToolStripStatusLabel4
        '
        Me.ToolStripStatusLabel4.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.ToolStripStatusLabel4.ForeColor = System.Drawing.Color.White
        Me.ToolStripStatusLabel4.Name = "ToolStripStatusLabel4"
        Me.ToolStripStatusLabel4.Size = New System.Drawing.Size(810, 19)
        Me.ToolStripStatusLabel4.Spring = True
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.ToolStripStatusLabel1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(83, 19)
        Me.ToolStripStatusLabel1.Text = "Date-Time:"
        '
        'lblDateTime
        '
        Me.lblDateTime.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDateTime.ForeColor = System.Drawing.Color.Blue
        Me.lblDateTime.Name = "lblDateTime"
        Me.lblDateTime.Size = New System.Drawing.Size(77, 19)
        Me.lblDateTime.Text = "Date Time"
        '
        'Timer2
        '
        Me.Timer2.Enabled = True
        '
        'AdminSection
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlDark
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1276, 502)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.MenuStrip)
        Me.ForeColor = System.Drawing.Color.Black
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.IsMdiContainer = True
        Me.MainMenuStrip = Me.MenuStrip
        Me.Name = "AdminSection"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultBounds
        Me.Text = "Students Management Information System"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.MenuStrip.ResumeLayout(False)
        Me.MenuStrip.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ToolTip As System.Windows.Forms.ToolTip
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents SchoolFeesHistoryToolStrip As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents lblAnimation As System.Windows.Forms.Label
    Friend WithEvents ToolStripSeparator6 As System.Windows.Forms.ToolStripSeparator
    Public WithEvents SettingsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents GradingSystemToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents MenuStrip As System.Windows.Forms.MenuStrip
    Public WithEvents StudentsToolStrip As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents EmployeeToolStrip As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents FinanceToolStrip As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents NewStudentRegistrationToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents ManageStudentsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents EmployeeRegistration As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents ReportToolStrip As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents ViewStudentProfileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents AccountReportToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents SearchStudentToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents PaymentsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents HelpToolStrip As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents AboutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents JecmasSolutionsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents UtilitiesToolStrip As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents ChangePasswordToolStrip As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents SystemToolStrip As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents LogOffToolStrip As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents ExitToolStrip As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents RecordsToolStrip As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents FeesPaymentRecordTooStrip As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents SalaryPaymentRecordTooStrip As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents OtherFeesHistoryToolStrip As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents CreateNewUserToolStrip As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents PasswordRecoveryToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents StaffReportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents RegisteredStaffToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents RegisteredStaffDeptToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents StudentsReportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents AllRegisteredStudentsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents RegisteredStudentByDepartmentToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents EmployeeDesignation As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Public WithEvents AcademicToolStrip As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents CheckPaymentsToolStrip As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Public WithEvents TermlyAssessmentToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents ToolStripSeparator7 As System.Windows.Forms.ToolStripSeparator
    Public WithEvents ManageStudentProfileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents OptionToolStrip As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents SchoolInfoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents ToolStripStatusLabel2 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel3 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents lblDateTime As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents Timer2 As System.Windows.Forms.Timer
    Friend WithEvents BillingToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TerminalBillToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AcademicYearToolStrip As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GradingSystemToolStrip As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StaffReToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolsToolStrip As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CalculatorToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MicrosoftWordToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AcademicRecordsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator10 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents TermlySchoolFeesPaidToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TermlyBusFeesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MonthlyExpenditureOnStaffToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TermlyExpenditureOnStaffToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents YearlyExpenditureOnStaffToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StuudentsArrearsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ListsOfActiveStudentsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ListsOfInactiveStudentsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ListOfActiveStaffToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ListOfInactiveStaffToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ActiveRegisteredStudentsByClassToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SubjectsToolStrip As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GenerateTerminalBillToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripStatusLabel4 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel1 As System.Windows.Forms.ToolStripStatusLabel
    Public WithEvents JobProfileMastery As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents EmployeeProfileMastery As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents EmployeeAttendanceRegister As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EmployeeInfoSheet As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents ToolStripSeparator11 As System.Windows.Forms.ToolStripSeparator
    Public WithEvents ToolStripSeparator12 As System.Windows.Forms.ToolStripSeparator
    Public WithEvents SBAToolStrip As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TSAToolStrip As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents TerminalReportToolStrip As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ClassRoomToolStrip As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FeesToolStrip As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AttendanceToolStrip As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ClassTeacherAssignmentToolStrip As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents StudentAttendanceToolStrip As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents DesignationToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BillSettingsToolStrip As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LockToolStrip As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SalaryPaymentToolStrip As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PaymentModeToolStrip As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OtherFeesPaymentsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents lblUserType As System.Windows.Forms.ToolStripStatusLabel
    Public WithEvents lblUser As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents OtherFeesSettingsToolStrip As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents IDCardGeneratorToolStrip As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StudentsIDToolStrip As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EmployeeIDToolStrip As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator5 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator9 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator13 As System.Windows.Forms.ToolStripSeparator
    Public WithEvents UseMaintenanceToolstrip As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents AccountSettingsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AppointmentTypeToolStrip As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PortfolioToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SystemSettingsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EmployeeLeaveApplicationToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ApplyForLeaveToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ApproveLeaveToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CheckSchFeesPaidToolStrip As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CheckOtherFeesPaidToolStrip As System.Windows.Forms.ToolStripMenuItem

End Class
