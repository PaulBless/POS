﻿Imports System.Data.SqlClient

Public Class frmTerminalReport
    'variable to hold student info
    Dim sid As Integer
    Dim sname As String
    Dim sclass As String

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtSID.Clear()
        txtRegNo.Clear()
        cboYear.ResetText()
        cboTerm.ResetText()
        txtName.Clear()
        txtClass.Clear()
        txtTerm.Clear()
        txtYear.Clear()
        dtpDate.Text = Now
        dtpNextTermBegins.Text = Now
    End Sub

    Private Sub btnGenerate_Click(sender As Object, e As EventArgs) Handles btnGenerate.Click
        If txtRegNo.Text = "" Then MsgBox("Invalid Student Registration No, Please check..", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "SIMS") : Exit Sub
        If cboYear.Text = "" Then MsgBox("Please specify academic year", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "SIMS") : Exit Sub
        If cboTerm.Text = "" Then MsgBox("Please specify term", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "SIMS") : Exit Sub

        Try
            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            com = New SqlCommand("select Year,Term,Subject,ClassScore,ExamScore,Total,Position from SBA where SID='" & sid & "' AND Year='" & cboYear.Text & "' AND Term='" & cboTerm.Text & "'", ConnectionModule.con)
            dr = com.ExecuteReader(CommandBehavior.CloseConnection)
            dgv.Rows.Clear()
            If (dr.Read()) Then
                txtName.Text = sname
                txtClass.Text = sclass
                txtYear.Text = dr.GetValue(0)
                txtTerm.Text = dr.GetValue(1)
                dgv.Rows.Add(dr.GetValue(2), dr.GetValue(3), dr.GetValue(4), dr.GetValue(5), dr.GetValue(6))
            Else
                MessageBox.Show("The search criteria did not match any record, Please check", "Record Not Found", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
            com.Dispose()

        Catch ex As Exception
            MsgBox(ex.ToString())
            con.Close()
        End Try
       
    End Sub

    Private Sub frmTerminalReport_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ActiveControl = txtRegNo
    End Sub

  Public Sub AddAcademicYear()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            dset = New Data.DataSet()
            adapter = New SqlDataAdapter()
            adapter.SelectCommand = New SqlCommand("select ID,New from AcademicYear order by New", ConnectionModule.con)
            dset.Clear()
            adapter.Fill(dset, "AcademicYear")
            cboYear.DataSource = dset.Tables("AcademicYear")
            cboYear.DisplayMember = "New"
            cboYear.ValueMember = "ID"
            cboYear.Refresh()
            cboYear.SelectedIndex = -1
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at add academic info")
            con.Close()
        End Try
    End Sub

    Public Sub AddTerm()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            dset = New Data.DataSet()
            adapter = New SqlDataAdapter()
            adapter.SelectCommand = New SqlCommand("select ID,Term from Term order by Term", ConnectionModule.con)
            dset.Clear()
            adapter.Fill(dset, "Term")
            cboTerm.DataSource = dset.Tables("Term")
            cboTerm.DisplayMember = "Term"
            cboTerm.ValueMember = "ID"
            cboTerm.Refresh()
            cboTerm.SelectedIndex = -1
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at add term info")
            con.Close()
        End Try
    End Sub

    Private Sub cboYear_DropDown(sender As Object, e As EventArgs) Handles cboYear.DropDown
        ''   AddAcademicYear()
        GetYear()
    End Sub

    Public Sub GetTerm()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            dset = New Data.DataSet()
            adapter = New SqlDataAdapter()
            adapter.SelectCommand = New SqlCommand("select distinct term from Session order by term asc", ConnectionModule.con)
            dset.Clear()
            adapter.Fill(dset, "Session")
            cboTerm.DataSource = dset.Tables("Session")
            cboTerm.DisplayMember = "Term"
            ''cboTerm.ValueMember = "ID"
            cboTerm.Refresh()
            cboTerm.SelectedIndex = -1
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at get academic year")
            con.Close()
        End Try
    End Sub
    Public Sub GetYear()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            dset = New Data.DataSet()
            adapter = New SqlDataAdapter()
            adapter.SelectCommand = New SqlCommand("select distinct Year from Session order by Year DESC", ConnectionModule.con)
            dset.Clear()
            adapter.Fill(dset, "Session")
            cboYear.DataSource = dset.Tables("Session")
            cboYear.DisplayMember = "Year"
            ''cboYear.ValueMember = "ID"
            cboYear.Refresh()
            cboYear.SelectedIndex = -1
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at get academic year")
            con.Close()
        End Try
    End Sub

    Private Sub cboTerm_DropDown(sender As Object, e As EventArgs) Handles cboTerm.DropDown
        ''AddTerm()
        GetTerm()
    End Sub

  
    Private Sub txtRegNo_TextChanged(sender As Object, e As EventArgs) Handles txtRegNo.TextChanged
        If txtRegNo.Text <> "" Then
            Try
                If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                ConnectionModule.con.Open()
                com = New SqlCommand("select * from Students where RegistrationNumber='" & Me.txtRegNo.Text & "'", ConnectionModule.con)
                dr = com.ExecuteReader(CommandBehavior.CloseConnection)
                If (dr.Read()) Then
                    txtSID.Text = dr.GetValue(0)
                    sid = dr.GetValue(0)
                    sname = dr.GetValue(2) + " " + dr.GetValue(3) + " " + dr.GetValue(4)
                    sclass = dr.GetValue(8)
                End If
                com.Dispose()

            Catch ex As Exception
                MsgBox(ex.Message)
                con.Close()
            End Try
        Else
            txtSID.Clear()
            txtRegNo.Clear()
        End If
    End Sub

    Private Sub txtAttendance_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtAttendance.KeyPress
        If Asc(e.KeyChar) <> 13 AndAlso Asc(e.KeyChar) <> 8 AndAlso Not IsNumeric(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub

    Private Sub txtTotalAttendance_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtTotalAttendance.KeyPress
        If Asc(e.KeyChar) <> 13 AndAlso Asc(e.KeyChar) <> 8 AndAlso Not IsNumeric(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub

    Private Sub txtTeacherRemarks_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtTeacherRemarks.KeyPress
        Select Case Asc(e.KeyChar)
            Case 8, 32, 65 To 90, 97 To 122
                e.Handled = False
            Case Else
                e.Handled = True
        End Select
    End Sub

    Private Sub txtHM_Signature_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtHM_Signature.KeyPress
        Select Case Asc(e.KeyChar)
            Case 8, 32, 65 To 90, 97 To 122
                e.Handled = False
            Case Else
                e.Handled = True
        End Select
    End Sub

    Private Sub txtInterest_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtInterest.KeyPress
        Select Case Asc(e.KeyChar)
            Case 8, 32, 65 To 90, 97 To 122
                e.Handled = False
            Case Else
                e.Handled = True
        End Select
    End Sub

    Private Sub txtAttitude_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtAttitude.KeyPress
        Select Case Asc(e.KeyChar)
            Case 8, 32, 65 To 90, 97 To 122
                e.Handled = False
            Case Else
                e.Handled = True
        End Select
    End Sub

    Private Sub txtConduct_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtConduct.KeyPress
        Select Case Asc(e.KeyChar)
            Case 8, 32, 65 To 90, 97 To 122
                e.Handled = False
            Case Else
                e.Handled = True
        End Select
    End Sub

   
    Private Sub btnPrint_Click(sender As Object, e As EventArgs) Handles btnPrint.Click
        If txtAttendance.Text = "" Then MsgBox("Specify student attendance made in term.", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "SIMS") : Exit Sub
        If txtTotalAttendance.Text = "" Then MsgBox("Specify total term attendance .", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "SIMS") : Exit Sub
        If txtAttitude.Text = "" Then MsgBox("Specify student attitude.", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "SIMS") : Exit Sub
        If txtInterest.Text = "" Then MsgBox("Specify student interest.", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "SIMS") : Exit Sub
        If txtConduct.Text = "" Then MsgBox("Specify student conduct.", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "SIMS") : Exit Sub
        If txtTeacherRemarks.Text = "" Then MsgBox("Provide remarks of class teacher.", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "SIMS") : Exit Sub

        Try

        Catch ex As Exception

        End Try
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub
End Class