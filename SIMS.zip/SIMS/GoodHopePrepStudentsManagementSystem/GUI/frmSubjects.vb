﻿Imports System.Data.SqlClient

Public Class frmSubjects
    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        If txtSubject.Text = "" Then MsgBox("Enter the subject name", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "SIMS Error") : Exit Sub
        If cboType.Text = "" Then MsgBox("Select the subject type", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "SIMS Error") : Exit Sub
        If MsgBox("Add new subject to the system, are you sure?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "Confirmation") = MsgBoxResult.Yes Then
            Try
                'check record exists
                If con.State = ConnectionState.Open Then con.Close()
                con.Open()
                com1 = New SqlCommand("select * from subjects where name='" & (txtSubject.Text) & "'", ConnectionModule.con)
                dr = com1.ExecuteReader(CommandBehavior.CloseConnection)
                If dr.Read() = True Then
                    dr.Close()
                    con.Close()
                    MsgBox("Record Exists.. Cannot save duplicate record..." + vbCrLf + "NB:- Please update the record..", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "SIMS") : Exit Sub
                Else
                    If con.State = ConnectionState.Open Then con.Close()
                    com1 = New SqlCommand("insert into subjects(name,type) values (@d1,@d2)", ConnectionModule.con)
                    com1.Parameters.Add("@d1", SqlDbType.NVarChar).Value = txtSubject.Text.Trim()
                    com1.Parameters.Add("@d2", SqlDbType.NVarChar).Value = cboType.Text
                    con.Open()
                    com1.ExecuteNonQuery()
                    MessageBox.Show("Subject successfully added.", "SIMS", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    com1.Dispose()  'dispose the command
                    con.Close()     'close the db connection
                    'clear controls
                    txtID.Clear()
                    txtSubject.Clear()
                    cboType.ResetText()
                    FetchSubjects()
                    btnSave.Enabled = True
                    btnDelete.Enabled = False
                    btnUpdate.Enabled = False
                End If

            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End If

    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        If txtID.Text = String.Empty Then MsgBox("Invalid record selection, check..", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "SIMS Error") : Exit Sub
        Try
            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            com1 = New SqlCommand("update subjects set name=@d1, type=@d2 where ID='" & dgv.SelectedRows(0).Cells(0).Value & "'", con)
            com1.Parameters.Add("@d1", SqlDbType.NVarChar).Value = txtSubject.Text
            com1.Parameters.Add("@d2", SqlDbType.NVarChar).Value = cboType.Text
            com1.ExecuteNonQuery()
            MessageBox.Show("Successfully updated.", "SIMS", MessageBoxButtons.OK, MessageBoxIcon.Information)
            com1.Dispose()
            con.Close()
            'clear controls
            txtID.Clear()
            txtSubject.Clear()
            cboType.ResetText()
            FetchSubjects()
            btnSave.Enabled = True
            btnUpdate.Enabled = False
            btnDelete.Enabled = False
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Private Sub FetchSubjects()
        Try
            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            com1 = New SqlCommand("select * from subjects", ConnectionModule.con)
            dr = com1.ExecuteReader(CommandBehavior.CloseConnection)
            dgv.Rows.Clear()
            While dr.Read() = True
                dgv.Rows.Add(dr(0), dr(1), dr(2))
            End While
            'dr.Close()
            con.Close()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub dgv_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv.CellClick
        dgv.SelectAll()
    End Sub
    Private Sub dgv_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv.CellContentClick
        Try
            txtID.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(0).Value
            txtSubject.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(1).Value.ToString()
            cboType.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(2).Value.ToString()
            btnUpdate.Enabled = True
            btnDelete.Enabled = True
            btnSave.Enabled = False

        Catch ex As Exception

        End Try

    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        If txtID.Text = String.Empty Then MsgBox("Invalid record selection, check..", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "SIMS Error") : Exit Sub
        Try
            If MessageBox.Show("Delete selected subject ---'" + txtSubject.Text + "'---' from system." + vbCrLf + "Continue?", "Confirmation", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) + MessageBoxOptions.RightAlign = DialogResult.OK Then
                If con.State = ConnectionState.Open Then con.Close()
                con.Open()
                com1 = New SqlCommand("delete from subjects where ID='" & dgv.SelectedRows(0).Cells(0).Value & "'", ConnectionModule.con)
                com1.ExecuteNonQuery()
                MessageBox.Show("Record deleted successfully.", "SIMS", MessageBoxButtons.OK, MessageBoxIcon.Information)
                com1.Dispose()
                con.Close()
                'clear controls
                txtID.Clear()
                txtSubject.Clear()
                cboType.ResetText()
                FetchSubjects()
                btnSave.Enabled = True
                btnUpdate.Enabled = False
                btnDelete.Enabled = False
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub dgv_CellClick(sender As Object, e As EventArgs) Handles dgv.CellClick
        dgv.SelectAll()
    End Sub

    Private Sub frmSubjects_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        FetchSubjects()
    End Sub
End Class