﻿Imports System.Data.SqlClient

Public Class frmInactiveEntry

    Dim Status As String

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub

    Private Sub btnGetFee_Click(sender As Object, e As EventArgs) Handles btnGetFee.Click
        dgvinfo.Rows.Clear()
        If Len(Trim(cboClass.Text)) = 0 Then
            MessageBox.Show("Please select class", "", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            cboClass.Focus()
            Exit Sub
        End If

        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()

            Dim cmd As SqlCommand = New SqlCommand("select * from Students where Class='" & Me.cboClass.Text & "'", ConnectionModule.con)
            Dim reader As SqlDataReader = cmd.ExecuteReader(CommandBehavior.CloseConnection)

            If (reader.Read()) Then
                dgvinfo.Rows.Add(reader(1).ToString, reader(2).ToString() + " " + reader(3).ToString() + " " + reader(4).ToString(), reader(25).ToString())
            End If
            cmd.Dispose()

        Catch ex As Exception
            MsgBox(ex.Message)
            con.Close()
        End Try
    End Sub

    Private Sub btnInactive_Click(sender As Object, e As EventArgs) Handles btnInactive.Click
        If dgvinfo.Rows.Count < 1 Then
            MsgBox("Sorry! No information to be updated. Search for student info first.", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "SIMS") : Exit Sub
        End If

        If cmbReason.Text = "" Then
            MsgBox("Please select reason for deactivating student", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "SIMS")
            Exit Sub
        End If

        Try
            For Each r As DataGridViewRow In dgvinfo.Rows
                If r.Selected = True Then
                    Status = "INACTIVE"
                Else
                    Status = "ACTIVE"
                End If

                If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                ConnectionModule.con.Open()

                Dim cmd As SqlCommand = New SqlCommand("update Students set Status='" & Status & "' where RegistrationNumber='" & dgvinfo.SelectedRows(0).Cells(0).Value & "'", ConnectionModule.con)
                cmd.ExecuteNonQuery()

                MsgBox("Student Status Updated Successfully!", MsgBoxStyle.OkOnly + MsgBoxStyle.Information, "SIMS")
                ClearForm()

            Next
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.OkOnly + MsgBoxStyle.Exclamation, "SIMS")
        End Try

    End Sub

    Sub ClearForm()
        cboClass.ResetText()
        cmbReason.ResetText()
        dgvinfo.Rows.Clear()
    End Sub

    Private Sub dgvinfo_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvinfo.CellContentClick
        dgvinfo.SelectAll()
    End Sub

    Private Sub cboClass_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboClass.SelectedIndexChanged
        dgvinfo.Rows.Clear()
    End Sub
End Class