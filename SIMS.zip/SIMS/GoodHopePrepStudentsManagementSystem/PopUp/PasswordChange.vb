﻿Imports System.Data.SqlClient

Public Class PasswordChange
    
   Private Sub PasswordChange_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'pass the username to the username textbox of the change password form
        Me.TextBoxUN.Text = LogUName
        'Me.Text = Me.Text + "- [Current User: " + LogName + "]"

    End Sub

    Private Sub TextBoxUN_Click(sender As Object, e As EventArgs)
        Enabled = False
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        Dim opwd As String = EncryptNew(TextBoxOldPass.Text)    'encrypt old password for checking
        Dim epwd As String = EncryptNew(TextBoxConfirmNewPass.Text) 'encrypt new password before saving into db

        If (TextBoxOldPass.Text = "") Then
            MessageBox.Show("Old password is required", "Error", MessageBoxButtons.OK)
            TextBoxOldPass.Focus()
            Exit Sub
        ElseIf TextBoxNewPass.Text = "" Then
            MessageBox.Show("New password is required", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information)
            TextBoxNewPass.Focus()
            Exit Sub
        ElseIf TextBoxConfirmNewPass.Text = "" Then
            MessageBox.Show("Confirm new password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information)
            TextBoxConfirmNewPass.Focus()
            Exit Sub
        ElseIf TextBoxNewPass.TextLength < 6 Then
            MessageBox.Show("Password lenght is weak. Should be atleast '6-characters long'", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            TextBoxNewPass.Focus()
            TextBoxNewPass.SelectAll()
            Exit Sub
        ElseIf (TextBoxNewPass.Text <> TextBoxConfirmNewPass.Text) Then
            MessageBox.Show("New password and Confirm passwords don't match. Check!!!", "Password Match Error ", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            TextBoxNewPass.SelectAll()
            TextBoxConfirmNewPass.SelectAll()
            TextBoxConfirmNewPass.Focus()
            Exit Sub
        ElseIf (TextBoxNewPass.Text = TextBoxOldPass.Text) Then
            MessageBox.Show("Old password and New password are the same. Please check", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            TextBoxNewPass.Focus()
            TextBoxNewPass.SelectAll()
            Exit Sub
        End If
        If TextBoxOldPass.Text <> LogUPass Then
            MsgBox("Old password is incorrect, please check..", MsgBoxStyle.Exclamation, "SMIS")
            TextBoxOldPass.SelectAll()
            Exit Sub
        End If
        Try
            Dim dlg As DialogResult = MessageBox.Show("Are you sure you want to change your password?", "Confirm Password Change", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1)
            If dlg = Windows.Forms.DialogResult.Yes Then
                Try
                    If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                    ConnectionModule.con.Open()
                    com = New SqlCommand("UPDATE Users SET Password=@Password WHERE Username= '" & TextBoxUN.Text & "' ", ConnectionModule.con)
                    com.Parameters.AddWithValue("@Password", TextBoxConfirmNewPass.Text)
                    com.ExecuteNonQuery()
                    MessageBox.Show("Successfully changed password! New Password is: " + TextBoxConfirmNewPass.Text.ToString, "Success", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1)
                    com.Dispose()
                    Reset()
                Catch ex As Exception
                    MessageBox.Show("Error, password change unsuccessful!", "Password Change Failed", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    con.Close()
                End Try
            End If
        Catch ex As Exception

        End Try


    End Sub

    Sub Reset()
        TextBoxNewPass.Clear()
        TextBoxConfirmNewPass.Clear()
        '  TextBoxUN.Clear()
        TextBoxOldPass.Clear()
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        Reset()
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub
End Class