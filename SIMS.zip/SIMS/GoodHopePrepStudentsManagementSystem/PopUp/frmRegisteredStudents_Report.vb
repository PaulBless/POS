﻿Public Class frmRegisteredStudents_Report

    Private Sub frmRegisteredStudents_Report_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        'Me.ReportViewer1.RefreshReport()
    End Sub
End Class