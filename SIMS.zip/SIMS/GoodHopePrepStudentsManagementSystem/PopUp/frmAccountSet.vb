﻿Imports System.Data.SqlClient
Imports System.Security.Authentication.ExtendedProtection

Public Class frmAccountSet

    Private Sub GroupBox1_Enter(sender As Object, e As EventArgs) Handles GroupBox1.Enter

    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtUsername.Clear()
        txt_pass.Clear()
        Role.ResetText()
        FillCombo()
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        If MsgBox("Are you sure you want to change this user's role", MsgBoxStyle.YesNo + MsgBoxStyle.Question, "Confirmation") = MsgBoxResult.Yes Then
            Try
                If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                ConnectionModule.con.Open()
                com1 = New SqlCommand("update Users set Role='" & Role.Text & "' where staffID='" & dgvinfo.SelectedRows(0).Cells(0).Value & "'", ConnectionModule.con)
                com1.ExecuteNonQuery()
                MsgBox("Successfully updated user's account.", MsgBoxStyle.OkOnly + MsgBoxStyle.Information, "SIMS")
                FillCombo()
                con.Close()
            Catch ex As Exception
                MsgBox(ex.ToString())
            End Try
        End If

    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub

    Private Sub GroupBox3_Enter(sender As Object, e As EventArgs) Handles GroupBox3.Enter

    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        If txt_pass.Text <> String.Empty Then
            If CheckBox1.CheckState = CheckState.Checked Then
                txt_pass.UseSystemPasswordChar = False
                CheckBox1.Text = "Hide"
                Exit Sub
            End If
            If CheckBox1.CheckState = CheckState.Unchecked Then
                txt_pass.UseSystemPasswordChar = True
                CheckBox1.Text = "Show"
                Exit Sub
            End If

        End If
    End Sub

    Private Sub Label5_Click(sender As Object, e As EventArgs) Handles Label5.Click

    End Sub

    Sub FillCombo()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            'ds = New DataSet()
            'adap = New SqlDataAdapter()
            'ds.Clear()
            'adap.SelectCommand = New SqlCommand("SELECT Staff.StaffID, RTRIM(Staff.FirstName + ' '+ Staff.MiddleName + ' ' + Staff.LastName) as Name, Users.Username, Users.Password, Users.Role FROM Staff INNER JOIN Users ON Staff.StaffID = Users.staffID", con)
            'adap.Fill(ds, "vwLogin")
            'dgvinfo.DataSource = ds.Tables("vwLogin")
            'dgvinfo.Refresh()

            com1 = New SqlCommand("SELECT Staff.StaffID, RTRIM(Staff.FirstName + ' '+ Staff.MiddleName + ' ' + Staff.LastName) as Name, Users.Username, Users.Password, Users.Role FROM Staff INNER JOIN Users ON Staff.StaffID = Users.staffID", con)
            dr = com1.ExecuteReader()
            '  If dr.Read() Then
            While dr.Read()
                dgvinfo.Rows.Add(dr(0), dr(1).ToString(), dr(2), dr(3), dr(4))
            End While
            '  End If
            dr.Close()

        Catch ex As Exception
            MsgBox(ex.ToString(), MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "at fill staffname")
            con.Close()
        End Try
    End Sub


    Private Sub frmAccountSet_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        FillCombo()
    End Sub

    Private Sub dgvinfo_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvinfo.CellContentClick
        Try
            txtUsername.Text = dgvinfo.Rows(dgvinfo.CurrentRow.Index).Cells(2).Value
            txt_pass.Text = dgvinfo.Rows(dgvinfo.CurrentRow.Index).Cells(3).Value
            Role.Text = dgvinfo.Rows(dgvinfo.CurrentRow.Index).Cells(4).Value

        Catch ex As Exception

        End Try
       
    End Sub
End Class