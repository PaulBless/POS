﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Web.UI

Public Class CreateEmployeeUser

    Private Sub CreateEmployeeUser_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'invoke method to load records into grid
        GetData()
        'set activecontrol
        ActiveControl = txtName

    End Sub

    Private Sub btn_cancel_Click(sender As Object, e As EventArgs)
        'close this form
        Me.Close()
    End Sub
    
    Sub FillCombo()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            dset = New DataSet()
            adapter = New SqlDataAdapter()
            dset.Clear()
            adapter.SelectCommand = New SqlCommand("select StaffID, (FirstName + ' ' + MiddleName + ' ' + LastName) as StaffName from Staff order by StaffID Desc", ConnectionModule.con)
            adapter.Fill(dset, "Staff")
            SName.DataSource = dset.Tables("Staff")
            SName.DisplayMember = "StaffName"
            SName.ValueMember = "StaffID"
            SName.SelectedIndex = -1

        Catch ex As Exception
            MsgBox(ex.ToString(), MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "at fill staffname")
            con.Close()
        End Try
    End Sub

    Sub ResetMe()
        txtName.Clear()
        txtID.Clear()
        txtContact.Clear()
        txtEmpId.Clear()
        cbogender.ResetText()
        txt_pass.Clear()
        txt_pass2.Clear()
        txtUsername.Clear()
        SName.ResetText()
        Role.ResetText()
        GetData()
    End Sub
    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        ResetMe()
    End Sub
    Private Sub GetDesignation()
        Try
            If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
            ConnectionModule.con.Open()
            dset = New Data.DataSet()
            adapter = New SqlDataAdapter()
            adapter.SelectCommand = New SqlCommand("select distinct desgname from designation1 order by desgname asc", ConnectionModule.con)
            dset.Clear()
            adapter.Fill(dset, "designation1")
            Role.DataSource = dset.Tables("designation1")
            Role.DisplayMember = "desgname"
            Role.Refresh()
            Role.SelectedIndex = -1
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "error at get desgination")
            con.Close()
        End Try
    End Sub


  Sub Register()
        'open db connection when closed
        If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
        ConnectionModule.con.Open()
        Try
            'encrypted entered password
            Dim epass As String = txt_pass2.Text
            Dim spass As String = EncryptNew(epass)
            com = New SqlCommand("insert into users (staffID,Username,Password,Role,RegDate,Status) values(@staffID,@Username,@Password,@Role,@RegDate,@Status)", ConnectionModule.con)
            com.Parameters.AddWithValue("@staffID", Val(txtID.Text))
            com.Parameters.AddWithValue("@Username", txtUsername.Text)
            com.Parameters.AddWithValue("@Password", txt_pass2.Text)
            com.Parameters.AddWithValue("@Role", Role.SelectedItem)
            com.Parameters.AddWithValue("@RegDate", DateTime.Now)
            com.Parameters.AddWithValue("@Status", Status)
            com.ExecuteNonQuery()

            MsgBox("Registration Successful. Please remember to keep your username and password for future login" & vbCrLf & "Username: '" & txtUsername.Text & "'  Password: '" & txt_pass2.Text & "", MsgBoxStyle.OkOnly + MsgBoxStyle.Information, "Registration Successful")
            com.Dispose()
            ResetMe()
            btnSave.Enabled = False
        Catch ex As Exception
            MessageBox.Show("Error, Could not complete the request. " + ex.ToString(), "Operation Failed", MessageBoxButtons.OK, MessageBoxIcon.Error)
            con.Close()

        End Try
        'End If

    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
     If txtUsername.Text = "" Then
            MessageBox.Show("Enter user name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1)
            txtUsername.Focus()
            Exit Sub
        End If
        If txt_pass.Text = "" Then
            MessageBox.Show("Enter password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1)
            txt_pass.Focus()
            Exit Sub
        End If
        If txt_pass2.Text = "" Then
            MessageBox.Show("Re-type password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1)
            txt_pass2.Focus()
            Exit Sub
        End If
        If Role.Text = "" Then
            MessageBox.Show("Select user type or role", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1)
            Role.Focus()
            Exit Sub
        End If
        If txt_pass.Text <> txt_pass2.Text Then
            MessageBox.Show("Password and Re-type Password don't match. Please check", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1)
            txt_pass2.Focus()
            txt_pass2.SelectAll()
            Exit Sub
        End If
        If txt_pass.TextLength < 6 Then
            MessageBox.Show("The password length is too weak. Please check.." + vbCrLf + "Password should be at least '6-characters long'", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1)
            txt_pass.Focus()
            txt_pass.SelectAll()
            Exit Sub
        End If

        'ask for confirmation
        If MessageBox.Show("Do you really want to register '--" + txtName.Text + "--' as new system user?" + vbCrLf + "Continue..", "Registration Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.Yes Then
            Try
                If ConnectionModule.con.State = ConnectionState.Open Then ConnectionModule.con.Close()
                ConnectionModule.con.Open()
                com = New SqlCommand("select staffID from Users where staffID='" & Val(txtID.Text) & "'", ConnectionModule.con)
                dr = com.ExecuteReader()
                If Not dr.Read() = True Then
                    dr.Close()
                    Register()
                Else
                    MsgBox("The staff name : --'" + SName.Text + "'-- has already been registered as system user.. Account Exists", MsgBoxStyle.OkOnly + MsgBoxStyle.Critical, "Duplicate Found")
                End If
            Catch ex As Exception
                MessageBox.Show(ex.ToString(), "error at check")
            End Try
        End If
    End Sub

    Private Sub GroupBox3_Enter(sender As Object, e As EventArgs) Handles GroupBox3.Enter

    End Sub
    Private Sub GetData()
        Try
            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            query = "select staffid,staffcode,firstname + space(1) + middlename + space(1) + lastname as empname, gender, phonenumber from staff"
            com = New SqlCommand(query, con)
            dr = com.ExecuteReader()
            dgv.Rows.Clear()
            While dr.Read()
                dgv.Rows.Add(dr(0), dr(1), dr(2), dr(3), dr(4))
            End While
            dr.Close()
            con.Close()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Private Sub dgv_CellDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv.CellDoubleClick

    End Sub

    Private Sub dgv_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv.CellContentClick
        Try
            txtID.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(0).Value.ToString()
            txtEmpId.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(1).Value.ToString()
            txtName.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(2).Value.ToString()
            cbogender.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(3).Value.ToString()
            txtContact.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(4).Value.ToString()
            btnSave.Enabled = True
            btnGetData.Enabled = False
        Catch ex As Exception

        End Try
    End Sub

    Private Sub btnGetData_Click(sender As Object, e As EventArgs) Handles btnGetData.Click
        Try
            GetData()
        Catch ex As Exception
            MsgBox(ex.ToString())
        End Try
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub

    Private Sub Role_DropDown(sender As Object, e As EventArgs) Handles Role.DropDown
        GetDesignation()
    End Sub

    Private Sub Role_SelectedIndexChanged(sender As Object, e As EventArgs) Handles Role.SelectedIndexChanged

    End Sub

    Private Sub txtUsername_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtUsername.KeyPress
        Select Case Asc(e.KeyChar)
            Case 8, 32, 65 To 90, 97 To 122
                e.Handled = False
            Case Else
                e.Handled = True
        End Select
    End Sub

    Private Sub txtUsername_TextChanged(sender As Object, e As EventArgs) Handles txtUsername.TextChanged

    End Sub
End Class