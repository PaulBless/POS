﻿Imports System.Configuration
Imports System.Text.RegularExpressions.Match
Imports System.Globalization.CultureInfo
Imports System.Data.SqlClient
Imports System.DirectoryServices

Module NumberConversionFunction
    ' Public Function AmountToWords(ByVal MyNumber)
    '    Dim temp
    '    Dim Num, Digits As String
    '    Dim DecimalPlace, iCount
    '    Dim Hundreds, Words As String
    '    Dim place(9) As String
    '    place(0) = "Thousand"
    '    place(2) = "Hundred"
    '    place(4) = ""
    '    place(6) = ""
    '    place(8) = ""
    '    On Error Resume Next

    '    'convert mynumber to string, trimming all spaces
    '    MyNumber = Trim(Str(MyNumber))
    '    'find decimal place within amount
    '    DecimalPlace = InStr(MyNumber, ".")
    '    If (DecimalPlace > 0) Then
    '        'convert digits
    '        temp = Left(Mid(MyNumber), DecimalPlace + 1) & "00", 2)
    '        Digits = " and " & ConvertTens(temp)

    '    End If

    'End Function

    'Private Function IIf(ByVal d As Double) As Boolean
    '    Throw New NotImplementedException()
    'End Function
End Module
