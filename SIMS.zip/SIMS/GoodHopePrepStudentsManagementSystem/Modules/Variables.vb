﻿Imports System.Data.SqlClient
Imports System.Globalization
Imports System.IO


Module Variables

    'public variables to instantiate sql classes
    Public com, com1 As SqlCommand
    Public dr As SqlDataReader
    Public adapter As SqlDataAdapter
    Public dset As Data.DataSet
    Public table As System.Data.DataTable

    'variables for processing images
    Public image() As Byte
    Public myStream As New MemoryStream

    Public SearchId As Integer = 0 'this retrieve id of any search record
    Public RegID As String       'new registration id
    Public query As String       'variable for all sql statements/queries
    Public value As Boolean = False
    Public rowno As Integer
    Public Status As String = "ACTIVE"      'this is the status of new client account
    Public month As String = DateTime.Now.Month     'this will be used to save the month of transaction

    'variables to generate auto id
    Public mydt As DateTime = DateTime.Now
    Public dtInfo As DateTimeFormatInfo = DateTimeFormatInfo.InvariantInfo
    Public myday As String = "dd"
    Public mymonth As String = "MM"
    Public myyear As String = "yyyy"
    Public mydtID As String
    Public newID As Integer

    'public property to hold logon user info
    'this record will be referenced in the main form and other forms
    Public Property LogName As String 'this property holds user fullname
    Public Property LogURole As String  'this property holds user type
    Public Property LogUName As String   'this holds username
    Public Property LogUid As Integer      'this holds userid
    Public Property LogUPass As String 'this hold password
    Public Property UserStatus As String    'this will hold the current status of user
End Module
