﻿Module Activities
    Public Sub AllUserActivities(ByVal st1 As String, ByVal st2 As String)

    End Sub
    Public Sub LogFunction(ByVal ms As String, ByVal ms1 As String)

    End Sub
End Module
