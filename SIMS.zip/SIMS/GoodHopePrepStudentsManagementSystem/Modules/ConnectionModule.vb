﻿Imports System.Data.Sql
Imports System.Data.SqlClient
Module ConnectionModule
    'Data Source=.\SQLEXPRESS; Initial Catalog=dbSIMS; Integrated Security=True
    'Public con As SqlConnection = New SqlConnection("Data Source=Preacher;Initial Catalog=dbSIMS;Integrated Security=True")
    Public con As SqlConnection = New SqlConnection("Data Source=.\;Initial Catalog=dbSIMS;Integrated Security=True")

End Module
