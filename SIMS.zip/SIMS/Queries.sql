﻿use dbSIMS

select id, registrationnumber,firstname + SPACE(1) + middlename + SPACE(1) + lastname as name, gender,nationality,department,class from Students where RegistrationNumber =RegistrationNumber

CREATE TABLE [dbo].[FeesPayment] (
    [fpid] INT IDENTITY (1, 1) NOT NULL,
	[PaymentId] as ('FPID/'+right('000'+CONVERT([varchar](4),[fpid],(0)),(4))) PERSISTED,
    [StudID] INT  not null,
	[FeeAmount] real null,
	[AcaYear] NVARCHAR(50) null,
    [Term] nvarchar(50) NULL,
	[PaymentDate] date null,
	[PaymentMode] nvarchar(50) null,
	[PayeeName] nvarchar(500) null,
	[PayeeTel] nvarchar(20) null
    CONSTRAINT [PK_FeesPayment] PRIMARY KEY CLUSTERED ([fpid] ASC)
);

